// Fill out your copyright notice in the Description page of Project Settings.

using UnrealBuildTool;

public class FPSProjectEditor : ModuleRules
{
	public FPSProjectEditor(ReadOnlyTargetRules Target) : base(Target)
	{
		string engine_path = System.IO.Path.GetFullPath(Target.RelativeEnginePath);

		//System.Diagnostics.Debug.WriteLine("++++++ ENGINE PATH: " + engine_path);

		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(new string[] { "Core", "CoreUObject", "Engine", "InputCore", "SQLite3UE4Plugin", "Json", "JsonUtilities" });
        
        PublicIncludePaths.AddRange(new string[] {
			"FPSProjectEditor/Public",
			//engine_path + "/Source/Editor/Kismet/Public"
			//engine_path + "/Source/Editor/DetailCustomizations/Public"
			engine_path + "/Source/Editor/PropertyEditor/Public",
			engine_path + "/Source/Editor/MergeActors/Public",
        });

		PrivateIncludePaths.AddRange(new string[] {
			"FPSProjectEditor/Private",
			//engine_path + "/Source/Editor/DetailCustomizations/Private"
			engine_path + "/Source/Editor/PropertyEditor/Private",
			engine_path + "/Source/Editor/MergeActors/Private",
			//engine_path + "/Source/Editor/Kismet/Private"
		});

		PublicDependencyModuleNames.AddRange(new string[] { "FPSProject" });

		PrivateDependencyModuleNames.AddRange(new string[] {
			"Engine",
			"Slate",
			"SlateCore",
			"ApplicationCore",
			"EditorStyle",
			"Kismet",
			"PropertyEditor",
			"SlateCore",
			"EditorWidgets",
			"KismetWidgets",
			"UnrealEd",
            "AssetTools",
			//"DetailCustomizations"
            "SQLite3UE4Plugin",
            "MergeActors",
        });
		//PrivateDependencyModuleNames.AddRange(new string[] { "UnrealEd" });
		PrivateIncludePathModuleNames.AddRange(new string[] {
			"Engine",
			"Kismet",
			"PropertyEditor",
            "AssetTools",
            "MergeActors",
            "MeshMergeUtilities",
            "MeshUtilities",
            "LevelEditor",
			//"DetailCustomizations",
		});
		DynamicallyLoadedModuleNames.AddRange(new string[] { });
	}
}