#pragma once

#include "AssetTypeActions_Base.h"

#include "CoreMinimal.h"
#include "LevelEditor.h"

#include "Kismet/BlueprintFunctionLibrary.h"
#include "Editor/UnrealEd/Public/Kismet2/KismetEditorUtilities.h"
#include "Editor/UnrealEd/Public/Toolkits/AssetEditorManager.h"
#include "Editor/KismetCompiler/Public/KismetCompilerModule.h"
#include "AssetRegistryModule.h"
#include "Engine/EngineTypes.h"
#include "Engine/StaticMeshActor.h"
#include "Runtime/Engine/Classes/Engine/SimpleConstructionScript.h"
#include "Runtime/Engine/Classes/Engine/SCS_Node.h"
#include <Editor\UnrealEd\Public\ComponentAssetBroker.h>
#include "SQLiteDatabase.h"
#include <Runtime/Core/Public/GenericPlatform/GenericPlatformFile.h>
#include <Runtime/Core/Public/HAL/PlatformFilemanager.h>
#include <Runtime\Core\Public\Misc\FileHelper.h>

#include <Editor\MergeActors\Private\MeshMergingTool\MeshMergingTool.h>
#include "Engine/MeshMerging.h"
#include <Editor\MergeActors\Public\IMergeActorsTool.h>
#include "Editor/MergeActors/Private/MergeProxyUtils/Utils.h"
#include "Editor/MergeActors/Public/IMergeActorsModule.h"
#include "Editor/MergeActors/Public/IMergeActorsTool.h"
#include "Editor/ContentBrowser/Public/ContentBrowserModule.h"
#include "Developer/MeshMergeUtilities/Public/MeshMergeModule.h"
#include "Runtime/Engine/Classes/Engine/Selection.h"
#include "Runtime/Core/Public/Misc/ScopedSlowTask.h"
#include "Editor/UnrealEd/Public/ScopedTransaction.h"
#include "Editor/ContentBrowser/Public/IContentBrowserSingleton.h"
#include "Runtime/Core/Public/Templates/SharedPointer.h"

#include "Runtime/JsonUtilities/Public/JsonObjectConverter.h"

#include "CreateSMAAssetTypeActions.generated.h"
//
///** Singleton wrapper to allow for using the setting structure in SSettingsView */
//UCLASS(config = Engine)
//class UMOTHMeshMergingSettingsObject : public UObject
//{
//	GENERATED_BODY()
//public:
//	UMOTHMeshMergingSettingsObject()
//	{
//		Settings.bMergePhysicsData = true;
//		// In this case set to AllLODs value since calculating the LODs is not possible and thus disabled in the UI
//		Settings.LODSelectionType = EMeshLODSelectionType::AllLODs;
//	}
//
//	static UMOTHMeshMergingSettingsObject* Get()
//	{
//		static bool bInitialized = false;
//		// This is a singleton, use default object
//		UMOTHMeshMergingSettingsObject* DefaultSettings = GetMutableDefault<UMOTHMeshMergingSettingsObject>();
//
//		if (!bInitialized)
//		{
//			bInitialized = true;
//		}
//
//		return DefaultSettings;
//	}
//
//public:
//	UPROPERTY(editanywhere, meta = (ShowOnlyInnerProperties), Category = MergeSettings)
//		FMeshMergingSettings Settings;
//};

class FCreateSMAAssetTypeActions : public FAssetTypeActions_Base
{
public:
	FCreateSMAAssetTypeActions(EAssetTypeCategories::Type InAssetCategory);

	// IAssetTypeActions interface
	virtual FText GetName() const override;
	virtual UClass* GetSupportedClass() const override;
	virtual uint32 GetCategories() override;
	virtual FColor GetTypeColor() const override;

	virtual bool IsImportedAsset() const override
	{
		return true;
	}

	/** Collects the resolved source paths for the imported assets */
	virtual void GetResolvedSourceFilePaths(const TArray<UObject*>& TypeAssets, TArray<FString>& OutSourceFilePaths) const override;

	// End of IAssetTypeActions interface

private:
	EAssetTypeCategories::Type MyAssetCategory;
};

/**
 * Mesh Merging Tool
 */
class FMOTHMeshMergingTool// : public IMergeActorsTool
{
public:

	FMOTHMeshMergingTool();

	// IMergeActorsTool interface
	//TSharedRef<SWidget> GetWidget();
	//FName GetIconName() const { return "MergeActors.MeshMergingTool"; }
	//FText GetTooltipText() const;
	FString GetDefaultPackageName() const;
	//bool CanMerge() const;
	//bool RunMerge(const FString& PackageName);

	bool RunMergeWithArgs();

	//private:
		/** Whether to replace source actors with a merged actor in the world */
	bool bReplaceSourceActors;

	/** Pointer to the mesh merging dialog containing settings for the merge */
	//TSharedPtr<SMeshMergingDialog> MergingDialog;

	/** Pointer to singleton settings object */
	//UMOTHMeshMergingSettingsObject* SettingsObject;

	//UPROPERTY(editanywhere, meta = (ShowOnlyInnerProperties), Category = MergeSettings)
		//FMeshMergingSettings Settings;
};

class FEditorUIExtender {
public:
	void Extend();
	void Release();

private:
	FDelegateHandle LevelViewportExtenderHandle;
	TSharedPtr<class FExtender> LevelToolbarExtender;
};

UCLASS()
class UEditorCommon : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	static const FString DatabaseName;
	static const FString DatabasePath;
	static sqlite3* SqliteDatabase;

	UFUNCTION(BlueprintCallable, Category = "World") static void MOTHMergeActors()
	{
		/*IContentBrowserSingleton& ContentBrowserSingleton = FModuleManager::LoadModuleChecked<FContentBrowserModule>("ContentBrowser").Get();
		TArray<FString> SelectedFolders;
		ContentBrowserSingleton.GetSelectedPathViewFolders(SelectedFolders);
		FString AssetFolder = SelectedFolders.Num() > 0 ? SelectedFolders[0] : "/Game";
		FString AssetPath = AssetFolder + "/" + "TEST_merge";

		FString PackageName, AssetName;
		IAssetTools& AssetTools = FModuleManager::Get().LoadModuleChecked<FAssetToolsModule>("AssetTools").Get();
		AssetTools.CreateUniqueAssetName(*AssetPath, TEXT(""), PackageName, AssetName);*/
		/*T* AssetObject = Cast<T>(AssetTools.CreateAsset(AssetName, AssetFolder, T::StaticClass(), nullptr));
		if (AssetObject && bSyncBrowserToAsset) {
			ContentBrowserSingleton.SyncBrowserToAssets(TArray<UObject*>({ AssetObject }));
		}
*/

		auto tool = MakeUnique<FMOTHMeshMergingTool>();
		//FMOTHMeshMergingTool tool;
		tool->bReplaceSourceActors = true;
		//tool->Settings.
		/*tool->Settings.SpecificLOD = 0;
		tool->Settings.LODSelectionType = EMeshLODSelectionType::AllLODs;
		tool->Settings.bMergePhysicsData = true;*/
		tool->RunMergeWithArgs();

		//FMeshMergingTool* tool = &FMeshMergingTool();

		//(&tool)->bReplaceSourceActors = true;

		//const IMeshMergeUtilities& MeshUtilities = FModuleManager::Get().LoadModuleChecked<IMeshMergeModule>("MeshMergeUtilities").GetUtilities();
	};

	UFUNCTION(BlueprintCallable, Category = "World") static void GenerateSurfaceEffects()
	{
		if (!USQLiteDatabase::IsDatabaseRegistered(UEditorCommon::DatabaseName))
		{
			if (!USQLiteDatabase::RegisterDatabase(UEditorCommon::DatabaseName, UEditorCommon::DatabasePath, true))
			{
				return;
			}
		}

		/*FString header = TEXT("{#}pragma once \
								\
								#include \"CoreMinimal.h\" \
								#include \"SurfaceEffectType.generated.h\" \
								\
								UENUM(BlueprintType) \
								enum class ESurfaceEffectType : uint8 \
								{ \
			");*/
		FString header = TEXT("");
		header = header.Append(TEXT("#pragma once\n"));
		header = header.Append(TEXT("\n"));
		header = header.Append(TEXT("#include \"CoreMinimal.h\"\n"));
		header = header.Append(TEXT("#include \"SurfaceEffectType.generated.h\"\n"));
		header = header.Append(TEXT("\n"));
		header = header.Append(TEXT("UENUM(BlueprintType)\n"));
		header = header.Append(TEXT("enum class ESurfaceEffectType : uint8\n"));
		header = header.Append(TEXT("{\n"));
		//header = header.Replace(TEXT("{#}"), TEXT("#"), ESearchCase::IgnoreCase);

		FString query = TEXT("select SurfaceEffectID, Name from SurfaceEffect order by Name");

		auto results = USQLiteDatabase::RunQueryAndGetResults(UEditorCommon::DatabaseName, query, UEditorCommon::SqliteDatabase);
		if (results.Success) {
			for (int i = 0; i < results.Results.Num(); i++) {
				auto SurfaceEffectID = (int)results.Results[i].Fields[0].IntValue;
				auto Name = results.Results[i].Fields[1].StringValue;
				auto cleaned = Name
					.Replace(TEXT("-"), TEXT(""), ESearchCase::IgnoreCase)
					.Replace(TEXT("  "), TEXT(" "), ESearchCase::IgnoreCase)
					.Replace(TEXT(" "), TEXT("_"), ESearchCase::IgnoreCase);

				auto fmt = FString::Printf(TEXT("\t%s = %i UMETA(DisplayName = \"%s\"), \n"), *cleaned, SurfaceEffectID, *Name);
				header = header.Append(fmt);
			}
		}

		header = header.Append(TEXT(" };"));

		USQLiteDatabase::CloseDatabase(UEditorCommon::SqliteDatabase);
		UEditorCommon::SqliteDatabase = NULL;

		auto dir = FPaths::ProjectDir() + FString("Source/FPSProject/Generated");
		UEditorCommon::SaveStringTextToFile(dir, FString(TEXT("SurfaceEffectType.h")), header);
	};

	UFUNCTION(BlueprintCallable, Category = "World") static void GenerateItemGroups()
	{
		if (!USQLiteDatabase::IsDatabaseRegistered(UEditorCommon::DatabaseName))
		{
			if (!USQLiteDatabase::RegisterDatabase(UEditorCommon::DatabaseName, UEditorCommon::DatabasePath, true))
			{
				return;
			}
		}

		FString header = TEXT("");
		header = header.Append(TEXT("#pragma once\n"));
		header = header.Append(TEXT("\n"));
		header = header.Append(TEXT("#include \"CoreMinimal.h\"\n"));
		header = header.Append(TEXT("#include \"ItemGroupType.generated.h\"\n"));
		header = header.Append(TEXT("\n"));
		header = header.Append(TEXT("UENUM(BlueprintType)\n"));
		header = header.Append(TEXT("enum class EItemGroupType : uint8\n"));
		header = header.Append(TEXT("{\n"));

		FString query = TEXT("select ItemGroupID, Name from ItemGroup order by Name");

		auto results = USQLiteDatabase::RunQueryAndGetResults(UEditorCommon::DatabaseName, query, UEditorCommon::SqliteDatabase);
		if (results.Success) {
			for (int i = 0; i < results.Results.Num(); i++) {
				auto ItemGroupID = (int)results.Results[i].Fields[0].IntValue;
				auto Name = results.Results[i].Fields[1].StringValue;
				auto cleaned = Name
					.Replace(TEXT("-"), TEXT(""), ESearchCase::IgnoreCase)
					.Replace(TEXT("  "), TEXT(" "), ESearchCase::IgnoreCase)
					.Replace(TEXT(" "), TEXT("_"), ESearchCase::IgnoreCase);

				auto fmt = FString::Printf(TEXT("\t%s = %i UMETA(DisplayName = \"%s\"), \n"), *cleaned, ItemGroupID, *Name);
				header = header.Append(fmt);
			}
		}

		header = header.Append(TEXT(" };"));

		USQLiteDatabase::CloseDatabase(UEditorCommon::SqliteDatabase);
		UEditorCommon::SqliteDatabase = NULL;

		auto dir = FPaths::ProjectDir() + FString("Source/FPSProject/Generated");
		UEditorCommon::SaveStringTextToFile(dir, FString(TEXT("ItemGroupType.h")), header);
	};

	UFUNCTION(BlueprintCallable, Category = "World") static void GenerateItemContainerMap()
	{
		if (!USQLiteDatabase::IsDatabaseRegistered(UEditorCommon::DatabaseName))
		{
			if (!USQLiteDatabase::RegisterDatabase(UEditorCommon::DatabaseName, UEditorCommon::DatabasePath, true))
			{
				return;
			}
		}

		FString header = TEXT("");
		header = header.Append(TEXT("#pragma once\n"));
		header = header.Append(TEXT("\n"));
		header = header.Append(TEXT("#include \"CoreMinimal.h\"\n"));
		header = header.Append(TEXT("#include \"ItemContainerMap.generated.h\"\n"));
		header = header.Append(TEXT("\n"));
		header = header.Append(TEXT("UENUM(BlueprintType)\n"));
		header = header.Append(TEXT("enum class EItemContainerMap : uint8\n"));
		header = header.Append(TEXT("{\n"));


		FString query = TEXT("select * from ( ");
		query = query.Append(TEXT("select 0 ItemContainerID, 'Unknown' Name "));
		query = query.Append(TEXT("union select ItemContainerID, Name from ItemContainer "));
		query = query.Append(TEXT(") "));
		query = query.Append(TEXT("order by case when ItemContainerID = 0 then 1 else 0 end desc, Name"));

		auto results = USQLiteDatabase::RunQueryAndGetResults(UEditorCommon::DatabaseName, query, UEditorCommon::SqliteDatabase);
		if (results.Success) {
			for (int i = 0; i < results.Results.Num(); i++) {
				auto ItemGroupID = (int)results.Results[i].Fields[0].IntValue;
				auto Name = results.Results[i].Fields[1].StringValue;
				auto cleaned = Name
					.Replace(TEXT("-"), TEXT(""), ESearchCase::IgnoreCase)
					.Replace(TEXT("  "), TEXT(" "), ESearchCase::IgnoreCase)
					.Replace(TEXT(" "), TEXT("_"), ESearchCase::IgnoreCase);

				auto fmt = FString::Printf(TEXT("\t%s = %i UMETA(DisplayName = \"%s\"), \n"), *cleaned, ItemGroupID, *Name);
				header = header.Append(fmt);
			}
		}

		header = header.Append(TEXT(" };"));

		USQLiteDatabase::CloseDatabase(UEditorCommon::SqliteDatabase);
		UEditorCommon::SqliteDatabase = NULL;

		auto dir = FPaths::ProjectDir() + FString("Source/FPSProject/Generated");
		UEditorCommon::SaveStringTextToFile(dir, FString(TEXT("ItemContainerMap.h")), header);
	};

	UFUNCTION(BlueprintCallable, Category = "World") static void GenerateItemDataTableJSON()
	{
		if (!USQLiteDatabase::IsDatabaseRegistered(UEditorCommon::DatabaseName))
		{
			if (!USQLiteDatabase::RegisterDatabase(UEditorCommon::DatabaseName, UEditorCommon::DatabasePath, true))
			{
				return;
			}
		}

		/*struct ItemDef {
			int ItemID;
			FString Name;
		};*/

		FString query = TEXT("select * from ( ");
		query = query.Append(TEXT("select 0 ItemID, 'Unknown' Name "));
		query = query.Append(TEXT("union select ItemID, Name from Item "));
		query = query.Append(TEXT(") "));
		query = query.Append(TEXT("order by case when ItemID = 0 then 1 else 0 end desc, Name"));

		TArray< TSharedPtr<FJsonValue> > ObjArray;

		auto results = USQLiteDatabase::RunQueryAndGetResults(UEditorCommon::DatabaseName, query, UEditorCommon::SqliteDatabase);
		if (results.Success) {
			for (int i = 0; i < results.Results.Num(); i++) {
				auto ItemID = (int)results.Results[i].Fields[0].IntValue;
				auto Name = results.Results[i].Fields[1].StringValue;

				/*auto item = ItemDef();
				item.ItemID = ItemID;
				item.Name = Name;*/
				//items.Add(item);

				TSharedPtr< FJsonObject > JsonObj = MakeShareable(new FJsonObject);

				JsonObj->SetNumberField("ItemID", ItemID);
				JsonObj->SetStringField("Name", Name);

				TSharedRef< FJsonValueObject > JsonValue = MakeShareable(new FJsonValueObject(JsonObj));
				ObjArray.Add(JsonValue);
			}
		}

		//TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());

		//JsonObject->SetArrayField("items", ObjArray);

		FString json;
		TSharedRef< TJsonWriter<> > Writer = TJsonWriterFactory<>::Create(&json);
		//FJsonSerializer::Serialize(JsonObject.ToSharedRef(), Writer);
		FJsonSerializer::Serialize(ObjArray, Writer);

		auto dir = FPaths::ProjectDir() + FString("Source/FPSProject/Generated");
		UEditorCommon::SaveStringTextToFile(dir, FString(TEXT("ItemDataTable.json")), json);
	};

	//UFUNCTION(BlueprintCallable, Category = "World") static void GenerateItemMap()
	//{
	//	if (!USQLiteDatabase::IsDatabaseRegistered(UEditorCommon::DatabaseName))
	//	{
	//		if (!USQLiteDatabase::RegisterDatabase(UEditorCommon::DatabaseName, UEditorCommon::DatabasePath, true))
	//		{
	//			return;
	//		}
	//	}

	//	FString header = TEXT("");
	//	header = header.Append(TEXT("#pragma once\n"));
	//	header = header.Append(TEXT("\n"));
	//	header = header.Append(TEXT("#include \"CoreMinimal.h\"\n"));
	//	header = header.Append(TEXT("#include \"ItemMap.generated.h\"\n"));
	//	header = header.Append(TEXT("\n"));
	//	header = header.Append(TEXT("UENUM(BlueprintType)\n"));
	//	header = header.Append(TEXT("enum class EItemMap : uint32\n"));
	//	header = header.Append(TEXT("{\n"));


	//	FString query = TEXT("select * from ( ");
	//	query = query.Append(TEXT("select 0 ItemID, 'Unknown' Name "));
	//	query = query.Append(TEXT("union select ItemID, Name from Item "));
	//	query = query.Append(TEXT(") "));
	//	query = query.Append(TEXT("order by case when ItemID = 0 then 1 else 0 end desc, Name"));

	//	auto results = USQLiteDatabase::RunQueryAndGetResults(UEditorCommon::DatabaseName, query, UEditorCommon::SqliteDatabase);
	//	if (results.Success) {
	//		for (int i = 0; i < results.Results.Num(); i++) {
	//			auto ItemGroupID = (int)results.Results[i].Fields[0].IntValue;
	//			auto Name = results.Results[i].Fields[1].StringValue;
	//			auto cleaned = Name
	//				.Replace(TEXT("-"), TEXT(""), ESearchCase::IgnoreCase)
	//				.Replace(TEXT("  "), TEXT(" "), ESearchCase::IgnoreCase)
	//				.Replace(TEXT(" "), TEXT("_"), ESearchCase::IgnoreCase);

	//			auto fmt = FString::Printf(TEXT("\t%s = %i UMETA(DisplayName = \"%s\"), \n"), *cleaned, ItemGroupID, *Name);
	//			header = header.Append(fmt);
	//		}
	//	}

	//	header = header.Append(TEXT(" };"));

	//	USQLiteDatabase::CloseDatabase(UEditorCommon::SqliteDatabase);
	//	UEditorCommon::SqliteDatabase = NULL;

	//	auto dir = FPaths::ProjectDir() + FString("Source/FPSProject/Generated");
	//	UEditorCommon::SaveStringTextToFile(dir, FString(TEXT("ItemMap.h")), header);
	//};

	static void SaveStringTextToFile(
		FString SaveDirectory,
		FString FileName,
		FString TextToSave
	) {
		//FString SaveDirectory = FString("C:/Path/To/My/Save/Directory");
		//FString FileName = FString("MyFileName.sav");
		//FString TextToSave = FString("Lorem ipsum");
		//bool AllowOverwriting = false;

		IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();

		// CreateDirectoryTree returns true if the destination
		// directory existed prior to call or has been created
		// during the call.
		if (PlatformFile.CreateDirectoryTree(*SaveDirectory))
		{
			// Get absolute file path
			FString AbsoluteFilePath = SaveDirectory + "/" + FileName;

			// Allow overwriting or file doesn't already exist
			//if (AllowOverwriting || !PlatformFile::FileExists(*AbsoluteFilePath))
			{
				FFileHelper::SaveStringToFile(TextToSave, *AbsoluteFilePath);
			}
		}
	}

	UFUNCTION(BlueprintCallable, Category = "World")
		static void CreateEditorBlueprint(UClass* SelectedClass, FString staticMeshPath, TArray<TSubclassOf<UActorComponent>> additionalActorComponents)
	{
		UClass* BlueprintClass = nullptr;
		UClass* BlueprintGeneratedClass = nullptr;

		int dot_index = 0;
		if (!staticMeshPath.FindLastChar('.', dot_index))
		{
			UE_LOG(LogTemp, Warning, TEXT("Invalid SM for SMABP `%s`"), *staticMeshPath);
			return;
		}
		auto OldPackageName = staticMeshPath.RightChop(dot_index + 1);
		auto PackageName = FString(TEXT("BP_")).Append(OldPackageName);
		//auto UserPackageName = staticMeshPath.Replace(*FString(PackageName).Append(TEXT(".")).Append(PackageName), *FString(NewPackageName).Append(TEXT(".")).Append(NewPackageName), ESearchCase::IgnoreCase);
		auto UserPackageName = staticMeshPath.Replace(*FString(OldPackageName).Append(TEXT(".")).Append(OldPackageName), *FString(PackageName), ESearchCase::IgnoreCase);

		//const FString PackageName = FPackageName::ObjectPathToPackageName(SaveObjectPath);

		IKismetCompilerInterface & KismetCompilerModule = FModuleManager::LoadModuleChecked<IKismetCompilerInterface>("KismetCompiler");
		KismetCompilerModule.GetBlueprintTypesForClass(SelectedClass, BlueprintClass, BlueprintGeneratedClass);

		if (!BlueprintGeneratedClass) {
			UE_LOG(LogTemp, Warning, TEXT("Not creating SMA actor `%s`"), *PackageName);
			return;
		}

		FString Name;
		FAssetToolsModule& AssetToolsModule = FModuleManager::LoadModuleChecked<FAssetToolsModule>("AssetTools");
		AssetToolsModule.Get().CreateUniqueAssetName(PackageName, TEXT(""), PackageName, Name);

		//auto fl = FPackageName::GetLongPackageAssetName(FullPath);

		//FString UserPackageName = PackageName; // FullPath.Replace(*FString(".").Append(Name), TEXT(""), ESearchCase::IgnoreCase);

		FName BPName(*FPackageName::GetLongPackageAssetName(UserPackageName));

		// Check if the user inputed a valid asset name, if they did not, give it the generated default name
		if (BPName == NAME_None)
		{
			// Use the defaults that were already generated.
			UserPackageName = PackageName;
			BPName = *Name;
		}

		// Then find/create it.
		UPackage* Package = CreatePackage(NULL, *UserPackageName);
		check(Package);

		check(SelectedClass);
		check(BlueprintGeneratedClass);

		UE_LOG(LogTemp, Warning, TEXT("Creating SMABP `%s`"), );

		// Create and init a new Blueprint
		UBlueprint* Blueprint = FKismetEditorUtilities::CreateBlueprint(SelectedClass, Package, BPName, BPTYPE_Normal, BlueprintClass, BlueprintGeneratedClass, FName("LevelEditorActions"));
		if (Blueprint)
		{
			// Notify the asset registry
			FAssetRegistryModule::AssetCreated(Blueprint);

			// Mark the package dirty...
			Package->MarkPackageDirty();

			AStaticMeshActor* sma = Cast<AStaticMeshActor>(Blueprint->GeneratedClass->GetDefaultObject());
			if (sma) {
				//sma->SetReplicates(true);
				if (staticMeshPath.Len() > 0) {
					UStaticMesh* mesh = Cast<UStaticMesh>(StaticLoadObject(UStaticMesh::StaticClass(), nullptr, *staticMeshPath));
					if (mesh) {
						sma->GetStaticMeshComponent()->SetStaticMesh(mesh);
					}
				}

				if (additionalActorComponents.Num() > 0)
				{
					TArray<UActorComponent*> components;
					for (auto path : additionalActorComponents)
					{
						auto cmp = path.Get();

						USCS_Node* NewNode = Blueprint->SimpleConstructionScript->CreateNode(cmp);
						// Assign the asset to the template
						FComponentAssetBrokerage::AssignAssetToComponent(NewNode->ComponentTemplate, Blueprint);

						// Add node to the SCS
						TArray<USCS_Node*> AllNodes = Blueprint->SimpleConstructionScript->GetAllNodes();
						USCS_Node* RootNode = AllNodes.Num() > 0 ? AllNodes[0] : NULL;
						if (!RootNode || (RootNode == Blueprint->SimpleConstructionScript->GetDefaultSceneRootNode()))
						{
							//New Root
							Blueprint->SimpleConstructionScript->AddNode(NewNode);
						}
						else
						{
							//Add as a child
							RootNode->AddChildNode(NewNode);
						}
					}

					// Recompile skeleton because of the new component(s) we added
					FKismetEditorUtilities::GenerateBlueprintSkeleton(Blueprint, true);
				}
			}

			FAssetEditorManager::Get().OpenEditorForAsset(Blueprint);
		}
	}
};
