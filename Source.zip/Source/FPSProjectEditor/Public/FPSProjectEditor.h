// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"

#include "Modules/ModuleInterface.h"
#include "Modules/ModuleManager.h"
#include "UnrealEd.h"

#include "IDetailCustomization.h"
#include "IPropertyTypeCustomization.h"

#include "DetailCategoryBuilder.h"
#include "DetailLayoutBuilder.h"

#include "IDetailChildrenBuilder.h"

#include "InputCoreTypes.h"
#include "EditorViewportClient.h"
#include "BlueprintEditorModule.h"
#include "ISCSEditorCustomization.h"

#include "Components/HierarchicalInstancedStaticMeshComponent.h"

#include "FPSProject.h"
#include "Presentation/PropertyEditor/PropertyEditor.h"
#include "PropertyHandleImpl.h"
#include "PropertyNode.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "WorldStaticMeshComponent.h"
#include "BuildingComponent.h"
#include "Engine/AssetManager.h"
#include "ComponentUtils.h"
#include "Engine/InheritableComponentHandler.h"
#include "LevelEditor.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "Framework/Commands/Commands.h"

#include "CreateSMAAssetTypeActions.h"

#include "ScopedTransaction.h"

//#include "Editor/DetailCustomizations/Private/DetailCustomizationsPrivatePCH.h"

class IPropertyHandle;
class IDetailChildrenBuilder;
class FStructOnScope;

DECLARE_LOG_CATEGORY_EXTERN(FPSProjectEditor, All, All)

//// Actions that can be invoked in the reference viewer
//class FInstanceEditorCommands : public TCommands<FInstanceEditorCommands>
//{
//public:
//	FInstanceEditorCommands();
//
//	// TCommands<> interface
//	virtual void RegisterCommands() override;
//	// End of TCommands<> interface
//
//	// Shows the reference viewer for the selected assets
//	TSharedPtr<FUICommandInfo> Copy;
//};


class FFPSProjectEditorModule : public IModuleInterface
{
public:
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	/*void AddMenuItems(FMenuBuilder& MenuBuilder)
	{
		MenuBuilder.AddMenuEntry(FInstanceEditorCommands::Get().Copy);
	}*/

	void AddMenuExtension(FMenuBuilder& builder);
	void TopMenuBuilderFunc(FMenuBuilder& TopMenuBuilder, const TArray<FString> SelectedPaths, UObject* na);

	FEditorUIExtender UIExtender;
};

class FFInstancedStaticMeshInstanceDataDetails : public IDetailCustomization
{
public:
	/** Makes a new instance of this detail layout class for a specific detail view requesting it */
	static TSharedRef<IDetailCustomization> MakeInstance();

	/** IDetailCustomization interface */
	virtual void CustomizeDetails(IDetailLayoutBuilder& DetailBuilder) override;

protected:
private:
};

class FBuildingComponentSCSEditorCustomization : public ISCSEditorCustomization
{
public:
	static TSharedRef<ISCSEditorCustomization> MakeInstance(TSharedRef< class IBlueprintEditor > InBlueprintEditor);

	static UInstancedStaticMeshComponent* CurrentComponent;

public:
	/** ISCSEditorCustomization interface */
	virtual bool HandleViewportClick(const TSharedRef<FEditorViewportClient>& InViewportClient, class FSceneView& InView, class HHitProxy* InHitProxy, FKey InKey, EInputEvent InEvent, uint32 InHitX, uint32 InHitY) override;
	virtual bool HandleViewportDrag(class USceneComponent* InComponentScene, class USceneComponent* InComponentTemplate, const FVector& InDeltaTranslation, const FRotator& InDeltaRotation, const FVector& InDeltaScale, const FVector& InPivot) override;
	virtual bool HandleGetWidgetLocation(class USceneComponent* InSceneComponent, FVector& OutWidgetLocation) override;
	virtual bool HandleGetWidgetTransform(class USceneComponent* InSceneComponent, FMatrix& OutWidgetTransform) override;

protected:
	/** Ensure that selection bits are in sync w/ the number of instances */
	void ValidateSelectedInstances(class UInstancedStaticMeshComponent* InComponent);

private:
	/** The blueprint editor we are bound to */
	TWeakPtr<class IBlueprintEditor> BlueprintEditorPtr;
};

class FBuildingComponentDetails : public IDetailCustomization
{
public:
	/** Makes a new instance of this detail layout class for a specific detail view requesting it */
	static TSharedRef<IDetailCustomization> MakeInstance();

	/** IDetailCustomization interface */
	virtual void CustomizeDetails(IDetailLayoutBuilder& DetailBuilder) override;

	FReply DuplicateSelectedInstances()
	{
		TArray<UObject*> StrongObjects;
		CopyFromWeakArray(StrongObjects, ObjectsBeingCustomized);

		FBuildingComponentDetails::DuplicateSelectedInstancesInBuilder(StrongObjects, this->CachedDetailBuilder);
		return FReply::Handled();
	}

	static void DuplicateInstanceInner(UInstancedStaticMeshComponent* component, int32 InstanceIndex)
	{
		auto bc = Cast<UBuildingComponent>(component);
		int32 new_index = -1;
		if (bc) {
			new_index = bc->Duplicate(InstanceIndex);
		}
		else {
			//auto bc = Cast<UHierarchicalInstancedStaticMeshComponent>(component);

#if WITH_EDITOR
			if (bc) {
				// update HISM arrays
				bc->BuildTreeIfOutdated(false, false);
			}
#endif
			auto tfm = FTransform(component->PerInstanceSMData[InstanceIndex].Transform); // intentionally hism, since it is the root that contains the latest transform
			new_index = component->AddInstance(tfm);
#if WITH_EDITOR
			if (bc) {
				// update HISM arrays
				bc->BuildTreeIfOutdated(false, false);
			}
#endif
		}

		//component->SelectInstance(false, InstanceIndex, 1);
		//component->SelectInstance(true, new_index, 1);

		UBuildingComponent::SetInstanceSelection(component, InstanceIndex, 1, false, false);
		UBuildingComponent::SetInstanceSelection(component, new_index, 1, true, false);
	}

	static void DuplicateInstance(UInstancedStaticMeshComponent* component, int32 InstanceIndex)
	{
		auto bc = Cast<UBuildingComponent>(component);
		if (bc) {
			DuplicateInstanceInner(component, InstanceIndex);
		}
		else {
			auto siblings = UBuildingComponent::GetAllComponents(component, true, false, true);
			for (auto link : siblings) {
				if (link.Component->PerInstanceSMData.IsValidIndex(InstanceIndex)) {
					DuplicateInstanceInner(link.Component, InstanceIndex);
				}
			}
		}
	}

	static void DuplicateSelectedInstancesInBuilder(TArray<UObject*> StrongObjects, IDetailLayoutBuilder* DetailBuilder)
	{
		FScopedTransaction Transaction(NSLOCTEXT("MOTH", "DuplicateInstances", "Duplicate Instances"));

		for (UObject* obj : StrongObjects)
		{
			auto hism = Cast<UInstancedStaticMeshComponent>(obj);
			if (hism) {
				//FBuildingComponentDetails::DuplicateInstance(hism, i);
				//auto siblings = UBuildingComponent::GetAllComponents(hism, true, false, true);
				//for (auto link : siblings) {
					//auto bc = Cast<UBuildingComponent>(link.Component);

				auto selected = UBuildingComponent::GetSelectedInstances(hism);

				//auto max = hism->SelectedInstances.Num(); // store the current as addinstance will grow this
				for (int i = 0; i < selected.Num(); i++) {
					if (selected[i] == 1 && hism->PerInstanceSMData.IsValidIndex(i)) {
						FBuildingComponentDetails::DuplicateInstance(hism, i);
						//							int32 new_index = -1;
						//							if (bc) {
						//								new_index = bc->Duplicate(i);
						//							}
						//							else {
						//#if WITH_EDITOR
						//								// update HISM arrays
						//								link.Component->BuildTreeIfOutdated(false, false);
						//#endif
						//								auto tfm = FTransform(hism->PerInstanceSMData[i].Transform); // intentionally hism, since it is the root that contains the latest transform
						//								new_index = link.Component->AddInstance(tfm);
						//#if WITH_EDITOR
						//								// update HISM arrays
						//								link.Component->BuildTreeIfOutdated(false, false);
						//#endif
						//							}
						//
						//							link.Component->SelectInstance(false, new_index, 1);
						//							link.Component->SelectInstance(true, new_index, 1);
					}
				}
				//}
			}
		}

		// force a refresh to ensure the active icon is updated
		if (DetailBuilder) {
			DetailBuilder->ForceRefreshDetails();
		}

		//TArray<TWeakObjectPtr<UObject>> ObjectsBeingCustomized;
		//DetailBuilder->GetObjectsBeingCustomized(/*out*/ ObjectsBeingCustomized);

		//TArray<UObject*> StrongObjects1;
		//CopyFromWeakArray(StrongObjects, ObjectsBeingCustomized);

		////auto handle = DetailBuilder->GetProperty("PerInstanceSMData", UInstancedStaticMeshComponent::StaticClass());
		////if (handle->IsValidHandle()) {
		//	//auto arr = handle->AsArray();

		//for (UObject* obj : StrongObjects)
		//{
		//	auto bc = Cast<UBuildingComponent>(obj);
		//	if (bc) {
		//		//TArray<UObject*> ArchetypeInstances;
		//		//bc->GetArchetypeInstances(ArchetypeInstances);

		//		bc->Modify();
		//		bc->RebuildSelection();
		//		auto max = bc->CustomPerInstanceSMData.Num();

		//		//TArray<int32> select_indicies;  intentionally disabling, leave the selected instances as they are already selected and could be looking at data
		//		int index = -1;
		//		do {
		//			index = -1;
		//			for (int i = index + 1; i < max; i++) {
		//				if (bc->CustomPerInstanceSMData[i].Selected && !bc->CustomPerInstanceSMData[i].CopyInProcess) {
		//					bc->CustomPerInstanceSMData[i].CopyInProcess = true;

		//					index = i;
		//					break;
		//				}
		//			}

		//			if (index > -1) {
		//				auto dupe_index = bc->Duplicate(index);
		//				//bc->CustomPerInstanceSMData[index].CopyInProcess = false;
		//				bc->CustomPerInstanceSMData[index].Selected = false;
		//				bc->CustomPerInstanceSMData[dupe_index].Selected = true;


		//				//						auto tfm = FTransform(bc->PerInstanceSMData[index].Transform);
		//				//						auto data = bc->CustomPerInstanceSMData[index].Duplicate();
		//				//
		//				//#if WITH_EDITOR
		//				//						bc->BuildTreeIfOutdated(false, false);
		//				//#endif
		//				//
		//				//						auto new_index = bc->AddInstance(tfm);
		//				//#if WITH_EDITOR
		//				//						bc->BuildTreeIfOutdated(false, false);
		//				//#endif
		//				//
		//				//
		//				//						//bc->SetInstanceDefaults(new_index);
		//				//						bc->CustomPerInstanceSMData[new_index] = data;

		//										////select_indicies.Add(new_index);

		//										//for (UObject* ao : ArchetypeInstances)
		//										//{
		//										//	auto abc = Cast<UBuildingComponent>(ao);
		//										//	if (abc) {
		//										//		abc->Modify();
		//										//		auto abc_new_index = abc->AddInstance(tfm);

		//										//		abc->SetInstanceDefaults(abc_new_index);
		//										//		abc->CustomPerInstanceSMData[abc_new_index] = data;
		//										//	}
		//										//}

		//										//TArray<USceneComponent*> children;

		//										//// add the view port instances
		//										//bc->GetChildrenComponents(true, children);

		//										//// remove editor instances
		//										//UBuildingComponent::FindAllChildrenComponents(bc, children); //  (no reset!)

		//										//for (int i = 0; i < children.Num(); i++) {
		//										//	auto sub_building = Cast<UBuildingComponent>(children[i]);
		//										//	if (sub_building) {
		//										//		sub_building->Modify();
		//										//		sub_building->InstanceReorderTable.Empty();
		//										//		sub_building->BuildTreeIfOutdated(false, false);
		//										//		sub_building->AddInstance(tfm);

		//										//		sub_building->SetInstanceDefaults(new_index); // will create a new record if not exists
		//										//		sub_building->CustomPerInstanceSMData[new_index] = sub_building->CustomPerInstanceSMData[index].Duplicate();

		//										//		ArchetypeInstances.Empty();
		//										//		sub_building->GetArchetypeInstances(ArchetypeInstances);

		//										//		for (UObject* obj : ArchetypeInstances)
		//										//		{
		//										//			auto abc = Cast<UBuildingComponent>(obj);
		//										//			if (abc) {
		//										//				abc->Modify();
		//										//				abc->InstanceReorderTable.Empty();
		//										//				abc->BuildTreeIfOutdated(false, false);
		//										//				abc->AddInstance(tfm);

		//										//				abc->SetInstanceDefaults(new_index); // will create a new record if not exists
		//										//				abc->CustomPerInstanceSMData[new_index] = abc->CustomPerInstanceSMData[index].Duplicate();
		//										//			}
		//										//		}
		//										//	}
		//										//}
		//			}
		//		} while (index > -1);

		//		for (int i = 0; i < bc->CustomPerInstanceSMData.Num(); i++) {
		//			if (bc->CustomPerInstanceSMData[i].CopyInProcess) {
		//				bc->CustomPerInstanceSMData[i].CopyInProcess = false;
		//			}
		//		}

		//		bc->SyncSelections();
		//		bc->SelectViewportInstances();

		//		//// reset selection
		//		//bc->SelectInstance(false, 0, bc->CustomPerInstanceSMData.Num());
		//		//for (UObject* ao : ArchetypeInstances)
		//		//{
		//		//	auto abc = Cast<UBuildingComponent>(ao);
		//		//	if (abc) {
		//		//		abc->SelectInstance(false, 0, abc->CustomPerInstanceSMData.Num());
		//		//	}
		//		//}

		//		//// select
		//		//for (int32 id : select_indicies)
		//		//{
		//		//	bc->SelectInstance(false, id, 1);
		//		//	for (UObject* ao : ArchetypeInstances)
		//		//	{
		//		//		auto abc = Cast<UBuildingComponent>(ao);
		//		//		if (abc) {
		//		//			abc->SelectInstance(false, id, 1);
		//		//		}
		//		//	}
		//		//}
		//	}
		//	else {
		//		
		//	}
		//}
		////}
	}

	FReply DeleteSelectedInstances()
	{
		//FScopedTransaction Transaction(NSLOCTEXT("MOTH", "DeleteSelectedInstances", "Delete Selected Instances"));

		// TODO: make a "GetSelectedInstances" function, and update the code that does this themself (ie UBuildingComponent::RebuildSelection, property customisation)

		TArray<UObject*> StrongObjects;
		CopyFromWeakArray(StrongObjects, ObjectsBeingCustomized);

		for (auto obj : StrongObjects) {
			auto ism = Cast<UInstancedStaticMeshComponent>(obj);
			if (ism) {
				auto selected = UBuildingComponent::GetSelectedInstances(ism);

				ism->Modify();

				for (int i = selected.Num() - 1; i >= 0; i--) {
					if (selected[i] == 1)
						ism->RemoveInstance(i);
				}
			}
		}

		// force a refresh to ensure the active icon is updated
		if (this->CachedDetailBuilder) {
			this->CachedDetailBuilder->ForceRefreshDetails();
		}

		//TArray<UObject*> StrongObjects;
		//CopyFromWeakArray(StrongObjects, ObjectsBeingCustomized);

		//auto handle = this->CachedDetailBuilder->GetProperty("PerInstanceSMData", UInstancedStaticMeshComponent::StaticClass());
		//if (handle->IsValidHandle()) {
		//	auto arr = handle->AsArray();

		//	for (UObject* obj : StrongObjects)
		//	{
		//		auto bc = Cast<UBuildingComponent>(obj);
		//		if (bc) {
		//			//TArray<UObject*> ArchetypeInstances;
		//			//bc->GetArchetypeInstances(ArchetypeInstances);

		//			bc->Modify();

		//			int index = -1;
		//			do {
		//				index = -1;
		//				for (int i = bc->CustomPerInstanceSMData.Num() - 1; i >= 0; i--) {
		//					if (bc->CustomPerInstanceSMData[i].Selected) {
		//						bc->CustomPerInstanceSMData[i].Selected = false;

		//						index = i;
		//						break;
		//					}
		//				}

		//				if (index > -1) {
		//					bc->RemoveInstance(index);

		//					/*for (UObject* ao : ArchetypeInstances)
		//					{
		//						auto abc = Cast<UBuildingComponent>(ao);
		//						if (abc) {
		//							abc->Modify();
		//							abc->RemoveInstance(index);
		//						}
		//					}*/
		//				}
		//			} while (index > -1);
		//		}
		//	}
		//}

		return FReply::Handled();
	}

	FReply SelectAllInstances() {
		FScopedTransaction Transaction(NSLOCTEXT("MOTH", "SelectInstances", "Select all Instances"));

		TArray<UObject*> StrongObjects;
		CopyFromWeakArray(StrongObjects, ObjectsBeingCustomized);

		auto handle = this->CachedDetailBuilder->GetProperty("PerInstanceSMData", UInstancedStaticMeshComponent::StaticClass());
		if (handle->IsValidHandle()) {
			auto arr = handle->AsArray();

			for (UObject* obj : StrongObjects)
			{
				auto bc = Cast<UHierarchicalInstancedStaticMeshComponent>(obj);
				if (bc) {
					auto components = UBuildingComponent::GetAllComponents(bc);
					for (auto cmp : components) {
						cmp.Component->Modify();
						cmp.Component->SelectInstance(true, 0, cmp.Component->PerInstanceSMData.Num());

						auto ibc = Cast<UBuildingComponent>(cmp.Component);
						if (ibc) {
							for (int x = 0; x < ibc->CustomPerInstanceSMData.Num(); x++)
							{
								ibc->CustomPerInstanceSMData[x].Selected = true;
							}
						}
					}
				}
			}
		}

		// force a refresh to ensure the active icon is updated
		if (this->CachedDetailBuilder) {
			this->CachedDetailBuilder->ForceRefreshDetails();
		}

		return FReply::Handled();
	}

	FReply SelectHalfInstances() {
		FScopedTransaction Transaction(NSLOCTEXT("MOTH", "SelectHalfInstances", "Select half Instances"));

		TArray<UObject*> StrongObjects;
		CopyFromWeakArray(StrongObjects, ObjectsBeingCustomized);

		//auto handle = this->CachedDetailBuilder->GetProperty("PerInstanceSMData", UInstancedStaticMeshComponent::StaticClass());
		//if (handle->IsValidHandle()) {
			//auto arr = handle->AsArray();

		for (UObject* obj : StrongObjects)
		{
			auto bc = Cast<UHierarchicalInstancedStaticMeshComponent>(obj);
			if (bc) {
				auto components = UBuildingComponent::GetAllComponents(bc);
				for (auto cmp : components) {
					auto num = FMath::FloorToInt(cmp.Component->PerInstanceSMData.Num() / 2.0f);

					cmp.Component->Modify();
					cmp.Component->ClearInstanceSelection();
					cmp.Component->SelectInstance(true, 0, num);

					auto ibc = Cast<UBuildingComponent>(cmp.Component);
					if (ibc) {
						for (int x = 0; x < ibc->CustomPerInstanceSMData.Num(); x++)
						{
							ibc->CustomPerInstanceSMData[x].Selected = x < num;
						}
					}
				}
			}
		}
		//}

		// force a refresh to ensure the active icon is updated
		if (this->CachedDetailBuilder) {
			this->CachedDetailBuilder->ForceRefreshDetails();
		}

		return FReply::Handled();
	}

	FReply SyncChildren() {
		FScopedTransaction Transaction(NSLOCTEXT("MOTH", "SyncChildren", "Sync children"));

		TArray<UObject*> StrongObjects;
		CopyFromWeakArray(StrongObjects, ObjectsBeingCustomized);

		for (UObject* obj : StrongObjects)
		{
			auto bc = Cast<UHierarchicalInstancedStaticMeshComponent>(obj);
			if (bc) {
				auto components = UBuildingComponent::GetAllComponents(bc, false, true);
				for (auto cmp : components) {

					while (cmp.Component->PerInstanceSMData.Num() < bc->PerInstanceSMData.Num()) {
						auto index = cmp.Component->PerInstanceSMData.Num();
						auto transform = FTransform(bc->PerInstanceSMData[index].Transform);
						auto building = Cast<UBuildingComponent>(cmp.Component);

						cmp.Component->Modify();

						if (building) {
							building->AddInstanceSingle(transform);
						}
						else {
							cmp.Component->AddInstance(transform);
						}
					}

				}
			}
		}

		// force a refresh to ensure the active icon is updated
		if (this->CachedDetailBuilder) {
			this->CachedDetailBuilder->ForceRefreshDetails();
		}

		return FReply::Handled();
	}

	FReply SyncDefaults() {
		FScopedTransaction Transaction(NSLOCTEXT("MOTH", "SyncDefaults", "Sync defaults"));

		TArray<UObject*> StrongObjects;
		CopyFromWeakArray(StrongObjects, ObjectsBeingCustomized);

		for (UObject* obj : StrongObjects)
		{
			auto bc = Cast<UBuildingComponent>(obj);
			if (bc) {
				auto components = UBuildingComponent::GetAllComponents(bc, true, false);
				for (auto cmp : components) {
					for (int index = 0; index < cmp.Component->PerInstanceSMData.Num(); index++)
					{
						auto transform = FTransform(bc->PerInstanceSMData[index].Transform);
						auto building = Cast<UBuildingComponent>(cmp.Component);

						cmp.Component->Modify();

						if (building) {
							building->SetInstanceDefaults(index);
						}
					}
				}
			}
		}

		// force a refresh to ensure the active icon is updated
		if (this->CachedDetailBuilder) {
			this->CachedDetailBuilder->ForceRefreshDetails();
		}

		return FReply::Handled();
	}
protected:
	TArray<TWeakObjectPtr<UObject>> ObjectsBeingCustomized;
	IDetailLayoutBuilder* CachedDetailBuilder;	// The detail builder for this customisation
};

class FInstanceDataCustomization : public IPropertyTypeCustomization
{
public:
	static TSharedRef<IPropertyTypeCustomization> MakeInstance() {
		return MakeShareable(new FInstanceDataCustomization);
	}

	virtual void CustomizeHeader(TSharedRef<IPropertyHandle> PropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils) override;
	virtual void CustomizeChildren(TSharedRef<IPropertyHandle> StructPropertyHandle, class IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& StructCustomizationUtils) override;

	void OnChildParameterChanged(TSharedRef<IPropertyHandle> source_handle, TSharedRef<IPropertyHandle> new_handle, int index, UHierarchicalInstancedStaticMeshComponent* component);
	void OnParameterChanged(TSharedRef<IPropertyHandle> source_handle, TSharedRef<IPropertyHandle> new_handle, int index, UHierarchicalInstancedStaticMeshComponent* component);
	void OnModelChanged(TSharedRef<IPropertyHandle> source_handle, TSharedRef<IPropertyHandle> new_handle, int index, UHierarchicalInstancedStaticMeshComponent* component);

	void OnPropertyChanged(TSharedRef<IPropertyHandle> InstanceDataHandle, TSharedRef<IPropertyHandle> PropertyHandle, UBuildingComponent* component, int index);

	void RemoveInstance_Click(TSharedRef<IPropertyHandle> InstanceDataHandle, UHierarchicalInstancedStaticMeshComponent* component, int index)
	{
		auto arr = InstanceDataHandle->GetParentHandle()->AsArray();
		auto ix = InstanceDataHandle->GetIndexInArray();
		if (arr->DeleteItem(ix) == FPropertyAccess::Success) {
			if (this->CachedDetailBuilder) {
				this->CachedDetailBuilder->ForceRefreshDetails();
			}				      
		}
	}

	void GoToInstance_Click(TSharedRef<IPropertyHandle> InstanceDataHandle, UHierarchicalInstancedStaticMeshComponent* component, int index)
	{
		UBuildingComponent::SetInstanceSelection(component, index);
		/*auto bc = Cast<UBuildingComponent>(component);
		if (bc) {
			if (bc->PerInstanceSMData.Num() > index) {
				bc->SelectInstance(false, 0, bc->PerInstanceSMData.Num());
				bc->SelectInstance(true, index);

				TArray<UObject*> ArchetypeInstances;
				bc->GetArchetypeInstances(ArchetypeInstances);

				for (UObject* obj : ArchetypeInstances)
				{
					auto abc = Cast<UBuildingComponent>(obj);
					if (abc) {
						if (abc->PerInstanceSMData.Num() > index) {
							abc->SelectInstance(false, 0, abc->PerInstanceSMData.Num());
							abc->SelectInstance(true, index);
						}
					}
				}
			}
		}*/

		//bc->MarkRenderStateDirty(); // should already occur
		InstanceDataHandle->NotifyPostChange();

		// force a refresh to ensure the active icon is updated
		if (this->CachedDetailBuilder) {
			this->CachedDetailBuilder->ForceRefreshDetails();
		}
	}
	void DuplicateInstance_Click(TSharedRef<IPropertyHandle> InstanceDataHandle, UHierarchicalInstancedStaticMeshComponent* component, int index, TArray<TSharedPtr<IPropertyHandle>> externals)
	{
		//TArray<UObject*> StrongObjects;
		//StrongObjects.Add(component);
		//FBuildingComponentDetails::DuplicateSelectedInstancesInBuilder(StrongObjects, this->CachedDetailBuilder);
		FBuildingComponentDetails::DuplicateInstance(component, index);

		return;
		//auto arr = InstanceDataHandle->GetParentHandle()->AsArray();
		///*
		//		if (arr->DuplicateItem(index) == FPropertyAccess::Success) {
		//		}

		//		return;*/
		//		//auto arr = InstanceDataHandle->GetParentHandle()->AsArray();

		//if (arr->DuplicateItem(index) == FPropertyAccess::Success)
		//{
		//	/*if (IsValid(FBuildingComponentSCSEditorCustomization::CurrentComponent)) {
		//		auto cc = FBuildingComponentSCSEditorCustomization::CurrentComponent;
		//		auto last = cc->PerInstanceSMData.Num() - 1;

		//		cc->SelectInstance(false, 0, last);
		//		cc->SelectInstance(true, last);
		//	}*/
		//	FInstanceDataCustomization::SetInstanceSelection(component, component->PerInstanceSMData.Num() - 1);

		//	//			uint32 num_elements = 0;
		//	//			if (arr->GetNumElements(num_elements) == FPropertyAccess::Success)
		//	//			{
		//	//				auto new_handle = arr->GetElement(num_elements - 1);
		//	//
		//	//				TArray<UObject*> Objects;
		//	//				new_handle->GetOuterObjects(Objects);
		//	//				if (Objects.Num() > 0) {
		//	//					auto cmp = Cast<UBuildingComponent>(Objects[0]);
		//	//
		//	//					if (cmp) {
		//	//						//			auto new_transform = FTransform(current_transform);
		//	//						cmp->CustomPerInstanceSMData[num_elements - 1] = cmp->CustomPerInstanceSMData[index].Duplicate();
		//	//
		//	//						/*if (FBuildingComponentSCSEditorCustomization::CurrentComponent) {
		//	//							auto viewport_cmp = Cast<UBuildingComponent>(FBuildingComponentSCSEditorCustomization::CurrentComponent);
		//	//								viewport_cmp->CustomPerInstanceSMData[num_elements - 1] = viewport_cmp->CustomPerInstanceSMData[index].Duplicate();
		//	//						}*/
		//	///*
		//	//						if (!cmp->CustomPerInstanceSMData[index].ItemClass)
		//	//							cmp->CustomPerInstanceSMData[index].ItemClass = cmp->DefaultItemClass;
		//	//						if (!cmp->CustomPerInstanceSMData[index].ItemComponentClass)
		//	//							cmp->CustomPerInstanceSMData[index].ItemComponentClass = cmp->DefaultItemComponentClass;*/
		//	//
		//	//						new_handle->NotifyPostChange();
		//	//
		//	//						// force a refresh to ensure the active icon is updated
		//	//						if (this->CachedDetailBuilder) {
		//	//							this->CachedDetailBuilder->ForceRefreshDetails();
		//	//						}
		//	//					}
		//	//				}
		//	//
		//	//				//for (int i = 0; i < externals.Num(); i++)
		//	//				//{
		//	//				//	auto external_handle = externals[i];
		//	//				//	auto prop = external_handle->GetProperty();
		//	//
		//	//				//	auto float_prop = Cast<UFloatProperty>(prop);
		//	//				//	if (float_prop) {
		//	//				//		float value = 0;
		//	//				//		//float_prop->GetPropertyValuePtr_InContainer()
		//	//
		//	//				//		if (external_handle->GetValue(value) == FPropertyAccess::Success)
		//	//				//		{
		//	//				//			//InstanceDataHandle->GetChildHandle(FName(*prop->GetName()))->GetValue(value);
		//	//
		//	//				//			new_handle->GetChildHandle(FName(*prop->GetName()))->SetValue(value);
		//	//				//		}
		//	//				//	}
		//	//
		//	//				//	/*auto b = external_handle->GetPropertyClass();
		//	//				//	auto c = external_handle->GetPropertyDisplayName();
		//	//
		//	//				//	if (a || b || c.IsEmpty()) {
		//	//
		//	//				//	}*/
		//	//
		//	//				//	/*if (!n.IsEmpty()) {
		//	//				//		auto float_prop = reinterpret_cast<FPropertyHandleFloat*>(external_handle.Get());
		//	//				//		if (float_prop) {
		//	//
		//	//				//			float old = 0;
		//	//				//			new_handle->GetChildHandle(FName(*n.ToString()))->GetValue(old);
		//	//
		//	//				//			float_prop->SetValue(old);
		//	//				//		}
		//	//				//	}*/
		//	//
		//	//				//	//void* data = nullptr;
		//	//				//	//auto name = external_handle->GetValueData(data);
		//	//
		//	//				//	//new_handle->GetChildHandle(FName(*n.ToString()))->
		//	//
		//	//				//	//auto prop = external_handle->GetMetaDataProperty();
		//	//
		//	//
		//	//				//	////auto prop = external_handle->GetProperty();
		//	//
		//	//				//	//auto float_prop = Cast<UFloatProperty>(prop);
		//	//				//	//if (float_prop) {
		//	//				//	//	float value;
		//	//				//	//	if (external_handle->GetValue(value) == FPropertyAccess::Success)
		//	//				//	//	{
		//	//				//	//		new_handle->GetChildHandle(FName(*prop->GetName()))->SetValue(value);
		//	//				//	//	}
		//	//				//	//}
		//	//				//}
		//	//
		//	//				/*float health = 0;
		//	//				InstanceDataHandle->GetChildHandle("Health")->GetValue(health);
		//	//				last->GetChildHandle("Health")->SetValue(health);*/
		//	//
		//	//			}
		//}
	}

	void SetDefaults_Click(TSharedRef<IPropertyHandle> InstanceDataHandle, UHierarchicalInstancedStaticMeshComponent* component, int index)
	{
		auto cmp2 = Cast<UBuildingComponent>(component);

		if (cmp2) {
			cmp2->CustomPerInstanceSMData[index].ItemClass = cmp2->DefaultItemClass;
			cmp2->CustomPerInstanceSMData[index].ItemComponentClass = cmp2->DefaultItemComponentClass;

			// force a refresh to ensure the active icon is updated
			if (this->CachedDetailBuilder) {
				this->CachedDetailBuilder->ForceRefreshDetails();
			}
		}
	}
private:

	IDetailLayoutBuilder* CachedDetailBuilder;	// The detail builder for this customisation

	/** Refresh the UI next frames. */
	bool bNeedsRefresh = false;
};