// Fill out your copyright notice in the Description page of Project Settings.

#include "FPSProjectEditor.h"
#include "Modules/ModuleManager.h"
#include "Modules/ModuleInterface.h"

#include "Editor/ContentBrowser/Public/ContentBrowserModule.h"

#include "IDetailPropertyRow.h"
#include "IDetailGroup.h"

#include "PropertyHandle.h"

#include "DetailWidgetRow.h"
#include "STextBlock.h"
#include "SComboBox.h"
#include "SWidget.h"
#include "PropertyCustomizationHelpers.h"
#include "Components/InstancedStaticMeshComponent.h"

IMPLEMENT_GAME_MODULE(FFPSProjectEditorModule, FPSProjectEditor);

DEFINE_LOG_CATEGORY(FPSProjectEditor)

//#define LOCTEXT_NAMESPACE "InstanceEditorCommands"
//
//FInstanceEditorCommands::FInstanceEditorCommands() : TCommands<FInstanceEditorCommands>(
//	"InstanceEditorCommands",
//	NSLOCTEXT("Contexts", "InstanceEditorCommands", "Asset Management"),
//	NAME_None,
//	FEditorStyle::GetStyleSetName())
//{
//}
//
//void FInstanceEditorCommands::RegisterCommands()
//{
//	UI_COMMAND(Copy, "Copy instance...", "Copies the selected instance(s)", EUserInterfaceActionType::Button, FInputChord(EModifierKey::Control, EKeys::C));
//}
//
//#undef LOCTEXT_NAMESPACE



#define LOCTEXT_NAMESPACE "FPSProjectEditor"

void FFPSProjectEditorModule::StartupModule()
{
	UE_LOG(FPSProjectEditor, Warning, TEXT("FPSProjectEditor: Log Started"));
	//return;
	FBlueprintEditorModule& BlueprintEditorModule = FModuleManager::LoadModuleChecked<FBlueprintEditorModule>("Kismet");
	BlueprintEditorModule.RegisterSCSEditorCustomization("BuildingComponent", FSCSEditorCustomizationBuilder::CreateStatic(&FBuildingComponentSCSEditorCustomization::MakeInstance));
	//BlueprintEditorModule.RegisterSCSEditorCustomization("HierarchicalInstancedStaticMeshComponent", FSCSEditorCustomizationBuilder::CreateStatic(&FBuildingComponentSCSEditorCustomization::MakeInstance));

	//BlueprintEditorModule.OnBlueprintEditorOpened

	static FName PropertyEditor("PropertyEditor");
	FPropertyEditorModule& PropertyModule = FModuleManager::GetModuleChecked<FPropertyEditorModule>(PropertyEditor);
	PropertyModule.RegisterCustomPropertyTypeLayout("InstancedStaticMeshInstanceData", FOnGetPropertyTypeCustomizationInstance::CreateStatic(&FInstanceDataCustomization::MakeInstance));

	//PropertyModule.RegisterCustomClassLayout("BuildingComponent", FOnGetDetailCustomizationInstance::CreateStatic(&FBuildingComponentDetails::MakeInstance));
	PropertyModule.RegisterCustomClassLayout("HierarchicalInstancedStaticMeshComponent", FOnGetDetailCustomizationInstance::CreateStatic(&FBuildingComponentDetails::MakeInstance));

	PropertyModule.NotifyCustomizationModuleChanged();

	UIExtender.Extend();

	//TSharedPtr<FExtender> MyExtender = MakeShareable(new FExtender);
	//MyExtender->AddToolBarExtension("Edit", EExtensionHook::After, NULL, FToolBarExtensionDelegate::CreateRaw(this, &FFPSProjectEditorModule::CopyPasteInstances));

	//FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");
	//LevelEditorModule.GetToolBarExtensibilityManager()->AddExtender(MyExtender);

	//FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");

	//FInstanceEditorCommands::Register();

	//TSharedPtr<FExtender> MenuExtender = MakeShareable(new FExtender());
	//MenuExtender->AddMenuExtension("Asset", EExtensionHook::After, NULL, FMenuExtensionDelegate::CreateRaw(this, &FFPSProjectEditorModule::AddMenuItems));
	//LevelEditorModule.GetMenuExtensibilityManager()->AddExtender(MenuExtender);


	//TSharedRef<FUICommandList> CommandList = LevelEditorModule.GetGlobalLevelEditorActions();

	//CommandList->MapAction(FInstanceEditorCommands::Get().Copy,
	//	FExecuteAction::CreateLambda([this]
	//{
	//	TArray<FName> OutAssetPackages;
	//	TArray<UObject*> ReferencedAssets;
	//	GEditor->GetReferencedAssetsForEditorSelection(ReferencedAssets);

	//	for (UObject* EditedAsset : ReferencedAssets)
	//	{
	//		if (EditedAsset && EditedAsset->IsAsset() && !EditedAsset->IsPendingKill())
	//		{
	//			OutAssetPackages.AddUnique(EditedAsset->GetOutermost()->GetFName());
	//		}
	//	}



	//}),
	//	FCanExecuteAction() //FCanExecuteAction::CreateRaw(this, &FAssetManagerEditorModule::AreLevelEditorPackagesSelected)
	//	);


	//IAssetTools& AssetTools = FModuleManager::LoadModuleChecked<FAssetToolsModule>("AssetTools").Get();
	//EAssetTypeCategories::Type CreatureAssetCategoryBit = AssetTools.RegisterAdvancedAssetCategory(FName(TEXT("MOTHAssetCategory")), LOCTEXT("MOTHAssetCategory", "MOTH"));

	//AssetTools.RegisterAssetTypeActions(MakeShareable(new FCreateSMAAssetTypeActions(CreatureAssetCategoryBit)));

	//FContentBrowserModule& ContentBrowserModule = FModuleManager::Get().LoadModuleChecked<FContentBrowserModule>("ContentBrowser");

	TSharedPtr<FUICommandList> CommandBindings = MakeShareable(new FUICommandList());

	FContentBrowserModule& ContentBrowserModule = FModuleManager::LoadModuleChecked<FContentBrowserModule>(TEXT("ContentBrowser"));
	//TWeakObjectPtr<const FFPSProjectEditorModule> WeakThis(this);
	ContentBrowserModule.GetAllAssetContextMenuExtenders().Add(FContentBrowserMenuExtender_SelectedPaths::CreateLambda([this](const TArray<FString> & SelectedPaths)
		{
			TSharedRef<FExtender> Extender = MakeShared<FExtender>();
			//if (WeakThis.IsValid())
			{
				Extender->AddMenuExtension(
					//"ContentBrowserNewAdvancedAsset",
					NAME_None,
					EExtensionHook::After,
					TSharedPtr<FUICommandList>(),
					FMenuExtensionDelegate::CreateRaw(this, &FFPSProjectEditorModule::AddMenuExtension)
				);
			}

			return Extender;
		}));


	//TSharedPtr<FExtender> MenuExtender = MakeShareable(new FExtender());


	//MenuExtender->AddMenuExtension(NAME_None, EExtensionHook::Before, NULL, FMenuExtensionDelegate::CreateRaw(this, &FFPSProjectEditorModule::AddMenuExtension));
	////FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");

	//ContentBrowserModule.GetAllAssetContextMenuExtenders()->Add

	/*TSharedPtr<FExtender> MenuExtender = MakeShareable(new FExtender());


	MenuExtender->AddMenuExtension("FileProject", EExtensionHook::After, MyPluginCommands, FMenuExtensionDelegate::CreateRaw(this, &FPluginCreatorModule::AddMenuExtension));
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");
	LevelEditorModule.GetMenuExtensibilityManager()->AddExtender(MenuExtender);*/
}

void FFPSProjectEditorModule::TopMenuBuilderFunc(FMenuBuilder& TopMenuBuilder, const TArray<FString> SelectedPaths, UObject* na)
{
	/*TopMenuBuilder.GetCustomization().AllowCustomization("*/;
};

void FFPSProjectEditorModule::AddMenuExtension(FMenuBuilder& builder)
{
	//FSlateIcon IconBrush = FSlateIcon(FEditorStyle::GetStyleSetName(), "LevelEditor.ViewOptions", "LevelEditor.ViewOptions.Small");

	//builder.AddMenuEntry(FCookbookCommands::Get().MyButton);
};

void FFPSProjectEditorModule::ShutdownModule()
{
	UIExtender.Release();
	UE_LOG(FPSProjectEditor, Warning, TEXT("FPSProjectEditor: Log Ended"));
}

#undef LOCTEXT_NAMESPACE

#define LOCTEXT_NAMESPACE "MyClassDetails"

TSharedRef<IDetailCustomization> FFInstancedStaticMeshInstanceDataDetails::MakeInstance()
{
	return MakeShareable(new FFInstancedStaticMeshInstanceDataDetails);
}

void FFInstancedStaticMeshInstanceDataDetails::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder)
{
}

#undef LOCTEXT_NAMESPACE


#define LOCTEXT_NAMESPACE "InstanceDataCustomization"
void FInstanceDataCustomization::CustomizeHeader(TSharedRef<IPropertyHandle> PropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
}
void FInstanceDataCustomization::OnChildParameterChanged(TSharedRef<IPropertyHandle> source_handle, TSharedRef<IPropertyHandle> new_handle, int index, UHierarchicalInstancedStaticMeshComponent* component)
{
}
void FInstanceDataCustomization::OnModelChanged(TSharedRef<IPropertyHandle> source_handle, TSharedRef<IPropertyHandle> new_handle, int index, UHierarchicalInstancedStaticMeshComponent* component)
{
}
void FInstanceDataCustomization::OnParameterChanged(TSharedRef<IPropertyHandle> source_handle, TSharedRef<IPropertyHandle> new_handle, int index, UHierarchicalInstancedStaticMeshComponent* component)
{
}

void FInstanceDataCustomization::OnPropertyChanged(TSharedRef<IPropertyHandle> InstanceDataHandle, TSharedRef<IPropertyHandle> PropertyHandle, UBuildingComponent* component, int index)
{
	// feed the changed value into the real object, since the external property is not attached to the instance data


	auto prop = PropertyHandle->GetProperty();
	//auto bc = Cast<UBuildingComponent>(component);

	auto float_property = Cast<UFloatProperty>(prop);
	if (float_property) {
		float newValue = 0;
		if (PropertyHandle->GetValue(newValue) == FPropertyAccess::Success) {
			float_property->SetPropertyValue_InContainer(&component->CustomPerInstanceSMData[index], newValue);
		}
	}
	else {
		auto class_property = Cast<UClassProperty>(prop);
		if (class_property) {
			UObject* newValue = nullptr;
			if (PropertyHandle->GetValue(newValue) == FPropertyAccess::Success) {
				//class_property->SetPropertyClass(&component->CustomPerInstanceSMData[index], newValue);
				//void* valuePtr = class_property->ContainerPtrToValuePtr<void>(&component->CustomPerInstanceSMData[index]);
				//void* valuePtr = class_property->GetObjectPropertyValue_InContainer(&component->CustomPerInstanceSMData, index);
				class_property->SetPropertyValue_InContainer(&component->CustomPerInstanceSMData[index], newValue);


				//UClassProperty* ClassProp = FindFieldChecked<UClassProperty>(GameModeClass, ClassPropertyName);
				//CurrentDefaultClass = (UClass*)ClassProp->GetObjectPropertyValue(ClassProp->ContainerPtrToValuePtr<void>(GetCurrentGameModeCDO()));
			}
		}
	}

	//if (component->CustomPerInstanceSMData.Num() > InstanceDataHandle->GetIndexInArray()) {
	//	auto propertyClass = FBuildingComponentInstanceData::StaticStruct();
	//	for (TFieldIterator<UProperty> Prop(propertyClass); Prop; ++Prop) {
	//		UProperty* Property = *Prop;

	//		PropertyHandle->GetProperty()

	//		TSharedPtr<IPropertyHandle> propertyHandle = InstanceDataHandle->GetChildHandle(FName(*Prop->GetName()));

	//		// property data type branches
	//		auto float_property = Cast<UFloatProperty>(Property);
	//		if (float_property) {
	//			float newValue = 0;
	//			if (PropertyHandle->GetValue(newValue) == FPropertyAccess::Success) {
	//				//float_property->SetFloatingPointPropertyValue(&component->CustomPerInstanceSMData[index], newValue);

	//				UStruct* StructProperty = Property->GetOwnerStruct();
	//				UObject* parent = Property->GetOuter();

	//				auto data = component->CustomPerInstanceSMData[index];
	//				//auto ValuePtr = Property->ContainerPtrToValuePtr<FBuildingComponentInstanceData>(parent);

	//				//UObject*  data_container = &data;
	//				//auto prop = float_property->GetPropertyValuePtr_InContainer(&data, index);
	//				float_property->SetPropertyValue_InContainer(&data, newValue);


	//				//float_property->SetFloatingPointPropertyValue(ValuePtr, newValue, index);

	//				//*ValuePtr = newValue;
	//			}
	//		}
	//		else {
	//			auto class_property = Cast<UClassProperty>(Property);
	//			if (class_property) {
	//				UObject* newValue = nullptr;
	//				if (PropertyHandle->GetValue(newValue) == FPropertyAccess::Success) {
	//					//class_property->SetPropertyClass(&component->CustomPerInstanceSMData[index], newValue);
	//					//void* valuePtr = class_property->ContainerPtrToValuePtr<void>(&component->CustomPerInstanceSMData[index]);
	//					//void* valuePtr = class_property->GetObjectPropertyValue_InContainer(&component->CustomPerInstanceSMData, index);
	//					//class_property->SetObjectPropertyValue(&component->CustomPerInstanceSMData[index], newValue);


	//					//UClassProperty* ClassProp = FindFieldChecked<UClassProperty>(GameModeClass, ClassPropertyName);
	//					//CurrentDefaultClass = (UClass*)ClassProp->GetObjectPropertyValue(ClassProp->ContainerPtrToValuePtr<void>(GetCurrentGameModeCDO()));
	//				}
	//			}
	//		}
	//	}
	//}

	InstanceDataHandle->NotifyPostChange();
}

void FInstanceDataCustomization::CustomizeChildren(TSharedRef<IPropertyHandle> InstanceDataHandle, class IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& StructCustomizationUtils)
{
	this->CachedDetailBuilder = &ChildBuilder.GetParentCategory().GetParentLayout();

	//ChildBuilder.GetParentCategory().GetParentLayout().ForceRefreshDetails();
	TSharedPtr<IPropertyHandle> TransformHandle = InstanceDataHandle->GetChildHandle(GET_MEMBER_NAME_CHECKED(FInstancedStaticMeshInstanceData, Transform));

	auto index = InstanceDataHandle->GetIndexInArray();
	auto index_fstr = FString::FromInt(index);
	auto index_ftxt = FText::FromString(index_fstr);
	auto group = &ChildBuilder.AddGroup("ArrayElement", index_ftxt);

	group->AddPropertyRow(TransformHandle.ToSharedRef());

	TArray<UObject*> Objects;
	InstanceDataHandle->GetOuterObjects(Objects);
	UBuildingComponent* component = NULL;
	UHierarchicalInstancedStaticMeshComponent* hism = NULL;
	UInstancedStaticMeshComponent* ism = NULL;
	if (Objects.Num() > 0) {
		component = Cast<UBuildingComponent>(Objects[0]);
		hism = Cast<UHierarchicalInstancedStaticMeshComponent>(Objects[0]);
		ism = Cast<UInstancedStaticMeshComponent>(Objects[0]);
	}

	TSharedPtr<FStructOnScope> ValueStruct = MakeShareable(new FStructOnScope(FBuildingComponentInstanceData::StaticStruct()));
	auto location = ValueStruct->GetStructMemory();
	auto StructData = ValueStruct.ToSharedRef();

	auto externals = InstanceDataHandle->AddChildStructure(StructData);

	TSharedRef<SWidget> RemoveButton = PropertyCustomizationHelpers::MakeDeleteButton(
		FSimpleDelegate::CreateSP(this, &FInstanceDataCustomization::RemoveInstance_Click, InstanceDataHandle, hism, index),
		LOCTEXT("RemoveBuildingInstance", "Remove this instance from the array")
	);
	TSharedRef<SWidget> GoToButton = PropertyCustomizationHelpers::MakeBrowseButton(
		FSimpleDelegate::CreateSP(this, &FInstanceDataCustomization::GoToInstance_Click, InstanceDataHandle, hism, index),
		LOCTEXT("GoToBuildingInstance", "Select this instance within the viewport")
	);
	TSharedRef<SWidget> DuplicateButton = PropertyCustomizationHelpers::MakeAddButton(
		FSimpleDelegate::CreateSP(this, &FInstanceDataCustomization::DuplicateInstance_Click, InstanceDataHandle, hism, index, externals),
		LOCTEXT("DuplicateInstance", "Duplicate this instance")
	);
	TSharedRef<SWidget> SetDefaultsButton = PropertyCustomizationHelpers::MakeResetButton(
		FSimpleDelegate::CreateSP(this, &FInstanceDataCustomization::SetDefaults_Click, InstanceDataHandle, hism, index),
		LOCTEXT("SetDefaults", "Set defaults from component")
	);

	/*bool is_selected = false;
	if (IsValid(FBuildingComponentSCSEditorCustomization::CurrentComponent) && FBuildingComponentSCSEditorCustomization::CurrentComponent) {
		if (FBuildingComponentSCSEditorCustomization::CurrentComponent->SelectedInstances.Num() > index) {
			is_selected = FBuildingComponentSCSEditorCustomization::CurrentComponent->SelectedInstances[index] == 1;
		}
	}*/
	TArray<int32> selected;
	if (ism) {
		selected = UBuildingComponent::GetSelectedInstances(ism);
	}
	bool is_selected = selected.IsValidIndex(index) && selected[index] == 1;

	/*if (component) {
		component->RebuildSelection();
	}
*/
	//auto components = UBuildingComponent::GetAllComponents(hism, true, false);
	//int ix = 0;
	//for (auto cmp : components) {
	//	/*RF_Transactional			=0x00000008,	///< Object is transactional.
	//RF_ClassDefaultObject		=0x00000010,	///< This object is its class's default object
	//RF_ArchetypeObject			=0x00000020,	///< This object is a template for another object - treat like a class default object
	//RF_Transient				=0x00000040,	///< Don't save object.*/

	//	auto arch = cmp.Component->HasAnyFlags(RF_ArchetypeObject);
	//	if (!arch) {
	//		if (cmp.Component->SelectedInstances.IsValidIndex(index)) {
	//			is_selected = cmp.Component->SelectedInstances[index] == 1;
	//			//break; dont do this, seems like the last arch type is the winner....not a clue why yet
	//		}
	//	}
	//	ix++;
	//}
	/*if (ix > 0) {
		if (component) {
			component->RebuildSelection();
		}
	}*/

	//if (component && component->CustomPerInstanceSMData.Num() > index) {
	//	is_selected = component->CustomPerInstanceSMData[index].Selected;

	//	/*TArray<UObject*> instances;
	//	component->GetArchetypeInstances(instances);

	//	for (UObject* obj : instances)
	//	{
	//		auto bc = Cast<UBuildingComponent>(obj);
	//		if (bc && bc->SelectedInstances.Num() > index) {
	//			is_selected = bc->SelectedInstances[index] == 1;
	//		}

	//		if (is_selected) { break; }
	//	}

	//	component->CustomPerInstanceSMData[index].Selected = is_selected;*/
	//}

	group->HeaderRow().ValueContent()
	[
		SNew(SHorizontalBox)

		+ SHorizontalBox::Slot()
		.HAlign(HAlign_Right)
		.VAlign(VAlign_Center)
		.AutoWidth()
		[
			SNew(STextBlock)
			.Font(FEditorStyle::GetFontStyle("TinyText"))
			.Text(FText::FromString(FString::FromInt(index)))
			.ToolTipText(LOCTEXT("InstanceID", "ID of the instance"))
		]

		+ SHorizontalBox::Slot()
		.HAlign(HAlign_Right)
		.VAlign(VAlign_Center)
		.AutoWidth()
		[
			RemoveButton
		]

		+ SHorizontalBox::Slot()
		.HAlign(HAlign_Right)
		.VAlign(VAlign_Center)
		.AutoWidth()
		[
			GoToButton
		]

		+ SHorizontalBox::Slot()
		.HAlign(HAlign_Right)
		.VAlign(VAlign_Center)
		.AutoWidth()
		[
			SNew(SImage)
			.ColorAndOpacity(FSlateColor::UseForeground())
			.Image(is_selected ? FEditorStyle::GetBrush("Level.VisibleHighlightIcon16x") : nullptr)
			.ToolTipText(LOCTEXT("SelectedInstance", "Selected instance"))
		]

		+ SHorizontalBox::Slot()
		.HAlign(HAlign_Right)
		.VAlign(VAlign_Center)
		.AutoWidth()
		[
			DuplicateButton
		]

		+ SHorizontalBox::Slot()
		.HAlign(HAlign_Right)
		.VAlign(VAlign_Center)
		.AutoWidth()
		[
			SetDefaultsButton
		]
	];

	if (component) {
		// now create the relay from FInstancedStaticMeshInstanceData, to FBuildingComponentInstanceData by iterating over each property in the latter and 
		// registering them as a new row, and attaching any watch events which will relay the "changed" data back into the CustomPerInstanceSMData property

		while (component->CustomPerInstanceSMData.Num() < (index + 1)) {
			auto data = FBuildingComponentInstanceData();
			component->CustomPerInstanceSMData.Add(data);
		}

		auto data = component->CustomPerInstanceSMData[index];

		memcpy(location, &data, ValueStruct->GetStruct()->GetStructureSize());

		for (int i = 0; i < externals.Num(); i++)
		{
			auto propertyHandle = externals[i];
			group->AddPropertyRow(propertyHandle.ToSharedRef());

			propertyHandle->SetOnPropertyValueChanged(FSimpleDelegate::CreateRaw(this, &FInstanceDataCustomization::OnPropertyChanged, InstanceDataHandle, propertyHandle.ToSharedRef(), component, index));

			//// property data type branches
			//auto float_property = Cast<UFloatProperty>(Property);
			//if (float_property) {
			//	float value = float_property->GetFloatingPointPropertyValue(&data);
			//}
		}

		//auto propertyClass = FBuildingComponentInstanceData::StaticStruct();
		//for (TFieldIterator<UProperty> Prop(propertyClass); Prop; ++Prop) {
		//	UProperty* Property = *Prop;

		//	TSharedPtr<IPropertyHandle> propertyHandle = InstanceDataHandle->GetChildHandle(FName(*Prop->GetName()));

		//	group->AddPropertyRow(propertyHandle.ToSharedRef());

		//	propertyHandle->SetOnPropertyValueChanged(FSimpleDelegate::CreateRaw(this, &FInstanceDataCustomization::OnPropertyChanged, InstanceDataHandle, propertyHandle.ToSharedRef(), component, index));

		//	// property data type branches
		//	auto float_property = Cast<UFloatProperty>(Property);
		//	if (float_property) {
		//		float value = float_property->GetFloatingPointPropertyValue(&data);
		//	}
		//}
	}
}
#undef LOCTEXT_NAMESPACE


UInstancedStaticMeshComponent* FBuildingComponentSCSEditorCustomization::CurrentComponent;

TSharedRef<ISCSEditorCustomization> FBuildingComponentSCSEditorCustomization::MakeInstance(TSharedRef< IBlueprintEditor > InBlueprintEditor)
{
	TSharedRef<FBuildingComponentSCSEditorCustomization> NewCustomization = MakeShareable(new FBuildingComponentSCSEditorCustomization());
	NewCustomization->BlueprintEditorPtr = InBlueprintEditor;
	return NewCustomization;
}

void FBuildingComponentSCSEditorCustomization::ValidateSelectedInstances(UInstancedStaticMeshComponent* InComponent)
{
	check(InComponent);

	// @TODO - revisit; this might be better done as post-edit handling in the InstancedStaticMesh class itself.
	// Ensure that the number of selection bits matches the number of instances; if not, it's likely that the user has
	// just added or removed an instance, in which case we'll reset the selection to select the last instance in the list.
	if (InComponent->SelectedInstances.Num() != InComponent->PerInstanceSMData.Num())
	{
		InComponent->SelectedInstances.Init(false, InComponent->PerInstanceSMData.Num());
		if (InComponent->PerInstanceSMData.Num() > 0)
		{
			InComponent->SelectInstance(true, InComponent->PerInstanceSMData.Num() - 1);
			InComponent->MarkRenderStateDirty();
		}
	}

	FBuildingComponentSCSEditorCustomization::CurrentComponent = InComponent;
}

bool FBuildingComponentSCSEditorCustomization::HandleViewportClick(const TSharedRef<FEditorViewportClient>& InViewportClient, class FSceneView& InView, class HHitProxy* InHitProxy, FKey InKey, EInputEvent InEvent, uint32 InHitX, uint32 InHitY)
{
	if (InHitProxy != NULL && InHitProxy->IsA(HInstancedStaticMeshInstance::StaticGetType()))
	{
		HInstancedStaticMeshInstance* InstancedStaticMeshInstanceProxy = static_cast<HInstancedStaticMeshInstance*>(InHitProxy);

		const bool bIsCtrlKeyDown = InViewportClient->Viewport->KeyState(EKeys::LeftControl) || InViewportClient->Viewport->KeyState(EKeys::RightControl);
		const bool bIsAltKeyDown = InViewportClient->Viewport->KeyState(EKeys::LeftAlt);
		const bool bCurrentSelection = InstancedStaticMeshInstanceProxy->Component->IsInstanceSelected(InstancedStaticMeshInstanceProxy->InstanceIndex);

		/*if (!bIsAltKeyDown)
		{
			InstancedStaticMeshInstanceProxy->Component->SelectInstance(false, 0, InstancedStaticMeshInstanceProxy->Component->PerInstanceSMData.Num());
		}
		InstancedStaticMeshInstanceProxy->Component->SelectInstance(bIsAltKeyDown ? !bCurrentSelection : true, InstancedStaticMeshInstanceProxy->InstanceIndex);
		InstancedStaticMeshInstanceProxy->Component->MarkRenderStateDirty();*/

		auto hism = Cast<UHierarchicalInstancedStaticMeshComponent>(InstancedStaticMeshInstanceProxy->Component);
		if (hism) {
			auto components = UBuildingComponent::GetAllComponents(hism, true, false);
			for (auto link : components)
			{
				// mark in scope transaction
				link.Component->Modify();

				auto ihism = Cast<UHierarchicalInstancedStaticMeshComponent>(link.Component);
				if (ihism) {
					ihism->BuildTreeIfOutdated(false, true);
				}
				if (!bIsAltKeyDown)
				{
					//link.Component->SelectInstance(false, 0, link.Component->PerInstanceSMData.Num());
					link.Component->ClearInstanceSelection();
				}
				link.Component->SelectInstance(bIsAltKeyDown ? !bCurrentSelection : true, InstancedStaticMeshInstanceProxy->InstanceIndex);
				auto bc = Cast<UBuildingComponent>(link.Component);
				if (bc) {
					bc->RebuildSelection();
				}
			}
		}

		if (BlueprintEditorPtr.IsValid())
		{
			// Note: This will find and select any node associated with the component instance that's attached to the proxy (including visualizers)
			auto node = BlueprintEditorPtr.Pin()->FindAndSelectSCSEditorTreeNode(InstancedStaticMeshInstanceProxy->Component, bIsCtrlKeyDown);
			/*if (node.IsValid()) {
				auto v = node.Get();
				v->
			}*/
		}

		return true;
	}

	return false;
}

bool FBuildingComponentSCSEditorCustomization::HandleViewportDrag(class USceneComponent* InSceneComponent, class USceneComponent* InComponentTemplate, const FVector& InDeltaTranslation, const FRotator& InDeltaRotation, const FVector& InDeltaScale, const FVector& InPivot)
{
	check(InSceneComponent->IsA(UInstancedStaticMeshComponent::StaticClass()));

	UInstancedStaticMeshComponent* InstancedStaticMeshComponentScene = CastChecked<UInstancedStaticMeshComponent>(InSceneComponent);
	UInstancedStaticMeshComponent* InstancedStaticMeshComponentTemplate = CastChecked<UInstancedStaticMeshComponent>(InComponentTemplate);

	// transform pivot into component's space
	const FVector LocalPivot = InstancedStaticMeshComponentScene->GetComponentToWorld().InverseTransformPosition(InPivot);

	// Ensure that selected instances are up-to-date
	ValidateSelectedInstances(InstancedStaticMeshComponentScene);

	bool bMovedInstance = false;
	check(InstancedStaticMeshComponentScene->SelectedInstances.Num() == InstancedStaticMeshComponentScene->PerInstanceSMData.Num());
	for (int32 InstanceIndex = 0; InstanceIndex < InstancedStaticMeshComponentScene->SelectedInstances.Num(); InstanceIndex++)
	{
		if (InstancedStaticMeshComponentScene->SelectedInstances[InstanceIndex] && InstancedStaticMeshComponentTemplate->PerInstanceSMData.IsValidIndex(InstanceIndex))
		{
			const FMatrix& MatrixScene = InstancedStaticMeshComponentScene->PerInstanceSMData[InstanceIndex].Transform;

			FVector Translation = MatrixScene.GetOrigin();
			FRotator Rotation = MatrixScene.Rotator();
			FVector Scale = MatrixScene.GetScaleVector();

			FVector NewTranslation = Translation;
			FRotator NewRotation = Rotation;
			FVector NewScale = Scale;

			if (!InDeltaRotation.IsZero())
			{
				NewRotation = FRotator(InDeltaRotation.Quaternion() * Rotation.Quaternion());

				NewTranslation -= LocalPivot;
				NewTranslation = FRotationMatrix(InDeltaRotation).TransformPosition(NewTranslation);
				NewTranslation += LocalPivot;
			}

			NewTranslation += InDeltaTranslation;

			if (!InDeltaScale.IsNearlyZero())
			{
				const FScaleMatrix ScaleMatrix(InDeltaScale);

				FVector DeltaScale3D = ScaleMatrix.TransformPosition(Scale);
				NewScale = Scale + DeltaScale3D;

				NewTranslation -= LocalPivot;
				NewTranslation += ScaleMatrix.TransformPosition(NewTranslation);
				NewTranslation += LocalPivot;
			}

			FMatrix& DefaultValue = InstancedStaticMeshComponentTemplate->PerInstanceSMData[InstanceIndex].Transform;
			const FTransform NewTransform(NewRotation, NewTranslation, NewScale);
			//InstancedStaticMeshComponentScene->UpdateInstanceTransform(InstanceIndex, NewTransform);

			//// Propagate the change to all other instances of the template.
			//TArray<UObject*> ArchetypeInstances;
			//InstancedStaticMeshComponentTemplate->GetArchetypeInstances(ArchetypeInstances);

			//TArray<USceneComponent*> all_children;

			//for (UObject* ArchetypeInstance : ArchetypeInstances)
			//{
			//	UInstancedStaticMeshComponent* InstancedStaticMeshComponent = CastChecked<UInstancedStaticMeshComponent>(ArchetypeInstance);
			//	if (InstancedStaticMeshComponent->PerInstanceSMData.IsValidIndex(InstanceIndex))
			//	{
			//		if (InstancedStaticMeshComponent->PerInstanceSMData[InstanceIndex].Transform.Equals(DefaultValue))
			//		{
			//			InstancedStaticMeshComponent->UpdateInstanceTransform(InstanceIndex, NewTransform, false, true, true);

			//			TArray<USceneComponent*> children;
			//			InstancedStaticMeshComponent->GetChildrenComponents(true, children);

			//			all_children.Append(children);
			//		}
			//	}
			//}
			bool ChildrenAreAttachments = false;
			auto bc = Cast<UBuildingComponent>(InstancedStaticMeshComponentScene);
			if (bc) {
				ChildrenAreAttachments = bc->ChildrenAreAttachments;
			}

			auto components = UBuildingComponent::GetAllComponents(InstancedStaticMeshComponentTemplate, true, ChildrenAreAttachments);
			for (auto link : components)
			{
				UInstancedStaticMeshComponent* InstancedStaticMeshComponent = link.Component;
				if (InstancedStaticMeshComponent->PerInstanceSMData.IsValidIndex(InstanceIndex))
				{
					//if (InstancedStaticMeshComponent->PerInstanceSMData[InstanceIndex].Transform.Equals(DefaultValue))
					{
						InstancedStaticMeshComponent->UpdateInstanceTransform(InstanceIndex, NewTransform, false, true, true);
					}
				}
			}
			//components = UBuildingComponent::GetAllComponents(InstancedStaticMeshComponentScene, true, ChildrenAreAttachments);
			//for (auto link : components)
			//{
			//	UInstancedStaticMeshComponent* InstancedStaticMeshComponent = link.Component;
			//	if (InstancedStaticMeshComponent->PerInstanceSMData.IsValidIndex(InstanceIndex))
			//	{
			//		//if (InstancedStaticMeshComponent->PerInstanceSMData[InstanceIndex].Transform.Equals(DefaultValue))
			//		{
			//			InstancedStaticMeshComponent->UpdateInstanceTransform(InstanceIndex, NewTransform, false, true, true);
			//		}
			//	}
			//}

			// Update the template.
			InstancedStaticMeshComponentTemplate->Modify();
			DefaultValue = InstancedStaticMeshComponentScene->PerInstanceSMData[InstanceIndex].Transform;

			bMovedInstance = true;

			//// mirror to children/attachments
			//auto bc = Cast<UBuildingComponent>(InstancedStaticMeshComponentScene);
			//if (bc && bc->ChildrenAreAttachments) {
			//	// add the view port instances
			//	TArray<USceneComponent*> real_children, template_children;
			//	InstancedStaticMeshComponentScene->GetChildrenComponents(true, real_children);
			//	InstancedStaticMeshComponentTemplate->GetChildrenComponents(true, template_children);

			//	UBuildingComponent::FindAllChildrenComponents(InstancedStaticMeshComponentScene, real_children);
			//	UBuildingComponent::FindAllChildrenComponents(InstancedStaticMeshComponentTemplate, template_children);

			//	all_children.Append(real_children);
			//	all_children.Append(template_children);

			//	TArray< UBuildingComponent*> processed;
			//	for (int i = 0; i < all_children.Num(); i++) {
			//		auto sub_building = Cast<UBuildingComponent>(all_children[i]);
			//		if (sub_building && !processed.Contains(sub_building)) {
			//			sub_building->UpdateInstanceTransform(InstanceIndex, NewTransform, false, true, true);
			//			processed.Add(sub_building);
			//		}
			//	}
			//}
		}
	}

	return bMovedInstance;
}

bool FBuildingComponentSCSEditorCustomization::HandleGetWidgetLocation(class USceneComponent* InSceneComponent, FVector& OutWidgetLocation)
{
	// location is average of selected instances
	float SelectedInstanceCount = 0.0f;
	FVector AverageLocation = FVector::ZeroVector;
	UInstancedStaticMeshComponent* InstancedStaticMeshComponent = CastChecked<UInstancedStaticMeshComponent>(InSceneComponent);

	// Ensure that selected instances are up-to-date
	ValidateSelectedInstances(InstancedStaticMeshComponent);

	for (int32 InstanceIndex = 0; InstanceIndex < InstancedStaticMeshComponent->SelectedInstances.Num(); InstanceIndex++)
	{
		if (InstancedStaticMeshComponent->SelectedInstances[InstanceIndex])
		{
			AverageLocation += InstancedStaticMeshComponent->GetComponentToWorld().TransformPosition(InstancedStaticMeshComponent->PerInstanceSMData[InstanceIndex].Transform.GetOrigin());
			SelectedInstanceCount += 1.0f;
		}
	}

	if (SelectedInstanceCount > 0.0f)
	{
		OutWidgetLocation = AverageLocation / SelectedInstanceCount;
		return true;
	}

	return false;
}

bool FBuildingComponentSCSEditorCustomization::HandleGetWidgetTransform(class USceneComponent* InSceneComponent, FMatrix& OutWidgetTransform)
{
	// transform is first selected instance
	bool bInstanceSelected = false;
	UInstancedStaticMeshComponent* InstancedStaticMeshComponent = CastChecked<UInstancedStaticMeshComponent>(InSceneComponent);

	// Ensure that selected instances are up-to-date
	ValidateSelectedInstances(InstancedStaticMeshComponent);

	for (int32 InstanceIndex = 0; InstanceIndex < InstancedStaticMeshComponent->SelectedInstances.Num(); InstanceIndex++)
	{
		if (InstancedStaticMeshComponent->SelectedInstances[InstanceIndex])
		{
			OutWidgetTransform = FRotationMatrix(InstancedStaticMeshComponent->PerInstanceSMData[InstanceIndex].Transform.Rotator());
			return true;
		}
	}

	return false;
}

#define LOCTEXT_NAMESPACE "MyClassDetails"

TSharedRef<IDetailCustomization> FBuildingComponentDetails::MakeInstance()
{
	return MakeShareable(new FBuildingComponentDetails);
}

void FBuildingComponentDetails::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder)
{
	this->CachedDetailBuilder = &DetailBuilder;

	// Create a category so this is displayed early in the properties
	IDetailCategoryBuilder& MyCategory = DetailBuilder.EditCategory("InstanceActions", LOCTEXT("Instance Actions", "Instance Actions"), ECategoryPriority::Important);

	//You can get properties using the detailbuilder
//MyProperty= DetailBuilder.GetProperty(GET_MEMBER_NAME_CHECKED(MyClass, MyClassPropertyName));

	ObjectsBeingCustomized.Empty();
	DetailBuilder.GetObjectsBeingCustomized(/*out*/ ObjectsBeingCustomized);

	MyCategory.AddCustomRow(LOCTEXT("Instance Actions", "Instance Actions"))
	.WholeRowContent()
	[
		SNew(SVerticalBox)

		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SHorizontalBox)

			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(2.0f, 0.0f)
			.VAlign(VAlign_Center)
			.HAlign(HAlign_Left)
			[
				SNew(SButton)
				.Text(LOCTEXT("Duplicate Selected Instances", "Duplicate Selected Instances"))
				.ToolTipText(LOCTEXT("DuplicateSelectedInstances_ToolTip", "Duplicates all selected instances"))
				.OnClicked(this, &FBuildingComponentDetails::DuplicateSelectedInstances)
			]

			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(2.0f, 0.0f)
			.VAlign(VAlign_Center)
			.HAlign(HAlign_Left)
			[
				SNew(SButton)
				.Text(LOCTEXT("Select all Instances", "Select all Instances"))
				.ToolTipText(LOCTEXT("SelectAllInstances_ToolTip", "Selects all instances"))
				.OnClicked(this, &FBuildingComponentDetails::SelectAllInstances)
			]
		]

		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SHorizontalBox)

			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(2.0f, 0.0f)
			.VAlign(VAlign_Center)
			.HAlign(HAlign_Left)
			[
				SNew(SButton)
				.Text(LOCTEXT("Select half", "Select half"))
				.ToolTipText(LOCTEXT("SelectHalfInstances_ToolTip", "Selects half of the instances"))
				.OnClicked(this, &FBuildingComponentDetails::SelectHalfInstances)
			]

			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(2.0f, 0.0f)
			.VAlign(VAlign_Center)
			.HAlign(HAlign_Left)
			[
				SNew(SButton)
				.Text(LOCTEXT("Delete selected", "Delete selected"))
				.ToolTipText(LOCTEXT("DeleteSelectedInstances_ToolTip", "Delete selected instances"))
				.OnClicked(this, &FBuildingComponentDetails::DeleteSelectedInstances)
			]
		]

		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SHorizontalBox)

			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(2.0f, 0.0f)
			.VAlign(VAlign_Center)
			.HAlign(HAlign_Left)
			[
				SNew(SButton)
				.Text(LOCTEXT("Sync children", "Sync children"))
			.ToolTipText(LOCTEXT("SyncChildren_ToolTip", "Syncs all children components and ensures their instance count is at least the same count as this component"))
			.OnClicked(this, &FBuildingComponentDetails::SyncChildren)
			]

			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(2.0f, 0.0f)
			.VAlign(VAlign_Center)
			.HAlign(HAlign_Left)
			[
				SNew(SButton)
				.Text(LOCTEXT("Sync defaults", "Sync defaults"))
				.ToolTipText(LOCTEXT("SyncDefaults_ToolTip", "Syncs all instances to use the defaults from this component"))
				.OnClicked(this, &FBuildingComponentDetails::SyncDefaults)
			]
		]
	];
}

#undef LOCTEXT_NAMESPACE