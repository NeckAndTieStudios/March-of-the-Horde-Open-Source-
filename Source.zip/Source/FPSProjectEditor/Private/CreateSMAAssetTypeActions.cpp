#include "CreateSMAAssetTypeActions.h"
#include "Engine/StaticMesh.h"

#include "AssetToolsModule.h"
#include "Editor.h"
#include "EditorModeManager.h"
#include "Engine/Selection.h"
#include "EngineUtils.h"
#include "Framework/Commands/UICommandList.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "Framework/MultiBox/MultiBoxExtender.h"
#include "Framework/Notifications/NotificationManager.h"
#include "Framework/SlateDelegates.h"
#include "LevelEditor.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "Widgets/SNullWidget.h"

#define LOCTEXT_NAMESPACE "AssetTypeActions"

const FString UEditorCommon::DatabaseName = FString("Game");
const FString UEditorCommon::DatabasePath = FString("Database/Game.db");
sqlite3* UEditorCommon::SqliteDatabase = NULL;

FCreateSMAAssetTypeActions::FCreateSMAAssetTypeActions(EAssetTypeCategories::Type InAssetCategory)
	:MyAssetCategory(InAssetCategory)
{

}

FText FCreateSMAAssetTypeActions::GetName() const
{
	return LOCTEXT("CreateSMABpFromThis", "Create StaticMeshActor using this...");
}

UClass* FCreateSMAAssetTypeActions::GetSupportedClass() const
{
	return UStaticMesh::StaticClass();
}

FColor FCreateSMAAssetTypeActions::GetTypeColor() const
{
	return FColorList::BrightGold;
}

void FCreateSMAAssetTypeActions::GetResolvedSourceFilePaths(const TArray<UObject*>& TypeAssets, TArray<FString>& OutSourceFilePaths) const
{

}

uint32 FCreateSMAAssetTypeActions::GetCategories()
{
	return MyAssetCategory;
}

#undef LOCTEXT_NAMESPACE


#define LOCTEXT_NAMESPACE "MeshMergingTool"

FMOTHMeshMergingTool::FMOTHMeshMergingTool()
	: bReplaceSourceActors(false)
{
	//SettingsObject = UMOTHMeshMergingSettingsObject::Get();

	//Settings.bMergePhysicsData = true;
	// In this case set to AllLODs value since calculating the LODs is not possible and thus disabled in the UI
	//Settings.LODSelectionType = EMeshLODSelectionType::AllLODs;
}

//TSharedRef<SWidget> FMOTHMeshMergingTool::GetWidget()
//{
//	//SAssignNew(MergingDialog, SMeshMergingDialog, this);
//	//return MergingDialog.ToSharedRef();
//	TSharedRef<SWidget> ref;
//	return ref;
//}
//
//FText FMOTHMeshMergingTool::GetTooltipText() const
//{
//	return LOCTEXT("MeshMergingToolTooltip", "Harvest geometry from selected actors and merge grouping them by materials.");
//}

FString FMOTHMeshMergingTool::GetDefaultPackageName() const
{
	FString PackageName = FPackageName::FilenameToLongPackageName(FPaths::ProjectContentDir() + TEXT("SM_MERGED"));

	USelection * SelectedActors = GEditor->GetSelectedActors();
	// Iterate through selected actors and find first static mesh asset
	// Use this static mesh path as destination package name for a merged mesh
	for (FSelectionIterator Iter(*SelectedActors); Iter; ++Iter)
	{
		AActor* Actor = Cast<AActor>(*Iter);
		if (Actor)
		{
			FString ActorName = Actor->GetName();
			PackageName = FString::Printf(TEXT("%s_%s"), *PackageName, *ActorName);
			break;
		}
	}

	if (PackageName.IsEmpty())
	{
		PackageName = MakeUniqueObjectName(NULL, UPackage::StaticClass(), *PackageName).ToString();
	}

	return PackageName;
}

bool FMOTHMeshMergingTool::RunMergeWithArgs()
{
//const FString& PackageName


	FString PackageName;
	bool first = false;

	TArray<TSharedPtr<FMergeComponentData>> SelectedComponents;

	//if (GEditor) {
	//	USelection* SelectedActors = GEditor->GetSelectedActors();
	//	for (FSelectionIterator Iter(*SelectedActors); Iter; ++Iter)
	//	{
	//		// We only care about actors that are referenced in the world for literals, and also in the same level as this blueprint
	//		AStaticMeshActor* Actor = Cast<AStaticMeshActor>(*Iter);
	//		if (Actor)
	//		{
	//			OutActors.Add(Actor);

	//			auto data = FMergeComponentData(Actor->GetStaticMeshComponent());
	//			//auto ref = TSharedPtr::ToSharedRef(data);
	//			TSharedPtr<FMergeComponentData> ref = MakeShareable(&data);
	//			SelectedComponents.Add(ref);
	//		}
	//	}
	//}

	const IMeshMergeUtilities& MeshUtilities = FModuleManager::Get().LoadModuleChecked<IMeshMergeModule>("MeshMergeUtilities").GetUtilities();
	USelection* SelectedActors = GEditor->GetSelectedActors();
	TArray<AActor*> Actors;
	TArray<ULevel*> UniqueLevels;
	for (FSelectionIterator Iter(*SelectedActors); Iter; ++Iter)
	{
		AStaticMeshActor* Actor = Cast<AStaticMeshActor>(*Iter);
		if (Actor)
		{
			Actors.Add(Actor);
			UniqueLevels.AddUnique(Actor->GetLevel());

			//auto data = FMergeComponentData(Actor->GetStaticMeshComponent());
			////auto ref = TSharedPtr::ToSharedRef(data);
			//TSharedPtr<FMergeComponentData> ref = MakeShareable(&data);
			//SelectedComponents.Add(ref);


			TArray<UPrimitiveComponent*> PrimComponents;
			Actor->GetComponents<UPrimitiveComponent>(PrimComponents);
			for (UPrimitiveComponent* PrimComponent : PrimComponents)
			{
				SelectedComponents.Add(TSharedPtr<FMergeComponentData>(new FMergeComponentData(PrimComponent)));
			}

			if (!first) {
				first = true;
				
				IContentBrowserSingleton& ContentBrowserSingleton = FModuleManager::LoadModuleChecked<FContentBrowserModule>("ContentBrowser").Get();
				TArray<FString> SelectedFolders;
				ContentBrowserSingleton.GetSelectedPathViewFolders(SelectedFolders);
				FString AssetFolder = SelectedFolders.Num() > 0 ? SelectedFolders[0] : "/Game";
				FString AssetPath = AssetFolder + "/SM_MERGED_" + Actor->GetName();

				FString AssetName;
				IAssetTools& AssetTools = FModuleManager::Get().LoadModuleChecked<FAssetToolsModule>("AssetTools").Get();
				AssetTools.CreateUniqueAssetName(*AssetPath, TEXT(""), PackageName, AssetName);

			}
		}
	}

	if (!first)
	{
		return false;
	}

	// This restriction is only for replacement of selected actors with merged mesh actor
	if (UniqueLevels.Num() > 1 && bReplaceSourceActors)
	{
		//FText Message = NSLOCTEXT("UnrealEd", "FailedToMergeActorsSublevels_Msg", "The selected actors should be in the same level");
		//OpenMsgDlgInt(EAppMsgType::Ok, Message, NSLOCTEXT("UnrealEd", "FailedToMergeActors_Title", "Unable to merge actors"));
		return false;
	}

	FVector MergedActorLocation;
	TArray<UObject*> AssetsToSync;
	// Merge...
	{
		FScopedSlowTask SlowTask(0, LOCTEXT("MergingActorsSlowTask", "Merging actors..."));
		SlowTask.MakeDialog();

		// Extracting static mesh components from the selected mesh components in the dialog
		//const TArray<TSharedPtr<FMergeComponentData>>& SelectedComponents = MergingDialog->GetSelectedComponents();
		TArray<UPrimitiveComponent*> ComponentsToMerge;

		for (const TSharedPtr<FMergeComponentData>& SelectedComponent : SelectedComponents)
		{
			// Determine whether or not this component should be incorporated according the user settings
			if (SelectedComponent->bShouldIncorporate && SelectedComponent->PrimComponent.IsValid())
			{
				ComponentsToMerge.Add(SelectedComponent->PrimComponent.Get());
			}
		}

		if (ComponentsToMerge.Num())
		{
			UWorld* World = ComponentsToMerge[0]->GetWorld();
			checkf(World != nullptr, TEXT("Invalid World retrieved from Mesh components"));
			const float ScreenAreaSize = TNumericLimits<float>::Max();
			//const FMeshMergingSettings settings = this->Settings;


			FMeshMergingSettings Settings;
			Settings.SpecificLOD = 0;
			Settings.LODSelectionType = EMeshLODSelectionType::AllLODs;
			Settings.bMergePhysicsData = true;

			const FMeshMergingSettings settings = Settings;
			MeshUtilities.MergeComponentsToStaticMesh(ComponentsToMerge, World, settings, nullptr, nullptr, PackageName, AssetsToSync, MergedActorLocation, ScreenAreaSize, true);
		}
	}

	if (AssetsToSync.Num())
	{
		FAssetRegistryModule& AssetRegistry = FModuleManager::Get().LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
		int32 AssetCount = AssetsToSync.Num();
		for (int32 AssetIndex = 0; AssetIndex < AssetCount; AssetIndex++)
		{
			AssetRegistry.AssetCreated(AssetsToSync[AssetIndex]);
			GEditor->BroadcastObjectReimported(AssetsToSync[AssetIndex]);
		}

		//Also notify the content browser that the new assets exists
		FContentBrowserModule& ContentBrowserModule = FModuleManager::Get().LoadModuleChecked<FContentBrowserModule>("ContentBrowser");
		ContentBrowserModule.Get().SyncBrowserToAssets(AssetsToSync, true);

		// Place new mesh in the world
		if (bReplaceSourceActors)
		{
			UStaticMesh* MergedMesh = nullptr;
			if (AssetsToSync.FindItemByClass(&MergedMesh))
			{
				const FScopedTransaction Transaction(LOCTEXT("PlaceMergedActor", "Place Merged Actor"));
				UniqueLevels[0]->Modify();

				UWorld* World = UniqueLevels[0]->OwningWorld;
				FActorSpawnParameters Params;
				Params.OverrideLevel = UniqueLevels[0];
				FRotator MergedActorRotation(ForceInit);

				AStaticMeshActor* MergedActor = World->SpawnActor<AStaticMeshActor>(MergedActorLocation, MergedActorRotation, Params);
				MergedActor->GetStaticMeshComponent()->SetStaticMesh(MergedMesh);
				MergedActor->SetActorLabel(AssetsToSync[0]->GetName());
				World->UpdateCullDistanceVolumes(MergedActor, MergedActor->GetStaticMeshComponent());
				// Remove source actors
				for (AActor* Actor : Actors)
				{
					Actor->Destroy();
				}
			}
		}
	}

	return true;
}

//bool FMOTHMeshMergingTool::RunMerge(const FString& PackageName)
//{
//	return false;
//	//TArray<TSharedPtr<FMergeComponentData>> SelectedComponents;
//
//	//MergingDialog->Reset();
//	//return RunMergeWithArgs(PackageName, *SelectedComponents);
//}
//
//bool FMOTHMeshMergingTool::CanMerge() const
//{
//	return false;
//	//return MergingDialog->GetNumSelectedMeshComponents() >= 1;
//}

#undef LOCTEXT_NAMESPACE
//
//#include "UI/EditorUIExtender.h"
//
//#include "Prefab/PrefabActor.h"
//#include "Prefab/PrefabTools.h"
//#include "Prefab/Random/PrefabSeedLinker.h"
//#include "PrefabEditorCommands.h"
//#include "PrefabEditorStyle.h"
//#include "Utils/PrefabEditorTools.h"


#define LOCTEXT_NAMESPACE "EditorUIExtender" 

void FEditorUIExtender::Extend()
{
	struct Local {

		static TSharedRef<FExtender> OnExtendLevelEditorActorContextMenu(const TSharedRef<FUICommandList> CommandList, const TArray<AActor*> SelectedActors) {
			TSharedRef<FExtender> Extender(new FExtender());

			if (SelectedActors.Num() > 0)
			{
				// Add asset actions extender
				Extender->AddMenuExtension(
					"ActorControl",
					EExtensionHook::After,
					CommandList,
					FMenuExtensionDelegate::CreateStatic(&Local::CreateActionMenu, SelectedActors));
			}

			return Extender;
		}

		static void CreateActionMenu(class FMenuBuilder& MenuBuilder, const TArray<AActor*> SelectedActors) {
			//if (ContextType == LevelEditorMenuContext::Viewport)
			MenuBuilder.AddMenuEntry
			(
				LOCTEXT("MOTHMergeActorsTitle", "Merge Actors (MOTH)"),
				LOCTEXT("MOTHMergeActorsText", "Merge the current selection of actors"),
				//FSlateIcon(FPrefabEditorStyle::Get().GetStyleSetName(), "Prefabricator.ContextMenu.Icon"),
				FSlateIcon(),
				FUIAction
				(
					FExecuteAction::CreateStatic(&UEditorCommon::MOTHMergeActors)
				)
			);
		}
	};

	FLevelEditorModule& LevelEditorModule = FModuleManager::Get().LoadModuleChecked<FLevelEditorModule>("LevelEditor");
	auto& MenuExtenders = LevelEditorModule.GetAllLevelViewportContextMenuExtenders();

	MenuExtenders.Add(FLevelEditorModule::FLevelViewportMenuExtender_SelectedActors::CreateStatic(&Local::OnExtendLevelEditorActorContextMenu));
	/*LevelViewportExtenderHandle = MenuExtenders.Last().GetHandle();

	LevelToolbarExtender = MakeShareable(new FExtender);
	LevelToolbarExtender->AddToolBarExtension(
		"Settings",
		EExtensionHook::After,
		FPrefabricatorCommands::Get().LevelMenuActionList,
		FToolBarExtensionDelegate::CreateStatic(&Local::ExtendLevelToolbar)
	);

	LevelEditorModule.GetToolBarExtensibilityManager().Get()->AddExtender(LevelToolbarExtender);*/
}

void FEditorUIExtender::Release()
{
	FLevelEditorModule* LevelEditorModule = FModuleManager::Get().GetModulePtr<FLevelEditorModule>("LevelEditor");
	if (LevelEditorModule)
	{
		if (LevelViewportExtenderHandle.IsValid())
		{
			typedef FLevelEditorModule::FLevelViewportMenuExtender_SelectedActors DelegateType;
			LevelEditorModule->GetAllLevelViewportContextMenuExtenders().RemoveAll([=](const DelegateType & In) { return In.GetHandle() == LevelViewportExtenderHandle; });
		}

		if (LevelEditorModule->GetToolBarExtensibilityManager().IsValid()) {
			LevelEditorModule->GetToolBarExtensibilityManager().Get()->RemoveExtender(LevelToolbarExtender);
		}
	}
}

#undef LOCTEXT_NAMESPACE