// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AvailableIngredient.h"
#include "ItemInstance.h"
#include "AvailableIngredientResult.generated.h"

USTRUCT(BlueprintType)
struct FAvailableIngredientResult
{
	GENERATED_USTRUCT_BODY()
public:
	UPROPERTY(EditAnywhere, Category = Item, BlueprintReadWrite)
		bool IsFulfilled;

	UPROPERTY(EditAnywhere, Category = Item, BlueprintReadWrite)
		TArray<FItemData> RequiredIngredients;

	UPROPERTY(EditAnywhere, Category = Item, BlueprintReadWrite)
		TArray<FAvailableIngredient> Results;

	FAvailableIngredientResult() {}

	FAvailableIngredientResult(bool isFulfilled, TArray<FAvailableIngredient> results, TArray<FItemData> requiredIngredients)
	{
		this->IsFulfilled = isFulfilled;
		this->Results = results;
		this->RequiredIngredients = requiredIngredients;
	}

	float DetermineMaxAmount(float fulfill_amount)
	{
		for (int i = 0; i < this->RequiredIngredients.Num(); i++)
		{
			//float total_required = ingredients[i]->Stack * amount;

			// find the required item from the ingredient results
			for (int x = 0; x < this->Results.Num(); x++)
			{
				auto ingredient_result = this->Results[x];
				if (ingredient_result.Ingredient.ItemID == this->RequiredIngredients[i].ItemID)
				{
					if (ingredient_result.Available < this->RequiredIngredients[i].Stack) {
						// cannot fulfil this item
						return 0;
					}

					int max_items_possible = ingredient_result.Available / ingredient_result.Ingredient.Stack/*Required*/;
					if (max_items_possible < fulfill_amount) {
						fulfill_amount = max_items_possible;
					}

					break;
				}
			}
		}
		return fulfill_amount;
	}

	void Deduct()
	{
		for (int i = 0; i < this->RequiredIngredients.Num(); i++)
		{
			float total_required = this->RequiredIngredients[i].Stack;

			// find the required item from the ingredient results
			for (int x = 0; x < this->Results.Num(); x++)
			{
				auto ingredient_result = this->Results[x];
				if (ingredient_result.Ingredient.ItemID == this->RequiredIngredients[i].ItemID)
				{
					// find the item from the ingredient results
					for (int s = 0; s < ingredient_result.Items.Num(); s++)
					{
						auto slot = &ingredient_result.Items[s].Container->Items[ingredient_result.Items[s].SlotID];
						if (/*slot*/slot->ItemID > 0) {
							auto amount_to_deduct = FMath::Min(slot->Stack, total_required);

							total_required -= amount_to_deduct;
							slot->Stack -= amount_to_deduct;

							/*if (slot->Stack <= 0) {
								slot->OnClear();
							}*/
						}
					}

					break;
				}
			}
		}
	}
};