// Fill out your copyright notice in the Description page of Project Settings.

#include "HitComponent.h"
#include "Engine.h"
#include "DrawDebugHelpers.h"
#include "FPSCharacter.h"
//
//// Sets default values
//UHitComponent::UHitComponent()
//{
//	PrimaryComponentTick.bCanEverTick = true; // will be disabled when not required
//
//	// InitializeComponent
//	bWantsInitializeComponent = true;
//}
//
//// Called when the game starts or when spawned
//void UHitComponent::BeginPlay()
//{
//	Super::BeginPlay();
//
//	this->GameInstance = this->GetWorld()->GetGameInstance<UGlobalGameInstance>();
//
//	SetComponentTickEnabled(false);
//
//	/*auto owner = this->GetOwner();
//	owner->SetMobility();*/
//
//
//	//auto w = actor->GetVelocity().SizeSquared();
//}
//
//// Called every frame
//void UHitComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
//{
//	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
//
//	//if (this->HitInstance.IsDestroyed) {
//	//	auto owner = this->GetOwner();
//	//	this->CurrentRotation = FMath::RInterpTo(this->CurrentRotation, FRotator(0.f, 0.f, 90.f), DeltaTime, 5.0f);
//
//	//	//owner->SetActorRotation(this->CurrentRotation);
//	//	owner->GetRootComponent()->SetWorldRotation(this->CurrentRotation);
//	//}
//
//	//if (!this->HitInstance.IsDestroyed) {
//	//	// if we are falling (the actor), and have not moved then we can despawn
//	//	AActor * actor = this->GetOwner();
//	//	if (actor) {
//	//		float movement = actor->GetVelocity().SizeSquared();
//	//		GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Movement: ").Append(FString::SanitizeFloat(movement)));
//	//		if (movement <= 0) {
//	//			this->Despawn();
//	//			//SetComponentTickEnabled(false);
//
//	//			//// tick is now disabled, so we can notify hooks of despawn
//	//			//this->OnDespawn();
//
//	//			/*if (this->DestroyDelay <= 0) {
//	//				this->OnDestroy();
//	//			}
//	//			else {
//	//				actor->GetWorldTimerManager().SetTimer(OnDespawnHandle, this, &UHitComponent::OnDestroy, this->DestroyDelay, false);
//	//			}*/
//	//		}
//	//	}
//	//	else {
//	//		GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("No actor"));
//	//	}
//	//}
//}
//
//void UHitComponent::ApplyDamage(FHitResult hit_result, float damage, AActor * initiator)
//{
//	//if (this->HitInstance.Health > 0.f) {
//	//	auto character = static_cast<AFPSCharacter *>(initiator);
//	//	if (character) {
//	//		/*if (this->HitInstance.HitLoot) {
//	//			for (int i = 0; i < this->HitInstance.HitLoot.Num(); i++) {
//	//				if (this->HitInstance.HitLoot[i].LootTexture) {
//
//	//				}
//	//			}
//	//		}*/
//	//	}
//	//}
//
//	bool killed = this->HitInstance.Health > 0.f;
//	this->HitInstance.Health -= damage;
//	killed = !killed && this->HitInstance.Health <= 0;
//
//	this->OnHit(hit_result, damage, killed, initiator);
//
//	if (killed) {
//		this->OnKilled();
//	}
//
//	//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Orange, FString("Updated health: ").Append(FString::SanitizeFloat(this->HitInstance.Health)));
//}
//
//UHitComponent * UHitComponent::GetInteraction(UGlobalGameInstance * gameInstance, FHitResult hit_result, EHitTrigger hitTrigger, AActor * initiator, FHitInteraction * interaction, UHitComponent * existingHitComponent)
//{
////	// TODO: modularise me
////
////	//FHitInteraction result;
////
////	auto hit_actor = hit_result.GetActor();
////
////	bool has_settings = false;
////	UHitComponent * hitComponent = existingHitComponent;
////	UClass * actor_class = NULL; // AStaticMeshActor::StaticClass();
////	FHitInstanceActor hit_instance_actor;
////	FHitInstance hit_instance;
////
////	// try process a foliage item - convert it over to a normal actor and remove the instance
////	auto ifm = Cast<UInstancedStaticMeshComponent>(hit_result.Component);
////	if (ifm) {
////		FTransform instanceTransform;
////		ifm->GetInstanceTransform(hit_result.Item, instanceTransform);
////
////		auto instanceMesh = ifm->GetStaticMesh();
////
////		//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("UInstancedStaticMeshComponent: ").Append(instanceMesh->GetName()));
////
////		for (int i = 0; i < gameInstance->HitSettingsMap.Num(); i++) {
////			auto hi = gameInstance->HitSettingsMap[i];
////			if (hi.HitTrigger == hitTrigger) {
////				for (int x = 0; x < hi.ApplicableActors.Num(); x++) {
////					if (hi.ApplicableActors[x].Name.Equals(instanceMesh->GetName())) {
////						hit_instance = hi;
////						hit_instance_actor = hi.ApplicableActors[x];
////						if (hi.ApplicableActors[x].ReplacementClass) {
////							actor_class = hi.ApplicableActors[x].ReplacementClass;
////						}
////						has_settings = true;
////						break;
////					}
////				}
////			}
////			if (has_settings)
////				break;
////		}
////
////		if (has_settings) {
////			if (actor_class) {
////				auto actor = hit_actor->GetWorld()->SpawnActor<AStaticMeshActor>(actor_class, instanceTransform, FActorSpawnParameters());
////
////				if (!hitComponent) {
////					hitComponent = Cast<UHitComponent>(actor->GetComponentByClass(UHitComponent::StaticClass()));
////					if (!hitComponent) {
////						// might get depreciated, thinking it may not be a good idea to auto create these
////						hitComponent = NewObject<UHitComponent>(actor, UHitComponent::StaticClass());
////						actor->SetMobility(EComponentMobility::Movable);
////						actor->GetStaticMeshComponent()->SetStaticMesh(instanceMesh);
////						actor->GetStaticMeshComponent()->SetWorldTransform(instanceTransform);
////
////						hitComponent->RegisterComponent(); // enables BeginPlay,Tick etc
/////*
////						hitComponent->HitInstance = hit_instance;
////						hitComponent->HitInstanceActor = hit_instance_actor;*/
////					}
////				}
////
////				// we can do this, as we are going to destroy this instance, and we want to transfer these details to the new actor
////				hitComponent->HitInstance = hit_instance;
////				hitComponent->HitInstanceActor = hit_instance_actor;
////
////				//actor->GetStaticMeshComponent()->SetSimulatePhysics(true);
////
////				hit_actor = actor;
////			}
////			ifm->RemoveInstance(hit_result.Item);
////		}
////		else {
////			//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Failed to find settings"));
////		}
////	}
////	else {
////		// no foliage
////		auto weapon = Cast<AWeapon>(hit_actor);
////		if (weapon) {
////			auto actorMesh = weapon->SkeletalMesh;
////
////			if (actorMesh && actorMesh->SkeletalMesh) {
////				for (int i = 0; i < gameInstance->HitSettingsMap.Num(); i++) {
////					auto hi = gameInstance->HitSettingsMap[i];
////					if (hi.HitTrigger == hitTrigger) {
////						for (int x = 0; x < hi.ApplicableActors.Num(); x++) {
////							if (hi.ApplicableActors[x].Name.Equals(actorMesh->SkeletalMesh->GetName())) {
////								hit_instance = hi;
////								hit_instance_actor = hi.ApplicableActors[x];
////								has_settings = true;
////								break;
////							}
////						}
////					}
////					if (has_settings)
////						break;
////				}
////
////				if (has_settings) {
////					if (!hitComponent) {
////						hitComponent = Cast<UHitComponent>(hit_actor->GetComponentByClass(UHitComponent::StaticClass()));
////						if (!hitComponent) {
////							hitComponent = NewObject<UHitComponent>(hit_actor, UHitComponent::StaticClass());
////
////							hitComponent->RegisterComponent(); // enables BeginPlay,Tick etc
////
////							hitComponent->HitInstance = hit_instance;
////							hitComponent->HitInstanceActor = hit_instance_actor;
////						}
////						/*else {
////							if (!hitComponent->HitInstance.IsActive) {
////								hitComponent->HitInstance = hit_instance;
////								hitComponent->HitInstanceActor = hit_instance_actor;
////							}
////						}*/
////						//else {
////						//	has_settings = true;
////						//	// trust that whoever created the component has the settings
////						//}
////					}
////
////					if (hitComponent && !hitComponent->HitInstance.IsActive) {
////						hitComponent->HitInstance = hit_instance;
////						hitComponent->HitInstanceActor = hit_instance_actor;
////					}
////				}
////				else {
////					GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString("Unregistered weapon: ").Append(actorMesh->SkeletalMesh->GetName()));
////				}
////			}
////		}
////		else {
////			// Try a general actor - some of these are converted from the foliage type
////
////			auto smActor = Cast<AStaticMeshActor>(hit_actor);
////			if (smActor) {
////				auto actorMeshComponent = smActor->GetStaticMeshComponent();
////				if (actorMeshComponent) {
////					auto actorMesh = actorMeshComponent->GetStaticMesh();
////
////					if (actorMesh) {
////						for (int i = 0; i < gameInstance->HitSettingsMap.Num(); i++) {
////							auto hi = gameInstance->HitSettingsMap[i];
////							if (hi.HitTrigger == hitTrigger) {
////								for (int x = 0; x < hi.ApplicableActors.Num(); x++) {
////									if (hi.ApplicableActors[x].Name.Equals(actorMesh->GetName())) {
////										hit_instance = hi;
////										hit_instance_actor = hi.ApplicableActors[x];
////										has_settings = true;
////										break;
////									}
////								}
////							}
////							if (has_settings)
////								break;
////						}
////
////
////						if (has_settings) {
////							if (!hitComponent) {
////								hitComponent = Cast<UHitComponent>(hit_actor->GetComponentByClass(UHitComponent::StaticClass()));
////								if (!hitComponent) {
////									hitComponent = NewObject<UHitComponent>(hit_actor, UHitComponent::StaticClass());
////
////									hitComponent->RegisterComponent(); // enables BeginPlay,Tick etc
////
////									hitComponent->HitInstance = hit_instance;
////									hitComponent->HitInstanceActor = hit_instance_actor;
////								}
////								//else {
////								//	has_settings = true;
////								//	// trust that whoever created the component has the settings
////								//}
////							}
////
////							if (hitComponent && !hitComponent->HitInstance.IsActive) {
////								hitComponent->HitInstance = hit_instance;
////								hitComponent->HitInstanceActor = hit_instance_actor;
////							}
////						}
////						else {
////							GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString("Unregistered static actor: ").Append(actorMesh->GetName()));
////						}
////					}
////				}
////			}
////			else {
////				// fallback to any existing component (or add one if we can)
////
////				if (!hitComponent) {
////					hitComponent = Cast<UHitComponent>(hit_actor->GetComponentByClass(UHitComponent::StaticClass()));
////				}
////
////				for (int i = 0; i < gameInstance->HitSettingsMap.Num(); i++) {
////					auto hi = gameInstance->HitSettingsMap[i];
////					if (hi.HitTrigger == hitTrigger) {
////						for (int x = 0; x < hi.ApplicableActors.Num(); x++) {
////							if (hi.ApplicableActors[x].Name.Equals(hit_actor->GetName())
////
////								//|| (hitComponent && hitComponent)
////								) {
////								hit_instance = hi;
////								hit_instance_actor = hi.ApplicableActors[x];
////								has_settings = true;
////								break;
////							}
////						}
////					}
////					if (has_settings)
////						break;
////				}
////
////				if (!hitComponent) {
////					if (has_settings) {
////						hitComponent = NewObject<UHitComponent>(hit_actor, UHitComponent::StaticClass());
////						hitComponent->HitInstance = hit_instance;
////						hitComponent->HitInstanceActor = hit_instance_actor;
////
////						hitComponent->RegisterComponent(); // enables BeginPlay,Tick etc
////					}
////					else {
////						GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString("Unregistered actor: ").Append(hit_actor->GetName()));
////					}
////				}
////				else {
////					has_settings = true;
////					// trust that whoever created the component has the settings
////				}
////
////				if (hitComponent && !hitComponent->HitInstance.IsActive) {
////					hitComponent->HitInstance = hit_instance;
////					hitComponent->HitInstanceActor = hit_instance_actor;
////				}
////			}
////		}
////	}
////
////	//result.HitComponent = hitComponent;
////	interaction->HitInstance = hit_instance;
////	interaction->HitInstanceActor = hit_instance_actor;
////
////	if (has_settings == true && hitComponent != NULL && (hitComponent->HitInstance.HitTrigger == hitTrigger || (hitComponent->HitTrigger == hitTrigger || hitComponent->HitTrigger == EHitTrigger::Any)) && hit_actor) {
////		//GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Green, FString("Hit component, actor: ").Append(hit_actor->GetName()));
////		return hitComponent;
////	}
////	else {
//		//GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString("No hit component, actor: ").Append(hit_actor->GetName()));
//		return NULL;
//	//}
//}
//
///*static*/void UHitComponent::ApplyInteraction(UGlobalGameInstance * gameInstance, FHitResult hit_result, float damage, EHitTrigger hitTrigger, AActor * initiator, UHitComponent * existingHitComponent)
//{
//	FHitInteraction interaction;
//	UHitComponent * hitComponent = UHitComponent::GetInteraction(gameInstance, hit_result, hitTrigger, initiator, &interaction, existingHitComponent);
//
//	if (hitComponent) {
//		hitComponent->OnInteraction(hitTrigger, hit_result, damage, initiator, interaction);
//		/*if (!cancel) {
//			if (hitComponent->HitTrigger == EHitTrigger::Any || hitComponent->HitTrigger == hitTrigger) {
//				hitComponent->ApplyDamage(hit_result, damage, initiator);
//			}
//			else if (interaction.HitInstance.HitTrigger == hitTrigger) {
//				auto player = Cast<AFPSCharacter>(initiator);
//				if (player) {
//					for (int i = 0; i < interaction.HitInstance.HitLoot.Num(); i++) {
//						player->GiveHitLoot(interaction.HitInstance.HitLoot[i]);
//					}
//				}
//			}
//		}*/
//	}
//}
//
//void UHitComponent::Despawn()
//{
//	//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Despawned"));
//	SetComponentTickEnabled(false);
//	this->OnDespawn();
//}
//
////void UHitComponent::OnDestroy()
////{
////	AActor * actor = this->GetOwner();
////	if (actor) {
////		//this->OnDropLoot();
////
////		/*
////		if (!actor->IsPendingKill())
////			actor->Destroy();
////		*/
////		switch (this->HitInstanceActor.DestroyAction) {
////		default:
////		case EDestroyAction::FadeOut:
////			GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("FadeOut"));
////			break;
////		}
////
////	}
////	else {
////		GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("No actor when destroying"));
////	}
////}
//
////void UHitComponent::OnDropLoot()
////{
////	if (is_destroyed) {
////		return;
////	}
////	is_destroyed = true;
////
////	AActor * actor = this->GetOwner();
////	GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("Dropping loot"));
////
////	if (this->HitInstanceActor.Loot.Num() > 0) {
////		for (int i = 0; i < this->HitInstanceActor.Loot.Num(); i++) {
////			FLoot loot = this->HitInstanceActor.Loot[i];
////
////			if (loot.ActorClass) {
////				FTransform actor_transform = actor->GetActorTransform(); // spawn with the same direction as the destroyed actor
////				FActorSpawnParameters params;
////				auto replacement_actor = actor->GetWorld()->SpawnActor<AActor>(loot.ActorClass, actor_transform);
////				GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Spawning: ").Append(loot.Name));
////			}
////			else {
////				GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("No hit instance actor loot actor class"));
////			}
////		}
////	}
////	else {
////		GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("No hit instance actor loot"));
////	}
////}