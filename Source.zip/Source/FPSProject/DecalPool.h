// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Components/DecalComponent.h"
#include "CoreMinimal.h"
#include "DecalPool.generated.h"

/* +=============================================
This is not the standard pool, this will simply cap the decals not batch spawn them

TODO: use this with a better name + UObjectPool
*/

UCLASS(Blueprintable, BlueprintType)
class FPSPROJECT_API UDecalPool : public UObject
{
	GENERATED_BODY()

protected:
	TArray<UDecalComponent*> pool;

	FTimerHandle CheckLimitHandle;

	UFUNCTION()
		void CheckLimit();
public:
	static UDecalPool * Instance;

	UDecalPool();
	~UDecalPool();

	UFUNCTION(BlueprintCallable)
		void Register(UDecalComponent* decal);

	UFUNCTION(BlueprintCallable)
		int GetCapacity();

	UFUNCTION(BlueprintImplementableEvent, Category = "Pool Events")
		void OnUnload(UDecalComponent* decal);

	void BeginWatching();
};
