// Fill out your copyright notice in the Description page of Project Settings.

#include "AssetItemComponent.h"
#include "UObject/ConstructorHelpers.h"
#include "CollisionQueryParams.h"
#include "Engine/World.h"
#include "Casts.h"
#include "DestructibleComponent.h"
#include "Particles/ParticleSystem.h"
#include "Kismet/GameplayStatics.h"
#include "DrawDebugHelpers.h"


// Sets default values for this component's properties
UAssetItemComponent::UAssetItemComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = false;

	//this->Spawn = CreateDefaultSubobject<USoundCue>(FName("Spawn"));
}


// Called when the game starts
void UAssetItemComponent::BeginPlay()
{
	Super::BeginPlay();

	this->GetOwner()->OnDestroyed.AddDynamic(this, &UAssetItemComponent::OnActorDestroyed);

	if (this->Spawn) {

		//UGameplayStatics::PlaySoundAtLocation(GetWorld(), this->Spawn, this->GetOwner()->GetActorLocation());
		this->AudioComponent = UGameplayStatics::SpawnSoundAtLocation(GetWorld(), this->Spawn, this->GetOwner()->GetActorLocation());

		////UAudioComponent * propellerAudioComponent = CreateDefaultSubobject<UAudioComponent>(TEXT("PropellerAudioComp"));
		//UAudioComponent * propellerAudioComponent = NewObject<UAudioComponent>(this->SpawnSound, UAudioComponent::StaticClass());

		//propellerAudioComponent->AttachToComponent(this->GetOwner()->GetRootComponent(), FAttachmentTransformRules::KeepRelativeTransform);
		////propellerAudioComponent->AttachTo(this->GetOwner()->GetRootComponent());

		////propellerAudioComponent->SetRelativeLocation(this->GetOwner()->Wo);

		//if (this->SpawnSound->IsValidLowLevelFast()) {
		//	propellerAudioComponent->SetSound(this->SpawnSound);
		//}
	}
}


// Called every frame
void UAssetItemComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	auto dm = this->GetOwner()->GetComponentByClass(UDestructibleComponent::StaticClass());
	if (dm)
	{
		if (dm->IsBeingDestroyed())
		{
			DrawDebugString(GetWorld(), this->GetOwner()->GetActorLocation() + FVector(0, 0, 250), TEXT("ACTIVE"));
		}
		else
		{
			DrawDebugString(GetWorld(), this->GetOwner()->GetActorLocation() + FVector(0, 0, 150), TEXT("NOT ACTIVE"));
		}
	}
}

void UAssetItemComponent::OnActorDestroyed(AActor* OtherActor)
{
	DrawDebugString(GetWorld(), this->GetOwner()->GetActorLocation() + FVector(0, 0, 50), TEXT("Destroyed"));
}

//UGlobalBulletSettings * UAssetItemComponent::GetBulletSettings()
//{
//	if (!this->BulletSettings || this->InheritBulletSettings) {
//		return NULL;
//	}
//	return this->BulletSettings;
//}

void UAssetItemComponent::DestroyComponent(bool bPromoteChildren)
{
	Super::DestroyComponent(bPromoteChildren);

	if (this->AudioComponent) {
		this->AudioComponent->DestroyComponent();
		this->AudioComponent = NULL;
	}
}