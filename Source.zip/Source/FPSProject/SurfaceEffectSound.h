// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Sound/SoundCue.h"
#include "Weighting.h"
#include "SurfaceEffectSound.generated.h"

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable)
class FPSPROJECT_API USurfaceEffectSound : public UObject
//USTRUCT(Blueprintable, BlueprintType)
//struct FPSPROJECT_API FSurfaceEffectSound : public FWeighting
{
	GENERATED_BODY()
	//GENERATED_USTRUCT_BODY()

public:
	// defines how many chances the item has of being used
	// 0 to disable
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weighting")
		float Weighting = 0.f;

	UPROPERTY(EditAnywhere, Category = "Surface Effect Sound")
		int SurfaceEffectSoundID;

	UPROPERTY(EditAnywhere, Category = "Surface Effect Sound")
		int SurfaceEffectID;

	UPROPERTY(EditAnywhere, Category = "Surface Effect Sound")
		USoundCue* Cue;

	/*UPROPERTY(EditAnywhere, Category = "Surface Effect Sound")
	float Weighting;*/
};

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable)
class FPSPROJECT_API USurfaceEffectDecal : public UObject
	//USTRUCT(Blueprintable, BlueprintType)
	//struct FPSPROJECT_API FSurfaceEffectDecal : public FWeighting
{
	GENERATED_BODY()
		//GENERATED_USTRUCT_BODY()

public:
	// defines how many chances the item has of being used
	// 0 to disable
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weighting")
		float Weighting = 0.f;

	UPROPERTY(EditAnywhere, Category = "Surface Effect Decal")
		int SurfaceEffectDecalID;

	UPROPERTY(EditAnywhere, Category = "Surface Effect Decal")
		int SurfaceEffectID;

	UPROPERTY(EditAnywhere, Category = "Surface Effect Decal")
		UObject* Decal;

	UPROPERTY(EditAnywhere, Category = "Surface Effect Decal")
		FVector DecalSize;

	/*UPROPERTY(EditAnywhere, Category = "Surface Effect Sound")
	float Weighting;*/
};

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable)
class FPSPROJECT_API USurfaceEffectParticle : public UObject
	//USTRUCT(Blueprintable, BlueprintType)
	//struct FPSPROJECT_API FSurfaceEffectDecal : public FWeighting
{
	GENERATED_BODY()
		//GENERATED_USTRUCT_BODY()

public:

	UPROPERTY(EditAnywhere, Category = "Surface Effect Particle")
		int SurfaceEffectParticleID;

	UPROPERTY(EditAnywhere, Category = "Surface Effect Particle")
		int SurfaceEffectID;

	UPROPERTY(EditAnywhere, Category = "Surface Effect Particle")
		UParticleSystem* Particle;

	UPROPERTY(EditAnywhere, Category = "Surface Effect Particle")
		FRotator Rotation;

	UPROPERTY(EditAnywhere, Category = "Surface Effect Particle")
		FVector Scale;

	// defines how many chances the item has of being used
	// 0 to disable
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect Particle")
		float Weighting = 0.f;
};