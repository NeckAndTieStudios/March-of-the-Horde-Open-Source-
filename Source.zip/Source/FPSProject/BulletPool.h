// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Bullet.h"
#include "CoreMinimal.h"

/* +=============================================
	TODO: MOVE TO USE UObjectPool
*/

DECLARE_STATS_GROUP(TEXT("BulletPool"), STATGROUP_BulletPool, STATCAT_Advanced);
DECLARE_CYCLE_STAT_EXTERN(TEXT("RequestBulletTypeFromPool"), STAT_RequestBulletTypeFromPool, STATGROUP_BulletPool, FPSPROJECT_API);
DECLARE_CYCLE_STAT_EXTERN(TEXT("ReturnBulletTypeToPool"), STAT_ReturnBulletTypeToPool, STATGROUP_BulletPool, FPSPROJECT_API);

class FPSPROJECT_API BulletPool
{
protected:
	TQueue<class ABullet*> * pool;

	void allocate();

	int block_size;
	UWorld * world;
	TSubclassOf<class ABullet> ProjectileClass;

	void ReleaseByArg(ABullet * bullet);

	int capacity = 0;
	int leased = 0;
	bool allow_increase = true;

public:
	BulletPool(int block_size, UWorld* world, TSubclassOf<class ABullet> ProjectileClass, bool allow_increase);
	~BulletPool();

	ABullet * Aquire(AActor* owner);
	void Release(ABullet * bullet);

	int GetCapacity();
	int GetLeased();
};
