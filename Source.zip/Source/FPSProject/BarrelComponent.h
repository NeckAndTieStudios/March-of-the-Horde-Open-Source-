// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Components/SceneComponent.h"
#include "Bullet.h"
#include "BulletPool.h"
#include "BarrelFireMode.h"
#include "BarrelType.h"
#include "BarrelComponent.generated.h"

DECLARE_STATS_GROUP(TEXT("BarrelComponent"), STATGROUP_BarrelComponent, STATCAT_Advanced);
DECLARE_CYCLE_STAT_EXTERN(TEXT("BarrelComponentFire"), STAT_BarrelComponentFire, STATGROUP_BarrelComponent, FPSPROJECT_API);
DECLARE_CYCLE_STAT_EXTERN(TEXT("BarrelComponentTick"), STAT_BarrelComponentTick, STATGROUP_BarrelComponent, FPSPROJECT_API);

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable)
class FPSPROJECT_API UBarrelComponent : public USceneComponent
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	UBarrelComponent();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	float Time = 0.f;
	float LastFire = 0.f;

	int last_fired_barrel = 0;

	TArray<FVector> barrel_locations;

	FVector CurrentPosition;
	FRotator CurrentRotation; //world rotation

	UPROPERTY(EditAnywhere)
		float Rotation = 0.f; //barrel point rotation

	FTimerHandle FireTimerHandle;

	//BulletPool * bullet_pool;

	int BulletsFired = 0;

public:
	// Called every frame
	virtual void TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	/** Fire the amount of bullets in the direction the actor is facing */
	UFUNCTION(BlueprintCallable)
	void Fire();

	void Reload();

	int GetBulletsFired();

	/** Projectile class to spawn */
	UPROPERTY(EditDefaultsOnly, Category = Projectile)
		TSubclassOf<class ABullet> ProjectileClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Barrel")
		bool IsFiring = false;

	UPROPERTY(EditAnywhere)
		int BulletsPerFire = 1;

	/** Fires per second */
	UPROPERTY(EditAnywhere)
		int FireRate = 15;

	/** 0 = on point, the higher the value the more random the bullets with vary in direction */
	UPROPERTY(EditAnywhere)
		float SprayRange = 1.0f;

	UPROPERTY(EditAnywhere)
		int Chambers = 5;

	UPROPERTY(EditAnywhere)
		int BarrelRadius = 1;

	UPROPERTY(EditAnywhere)
		float RotationSpeed = 500.f;

	UPROPERTY(EditAnywhere)
		EBarrelType BarrelType = EBarrelType::Circular;

	UPROPERTY(EditAnywhere)
		int MaxBullets = 0;

	UPROPERTY(EditAnywhere)
		EBarrelFireMode FireMode = EBarrelFireMode::Single;

	UFUNCTION(BlueprintImplementableEvent, Category = "Barrel Events")
		void OnFire(FVector location, FRotator rot);

	UFUNCTION()
		void StartFire();
};
