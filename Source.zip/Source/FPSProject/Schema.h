// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Common.h"
#include "Schema.generated.h"

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FSchema
{
	GENERATED_USTRUCT_BODY()

public:

};
//
//USTRUCT(Blueprintable, BlueprintType)
//struct FPSPROJECT_API FBulletSurfaceModel
//{
//	GENERATED_USTRUCT_BODY()
//
//public:
//
//
//};
//
//
//USTRUCT(Blueprintable, BlueprintType)
//struct FPSPROJECT_API FBulletModel
//{
//	GENERATED_USTRUCT_BODY()
//
//public:
//	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bullet")
//		int BulletID;
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bullet")
//		int BulletComponentID;
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bullet")
//		int BulletTypeID;
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bullet")
//		int BulletID;
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bullet")
//		int BulletID;
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bullet")
//		int BulletID;
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bullet")
//		int BulletID;
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bullet")
//		int BulletID;
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bullet")
//		int BulletID;
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bullet")
//		FBulletSurfaceModel Surface;
//};