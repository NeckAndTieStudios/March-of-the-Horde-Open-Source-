// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "GameFramework/Actor.h"
#include "Engine/StaticMeshActor.h"
#include "Sound/SoundCue.h"
#include "Common.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "InteractionTrigger.h"
#include "ItemPlaceableType.h"
#include "ItemAttributeType.h"
#include "ItemLootFormula.h"
#include "SurfaceEffectSound.h"
#include "SurfaceEffect.h"
#include "ItemAliasInstance.h"
#include "ItemAttributeInstance.h"
#include "ItemInstance.h"
#include "ItemComponent.h"
#include "InstancedComponentsEntry.h"
#include "AutoInstancedStaticMeshActor.h"
#include "AutoInstancedStaticMeshComponent.h"
#include "ItemUpgrade.h"
#include "ContentResolver.generated.h"

class UItemAliasInstance;


USTRUCT(Blueprintable, BlueprintType)
struct FResolveInteractionResponse
{
	GENERATED_USTRUCT_BODY()

private:

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemID = 0;
};

/* Top Level API's - don't let application logic touch the DB models */

UCLASS(Blueprintable)
class FPSPROJECT_API UContentResolver : public UObject
{
	GENERATED_BODY()

public:
	//UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Resolution")

	/*UPROPERTY()
		UWorld * world;*/

	static UContentResolver * Instance;

	UFUNCTION(BlueprintCallable)
		virtual void Initialise();

	UFUNCTION(BlueprintCallable)
		virtual TArray<UItemComponent*> ResolveInteraction(EInteractionTrigger trigger, FHitResult hit_result, AActor * initiator, bool process = true);// = 0;

	/*UFUNCTION(BlueprintCallable)
		virtual UItemInstance * ResolveItemByID(int itemID);*/

	/*UFUNCTION(BlueprintCallable)
		virtual UItemInstance * ResolveItemByAlias(const FString& alias);*/

	/*UFUNCTION(BlueprintCallable)
		virtual UItemAliasInstance * ResolveAliasForItem(UItemInstance* item);*/
/*
	UFUNCTION(BlueprintCallable)
		virtual TArray<UItemAliasInstance*> ResolveAliases();*/

	/*UFUNCTION(BlueprintCallable)
		virtual void ResolveAttributesForItem(UItemInstance* &item);*/

	/*UFUNCTION(BlueprintCallable)
		virtual TArray<UItemInstance *> ResolveLootForItem(UItemInstance* item, EInteractionTrigger trigger);*/

	/*UFUNCTION()
		virtual TArray<UItemInstance *> ResolveRecipesForItem(UItemInstance* item);*/

	/*UFUNCTION(BlueprintCallable)
		virtual TArray<UItemInstance *> ResolveRecipes(UObject* owner);*/

	/*UFUNCTION(BlueprintCallable)
		virtual TArray<UItemInstance *> ResolveRecipesForItem(UItemInstance* item);*/

	/*UFUNCTION(BlueprintCallable)
		virtual TArray<UItemInstance *> ResolveIngredientsForItem(UItemInstance* item);*/

	/*UFUNCTION(BlueprintCallable)
		virtual TArray<UItemInteraction *> ResolveInteractionsForItem(UItemInstance* item);*/

	/*UFUNCTION(BlueprintCallable)
		virtual TArray<UItemUpgradeInstance *> ResolveUpgradesForItem(UItemInstance* item);*/
/*
	UFUNCTION(BlueprintCallable)
		virtual TArray<UItemRepairInstance *> ResolveRepairRequirementsForItem(UItemInstance* item);*/

	UFUNCTION(BlueprintCallable)
		virtual UClass * ResolveBlueprint(const FString& reference);

	UFUNCTION(BlueprintCallable)
		virtual void AddInteractionAtLocation(FHitResult hitResult, UPrimitiveComponent* component, int damage, float radius, float strength);

	/*UFUNCTION()
		template< class T >
		virtual T* FindObject(const FString& class_name) const;*/

	template< class T >
	T* FindObjectByReference(const FString& class_name, bool allowLoad = false) const
	{
		UObject* ClassPackage = ANY_PACKAGE;

		if (T* Result = FindObject<T>(nullptr, *class_name))
			return Result;

		if (UObjectRedirector* RenamedClassRedirector = FindObject<UObjectRedirector>(ClassPackage, *class_name))
			return (T*)CastChecked<T>(RenamedClassRedirector->DestinationObject);

		////FObjectFinder finder(*class_name);
		//ConstructorHelpers::FObjectFinder<T> newAsset(*class_name);
		//if (newAsset.Succeeded())
		//{
		//	return newAsset.Object;
		//}

		if (allowLoad) {
			if (T* Result = LoadObject<T>(nullptr, *class_name))
				return Result;
		}

		return nullptr;
	}
};

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable)
class FPSPROJECT_API AItemActor : public AActor
{
	GENERATED_BODY()

public:

	// hosts a UItemComponent
	// TODO: auto create UItemComponent and make it available here

};
//UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable)
//class FPSPROJECT_API UItemLootInstance : public UItemInstance
//{
//	GENERATED_BODY()
//
//public:
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		float Stack;
//};