// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/SceneComponent.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "ItemComponent.h"
#include "Breakpoints.h" 
#include "ComponentUtils.h"
#include "LinkedComponent.h"
#include "GlobalGameInstance.h"
#include "BuildingComponentRelation.h"
#include "BuildingComponentInstanceData.h"
#include "BuildingComponent.generated.h"

// trying to avoid using a component again
// should now be able to be DB driven, and store any additional data in appropriate components
UCLASS(ClassGroup = (Rendering, Common), hidecategories = (Object, Activation, "Components|Activation"), ShowCategories = (Mobility), editinlinenew, meta = (BlueprintSpawnableComponent))
class FPSPROJECT_API UBuildingMeshComponent : public UStaticMeshComponent
{
	GENERATED_BODY()

public:

};

UCLASS(hidecategories = (Input), showcategories = ("Input|MouseInput", "Input|TouchInput"), ConversionRoot, ComponentWrapperClass, meta = (ChildCanTick))
class FPSPROJECT_API ABuildingMeshPreviewActor : public AActor
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UStaticMesh* Mesh;
};

UCLASS(hidecategories = (Input), showcategories = ("Input|MouseInput", "Input|TouchInput"), ConversionRoot, ComponentWrapperClass, meta = (ChildCanTick))
class FPSPROJECT_API ABuildingMeshActor : public AStaticMeshActor
{
	GENERATED_BODY()

public:

	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
		ABuildingMeshPreviewActor* GetPreviewActor();

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FItemData Item;

	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
		void Init(FItemData ItemInstance, UStaticMesh* StaticMesh = NULL);

};

UCLASS(ClassGroup = Rendering, meta = (BlueprintSpawnableComponent))
class FPSPROJECT_API UBuildingComponent : public UHierarchicalInstancedStaticMeshComponent
{
	GENERATED_BODY()

public:
	UBuildingComponent();

	UPROPERTY()
		TArray<FBuildingComponentInstanceData> CustomPerInstanceSMData;

	/// Sets up any child component as an attachment.
	/// Any instance added to this BP will then propagate down to the children. Each instance ID is interchangable.
	/// Children components MUST be of a UBuildingComponent type
	UPROPERTY(EditAnywhere, Category = "Buildings")
		bool ChildrenAreAttachments = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Building - Default Instance Data")
		TSubclassOf<class UItemComponent> DefaultItemComponentClass = NULL;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Building - Default Instance Data")
		TSubclassOf<class UItemInstance> DefaultItemClass = NULL;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Building")
		TArray<FSoundCueWeighting> MeshChangeSounds;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Building")
		UParticleSystem * HitParticle;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Building")
		FRotator HitParticleOffset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Building")
		FVector HitParticleScale;*/

	virtual void SetInstanceDefaults(int32 InstanceIndex)
	{
		int max = 1000;
		int ix = CustomPerInstanceSMData.Num();
		while (CustomPerInstanceSMData.Num() <= InstanceIndex && max-- > 0) {
			auto new_data = FBuildingComponentInstanceData(); // this, ix);
			auto index = CustomPerInstanceSMData.Add(new_data);
		}

		CustomPerInstanceSMData[InstanceIndex].ItemComponentClass = this->DefaultItemComponentClass;
		CustomPerInstanceSMData[InstanceIndex].ItemClass = this->DefaultItemClass;

		if (CustomPerInstanceSMData[InstanceIndex].ItemComponent) {
			CustomPerInstanceSMData[InstanceIndex].ItemComponent->InstanceID = InstanceIndex;
		}
	}

	/*virtual void SetSelection(bool state, int32 InstanceIndex)
	{
		int max = 1000;
		while (CustomPerInstanceSMData.Num() <= InstanceIndex && max-- > 0) {
			auto new_data = FBuildingComponentInstanceData();
			auto index = CustomPerInstanceSMData.Add(new_data);
		}

		CustomPerInstanceSMData[InstanceIndex].Selected = state;
	}*/

	UFUNCTION(BlueprintCallable) void Animate(int32 InstanceID, FTransform transform, UItemAliasInstance* alias, bool killed)
	{
		// play sound
		if (alias->BreakpointSurfaceEffectID > 0) {
			auto gi = this->GetWorld()->GetGameInstance<UGlobalGameInstance>();
			if (gi) {
				auto effect_item = gi->SurfaceEffects.Find(alias->BreakpointSurfaceEffectID);
				if (effect_item) {
					auto effect = *effect_item;
					if (effect->Sounds.Num() > 0) {
						effect->PlaySoundAtLocation(transform.GetLocation() + this->GetComponentLocation());
						//UCommon::PlayWeightedSound(effect->Sounds, this->GetWorld(), transform.GetLocation() + this->GetComponentLocation());
					}
				}
				/*if (this->MeshChangeSounds.Num() > 0) {
					UCommon::PlayWeightedSound(this->MeshChangeSounds, this->GetWorld(), transform.GetLocation());
				}*/
			}
		}

		// spawn particle
		if (alias->Particle) {
			auto component = UGameplayStatics::SpawnEmitterAtLocation(this->GetWorld(), alias->Particle, transform.GetLocation() + this->GetComponentLocation(), alias->ParticleRotation + transform.Rotator(), alias->ParticleScale, false, EPSCPoolMethod::AutoRelease);

			component->SetWorldScale3D(FVector(1));

			component->Activate();
		}

		//// spawn the children DM's
		//auto data = this->CustomPerInstanceSMData[InstanceID];
		//for (auto child : data.Children) {
		//	this->SpawnChildDM(child->Entry);
		//}
	}

	//void SpawnChildDM(FInstancedStaticMeshComponentInstanceData data) {
	//	if (data.ItemInstance) {
	//		//data.ItemInstance->Spawn
	//	}

	//	for (auto child : data.Children) {
	//		this->SpawnChildDM(child->Entry);
	//	}
	//}

	UFUNCTION(BlueprintCallable) void AddDecal(int32 InstanceID, FWordStaticMeshDecal decal)
	{
		if (this->CustomPerInstanceSMData.IsValidIndex(InstanceID)) {
			this->CustomPerInstanceSMData[InstanceID].DecalInstances.Add(decal);
		}
	}

	UFUNCTION(BlueprintCallable) void ClearDecals(int32 InstanceID)
	{
		if (this->CustomPerInstanceSMData.IsValidIndex(InstanceID)) {
			for (int i = this->CustomPerInstanceSMData[InstanceID].DecalInstances.Num() - 1; i >= 0; i--)
			{
				auto gi = Cast<UGlobalGameInstance>(this->GetWorld()->GetGameInstance());
				gi->StaticMeshActorPool->Release(this->CustomPerInstanceSMData[InstanceID].DecalInstances[i].Decal);
				this->CustomPerInstanceSMData[InstanceID].DecalInstances.RemoveAt(i);
			}
		}
	}

	UFUNCTION(BlueprintCallable) bool MigrateInstance(int32 InstanceID, UStaticMesh* targetMesh, UBuildingComponent* &target, int32 &targetInstanceID, UBuildingComponent* parent = NULL, int32 reuse_instance = -1, bool use_hidden_instance = false)
	{
		return UBuildingComponent::MoveInstance(this, InstanceID, targetMesh, target, targetInstanceID, parent, reuse_instance, use_hidden_instance);
	}

	static bool MoveInstance(UBuildingComponent* source, int32 InstanceID, UStaticMesh* targetMesh, UBuildingComponent* &target, int32 &targetInstanceID, UBuildingComponent* parent = NULL, int32 reuse_instance = -1, bool use_hidden_instance = false)
	{
		//UBuildingComponent* target = NULL;
		auto components = source->GetOwner()->GetComponentsByClass(UBuildingComponent::StaticClass());
		for (auto component : components)
		{
			auto bc = Cast<UBuildingComponent>(component);
			if (bc && bc->GetStaticMesh() == targetMesh && (parent == NULL || bc->GetAttachParent() == parent)) {
				target = bc;
				break;
			}
		}

		if (!target) {
			target = NewObject<UBuildingComponent>(source->GetOwner());
			target->SetStaticMesh(targetMesh);
			//target->SetMobility(this->GetMobility);
			target->SetCollisionProfileName(source->GetCollisionProfileName());
			target->SetWorldLocation(source->GetComponentLocation());
			target->ChildrenAreAttachments = source->ChildrenAreAttachments;

			if (parent) {
				target->AttachToComponent(parent, FAttachmentTransformRules::KeepWorldTransform);
			}

			/*if (source->ChildrenAreAttachments) {

				TArray<USceneComponent*> children;
				source->GetChildrenComponents(false, children);

				for (int i = 0; i < children.Num(); i++) {

				}

			}*/

			target->RegisterComponent();
		}

		if (target) {
			if (!source->CustomPerInstanceSMData.IsValidIndex(InstanceID)) {
				target->RegisterComponent();
			}
			auto data = source->CustomPerInstanceSMData[InstanceID];// .Duplicate();
			auto transform = FTransform(source->PerInstanceSMData[InstanceID].Transform);

			//data.ItemInstance = this->CustomPerInstanceSMData[item_component->InstanceID].ItemInstance;
			//data.ItemComponent = this->CustomPerInstanceSMData[item_component->InstanceID].ItemComponent;

			/*if (ClearDecalsOnMeshChange) {
				this->ClearDecals(item_component->InstanceID);
			}*/

			//source->RemoveInstanceSingle(InstanceID); // dont kill the children
			//source->RemoveInstanceData(InstanceID);
			if (source->CustomPerInstanceSMData[InstanceID].ItemComponent) {
				source->CustomPerInstanceSMData[InstanceID].ItemComponent->RemoveInstance();
			}

			int32 new_index = reuse_instance;

			if (reuse_instance < 0 && use_hidden_instance) {
				for (int i = 0; i < target->PerInstanceSMData.Num(); i++) {
					auto location = FTransform(target->PerInstanceSMData[i].Transform).GetLocation();
					if ((int)location.Z == -100000) {
						new_index = i;
						target->UpdateInstanceTransformSingle(i, transform);
						break;
					}
				}
			}

			if (new_index < 0) {
				new_index = target->AddInstanceSingle(transform);  // dont add children (if the structure had been created....)
				// ensure the data array is synced
				target->SetInstanceDefaults(new_index);
			}


			//// remove from parent
			//if (data.CurrentComponent) {
			//	auto parent_data = data.CurrentComponent->CustomPerInstanceSMData[data.CurrentComponentIndex];
			//	for (int i = parent_data.Children.Num() - 1; i >= 0; i--)
			//	{
			//		auto child = parent_data.Children[i];
			//		if (child.Component == source && child.InstanceID == InstanceID) {
			//			data.CurrentComponent->CustomPerInstanceSMData[data.CurrentComponentIndex].Children.RemoveAt(i);
			//		}
			//	}
			//}

			data.SetCurrentComponent(target, new_index);

			//data.ParentChildRecord = this;
			if (data.ParentChildRecord) {
				data.ParentChildRecord->SetInstanceData(data); // update the copied struct...
			}

			//data.CurrentComponent = target;
			//data.CurrentComponentIndex = new_index;

			//data.SetParent(target, new_index);

			target->CustomPerInstanceSMData[new_index] = data;

			//data.ItemComponent->InstanceID = new_index;
			//data.ItemComponent->InstanceComponent = target;


			//// add to new parent
			//if (data.CurrentComponent) {
			//	UBuildingComponentRelation entry;
			//	entry.Component = target;
			//	entry.InstanceID = new_index;
			//	data.CurrentComponent->CustomPerInstanceSMData[data.CurrentComponentIndex].Children.Add(entry);
			//}

			//// set data to new parent
			//data.SetParent(target, new_index);

			//// add to new parent
			//if (data.Parent.Component) {
			//	UBuildingComponentRelation entry;
			//	entry.Component = target;
			//	entry.InstanceID = new_index;
			//	data.Parent.Component->CustomPerInstanceSMData[data.Parent.InstanceID].Children.Add(entry);
			//}

			targetInstanceID = new_index;

			//if (source->ChildrenAreAttachments) {
			//	//TODO: this needs to happen otherwise when this component is destroyed, it will never kill the children as they are then out of sync!
			//	// copy structure

			//	TArray<USceneComponent*> children;
			//	source->GetChildrenComponents(false, children);

			//	for(int i = 0; i < data.Children.Num(); i++) {
			//		UBuildingComponent* tmp = NULL;
			//		int32 temp_new_index = -1;
			//		if (UBuildingComponent::MoveInstance(data.Children[i].Component, data.Children[i].InstanceID, data.Children[i].Component->GetStaticMesh(), tmp, temp_new_index, target)) {
			//			data.Children[i].Component = tmp;
			//			data.Children[i].InstanceID = temp_new_index;
			//		}
			//	}


			//	//for (auto child : children)
			//	//{
			//	//	auto bc = Cast<UBuildingComponent>(child);
			//	//	if (bc) {
			//	//		UBuildingComponent* tmp = NULL;
			//	//		int32 temp_new_index = -1;
			//	//		if (UBuildingComponent::MoveInstance(bc, InstanceID, bc->GetStaticMesh(), tmp, temp_new_index, target)) {
			//	//		}
			//	//	}
			//	//}
			//}

			return true;
		}

		return false;
	}

	UFUNCTION(BlueprintCallable) void OnDamage(AActor* initiator, FHitResult hitresult, UItemComponent* item_component, bool killed)
	{
		//bool animated = false;
		//if (item_component) {
		//	if (!killed && item_component->ItemInstance.ItemID > 0) {
		//		auto new_alias = item_component->GetAliasByHealth();
		//		if (new_alias && item_component->ItemInstance->Alias != new_alias) {
		//			auto mesh = Cast<UStaticMesh>(new_alias->GetInstance());
		//			if (mesh) {
		//				// migrate
		//				//	- find existing component within the actor, or create one
		//				//	- store data+transform
		//				//	- remove instance from this component
		//				//	- add instance and update data

		//				UBuildingComponent* target = NULL;
		//				int32 new_index = -1;
		//				if (UBuildingComponent::MoveInstance(this, item_component->InstanceID, mesh, target, new_index))
		//				{
		//					auto transform = FTransform(target->PerInstanceSMData[new_index].Transform);
		//					target->Animate(new_index, transform, item_component->ItemInstance->Alias, killed);
		//					animated = true;

		//					item_component->ItemInstance->Alias = new_alias;
		//				}
		//			}
		//		}
		//		//auto aliases = item_component->ItemInstance->GetAliases();

		//		//for (auto alias : aliases)
		//		//{
		//		//	if (alias->HealthBreakpoint > 0 && item_component->ItemInstance->Health <= alias->HealthBreakpoint && alias->HealthBreakpoint < item_component->ItemInstance->Alias->HealthBreakpoint) {
		//		//		auto mesh = Cast<UStaticMesh>(alias->GetInstance());
		//		//		if (mesh) {
		//		//			// migrate
		//		//			//	- find existing component within the actor, or create one
		//		//			//	- store data+transform
		//		//			//	- remove instance from this component
		//		//			//	- add instance and update data

		//		//			UBuildingComponent* target = NULL;
		//		//			int32 new_index = -1;
		//		//			if (UBuildingComponent::MoveInstance(this, item_component->InstanceID, mesh, target, new_index))
		//		//			{
		//		//				auto transform = FTransform(target->PerInstanceSMData[new_index].Transform);
		//		//				target->Animate(new_index, transform, item_component->ItemInstance->Alias, killed);
		//		//				animated = true;

		//		//				item_component->ItemInstance->Alias = alias;
		//		//			}

		//		//			//UBuildingComponent* target = NULL;
		//		//			//auto components = this->GetOwner()->GetComponentsByClass(UBuildingComponent::StaticClass());
		//		//			//for (auto component : components)
		//		//			//{
		//		//			//	auto bc = Cast<UBuildingComponent>(component);
		//		//			//	if (bc && bc->GetStaticMesh() == mesh) {
		//		//			//		target = bc;
		//		//			//		break;
		//		//			//	}
		//		//			//}

		//		//			//if (!target) {
		//		//			//	target = NewObject<UBuildingComponent>(this->GetOwner());
		//		//			//	target->SetStaticMesh(mesh);
		//		//			//	//target->SetMobility(this->GetMobility);
		//		//			//	target->SetCollisionProfileName(this->GetCollisionProfileName());
		//		//			//	target->RegisterComponent();
		//		//			//	target->SetWorldLocation(this->GetComponentLocation());

		//		//			//	if (this->ChildrenAreAttachments) {
		//		//			//		//TODO: this needs to happen otherwise when this component is destroyed, it will never kill the children
		//		//			//		// copy structure

		//		//			//		TArray<USceneComponent*> children;
		//		//			//		this->GetChildrenComponents(true, children);


		//		//			//	}
		//		//			//}

		//		//			//if (target) {
		//		//			//	auto data = this->CustomPerInstanceSMData[item_component->InstanceID].Duplicate();
		//		//			//	auto transform = FTransform(this->PerInstanceSMData[item_component->InstanceID].Transform);

		//		//			//	//data.ItemInstance = this->CustomPerInstanceSMData[item_component->InstanceID].ItemInstance;
		//		//			//	//data.ItemComponent = this->CustomPerInstanceSMData[item_component->InstanceID].ItemComponent;

		//		//			//	/*if (ClearDecalsOnMeshChange) {
		//		//			//		this->ClearDecals(item_component->InstanceID);
		//		//			//	}*/

		//		//			//	this->RemoveInstanceSingle(item_component->InstanceID); // dont kill the children

		//		//			//	auto new_index = target->AddInstanceSingle(transform);  // dont add children (if the structure had been created....)
		//		//			//	// ensure the data array is synced
		//		//			//	target->SetInstanceDefaults(new_index);
		//		//			//	target->CustomPerInstanceSMData[new_index] = data;

		//		//			//	item_component->InstanceID = new_index;
		//		//			//	item_component->InstanceComponent = target;

		//		//			//	target->Animate(new_index, transform, item_component->ItemInstance->Alias);
		//		//			//	animated = true;

		//		//			//	item_component->ItemInstance->Alias = alias;
		//		//			//}
		//		//		}

		//		//		break;
		//		//	}
		//		//}
		//	}

		//	if (!animated && killed) {
		//		auto transform = FTransform(this->PerInstanceSMData[item_component->InstanceID].Transform);
		//		this->Animate(item_component->InstanceID, transform, item_component->ItemInstance->Alias, killed);
		//	}
		//}
		////auto instanceMesh = this->GetStaticMesh();
		////if (instanceMesh) {
		////	auto name = UCommon::GetReferencePath(instanceMesh);

		////	if (name.EndsWith(FString(TEXT("HP"))))
		////	{
		////		//item_component->Health
		////		//for(int i = 0; i < this->)
		////	}
		////}
	}

	static TArray<FLinkedComponent> GetAllComponents(UInstancedStaticMeshComponent* root, bool includeSelf = true, bool includeChildren = true, bool includeSCS = true, bool includeArch = true)
	{
		TArray<FLinkedComponent> components;
		TArray<UObject*> ArchetypeInstances;

		if (includeSelf) {
			components.Add(FLinkedComponent(ELinkedComponentType::Root, root));

#if WITH_EDITOR
			if (includeArch) {
				root->GetArchetypeInstances(ArchetypeInstances);

				for (UObject* obj : ArchetypeInstances)
				{
					auto abc = Cast<UInstancedStaticMeshComponent>(obj);
					if (abc && components.FilterByPredicate([abc](const FLinkedComponent item) {
						return item.Component == abc;
					}).Num() == 0) {
						components.Add(FLinkedComponent(ELinkedComponentType::RootArch, abc));
					}
				}
			}

			if (includeSCS) {
				// no reset, we onlt want to append
				USCS_Node* SCSNode = ComponentUtils::FindCorrespondingSCSNode(root);
				if (SCSNode) {
					auto ChildSceneComponent = Cast<UInstancedStaticMeshComponent>(SCSNode->ComponentTemplate);
					if (ChildSceneComponent && components.FilterByPredicate([ChildSceneComponent](const FLinkedComponent item) {
						return item.Component == ChildSceneComponent;
					}).Num() == 0) {
						components.Add(FLinkedComponent(ELinkedComponentType::RootSCS, ChildSceneComponent));
					}

					ChildSceneComponent = Cast<UInstancedStaticMeshComponent>(SCSNode->EditorComponentInstance);
					if (ChildSceneComponent && components.FilterByPredicate([ChildSceneComponent](const FLinkedComponent item) {
						return item.Component == ChildSceneComponent;
					}).Num() == 0) {
						components.Add(FLinkedComponent(ELinkedComponentType::RootSCS, ChildSceneComponent));
					}
				}
			}
#endif
		}

		auto bc = Cast<UBuildingComponent>(root);
		if (bc && bc->ChildrenAreAttachments && includeChildren)
		{
			TArray<USceneComponent*> children;
			root->GetChildrenComponents(true, children);

			for (int i = 0; i < children.Num(); i++) {
				auto sub_building = Cast<UInstancedStaticMeshComponent>(children[i]);
				if (sub_building && components.FilterByPredicate([sub_building](const FLinkedComponent item) {
					return item.Component == sub_building;
				}).Num() == 0) {
					components.Add(FLinkedComponent(ELinkedComponentType::Child, sub_building));

#if WITH_EDITOR
					ArchetypeInstances.Empty();
					sub_building->GetArchetypeInstances(ArchetypeInstances);

					for (UObject* obj : ArchetypeInstances)
					{
						auto abc = Cast<UInstancedStaticMeshComponent>(obj);
						if (abc && components.FilterByPredicate([abc](const FLinkedComponent item) {
							return item.Component == abc;
						}).Num() == 0) {
							components.Add(FLinkedComponent(ELinkedComponentType::ChildArch, abc));
						}
					}
#endif
				}
			}


			if (includeSCS) {
				// editor instances
				children.Empty();
				UBuildingComponent::FindAllChildrenComponents(root, children);

				for (int i = 0; i < children.Num(); i++) {
					auto sub_building = Cast<UInstancedStaticMeshComponent>(children[i]);
					if (sub_building && components.FilterByPredicate([sub_building](const FLinkedComponent item) {
						return item.Component == sub_building;
					}).Num() == 0) {
						components.Add(FLinkedComponent(ELinkedComponentType::USCS, sub_building));

#if WITH_EDITOR
						ArchetypeInstances.Empty();
						sub_building->GetArchetypeInstances(ArchetypeInstances);

						for (UObject* obj : ArchetypeInstances)
						{
							auto abc = Cast<UInstancedStaticMeshComponent>(obj);
							if (abc && components.FilterByPredicate([abc](const FLinkedComponent item) {
								return item.Component == abc;
							}).Num() == 0) {
								components.Add(FLinkedComponent(ELinkedComponentType::USCSArch, abc));
							}
						}
#endif
					}
				}
			}
		}

		return components;
	}

	virtual void SetInstanceDataFromIndex(int32 FromInstanceIndex, int32 ToInstanceIndex)
	{
		auto components = UBuildingComponent::GetAllComponents(this);
		for (auto link : components)
		{
			auto bc = Cast<UBuildingComponent>(link.Component);
			if (bc) {
				// mark in scope transaction
				bc->Modify();
				// ensure the data array is synced
				bc->SetInstanceDefaults(ToInstanceIndex);
				// duplicate
				bc->CustomPerInstanceSMData[ToInstanceIndex] = bc->CustomPerInstanceSMData[FromInstanceIndex].Duplicate();
			}
		}
	}

	virtual void BeginPlay() override
	{
		Super::BeginPlay();

		for (int i = 0; i < CustomPerInstanceSMData.Num(); i++) {
			CustomPerInstanceSMData[i].BeginPlay(this, i);
		}

		//auto parent = this->GetAttachParent();
		//if (parent == this->GetAttachmentRoot())
		//{
		//	// once all children are loaded, let the parent associate all children to the data

		//	TArray<USceneComponent*> components;
		//	this->GetChildrenComponents(true, components);
		//	components.Add(this);

		//	// for each component, find their children and populate their approprate entries
		//	for (auto component : components)
		//	{
		//		auto parent = Cast<UBuildingComponent>(component);
		//		if (parent == NULL) continue;

		//		TArray<USceneComponent*> children;
		//		component->GetChildrenComponents(false, children);

		//		for (auto c : children)
		//		{
		//			auto bc = Cast<UBuildingComponent>(c);
		//			if (bc) {

		//				for (int i = 0; i < bc->CustomPerInstanceSMData.Num(); i++) {
		//					auto entry = NewObject<UBuildingComponentRelation>(GetOwner());
		//					entry->Entry = bc->CustomPerInstanceSMData[i];
		//					parent->CustomPerInstanceSMData[i].Children.Add(entry);
		//				}


		//				//for (int i = 0; i < parent->CustomPerInstanceSMData.Num(); i++) {
		//				//	/*UBuildingComponentRelation entry;
		//				//	entry.Component = bc;
		//				//	entry.InstanceID = i;*/
		//				//	auto entry = NewObject<UBuildingComponentRelation>(GetOwner());
		//				//	entry->Entry = parent->CustomPerInstanceSMData[i];
		//				//	parent->CustomPerInstanceSMData[i].Children.Add(entry);

		//				//	/*for (int y = 0; y < bc->CustomPerInstanceSMData.Num(); y++) {
		//				//		parent->CustomPerInstanceSMData[i].Children.Add(parent->CustomPerInstanceSMData[y]);
		//				//	}*/

		//				//	//bc->CustomPerInstanceSMData[i].SetParent();
		//				//}

		//				/*for (int i = 0; i < bc->CustomPerInstanceSMData.Num(); i++) {
		//					bc->CustomPerInstanceSMData[i].SetParent(parent, i);
		//				}*/

		//			}
		//		}
		//	}
		//}
	}

#if WITH_EDITOR
	// rebuilds our selection status using SelectedInstances
	virtual void RebuildSelection()
	{
		//auto components = UBuildingComponent::GetAllComponents(this, true, false);
		//for (auto link : components)
		//{
		//	auto bc = Cast<UBuildingComponent>(link.Component);
		//	if (bc) {
		//		for (int i = 0; i < bc->CustomPerInstanceSMData.Num(); i++) {
		//			bc->CustomPerInstanceSMData[i].Selected = bc->SelectedInstances.IsValidIndex(i) && bc->SelectedInstances[i] == 1;
		//			this->CustomPerInstanceSMData[i].Selected = bc->CustomPerInstanceSMData[i].Selected;
		//			// no break, the last is the winner it seems
		//		}
		//	}
		//}

		auto selection = UBuildingComponent::GetSelectedInstances(this);
		for (int i = 0; i < selection.Num(); i++) {
			if (this->CustomPerInstanceSMData.IsValidIndex(i)) {
				this->CustomPerInstanceSMData[i].Selected = selection[i] == 1;
			}
		}
	}

	static TArray<int32> GetSelectedInstances(UInstancedStaticMeshComponent* component)
	{
		TArray<int32> selected;

		selected.Init(0, component->PerInstanceSMData.Num());

		auto components = UBuildingComponent::GetAllComponents(component, true, false);
		for (auto link : components)
		{
			auto arch = link.Component->HasAnyFlags(RF_ArchetypeObject);
			if (!arch) {
				for (int i = 0; i < selected.Num(); i++) {
					selected[i] = link.Component->SelectedInstances.IsValidIndex(i) && link.Component->SelectedInstances[i] == 1 ? 1 : 0;
					// no break, the last is the winner it seems
				}
			}
		}

		return selected;
	}

	/*virtual void SyncSelections() {
		auto components = UBuildingComponent::GetAllComponents(this);
		for (auto link : components)
		{
			if (link.Component != this) {
				auto bc = Cast<UBuildingComponent>(link.Component);
				if (bc) {
					bc->Modify();
					for (int i = 0; i < bc->CustomPerInstanceSMData.Num(); i++) {
						bc->CustomPerInstanceSMData[i].Selected = this->CustomPerInstanceSMData[i].Selected;
					}
				}
			}
		}
	}*/

	// rebuilds SelectedInstances for the current and children instances
	virtual void SelectViewportInstances(int32 Index = -1)
	{
		auto components = UBuildingComponent::GetAllComponents(this);
		for (auto link : components)
		{
			auto bc = Cast<UBuildingComponent>(link.Component);
			if (bc) {
				bc->Modify();
				bc->ClearInstanceSelection();

				if (Index == -1) {
					for (int i = 0; i < bc->CustomPerInstanceSMData.Num(); i++) {
						if (bc->CustomPerInstanceSMData[i].Selected) {
							bc->SelectInstance(true, i, 1);
						}
					}
				}
				else {
					bc->SelectInstance(bc->CustomPerInstanceSMData[Index].Selected, Index, 1);
				}
			}
		}

		if (components.Num() == 9999999) {
			components.Empty();
		}
	}
#endif

	virtual void OnPostLoadPerInstanceData() override
	{
		BuildTreeIfOutdated(false, false); // reorder fix for loaded/saved corruptions
		Super::OnPostLoadPerInstanceData();
	}

	virtual int32 AddInstanceSingle(const FTransform& InstanceTransform)
	{
		return UHierarchicalInstancedStaticMeshComponent::AddInstance(InstanceTransform);
	}

	virtual TArray<FLinkedComponent> PostAddInstance(int32 InstanceIndex)
	{
		auto transform = FTransform(this->PerInstanceSMData[InstanceIndex].Transform);

		auto components = UBuildingComponent::GetAllComponents(this);
		for (auto link : components)
		{
			auto bc = Cast<UBuildingComponent>(link.Component);
			if (bc) {
				if (bc->PerInstanceSMData.Num() == InstanceIndex) {
					// mark in scope transaction
					bc->Modify();

					auto add_index = bc->AddInstanceSingle(transform);

					// ensure it was added where its expected to
					check(add_index == InstanceIndex);
				}
				// ensure the data array is synced
				bc->SetInstanceDefaults(InstanceIndex);

#if WITH_EDITOR
				// update HISM arrays
				bc->BuildTreeIfOutdated(false, false);
#endif
			}
		}

		return components;
	}

	virtual void PostDeleteInstance(int32 InstanceIndex)
	{
		if (!this->GetWorld() && this->GetWorld()->WorldType == EWorldType::Editor)
		{
			GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, TEXT("EWorldType::Editor"));
			auto len = this->PerInstanceSMData.Num();
			auto components = UBuildingComponent::GetAllComponents(this);
			for (auto link : components)
			{
				if (true) { //link.Component != this) {
					auto bc = Cast<UBuildingComponent>(link.Component);
					if (bc) {
						if (bc->PerInstanceSMData.Num() > len) {
							// mark in scope transaction
							bc->Modify();
							bc->RemoveInstanceSingle(InstanceIndex);
						}
						if (bc->CustomPerInstanceSMData.Num() > len) {
							// mark in scope transaction
							bc->Modify();
							bc->RemoveInstanceData(InstanceIndex);
						}
						else {
							bc->Modify();
						}
					}
				}
			}
		}
		else
		{
			GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, TEXT("NOT EWorldType::Editor"));
			if (CustomPerInstanceSMData.IsValidIndex(InstanceIndex))
			{
				for (int i = CustomPerInstanceSMData[InstanceIndex].Children.Num() - 1; i >= 0; i--)
				{
					auto entry = CustomPerInstanceSMData[InstanceIndex].Children[i];
					entry->Entry.CurrentComponent->RemoveInstance(entry->Entry.CurrentComponentIndex);
				}
			}
		}
	}

	virtual void PostDuplicateInstance(int32 SourceIndex, int32 NewIndex)
	{
		auto components = this->PostAddInstance(NewIndex);
		for (auto link : components)
		{
			auto bc = Cast<UBuildingComponent>(link.Component);
			if (bc) {
				bc->CustomPerInstanceSMData[NewIndex] = bc->CustomPerInstanceSMData[SourceIndex].Duplicate();
			}
		}
	}

	virtual int32 AddInstance(const FTransform& InstanceTransform) override
	{
#if WITH_EDITOR
		// mark in scope transaction
		this->Modify();
#endif
		int32 InstanceIndex = UHierarchicalInstancedStaticMeshComponent::AddInstance(InstanceTransform);

		if (InstanceIndex != INDEX_NONE)
		{
			//auto components = UBuildingComponent::GetAllComponents(this);
			//for (auto link : components)
			//{
			//	// mark in scope transaction
			//	link.Component->Modify();
			//	// ensure the data array is synced
			//	link.Component->SetInstanceDefaults(InstanceIndex);

			//	// replicate the transform down the chain if not the current component since it already has been done
			//	if (link.Component != this) {
			//		auto add_index = link.Component->AddInstanceSingle(InstanceTransform);
			//		check(add_index == InstanceIndex);
			//	}
			//}

			PostAddInstance(InstanceIndex);

			/*SetInstanceDefaults(InstanceIndex);

			if (ChildrenAreAttachments)
			{
				TArray<USceneComponent*> children;
				this->GetChildrenComponents(false, children);

				for (int i = 0; i < children.Num(); i++) {
					auto sub_building = Cast<UBuildingComponent>(children[i]);
					if (sub_building) {
						sub_building->AddInstance(InstanceTransform);
					}
				}
			}*/
		}

		return InstanceIndex;
	}

	virtual bool RemoveInstanceSingle(int32 InstanceIndex)
	{
		this->ClearDecals(InstanceIndex);

		/*	auto parent_bc = Cast<UBuildingComponent>(this->GetAttachParent());
			if (parent_bc) {
				if (parent_bc->CustomPerInstanceSMData.IsValidIndex(InstanceIndex)) {
					if (parent_bc->CustomPerInstanceSMData[InstanceIndex].Parent.Component) {
						auto our_entry = parent_bc->CustomPerInstanceSMData[InstanceIndex].Parent.Component->CustomPerInstanceSMData[parent_bc->CustomPerInstanceSMData[InstanceIndex].Parent.InstanceID];
						for (int i = our_entry.Children.Num() - 1; i >= 0; i--) {
							if (our_entry.Children[i].Component == this && our_entry.Children[i].InstanceID == InstanceIndex) {
								our_entry.Children.RemoveAt(i);
								break;
							}
						}
					}
				}
			}*/

		return UHierarchicalInstancedStaticMeshComponent::RemoveInstance(InstanceIndex);
	}

	virtual bool RemoveInstance(int32 InstanceIndex) override
	{
		auto result = UHierarchicalInstancedStaticMeshComponent::RemoveInstance(InstanceIndex);

		if (result) {
			PostDeleteInstance(InstanceIndex);

			//auto components = UBuildingComponent::GetAllComponents(this);
			//for (auto link : components)
			//{
			//	// mark in scope transaction
			//	link.Component->Modify();
			//	// ensure the data array is synced
			//	link.Component->RemoveInstanceData(InstanceIndex);

			//	// replicate the transform down the chain if not the current component since it already has been done
			//	if (link.Component != this) {
			//		link.Component->RemoveInstanceSingle(InstanceIndex);
			//	}
			//}

			/*this->RemoveInstanceData(InstanceIndex);

			if (ChildrenAreAttachments)
			{
				TArray<USceneComponent*> children;
				this->GetChildrenComponents(false, children);

				for (int i = 0; i < children.Num(); i++) {
					auto sub_building = Cast<UBuildingComponent>(children[i]);
					if (sub_building) {
						sub_building->RemoveInstance(InstanceIndex);
					}
				}
			}*/
		}

		return result;
	}

	virtual void ClearInstancesSingle()
	{
		UHierarchicalInstancedStaticMeshComponent::ClearInstances();
	}

	virtual void ClearInstances() override
	{
		UHierarchicalInstancedStaticMeshComponent::ClearInstances();

		auto components = UBuildingComponent::GetAllComponents(this);
		for (auto link : components)
		{
			// mark in scope transaction
			link.Component->Modify();

			auto bc = Cast<UBuildingComponent>(link.Component);
			if (bc) {
				// ensure the data array is synced
				bc->CustomPerInstanceSMData.Empty();

				// replicate the transform down the chain if not the current component since it already has been done
				if (bc != this) {
					bc->ClearInstancesSingle();
				}
			}
			else {
				// replicate the transform down the chain if not the current component since it already has been done
				if (link.Component != this) {
					link.Component->ClearInstances();
				}
			}
		}

		/*this->CustomPerInstanceSMData.Empty();

		if (ChildrenAreAttachments)
		{
			TArray<USceneComponent*> children;
			this->GetChildrenComponents(false, children);

			for (int i = 0; i < children.Num(); i++) {
				auto sub_building = Cast<UBuildingComponent>(children[i]);
				if (sub_building) {
					sub_building->ClearInstances();
				}
			}
		}*/
	}

	virtual bool UpdateInstanceTransformSingle(int32 InstanceIndex, const FTransform& NewInstanceTransform, bool bWorldSpace = false, bool bMarkRenderStateDirty = false, bool bTeleport = false)
	{
		return UHierarchicalInstancedStaticMeshComponent::UpdateInstanceTransform(InstanceIndex, NewInstanceTransform, bWorldSpace, bMarkRenderStateDirty, bTeleport);
	}

	virtual bool UpdateInstanceTransform(int32 InstanceIndex, const FTransform& NewInstanceTransform, bool bWorldSpace = false, bool bMarkRenderStateDirty = false, bool bTeleport = false) override
	{
		auto result = UHierarchicalInstancedStaticMeshComponent::UpdateInstanceTransform(InstanceIndex, NewInstanceTransform, bWorldSpace, bMarkRenderStateDirty, bTeleport);

		/*if (ChildrenAreAttachments)
		{
			TArray<USceneComponent*> children;
			this->GetChildrenComponents(false, children);

			for (int i = 0; i < children.Num(); i++) {
				auto sub_building = Cast<UBuildingComponent>(children[i]);
				if (sub_building) {
					sub_building->Modify();
					sub_building->UpdateInstanceTransform(InstanceIndex, NewInstanceTransform, bWorldSpace, true, true);
				}
			}
		}*/

		if (!this->GetWorld() || this->GetWorld()->WorldType == EWorldType::Editor)
		{
			GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, TEXT("EWorldType::Editor"));

			auto components = UBuildingComponent::GetAllComponents(this);
			for (auto link : components)
			{
				auto bc = Cast<UBuildingComponent>(link.Component);
				if (bc) {
					if (bc != this) {
						bc->Modify();
						bc->UpdateInstanceTransformSingle(InstanceIndex, NewInstanceTransform, bWorldSpace, true, true);
					}
				}
				else {
					if (link.Component != this) {
						link.Component->Modify();
						link.Component->UpdateInstanceTransform(InstanceIndex, NewInstanceTransform, bWorldSpace, true, true);
					}
				}
			}
		}
		else
		{
			GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, TEXT("NOT EWorldType::Editor"));
			if (this->CustomPerInstanceSMData.IsValidIndex(InstanceIndex))
			{
				for (auto child : this->CustomPerInstanceSMData[InstanceIndex].Children) {
					child->Entry.CurrentComponent->UpdateInstanceTransform(child->Entry.CurrentComponentIndex, NewInstanceTransform, bWorldSpace, true, true);
				}
			}
		}

		return result;
	}

	virtual void RemoveInstanceData(int32 InstanceIndex)
	{
		// KEEP IN SYNC WITH UE's INSTANCE BODIES
		int max_instances = this->CustomPerInstanceSMData.Num();
		if (max_instances > InstanceIndex)
		{
			if (this->CustomPerInstanceSMData[InstanceIndex].ItemComponent) {
				this->CustomPerInstanceSMData[InstanceIndex].ItemComponent->InstanceID = -1;
			}

			int LastInstanceIndex = max_instances - 1;
			if (InstanceIndex == LastInstanceIndex)
			{
				this->CustomPerInstanceSMData.RemoveAt(InstanceIndex);
			}
			else
			{
				this->CustomPerInstanceSMData.RemoveAtSwap(InstanceIndex);
			}
		}
		// resync ids - todo, only should be needed at RemoveAtSwap
		for (int i = 0; i < this->CustomPerInstanceSMData.Num(); i++) {
			if (this->CustomPerInstanceSMData[i].ItemComponent) {
				this->CustomPerInstanceSMData[i].ItemComponent->InstanceID = i;
			}
		}
	}

	static void FindAllChildrenComponents(USceneComponent* component, TArray<USceneComponent*> &descendants)
	{
		// no reset, we onlt want to append
		USCS_Node* SCSNode = ComponentUtils::FindCorrespondingSCSNode(component);
		if (SCSNode != nullptr)
		{
			// gather children from the SCSNode
			for (USCS_Node* SCSChild : SCSNode->GetChildNodes())
			{
				USceneComponent* ChildSceneComponent = Cast<USceneComponent>(SCSChild->ComponentTemplate);
				if (ChildSceneComponent != nullptr && !descendants.Contains(ChildSceneComponent))
				{
					descendants.Add(ChildSceneComponent);

					UBuildingComponent::FindAllChildrenComponents(ChildSceneComponent, descendants);
				}
			}
		}
	}

	int32 Duplicate(int32 index)
	{
		auto tfm = FTransform(this->PerInstanceSMData[index].Transform);

		auto new_index = this->AddInstance(tfm);
		PostDuplicateInstance(index, new_index);

		return new_index;
	}

#if WITH_EDITOR
	static void SetInstanceSelection(UInstancedStaticMeshComponent* component, int startIndex, int instanceCount = 1, bool state = true, bool clear = true)
	{
		auto components = UBuildingComponent::GetAllComponents(component, true, true);
		int i = 0;
		for (auto link : components)
		{
			auto arch = link.Component->HasAnyFlags(RF_ArchetypeObject);
			if (clear) { link.Component->ClearInstanceSelection(); }

			if (!arch) {
				if (link.Component->PerInstanceSMData.Num() > startIndex) {
					link.Component->SelectInstance(state, startIndex, instanceCount);
					auto bc = Cast<UBuildingComponent>(link.Component);
					if (bc) {
						bc->RebuildSelection();
					}
				}
			}
			i++;
		}
	}

	static void ClearSelectedInstances(UInstancedStaticMeshComponent* component, int startIndex, int instanceCount = 1, bool state = true)
	{
		auto components = UBuildingComponent::GetAllComponents(component, true, false);
		for (auto link : components)
		{
			auto arch = link.Component->HasAnyFlags(RF_ArchetypeObject);
			link.Component->ClearInstanceSelection();
		}
	}

	void PostEditChangeChainProperty(FPropertyChangedChainEvent& PropertyChangedEvent);
	void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent);
	//void PreEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent);
#endif
};