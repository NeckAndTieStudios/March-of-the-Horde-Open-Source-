// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine.h"
#include "Engine/Classes/GameFramework/Actor.h"
//#include "Public/Containers/Queue.h"
#include "ActorPool.generated.h"

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FActorPoolEntry
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		AActor* Actor;
/*
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int Ticket;*/

	FActorPoolEntry() { }
	FActorPoolEntry(AActor* Actor)
	{
		this->Actor = Actor;
	}
};

UCLASS(Blueprintable, BlueprintType)
class FPSPROJECT_API UActorPool : public UObject
{
	GENERATED_BODY()

protected:
	TQueue<class AActor*> pool;
	TArray<class AActor*> leased;

	void allocate();

	int capacity = 0;

	void ReleaseByArg(AActor * actor);

	int FindLeased(AActor* actor);

public:
	UActorPool();
	~UActorPool();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Actor Pool")
		int BlockSize = 1000;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Actor Pool")
		TSubclassOf<class AActor> ActorClass;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Actor Pool")
		bool AllowIncrease = true;

	UFUNCTION()
		AActor * Aquire();

	UFUNCTION()
		void Release(AActor * actor);

	UFUNCTION()
		int GetCapacity();

	UFUNCTION()
		int GetLeased();

	UFUNCTION()
		bool IsLeased(AActor* actor);
};

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent))
class FPSPROJECT_API UActorPoolComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UActorPoolComponent()
	{

	}

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Actor Pool")
		UActorPool * Pool;
};