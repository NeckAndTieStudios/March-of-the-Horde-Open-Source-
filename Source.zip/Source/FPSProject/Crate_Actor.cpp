// Fill out your copyright notice in the Description page of Project Settings.

#include "Crate_Actor.h"


// Sets default values
ACrate_Actor::ACrate_Actor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void ACrate_Actor::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void ACrate_Actor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

