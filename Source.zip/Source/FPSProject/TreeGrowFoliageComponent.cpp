// Fill out your copyright notice in the Description page of Project Settings.

#include "TreeGrowFoliageComponent.h"
#include "Engine.h"
#include "DrawDebugHelpers.h"
#include "FPSCharacter.h"

// Sets default values
UTreeGrowFoliageComponent::UTreeGrowFoliageComponent()
{
	PrimaryComponentTick.bCanEverTick = true; // will be disabled when not required

	// InitializeComponent
	bWantsInitializeComponent = true;
}

// Called when the game starts or when spawned
void UTreeGrowFoliageComponent::BeginPlay()
{
	Super::BeginPlay();

	//this->GameInstance = this->GetWorld()->GetGameInstance<UGlobalGameInstance>();

	SetComponentTickEnabled(false);
}

// Called every frame
void UTreeGrowFoliageComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	
}