// Fill out your copyright notice in the Description page of Project Settings.

#include "SurfaceEffectLibrary.h"
#include "AutoInstancedStaticMeshActor.h"
#include "SurfaceEffect.h"

USurfaceEffect* USurfaceEffectLibrary::GetSurfaceEffect(int surfaceEffectID, UGlobalGameInstance* gameInstance)
{
	USurfaceEffect* effect = NULL;

	if (gameInstance->DatabaseInstances.Num() > surfaceEffectID) {
		effect = gameInstance->DatabaseInstances[surfaceEffectID];
	}

	return effect;
}

USurfaceEffect* USurfaceEffectLibrary::GetSurfaceEffectBySurfaceType(int surfaceTypeID, UGlobalGameInstance* gameInstance)
{
	USurfaceEffect* effect = NULL;

	if (gameInstance->SurfaceTypeInstances.Num() > surfaceTypeID) {
		effect = gameInstance->SurfaceTypeInstances[surfaceTypeID];
	}

	return effect;
}

//void U3dDecalLibrary::Spawn3dDecal(int surfaceEffectID, FVector location, FRotator rotation)
//{
//	if (surfaceEffectID >= 0 && USurfaceEffect::MappedInstances.Num() > surfaceEffectID)
//	{
//		auto effect = USurfaceEffect::MappedInstances[surfaceEffectID];
//		//auto entry = AAutoInstancedStaticMeshActor::GetInstanceComponent(mesh, EComponentMobility::Static, this->GetCollisionProfileName(), actor, EInstancedCategory::Buildings);
//	}
//}