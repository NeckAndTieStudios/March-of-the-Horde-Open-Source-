// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "AutoInstancedStaticMeshComponent.generated.h"

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable)
class FPSPROJECT_API UAutoInstancedStaticMeshComponent : public UActorComponent
{
	GENERATED_BODY()

public:

protected:

public:
	UAutoInstancedStaticMeshComponent();

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TEnumAsByte<EComponentMobility::Type> Mobility;

	virtual void BeginPlay() override;
};