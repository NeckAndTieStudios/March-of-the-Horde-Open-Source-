// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "InteractionTrigger.generated.h"

UENUM(BlueprintType)
enum class EInteractionTrigger : uint8
{
	None = 1 UMETA(DisplayName = "None"),
	Any = 2 UMETA(DisplayName = "Any"),

	Primary = 3 UMETA(DisplayName = "Primary (Left Mouse)"),
	Secondary = 4 UMETA(DisplayName = "Secondary (Right Mouse)"),
	Look = 5 UMETA(DisplayName = "Look"),
	Pickup = 6 UMETA(DisplayName = "Pickup"),
	Bullet = 7 UMETA(DisplayName = "Bullet"),

	MAX = Bullet UMETA(Hidden),
	DEFAULT = None UMETA(DisplayName = "DEFAULT (None)")
};