// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "GameFramework/Actor.h"
#include "GameFramework/Volume.h"
#include "GameFramework/Character.h"
#include "DrawDebugHelpers.h"
#include "Engine.h"
#include "CreatureSpawner.generated.h"

class UCreatureSpawner;
class ACreatureSpawnerVolume;

UCLASS(Blueprintable, BlueprintType)
class FPSPROJECT_API ACreatureCharacter : public ACharacter
{
	GENERATED_BODY()

public:

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UCreatureSpawner* Spawner;*/

	//virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

};

UCLASS()
class FPSPROJECT_API UCreatureCharacterComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UCreatureSpawner* Spawner;

	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
};

USTRUCT(Blueprintable, BlueprintType)
struct FCreatureBlueprint
{
	GENERATED_USTRUCT_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TSubclassOf<ACharacter> NPC;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TSubclassOf<UCreatureSpawner> Spawner;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int MaxCreatures = 10;

	/// How often to check for spawning a new NPC (in seconds)
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float SpawnInterval = 5.0f;

	/// Radius of the trace to detect ground level
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float GroundColliderSize = 5.0f;

	/// Offset applied to the spawn location
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FVector SpawnLocationOffset = FVector(0, 0, 50);

	/// Whether this spawner should work in game
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool Enabled = true;
};

UCLASS(Blueprintable, BlueprintType)
class FPSPROJECT_API UCreatureSpawnerComponent : public USceneComponent
{
	GENERATED_BODY()

public:
};

UCLASS(Blueprintable, BlueprintType)
class FPSPROJECT_API UCreatureSpawner : public UObject
{
	GENERATED_BODY()

private:

	FTimerHandle OnTrySpawnHandle;

	int CreaturesSpawned = 0;

public:

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FCreatureBlueprint Blueprint;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		AActor* Owner;

	virtual UWorld* GetWorld() const override //allows world-based functions to show in blueprints
	{
		//return this->world;
		if (HasAllFlags(RF_ClassDefaultObject))
		{
			// If we are a CDO, we must return nullptr instead of calling Outer->GetWorld() to fool UObject::ImplementsGetWorld.
			return nullptr;
		}
		return GetOuter()->GetWorld();
	}

	//UPROPERTY(EditAnywhere, BlueprintReadWrite)
		//ACreatureSpawnerVolume* CreatureSpawnerVolume;

	UFUNCTION(BlueprintNativeEvent)
		void BeginPlay();

	AActor* GetOwner()
	{
		return this->Owner;
	}

	UFUNCTION(BlueprintNativeEvent)
		void EndPlay(const EEndPlayReason::Type EndPlayReason);

	UFUNCTION(BlueprintNativeEvent)
		void StartSpawn();

	UFUNCTION(BlueprintNativeEvent)
		bool CanSpawnNpc(FTransform transform);

	UFUNCTION(BlueprintNativeEvent)
		FTransform GetSpawnLocation();

	UFUNCTION(BlueprintNativeEvent)
		void SpawnNpc();

	UFUNCTION(BlueprintNativeEvent)
		void ReleaseNpc(AActor* creature);

	UFUNCTION(BlueprintNativeEvent)
		void OnTrySpawn();
};

UCLASS(Blueprintable, BlueprintType)
class FPSPROJECT_API ACreatureSpawnerVolume : public AVolume
{
	GENERATED_UCLASS_BODY()

protected:

public:
	int m_CurrentCreatures = 0;

	UPROPERTY(Category = CreatureSpawner, EditAnywhere, BlueprintReadWrite)
		TArray<FCreatureBlueprint> Creatures;

	UPROPERTY(Category = CreatureSpawner, EditAnywhere, BlueprintReadWrite)
		TArray<UCreatureSpawner*> Components;

	/// Allows this volume to limit the max creatures the spawners are producing. 0 to disable
	UPROPERTY(Category = CreatureSpawner, EditAnywhere, BlueprintReadWrite)
		int MaxCreatures = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool Enabled = true;

	virtual void BeginPlay() override
	{
		Super::BeginPlay();

		for (auto creature : Creatures) {

			if (creature.Spawner) {
				auto component = NewObject<UCreatureSpawner>(this, creature.Spawner);
				//component->SetupAttachment(this->GetBrushComponent());
				//component->AttachToComponent(this->GetBrushComponent(), FAttachmentTransformRules::KeepRelativeTransform);
				//component->SetWorldTransform(this->GetActorTransform());

				component->Owner = this;
				component->Blueprint = creature;
				//component->CreatureSpawnerVolume = this;

				Components.Add(component);
				//component->RegisterComponent();

				component->BeginPlay();
			}
		}

	}
	void EndPlay(const EEndPlayReason::Type EndPlayReason) override
	{
		for (auto component : Components) {

			component->EndPlay(EndPlayReason);
		}
	}

	/*UPROPERTY(Category = CreatureSpawner, VisibleAnywhere, BlueprintReadOnly)
		UCreatureSpawner* CreatureSpawnerComponent;

	ACreatureSpawnerVolume();*/
	//
	//#if WITH_EDITOR
	//
	//	// UObject interface
	//	virtual void PostEditImport() override;
	//
	//	virtual bool GetReferencedContentObjects(TArray<UObject*>& Objects) const override;
	//#endif
};
