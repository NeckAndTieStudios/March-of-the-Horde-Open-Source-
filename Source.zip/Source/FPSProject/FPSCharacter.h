// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "Engine.h"
#include "FPSProjectile.h"
#include "Crate_Actor.h"
#include "Barrel.h"
#include "Bullet.h"
#include "Weapon.h"
#include "Camera/CameraComponent.h"
#include "HitComponent.h"
#include "HitLoot.h"
#include "ItemWidget.h"
#include "Components/ScrollBox.h"
#include "Components/GridPanel.h"
#include "CharacterInventoryWidget.h"
#include "DatabaseModels.h"
#include "AvailableIngredientResult.h"
#include "BuildingComponent.h"
#include "ItemContainer.h"
#include "UnrealNetwork.h"
#include "Engine/ActorChannel.h"
#include "FPSCharacter.generated.h"

const FString CHARACTER_INVENTORY_MAIN = TEXT("Inventory");
const FString CHARACTER_INVENTORY_TOOLBELT = TEXT("Toolbelt ");
const FString CHARACTER_INVENTORY_STASH = TEXT("Stash");
const FString CHARACTER_INVENTORY_CRAFT_QUEUE = TEXT("Craft Queue");

USTRUCT(Blueprintable, BlueprintType)
struct FTryFindItemByInventoryResult
{
	GENERATED_USTRUCT_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int SlotID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FItemData Slot;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UItemContainer* Container;

	FTryFindItemByInventoryResult() {}
	FTryFindItemByInventoryResult(UItemContainer* container, int slotID, FItemData slot)
	{
		this->Container = container;
		this->SlotID = slotID;
		this->Slot = slot;
	}
};

USTRUCT(Blueprintable, BlueprintType)
struct FTakeFromInventoryRequest
{
	GENERATED_USTRUCT_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int RequiredItemID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float RequiredAmount;

	FTakeFromInventoryRequest() {}
	FTakeFromInventoryRequest(int requiredItemID, float requiredAmount)
	{
		this->RequiredItemID = requiredItemID;
		this->RequiredAmount = requiredAmount;
	}
};

USTRUCT(Blueprintable, BlueprintType)
struct FTakeUpgradeFromInventoryRequest : public FTakeFromInventoryRequest
{
	GENERATED_USTRUCT_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UItemUpgradeInstance* UpgradeInstance;

	FTakeUpgradeFromInventoryRequest() {}
	FTakeUpgradeFromInventoryRequest(UItemUpgradeInstance* instance)
	{
		this->RequiredItemID = instance->RequiredItemID;
		this->RequiredAmount = instance->Stack;
		this->UpgradeInstance = instance;
	}
};

USTRUCT(Blueprintable, BlueprintType)
struct FTakeRepairFromInventoryRequest : public FTakeFromInventoryRequest
{
	GENERATED_USTRUCT_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UItemRepairInstance* RepairInstance;

	FTakeRepairFromInventoryRequest() {}
	FTakeRepairFromInventoryRequest(UItemRepairInstance* instance)
	{
		this->RequiredItemID = instance->RepairItemID;
		this->RequiredAmount = instance->RequiredQuantity;
		this->RepairInstance = instance;
	}
};

USTRUCT(Blueprintable, BlueprintType)
struct FTakeIngredientFromInventoryRequest : public FTakeFromInventoryRequest
{
	GENERATED_USTRUCT_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FItemData ItemIngredientInstance;

	FTakeIngredientFromInventoryRequest() {}
	FTakeIngredientFromInventoryRequest(FItemData instance)
	{
		this->RequiredItemID = instance.ItemID;
		this->RequiredAmount = instance.Stack;
		this->ItemIngredientInstance = instance;
	}
};

//UCLASS()
//class FPSPROJECT_API ABuildModeActor : public AActor
//{
//	GENERATED_BODY()
//
//protected:
//
//public:
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		UStaticMesh* Mesh;
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		UItemInstance* Item;
//
//	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
//		void Init(UItemInstance* ItemInstance, UStaticMesh* StaticMesh);
//};

UENUM(BlueprintType)
enum class ETraceType : uint8
{
	LineSingle = 1 UMETA(DisplayName = "Line - first object"),
	SphereSingle = 2 UMETA(DisplayName = "Sphere - first object"),
	LineMulti = 3 UMETA(DisplayName = "Line - multiple objects"),
	SphereMulti = 4 UMETA(DisplayName = "Sphere - multiple objects"),
};

UCLASS()
class FPSPROJECT_API AMOTHCharacter : public ACharacter
{
	GENERATED_BODY()

private:

	/** pawn mesh: 1st person view */
	UPROPERTY(VisibleDefaultsOnly, Category = Mesh)
		USkeletalMeshComponent* Mesh1P;

protected:
	/** Returns Mesh1P subobject **/
	FORCEINLINE USkeletalMeshComponent* GetMesh1P() const { return Mesh1P; }

public:
	AMOTHCharacter(const FObjectInitializer& ObjectInitializer);

	// Called every frame
	virtual void Tick(float DeltaTime) override;

	virtual void BeginPlay() override;

#pragma region Toolbelt
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ToolbeltIndex;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int LastToolbeltIndex;

	UFUNCTION(BlueprintCallable) FItemData GetToolbeltItemByIndex(int index)
	{
		FItemData result = FItemData();
		UItemContainer* container = NULL;

		//if (result == NULL) {
		if (result.ItemID <= 0) {
			container = this->TryGetContainerByName("Toolbelt 1");
		}
		/*if (result == NULL) {
			container = this->TryGetContainerByName("Toolbelt 2");
		}*/

		if (container) {
			result = container->Items[index];
		}

		return result;
	}

	UFUNCTION(BlueprintCallable) FItemData GetSelectedItemInToolbelt()
	{
		return GetToolbeltItemByIndex(ToolbeltIndex);
	}

	UFUNCTION(BlueprintCallable) bool TakeItemFromInventory(int itemID, float amount)
	{
		TArray<FTakeFromInventoryRequest> requests;
		requests.Add(FTakeFromInventoryRequest(itemID, amount));
		return AMOTHCharacter::TryTakeFromInventory<FTakeFromInventoryRequest, bool>(this, requests, [this, amount](TArray<FTryFindItemByInventoryResult> results, TArray<FTakeFromInventoryRequest> requests) {


			return true;
			}, false);
	}

	UFUNCTION(BlueprintCallable) bool TakeItemFromToolbelt(float amount = 1)
	{
		auto container = this->TryGetContainerByName("Toolbelt 1");
		if (!container || container->Items[ToolbeltIndex].ItemID == 0) {
			return false;
		}

		TArray<FTakeFromInventoryRequest> requests;
		requests.Add(FTakeFromInventoryRequest(container->Items[ToolbeltIndex].ItemID, amount));
		return AMOTHCharacter::TryTakeFromInventory<FTakeFromInventoryRequest, bool>(this, requests, [this, amount](TArray<FTryFindItemByInventoryResult> results, TArray<FTakeFromInventoryRequest> requests) {


			return true;
			}, false, container, ToolbeltIndex);
	}

	UFUNCTION(BlueprintCallable, BlueprintNativeEvent) void MoveToolBeltSelection(int ToolBeltID, int Direction);
#pragma endregion

#pragma region UI
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsShiftKeyDown = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		USelectableWidget* SelectedWidget;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsHUDVisible = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Replicated, ReplicatedUsing = OnRep_IsInventoryOpen)
		bool IsInventoryOpen = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Replicated, ReplicatedUsing = OnRep_IsInventoryCraftingOpen)
		bool IsInventoryCraftingOpen = false;

	UFUNCTION() virtual void OnRep_IsInventoryOpen()
	{
		//GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString(TEXT("IsInventoryOpen replicated")));
		//UE_LOG(LogTemp, Warning, TEXT("IsInventoryOpen replicated"));
	}

	UFUNCTION() virtual void OnRep_IsInventoryCraftingOpen()
	{
		//GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString(TEXT("IsInventoryCraftingOpen replicated")));
		//UE_LOG(LogTemp, Warning, TEXT("IsInventoryCraftingOpen replicated"));
	}

	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
		void OnToolbeltUpdated(int toolbeltID);

	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
		UUserWidget* GetHUDWidget();

	UFUNCTION(BlueprintCallable, BlueprintNativeEvent)
		void SetSelectedWidget(USelectableWidget* widget);
#pragma endregion

#pragma region Building
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int BuildActorRotateDirection = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float BuildActorRotateSpeed = 5.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool BuildModeSnapRotation = true;


	/*UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Building)
		AActor* BuildModeActor = NULL;*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Weapons)
		TSubclassOf<class ABuildingMeshActor> BuildModeActorClass;

	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
		USkeletalMeshComponent* GetWeaponAttachSkeletalMesh();

	UFUNCTION(BlueprintCallable) void SetBuildModeRotation(int direction, bool rotating)
	{
		auto build_actor = Cast<ABuildingMeshActor>(this->HeldActor);
		if (build_actor) {
			auto preview_actor = build_actor->GetPreviewActor();
			if (preview_actor) {
				if (rotating) {
					if (BuildModeSnapRotation) {
						//45deg 
						preview_actor->AddActorLocalRotation(FRotator(0, 45 * direction, 0));
					}
					else {
						//incremental
						BuildActorRotateDirection = direction;
					}
				}
				else {
					BuildActorRotateDirection = 0;
				}
			}
			else {

			}
		}
	}

	UFUNCTION(BlueprintCallable) void UpdateBuildModeRotation(float Delta)
	{
		if (!BuildModeSnapRotation && BuildActorRotateDirection != 0) {
			auto build_actor = Cast<ABuildingMeshActor>(this->HeldActor);
			if (build_actor) {
				auto preview_actor = build_actor->GetPreviewActor();
				if (preview_actor) {
					auto yaw = BuildActorRotateSpeed * BuildActorRotateDirection;
					FRotator rotation(0, yaw, 0);
					preview_actor->AddActorLocalRotation(rotation);
				}
				else {

				}
			}
		}
	}

	UFUNCTION(BlueprintCallable) bool GetIsInBuildMode()
	{
		return !!Cast<ABuildingMeshActor>(this->HeldActor);
	}

	UFUNCTION(BlueprintCallable) void SetHeldActor(AActor* NewHeldActor, const FItemData& Item);

	UFUNCTION(BlueprintCallable) AWeapon* GetDefaultHeldActor()
	{
		auto actor = GetWorld()->SpawnActor<AWeapon>(this->HeldActorClass, FVector(0.f), FRotator(0.f));
		actor->SetOwner(this);
		actor->AttachToActor(this, FAttachmentTransformRules(EAttachmentRule::SnapToTarget, true/*super dooper important in order for world position to work*/));
		return actor;
	}

	UFUNCTION(BlueprintCallable) void SetBuildMode(UStaticMesh* BuildMesh, const FItemData& Item)
	{
		//auto build_actor = Cast<ABuildModeActor>(this->HeldActor);
		//if (build_actor) {
		//	// existing actor
		//	if (build_actor->Mesh != BuildMesh || (Item && Item->IsPlaceable)) {
		//		build_actor->Destroy();
		//		this->HeldActor = NULL;
		//	}
		//}

		if (BuildMesh) {
			//FActorSpawnParameters params;
			//params.Owner = thus;
			auto sma = GetWorld()->SpawnActor<ABuildingMeshActor>(BuildModeActorClass); // , FTransform(), params);
			if (sma) {
				sma->SetOwner(this);
				sma->SetActorRelativeLocation(FVector());
				sma->SetActorRelativeRotation(FRotator());

				/*auto smc = sma->GetStaticMeshComponent();
				if (smc) {
					smc->SetStaticMesh(BuildMesh);
				}*/

				this->SetHeldActor(sma, Item);

				auto mesh = GetWeaponAttachSkeletalMesh();
				if (mesh) {
					FAttachmentTransformRules rules(EAttachmentRule::SnapToTarget, EAttachmentRule::KeepRelative, EAttachmentRule::KeepRelative, true);
					sma->AttachToComponent(mesh, rules);
				}

				/*auto selected_widget = this->GetSelectedItemInToolbelt();
				if (selected_widget && selected_widget->ItemInstance) {
					build_actor->SetActorRelativeLocation(selected_widget->ItemInstance->HandOffsetLocation);
					build_actor->SetActorRelativeRotation(selected_widget->ItemInstance->HandOffsetRotation);
				}*/
				/*if (ItemInstance) {
					build_actor->SetActorRelativeLocation(ItemInstance->BuidOffsetLocation);
					build_actor->SetActorRelativeRotation(ItemInstance->BuidOffsetRotation);
				}*/

				sma->SetActorEnableCollision(true);
				sma->SetActorTickEnabled(true);
				sma->SetActorHiddenInGame(false);

				sma->Init(Item, BuildMesh);
			}
		}
		else {
			this->SetHeldActor(NULL, FItemData());
		}
	}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Weapons, Replicated, ReplicatedUsing = OnRep_RequiresHandActorUpdate)
		bool RequiresHandActorUpdate = false;

	UFUNCTION() virtual void OnRep_RequiresHandActorUpdate()
	{
		GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString(TEXT("RequiresHandActorUpdate replicated")));
		UE_LOG(LogTemp, Warning, TEXT("RequiresHandActorUpdate replicated"));
	}

	UFUNCTION(BlueprintCallable) void UpdateCurrentlyHeldItem()
	{
		RequiresHandActorUpdate = true;
	}

	UPROPERTY(EditAnywhere, Category = Weapons)
		FItemData LastHeldItemInstance = FItemData();
	// SERVER 
	UFUNCTION(BlueprintCallable) void TryUpdateHeldActor()
	{
		if (Role < ROLE_Authority) {
			return;
		}

		this->RequiresHandActorUpdate = false;

		auto selected_widget = GetSelectedItemInToolbelt();

		//if (IsValid(selected_widget)) {
		if (selected_widget.ItemID > 0) {
			if (LastHeldItemInstance.ItemID != selected_widget.ItemID) {
				LastHeldItemInstance = selected_widget;

				auto def = GetGameInstance<UGlobalGameInstance>()->ItemCache->GetLocalItemByID(selected_widget.ItemID);

				if (selected_widget.IsPlaceable) {
					if (def->Alias) {
						auto mesh = Cast<UStaticMesh>(def->Alias->GetInstance());
						SetBuildMode(mesh, selected_widget);
					}
				}
				else {
					auto actor = def->GetActor(this);
					if (IsValid(actor) && !actor->IsPendingKill() && !actor->IsActorBeingDestroyed()) {
						auto mesh = GetWeaponAttachSkeletalMesh();
						if (mesh) {
							actor->AttachToComponent(mesh, FAttachmentTransformRules::KeepRelativeTransform, FName(TEXT("WeaponSocket")));

							/*auto smc = actor->GetComponentByClass(USkeletalMeshComponent::StaticClass());
							if (IsValid(smc)) {
								actor->SetActorRelativeLocation(selected_widget->ItemInstance->HandOffsetLocation);
								actor->SetActorRelativeRotation(selected_widget->ItemInstance->HandOffsetRotation);
							}*/
							//auto smc = actor->GetComponentByClass(UStaticMeshComponent::StaticClass());
							//if (IsValid(smc)) {
							actor->SetActorRelativeLocation(def->HandOffsetLocation);
							actor->SetActorRelativeRotation(def->HandOffsetRotation);
							//}
						}
						actor->SetActorEnableCollision(true);
						actor->SetActorTickEnabled(false);
						actor->SetActorHiddenInGame(false);
					}

					SetHeldActor(actor, selected_widget);
				}
			}
		}
		else {
			//if (IsValid(LastHeldItemInstance)) {
			if (LastHeldItemInstance.ItemID > 0) {
				SetHeldActor(NULL, FItemData());
				LastHeldItemInstance = selected_widget;
			}
		}
	}
#pragma endregion

#pragma region Weapons
	UPROPERTY(EditAnywhere, Category = Weapons)
		AWeapon* Weapon;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Weapons)
		TSubclassOf<class AWeapon> WeaponClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Weapons)
		TSubclassOf<class AWeapon> HandWeaponClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Weapons)
		AWeapon* HandWeapon;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Weapons)
		TSubclassOf<class AActor> HeldActorClass;

	//// the default actor in hand (visible or not) when there is no item in the inventory slot
	//UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Weapons)
	//	AActor * DefaultHeldActor;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Weapons, Replicated, ReplicatedUsing = OnRep_HeldActor)
		AActor* HeldActor;

	UFUNCTION() virtual void OnRep_HeldActor()
	{
		GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString(TEXT("Character.HeldActor replicated")));
		UE_LOG(LogTemp, Warning, TEXT("Character.HeldActor replicated"));
	}

	UFUNCTION(BlueprintCallable)
		void ChangeWeapon(TSubclassOf<class AWeapon> weapon_class);
#pragma endregion

#pragma region Interactables

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Replicated, ReplicatedUsing = OnRep_InstanceMeshReplicator)
		AInstanceMeshReplicator* InstanceMeshReplicator;

	UFUNCTION() virtual void OnRep_InstanceMeshReplicator()
	{
		GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString(TEXT("InstanceMeshReplicator replicated")));
		this->InvalidateLookItem();
	}

	/*void GetLifetimeReplicatedProps(TArray< FLifetimeProperty >& OutLifetimeProps) const
	{
		Super::GetLifetimeReplicatedProps(OutLifetimeProps);
		DOREPLIFETIME(UGlobalGameInstance, InstanceMeshReplicator);
	}*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float ArmLength = 150.0f;

	UPROPERTY()
		float LookForInteractableDelta = 0.f;

	UPROPERTY(EditAnywhere, Category = Interactable, BlueprintReadWrite)
		float LookForInteractableRadius = 10.f;

	UPROPERTY(EditAnywhere, Category = Interactable, BlueprintReadWrite)
		ETraceType LookForInteractableTraceType = ETraceType::LineSingle;

	UPROPERTY(EditAnywhere, Category = Interactable, BlueprintReadWrite)
		bool ShowDebugLookTrace = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float InteractionDistance = 200.f;

	UPROPERTY(EditAnywhere, Category = Interactable, BlueprintReadWrite)
		FHitResult LookAtHitResult;

	UPROPERTY(EditAnywhere, Category = Interactable, BlueprintReadWrite)
		UItemComponent* LookAtItem;

	UPROPERTY(EditAnywhere, Category = Interactable, BlueprintReadWrite)
		TArray<UItemComponent*> LookAtItems;

	UPROPERTY(EditAnywhere, Category = Interactable, BlueprintReadWrite)
		UPrimitiveComponent* LookAtComponent;

	UPROPERTY(EditAnywhere, Category = Interactable, BlueprintReadWrite, Replicated)
		int LookAtInvalidate = 0;

	UPROPERTY()
		int _lastLookAtInvalidate = 0;

	UFUNCTION(BlueprintCallable)
		void InvalidateLookItem(bool invalidateFoliageForEveryone = false)
	{
		LookAtInvalidate++;
		if (invalidateFoliageForEveryone) {
			if (IsValid(this->InstanceMeshReplicator)) {
				this->InstanceMeshReplicator->InvalidateLookItem();
			}
		}
	}

	bool lookInProcess = false;
	UFUNCTION(BlueprintCallable)
		void LookForInteractable(bool force = false);

	UFUNCTION(BlueprintImplementableEvent, Category = "Interactable Events")
		void InteractableFocused();

	UFUNCTION(BlueprintCallable, BlueprintNativeEvent)
		UCameraComponent* GetCamera();

	UFUNCTION(BlueprintCallable)
		void InteractWithLookAtItem();

	UFUNCTION(BlueprintCallable)
		void CancelInteractWithLookAtItem();

	UFUNCTION(BlueprintCallable) void InteractTriggerPressed();
	UFUNCTION(BlueprintCallable) void InteractTriggerReleased();

	UFUNCTION(BlueprintImplementableEvent)
		bool OnInteractTriggerPressed();

	UFUNCTION(BlueprintImplementableEvent)
		bool OnInteractTriggerReleased();

#pragma endregion

	
	UFUNCTION(BlueprintCallable, BlueprintNativeEvent) void OnCameraUpdate(const FVector& CameraLocation, const FRotator& CameraRotation);
	void OnCameraUpdate_Implementation(const FVector& CameraLocation, const FRotator& CameraRotation)
	{
		USkeletalMeshComponent* DefMesh1P = Cast<USkeletalMeshComponent>(GetClass()->GetDefaultSubobjectByName(TEXT("PawnMesh1P")));
		const FMatrix DefMeshLS = FRotationTranslationMatrix(DefMesh1P->RelativeRotation, DefMesh1P->RelativeLocation);
		const FMatrix LocalToWorld = ActorToWorld().ToMatrixWithScale();

		// Mesh rotating code expect uniform scale in LocalToWorld matrix

		const FRotator RotCameraPitch(CameraRotation.Pitch, 0.0f, 0.0f);
		const FRotator RotCameraYaw(0.0f, CameraRotation.Yaw, 0.0f);

		const FMatrix LeveledCameraLS = FRotationTranslationMatrix(RotCameraYaw, CameraLocation) * LocalToWorld.Inverse();
		const FMatrix PitchedCameraLS = FRotationMatrix(RotCameraPitch) * LeveledCameraLS;
		const FMatrix MeshRelativeToCamera = DefMeshLS * LeveledCameraLS.Inverse();
		const FMatrix PitchedMesh = MeshRelativeToCamera * PitchedCameraLS;

		Mesh1P->SetRelativeLocationAndRotation(PitchedMesh.GetOrigin(), PitchedMesh.Rotator());
	}


	UFUNCTION(BlueprintCallable, BlueprintNativeEvent) bool IsFirstPerson();
	bool IsFirstPerson_Implementation()
	{
		return false;
	}
	UFUNCTION(BlueprintCallable, BlueprintNativeEvent) bool IsTargeting();
	bool IsTargeting_Implementation()
	{
		return false;
	}

	void GetLifetimeReplicatedProps(TArray< FLifetimeProperty >& OutLifetimeProps) const
	{
		Super::GetLifetimeReplicatedProps(OutLifetimeProps);

		//DOREPLIFETIME_CONDITION(AMOTHCharacter, Inventories, COND_OwnerOnly);
		//DOREPLIFETIME(AMOTHCharacter, ToolbeltIndex);
		//DOREPLIFETIME(AMOTHCharacter, InventoryMap);
		DOREPLIFETIME(AMOTHCharacter, InventoryWeight);
		DOREPLIFETIME(AMOTHCharacter, Inventories);
		DOREPLIFETIME(AMOTHCharacter, HeldActor);
		DOREPLIFETIME(AMOTHCharacter, InstanceMeshReplicator);
	}

	virtual bool ReplicateSubobjects(UActorChannel* Channel, FOutBunch* Bunch, FReplicationFlags* RepFlags) override
	{
		bool wroteSomething = Super::ReplicateSubobjects(Channel, Bunch, RepFlags);
		//wroteSomething |= Channel->ReplicateSubobjectList(InventoryMap, *Bunch, *RepFlags);
		wroteSomething |= Channel->ReplicateSubobjectList(Inventories, *Bunch, *RepFlags);

		//for (auto container : Inventories)
		//{
		//	if (container)
		//	{
		//		//wroteSomething |= Channel->ReplicateSubobject(container, *Bunch, *RepFlags);
		//		wroteSomething |= container->ReplicateSubobject(Channel, *Bunch, *RepFlags);
		//	}
		//}

		return wroteSomething;
	}

#pragma region Inventories
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Replicated)
		float InventoryWeight = 0.f;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Inventory)
		TMap<FString, UItemContainer*> Inventory;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Inventory)
		TArray<FInventoryConfig> InventoryConfig;*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Inventory, Replicated, ReplicatedUsing = OnRep_Inventories)
		TArray<UItemContainer*> Inventories;

	UFUNCTION() virtual void OnRep_Inventories()
	{
		GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString(TEXT("Inventories replicated")));
		UE_LOG(LogTemp, Warning, TEXT("Inventories replicated"));

		if (Inventories.Num() > 0 && InventoryMap.Num() == 0) {
			bool created = false;
			for (int i = 0; i < Inventories.Num(); i++) {
				if (Inventories[i]) {
					InventoryMap.Add(Inventories[i]->Name, i);
					created = true;
				}
			}
			if (created) {
				OnInventoryCreated();
			}
		}

		// update the item in hand if something has changed it
		// TODO: scope this by selected toolbelt if that was replicated (no idea if possible)
		this->UpdateCurrentlyHeldItem();
	}

	UFUNCTION(BlueprintImplementableEvent, Category = "Inventory Events")
		void OnInventoryCreated();
	/*
		UFUNCTION(BlueprintImplementableEvent, Category = "Inventory Events")
			void OnRequestSlotChange(UItemContainer* container);*/

	UPROPERTY(Replicated)
		TMap<FString, int> InventoryMap;

	UFUNCTION(BlueprintCallable) virtual UItemContainer* CreateInventory(FString inventoryName, int slots)
	{
		auto container = NewObject<UItemContainer>(this, FName(*this->GetName().Append(FString("_Inventory_")).Append(inventoryName)));
		//auto container = CreateDefaultSubobject<UItemContainer>(FName(*FString(TEXT("Inventory_")).Append(inventoryName)));
		container->Setup(inventoryName, slots);
		int ID = Inventories.Add(container);

		InventoryMap.Add(inventoryName, ID);

		//GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString(TEXT("Added inventory: ")).Append(inventoryName));
		//UE_LOG(LogTemp, Warning, FString(TEXT("Added inventory: ")).Append(inventoryName));

		return container;
	}

	UFUNCTION(BlueprintCallable) virtual FHitResult Trace(FName traceName, float traceRadius, ETraceType traceType)
	{
		FHitResult result = FHitResult();

		auto controller = this->GetController();
		if (controller) {
			FVector trace_start;
			FRotator rotation;
			controller->GetPlayerViewPoint(trace_start, rotation);

			auto trace_end = trace_start + rotation.RotateVector(FVector(this->InteractionDistance, 0.f, 0.f));

			result = this->TraceManual(traceName, traceRadius, traceType, trace_start, trace_end);
		}

		return result;
	}

	UFUNCTION(BlueprintCallable) virtual FHitResult TraceManual(FName traceName, float traceRadius, ETraceType traceType, FVector trace_start, FVector trace_end)
	{
		FHitResult result = FHitResult();

		FCollisionQueryParams collision_params(traceName, true, this);
		collision_params.bReturnPhysicalMaterial = true;

		// ignore the current character or else we will hit weapons or build actors (should make a flag to ignore build mode here)
		collision_params.AddIgnoredActor(this);
		if (this->HeldActor != NULL)
			collision_params.AddIgnoredActor(this->HeldActor);

		FCollisionObjectQueryParams object_params;
		object_params.AddObjectTypesToQuery(ECC_WorldStatic);
		object_params.AddObjectTypesToQuery(ECC_WorldDynamic);
		object_params.AddObjectTypesToQuery(ECC_PhysicsBody);
		object_params.AddObjectTypesToQuery(ECC_Destructible);
		object_params.AddObjectTypesToQuery(ECC_EngineTraceChannel2);
		object_params.AddObjectTypesToQuery(ECC_GameTraceChannel2);


		if (this->ShowDebugLookTrace)
		{
			const FName TraceTag("MOTHCharacter.Trace");
			GetWorld()->DebugDrawTraceTag = TraceTag;
			collision_params.TraceTag = TraceTag;
		}

		FVector extent;
		extent.X = traceRadius * 0.5f;
		extent.Y = extent.X;
		extent.Z = extent.X;
		//if (GetWorld()->SweepSingleByObjectType(hit_result, trace_start, trace_end, FQuat(), object_params, FCollisionShape::MakeSphere(20.f), collision_params) && hit_result.IsValidBlockingHit())
		//if (GetWorld()->SweepMultiByObjectType(results, trace_start, trace_end, FQuat(), object_params, FCollisionShape::MakeCapsule(extent), collision_params) && /*hit_result.IsValidBlockingHit()*/results.Num() > 0)
		//GetWorld()->OverlapAnyTestByObjectType()
			//if (GetWorld()->LineTraceSingleByObjectType(hit_result, trace_start, trace_end, object_params, collision_params) && hit_result.IsValidBlockingHit())

		//TArray<FHitResult> results;

		FHitResult single;
		TArray<FHitResult> multi;

		switch (traceType) {
		case ETraceType::LineSingle:
			if (GetWorld()->LineTraceSingleByObjectType(single, trace_start, trace_end, object_params, collision_params) && single.IsValidBlockingHit())
			{
				result = single;
			}
			break;
		case ETraceType::SphereSingle:
			if (GetWorld()->SweepSingleByObjectType(single, trace_start, trace_end, FQuat::Identity, object_params, FCollisionShape::MakeCapsule(extent), collision_params) && single.IsValidBlockingHit())
			{
				result = single;
			}
			break;
		case ETraceType::LineMulti:
			if (GetWorld()->LineTraceMultiByObjectType(multi, trace_start, trace_end, object_params, collision_params))
			{
				for (int i = 0; i < multi.Num(); i++) {
					if (multi[i].IsValidBlockingHit()) {
						result = multi[i];
						break;
					}
				}
			}
			break;
		case ETraceType::SphereMulti:
			if (GetWorld()->SweepMultiByObjectType(multi, trace_start, trace_end, FQuat::Identity, object_params, FCollisionShape::MakeCapsule(extent), collision_params))
			{
				for (int i = 0; i < multi.Num(); i++) {
					if (multi[i].IsValidBlockingHit()) {
						result = multi[i];
						break;
					}
				}
			}
			break;
		}

		return result;
	}

	UFUNCTION(BlueprintCallable) virtual void SetupInventories()
	{
		/*for (auto config : InventoryConfig)
		{
			auto container = NewObject<UItemContainer>(this);
			container->Setup(config);
			Inventory.Add(container->Name, container);
		}*/

		//GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, TEXT("Creating inventories"));
		FString ObjectName = this->GetName();
		UE_LOG(LogTemp, Warning, TEXT("[%s] Creating inventories"), *ObjectName);

		CreateInventory("Toolbelt 1", 10);
		CreateInventory("Toolbelt 2", 10);
		CreateInventory("Craft Queue", 10);
		CreateInventory("Inventory", 10 * 6);
		CreateInventory("Stash", 10 * 6);

		//GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, TEXT("Done creating inventories"));
		UE_LOG(LogTemp, Warning, TEXT("[%s] Done creating inventories"), *ObjectName);
	}

	UFUNCTION(BlueprintCallable) virtual UItemContainer* TryGetContainerByName(FString InventoryName)
	{
		UItemContainer* container = NULL;

		auto pair = InventoryMap.Find(InventoryName);
		if (pair) {
			int index = *pair;
			container = Inventories[index];
		}

		return container;
	}

	/*UFUNCTION() virtual TMap<FString, UItemContainer*> GetInventories()
	{
		return this->Inventory;
	}*/

	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
		void OnRequestCraft(FItemData item);
	/*
		UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
			void OnRequestRecipeUpdate();*/

	UFUNCTION(BlueprintCallable) virtual float CalculateInventoryWeight()
	{
		float weight = 0.f;

		/*for (const TPair<FString, UItemContainer*>& pair : Inventory)
		{
			weight += pair.Value->CalculateWeight();
		}*/
		/*for (auto container : this->Inventories) {
			weight += container->CalculateWeight();
		}*/

		weight += TryGetContainerByName("Toolbelt 1")->CalculateWeight();
		weight += TryGetContainerByName("Toolbelt 2")->CalculateWeight();
		weight += TryGetContainerByName("Inventory")->CalculateWeight();

		this->InventoryWeight = weight;

		return weight;
	}

	UFUNCTION(BlueprintCallable)
		FAvailableIngredientResult TryFindIngredients(TArray<FItemData> requiredIngredients);

	//template<typename T, typename std::enable_if<std::is_base_of< FTakeFromInventoryRequest, T>::value, T>::type >
	template<typename T, typename R, typename std::enable_if<std::is_base_of<FTakeFromInventoryRequest, T>::value>::type* = nullptr>
	static R TryTakeFromInventory(AMOTHCharacter * character, TArray<T> requests, TFunction<R(TArray<FTryFindItemByInventoryResult>, TArray<T>)> && Process, R defaultValue, UItemContainer * specificContainer = NULL, int specificContainerIndex = -1)
	{
		TArray<FTryFindItemByInventoryResult> matches;

		TArray<UItemContainer*> containers;

		if (specificContainer) {
			containers.Add(specificContainer);
		}
		if (containers.Num() == 0) {
			containers = character->Inventories;
		}

		//auto inventories = character->GetInventories();

		//ensure the upgrade can be fulfilled 
		bool can_fulfill = true;
		for (int i = 0; i < requests.Num(); i++)
		{
			auto request = requests[i];

			if (request.RequiredAmount > 0.f) {
				TArray<FTryFindItemByInventoryResult> slots;
				float available = 0.f;
				/*
								for (const TPair<FString, UItemContainer*>& pair : inventories)
								{
									slots = AMOTHCharacter::TryFindItemByInventory(pair.Value->Items, request.RequiredItemID, available);*/


				for (auto container : containers)
				{
					if (specificContainer && specificContainerIndex > -1) {
						slots.Add(FTryFindItemByInventoryResult(specificContainer, specificContainerIndex, specificContainer->Items[specificContainerIndex]));
					}
					else {
						slots = AMOTHCharacter::TryFindItemByInventory(container, request.RequiredItemID, available);
					}

					if (slots.Num() > 0) {
						matches.Append(slots);
					}

					if (available >= request.RequiredAmount) { // if there is enough, no need to continue looking
						break;
					}
				}

				// we are done looking for this requirement, if there is enough we should no longer proceed
				if (available < request.RequiredAmount) {
					can_fulfill = false;
					break;
				}
			}
		}

		R result;
		if (can_fulfill) {
			result = Process(matches, requests);
			if (result) {
				// deduct
				for (int i = 0; i < requests.Num(); i++)
				{
					auto request = requests[i];
					float remaining = request.RequiredAmount;

					for (int y = 0; y < matches.Num(); y++)
					{
						auto match = matches[y];

						auto slot = &match.Container->Items[match.SlotID];
						float amount_to_deduct = FMath::Min(slot->Stack, remaining);

						slot->Stack -= amount_to_deduct;
						remaining -= amount_to_deduct;

						if (slot->Stack <= 0) {
							match.Container->Items[match.SlotID] = FItemData();
						}

						if (remaining <= 0.f) {
							break;
						}

						/*for (int x = 0; x < match.Slots.Num(); x++) {
							auto slot = match.Slots[x];
							if (slot.ItemID == request.RequiredItemID) {
								float amount_to_deduct = FMath::Min(slot.Stack, remaining);

								slot.Stack -= amount_to_deduct;
								remaining -= amount_to_deduct;

								if (remaining <= 0.f) {
									break;
								}
							}
						}*/
					}
				}

				return result;
			}
		}
		else {

		}
		return defaultValue;
		//return false;
	}

	/*UItemContainer* TryGetContainerByName(FString InventoryName)
	{
		UItemContainer* result = NULL;

		if (this->Inventory.Contains(InventoryName))
		{
			result = this->Inventory[InventoryName];
		}

		return result;
	}*/

	UFUNCTION(BlueprintCallable)
		TArray<FItemData> GetCraftableRecipes();

	UFUNCTION(BlueprintCallable)
		void UpdateCraftRecipes(UScrollBox * parent, bool is_queue_full);// UGridPanel* craft_queue);

	UFUNCTION(BlueprintCallable)
		TArray<FItemData> FindItemsWithinInventory(FString item_term, FString inventory_name);

	TArray<FItemData> TryFindSlotForItem(UItemContainer * container, UPARAM(ref) FItemData & item, bool allow_max_stack, float amount = -1);

	//static TArray<UItemWidget*> TryFindSlotForItem(UItemInstance* item, TArray<UItemContainer*>& container_pool, FString ignore, bool allow_max_stack, bool show_notification);

	UFUNCTION(BlueprintCallable)
		TArray<FItemData> TryFindSlotForItem(UPARAM(ref) FItemData & item, FString ignore, bool allow_max_stack, bool show_notification, float amount = -1);

	UFUNCTION(BlueprintCallable)
		TArray<FItemData> TryFindSlotForItemByInventory(FString inventory_name, UPARAM(ref) FItemData & item, bool allow_max_stack, float amount = -1);

	UFUNCTION(BlueprintCallable)
		TArray<FItemData> TryMoveSlot(FString target_inventory, UItemContainer * container, int slot)
	{
		auto res = TryFindSlotForItemByInventory(target_inventory, container->Items[slot], false);

		if (res.Num() > 0) {
			GEngine->AddOnScreenDebugMessage(-1, 10.0f, FColor::Magenta, FString::Printf(TEXT("Item slot found, new stack size: %f"), container->Items[slot].Stack));
		}

		return res;
	}

	UFUNCTION(BlueprintCallable)
		bool GiveItem(UPARAM(ref) FItemData & item, bool show_notification);

	UFUNCTION(BlueprintCallable)
		void TryCraftItem(UPARAM(ref) FItemData & item, int amount);

	UFUNCTION(BlueprintCallable)
		float CalculateInventoryWeightByName(FString inventory_name);
	/*
		UFUNCTION(BlueprintCallable)
			void AddInventoryWidget(FString inventory_name, UItemInstance* widget);*/

			/*==== EVENTS ====*/

	UFUNCTION(BlueprintImplementableEvent)
		void OnGiveItem(FItemData item);

	UFUNCTION(BlueprintImplementableEvent, Category = "Inventory Events")
		void OnFindSlotForItem(UPARAM(ref) TArray<FItemData> & collection, FItemData item, const FString & ignore, bool allow_max_stack, bool show_notification, float amount = -1);

	UFUNCTION(BlueprintImplementableEvent)
		void OnItemAdded(FItemData item, float initialQuantity);

	UFUNCTION(BlueprintCallable)
		static TArray<FTryFindItemByInventoryResult> TryFindItemByInventory(UItemContainer * container, int itemID, float& available);

	UFUNCTION(BlueprintCallable)
		static void TryFindIngredientsByInventory(UItemContainer * container, FAvailableIngredient & availableIngredient, float& total_required);

	UFUNCTION(BlueprintCallable)
		bool GiveItemByID(int itemID, float quantity, bool show_notification);

#pragma endregion

#pragma region Damage
	UFUNCTION(BlueprintCallable, BlueprintNativeEvent) void OnDamaged(FHitResult HitResult, AActor * initiator, EInteractionTrigger trigger);

	TArray<UItemComponent*> GetFoliageFromRequest(FResolutionRequest request, bool allowInitialisation = true);

	UFUNCTION(BlueprintImplementableEvent, Category = "Client Request Events")
		void RequestFoliageRemoval(FResolutionRequest request);

	UFUNCTION(BlueprintNativeEvent, Category = "")
		void RequestFoliageInteraction(FResolutionRequest request);

	UFUNCTION(Server, Reliable, WithValidation)
		void RequestFoliageInteractionNetwork(FResolutionRequest request);
#pragma endregion

};

class UItemWidget;

UCLASS()
class FPSPROJECT_API AFPSCharacter : public AMOTHCharacter
{
	GENERATED_BODY()

public:
	// Sets default values for this character's properties
	AFPSCharacter(const FObjectInitializer& ObjectInitializer);

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	void OnHotKey_Noclip();

	bool AllowNoClip = false;

	/*ABarrel* _barrel_single;
	ABarrel* _barrel_burst;
	ABarrel* _barrel_auto;
	AWeapon* _weapon;*/

	//UPROPERTY()
		//FTimerHandle LookForInteractableHandle;


	UPROPERTY(EditAnywhere, Category = Interactable)
		int interactableSkip = 0;

	/*
		UPROPERTY(EditAnywhere)
			UGlobalGameInstance* GameInstance;*/
public:
	virtual void AddControllerYawInput(float Val) override;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UCapsuleComponent* InteractionCapsule;*/

		//// Called every frame
		//virtual void Tick(float DeltaTime) override;

		// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	float spawnZ;

	// Handles input for moving forward and backward.
	UFUNCTION()
		void MoveForward(float Value);

	// Handles input for moving right and left.
	UFUNCTION()
		void MoveRight(float Value);

	// Handles input for moving right and left.
	UFUNCTION()
		void LookUp(float Value);

	// Sets jump flag when key is pressed.
	UFUNCTION()
		void StartJump();

	// Clears jump flag when key is released.
	UFUNCTION()
		void StopJump();

	//// Gun muzzle's offset from the camera location.
	//UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Gameplay)
	//	FVector MuzzleOffset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UCameraComponent* ActiveCamera;


	/*virtual UCameraComponent* GetCamera() override
	{
		return ActiveCamera;
	}
*/
	FHitResult GetLookAtHitResult()
	{
		return this->LookAtHitResult;
	}
	UItemComponent* GetLookAtItem()
	{
		return this->LookAtItem;
	}

	//// Projectile class to spawn.
	//UPROPERTY(EditAnywhere, Category = Bullet)
	//	TSubclassOf<class AFPSProjectile> ProjectileClass;

	//// Projectile class to spawn.
	//UPROPERTY(EditAnywhere, Category = Bullet)
	//	TSubclassOf<class ABullet> BulletProjectileClass;

	////// Projectile class to spawn.
	////UPROPERTY(EditAnywhere, Category = Bullet)
	////	TSubclassOf<class ABarrel> BarrelClass;

	//UPROPERTY(EditAnywhere, Category = Bullet)
	//	EFireMode FireMode = EFireMode::Auto;

	//// Projectile class to spawn.
	//UPROPERTY(EditAnywhere, Category = Bullet)
	//	TSubclassOf<class ABarrel> SingleFireClass;
	//// Projectile class to spawn.
	//UPROPERTY(EditAnywhere, Category = Bullet)
	//	TSubclassOf<class ABarrel> BurstFireClass;
	//// Projectile class to spawn.
	//UPROPERTY(EditAnywhere, Category = Bullet)
	//	TSubclassOf<class ABarrel> AutoFireClass;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Weapons)
		UChildActorComponent * WeaponActor;*/
		/*
			UPROPERTY(EditAnywhere, Category = Weapons)
				TSubclassOf<class AWeapon> WeaponClass;*/

				/*UFUNCTION()
					void FireStart();
				UFUNCTION()
					void FireStop();*/

	UFUNCTION(BlueprintImplementableEvent, Category = "Character Events")
		void OnInteractPrimaryPressed();
	UFUNCTION(BlueprintImplementableEvent, Category = "Character Events")
		void OnInteractPrimaryReleased();

	UFUNCTION(BlueprintImplementableEvent, Category = "Character Events")
		void OnInteractSecondaryPressed();
	UFUNCTION(BlueprintImplementableEvent, Category = "Character Events")
		void OnInteractSecondaryReleased();

	UFUNCTION()
		void On_ToggleBulletLines();
	UFUNCTION()
		void On_ToggleBulletInfo();

	UFUNCTION()
		void On_BeginOverlap(class UPrimitiveComponent* OverlappedComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
	UFUNCTION()
		void On_EndOverlap(class UPrimitiveComponent* OverlappedComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

	/*UFUNCTION()
		void OnCycleFireMode();*/

		//UPROPERTY(EditAnywhere)
		//	TSubclassOf<class ACrate_Actor> ToSpawn;

		/*UFUNCTION(BlueprintCallable)
			void Spawn();*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float WalkSpeed = 300.f;
	//float WalkSpeed = 150.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float JogSpeed = 325.0f;
	//float JogSpeed = 325.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float RunSpeed = 100.0f;
	//float RunSpeed = 525.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float SwimSlowSpeed = 100;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float SwimRegularSpeed = 175.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float SwimFastSpeed = 250.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsSwimSlowSpeed = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsSwimRegularSpeed = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsSwimFastSpeed = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsWalking = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsJogging = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsRunning = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float WalkingGravity = 2.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float SwimmingGravity = 0.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float ClimbingGravity = 0.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float RegularBreakingFriction = 0.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float ClimbingBreakingFriction = 0.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool PreventMovement = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsADS = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsNearClimbable = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsOnClimbable = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsMovingCamera = false;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsInventoryOpen = false;*/
		/*
			UPROPERTY(EditAnywhere, BlueprintReadWrite)
				bool IsInventoryCraftingOpen = false;*/

	UFUNCTION()
		void On_StartSprint();

	UFUNCTION()
		void On_StopSprint();

	UFUNCTION(BlueprintImplementableEvent, Category = "Character Events")
		void On_IsOnClimbableChange(bool previous);


	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float Health = 100.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float MaxHealth = 100.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool CanDismount = true;

	/*UFUNCTION(BlueprintCallable)
		void GiveHitLoot(FHitLoot hit_loot);


	UFUNCTION(BlueprintImplementableEvent)
		void OnGiveHitLoot(FHitLoot hit_loot);*/

		/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
			TArray<FHitLoot> ToolBeltInventory;*/

			/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
				TArray<FHitLoot> Inventory;*/

				/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
					TArray<UItemInstance *> Inventory;

				UPROPERTY(EditAnywhere, BlueprintReadWrite)
					TArray<UItemInstance *> ToolBeltInventory;*/

					/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
						TMap<FString, FCharacterInventoryWidget> Inventories;*/


						/*UFUNCTION(BlueprintCallable)
							bool GiveItem(UItemInstance* item, bool show_notification);

						UFUNCTION(BlueprintImplementableEvent)
							void OnGiveItem(UItemInstance* item);*/

	UFUNCTION(BlueprintImplementableEvent, Category = "ToolBelt Events")
		void ToolBelt_OnSlotUpdated(const TArray<UItemWidget*>& collection, int slot, bool inserted, float appendedQuantity);

	UFUNCTION(BlueprintImplementableEvent, Category = "ToolBelt Events")
		void Inventory_OnSlotUpdated(const TArray<UItemWidget*>& collection, int slot, bool inserted, float appendedQuantity);

	/*UFUNCTION(BlueprintImplementableEvent, Category = "Inventory Events")
		void OnFindSlotForItem(const TArray<UItemWidget*>& slots, UItemInstance* item, const FString& ignore, bool allow_max_stack, bool show_notification);

	UFUNCTION(BlueprintCallable)
		void TryCraftItem(UItemInstance* item, int amount);*/
		/*
			UFUNCTION(BlueprintCallable)
				TArray<UItemInstance*> GetCraftableRecipes();*/

				/*UFUNCTION(BlueprintCallable)
					void UpdateCraftRecipes(UScrollBox* parent, UGridPanel* craft_queue);

				UFUNCTION(BlueprintCallable)
					TArray<UItemWidget*> FindItemsWithinInventory(FString item_term, FString inventory_name);*/
					/*
						UFUNCTION(BlueprintCallable)
							float CalculateInventoryWeight(FString inventory_name);*/


							/*UFUNCTION(BlueprintImplementableEvent)
								void OnItemAdded(UItemInstance* item, float initialQuantity);*/

								////template<typename T, typename std::enable_if<std::is_base_of< FTakeFromInventoryRequest, T>::value, T>::type >
								//template<typename T, typename R, typename std::enable_if<std::is_base_of<FTakeFromInventoryRequest, T>::value>::type* = nullptr>
								//static R TryTakeFromInventory(AFPSCharacter* character, TArray<T> requests, TFunction<R(TArray<UItemWidget*>, TArray<T>)> && Process, R defaultValue)
								//{
								//	TArray<UItemWidget*> required;

								//	//ensure the upgrade can be fulfilled 
								//	bool can_fulfill = true;
								//	for (int i = 0; i < requests.Num(); i++)
								//	{
								//		auto request = requests[i];
								//		if (request.RequiredAmount > 0.f) {
								//			// is in inventory?

								//			TArray<UItemWidget*> slots;
								//			float available = 0.f;

								//			slots = AMOTHCharacter::TryFindItemByInventory(character->Inventories[CHARACTER_INVENTORY_MAIN].Widgets, request.RequiredItemID, available);

								//			if (slots.Num() > 0) {
								//				required.Append(slots);
								//			}

								//			if (available < request.RequiredAmount) { // keep looking for more
								//				for (int t = 0; t < UGameSettings::Instance->ToolBelts; t++) {
								//					FString toolbelt = (CHARACTER_INVENTORY_TOOLBELT);
								//					toolbelt = toolbelt.Append(FString::FromInt(t + 1));

								//					auto inventory = character->Inventories.Find(toolbelt);
								//					if (inventory) {
								//						slots = AMOTHCharacter::TryFindItemByInventory(inventory->Widgets, request.RequiredItemID, available);

								//						if (slots.Num() > 0) {
								//							required.Append(slots);
								//						}

								//						if (available >= request.RequiredAmount) { // if there is enough, no need to continue looking
								//							break;
								//						}
								//					}
								//				}
								//			}

								//			// we are done looking for this requirement, if there is enough we should no longer proceed
								//			if (available < request.RequiredAmount) {
								//				can_fulfill = false;
								//				break;
								//			}
								//		}
								//	}

								//	R result;
								//	if (can_fulfill) {
								//		result = Process(required, requests);
								//		if (result) {
								//			// deduct
								//			for (int i = 0; i < requests.Num(); i++)
								//			{
								//				auto request = requests[i];
								//				float remaining = request.RequiredAmount;

								//				for (int x = 0; x < required.Num(); x++) {
								//					auto slot = required[x];
								//					if (slot->ItemInstance->ItemID == request.RequiredItemID) {
								//						float amount_to_deduct = FMath::Min(slot->ItemInstance->Stack, remaining);

								//						slot->ItemInstance->Stack -= amount_to_deduct;
								//						remaining -= amount_to_deduct;

								//						slot->OnUpdated(required, slot->ItemSlot, false, amount_to_deduct);
								//						if (slot->ItemInstance && slot->ItemInstance && slot->ItemInstance->Stack <= 0) {
								//							slot->OnClear();
								//						}

								//						if (remaining <= 0.f) {
								//							break;
								//						}
								//					}
								//				}
								//			}

								//			return result;
								//		}
								//	}
								//	else {

								//	}
								//	return defaultValue;
								//	//return false;
								//}
};
//
//class FCharacterBackgroundTask : public FNonAbandonableTask
//{
//	friend class FAutoDeleteAsyncTask<FCharacterBackgroundTask>;
//
//public:
//	FCharacterBackgroundTask(AFPSCharacter* character) :
//		Character(character)
//	{}
//
//protected:
//	AFPSCharacter* Character;
//
//	void DoWork()
//	{
//		// Place the Async Code here.  This function runs automatically.
//	}
//
//	// This next section of code needs to be here.  Not important as to why.
//
//	FORCEINLINE TStatId GetStatId() const
//	{
//		RETURN_QUICK_DECLARE_CYCLE_STAT(FMyTaskName, STATGROUP_ThreadPoolAsyncTasks);
//	}
//};