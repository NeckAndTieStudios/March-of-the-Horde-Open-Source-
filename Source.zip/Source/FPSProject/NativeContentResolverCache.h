// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ContentResolver.h"
#include "Database.h"
#include "DatabaseModels.h"
//#include "SQLite3UE4Plugin/Classes/SQLiteDatabase.h"
#include "Runtime/Foliage/Public/InstancedFoliageActor.h"
#include "NativeContentResolverCache.generated.h"

struct FFoliageInstanceRef
{
public:
	UInstancedStaticMeshComponent* Component;
	FTransform Transform;
	int InstanceID;

	FFoliageInstanceRef() {}
	FFoliageInstanceRef(UInstancedStaticMeshComponent* component, FTransform transform, int instanceID)
	{
		this->Component = component;
		this->Transform = transform;
		this->InstanceID = instanceID;
	}
};

UCLASS(Blueprintable)
class FPSPROJECT_API UNativeContentResolverCache : public UContentResolver
{
	GENERATED_BODY()

public:

	UFUNCTION(BlueprintCallable, Category = "Content Resolver")
		bool PreLoad();

	virtual UWorld* GetWorld() const override //allows world-based functions to show in blueprints
	{
		//return this->world;
		if (HasAllFlags(RF_ClassDefaultObject))
		{
			// If we are a CDO, we must return nullptr instead of calling Outer->GetWorld() to fool UObject::ImplementsGetWorld.
			return nullptr;
		}
		return GetOuter()->GetWorld();
	}

	// // https://en.wikipedia.org/wiki/Fitness_proportionate_selection
	// // this is a modified version of this
	// // the only difference is that when ALL weights are the same we fallback to a random pick where the weight > 0
	// UFUNCTION(BlueprintCallable, Category = "Random")
	// static int Roulette(TArray<FDatabase> items);

	// ResolveBullet
	// ResolveHarvest
	// ResolveHit

	// ??

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TMap<FString, UItemInstance*> Items;

	//UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Resolution") // let the BP handle this - USQLite is easier to deal with there
	//UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Resolution") 4.19->4.20
	void Initialise() override;

	//UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Resolution") 4.19->4.20
	TArray<UItemComponent*> ResolveInteraction(EInteractionTrigger trigger, FHitResult hit_result, AActor* initiator, bool process = true) override;

	//UItemInstance * ResolveItemByID(int itemID) override;

	//UItemInstance* ResolveItemByAlias(const FString& alias) override;

	//UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Resolution") 4.19->4.20
	//UItemAliasInstance * ResolveAliasForItem(UItemInstance* item) override;

	//TArray<UItemAliasInstance*> ResolveAliases(UItemInstance* item) override;

	//UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Resolution") 4.19->4.20
	//void ResolveAttributesForItem(UItemInstance* &item) override;

	//UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Resolution") 4.19->4.20
	//TArray<UItemInstance *> ResolveLootForItem(UItemInstance* item, EInteractionTrigger trigger) override;

	//TArray<UItemInstance *> ResolveRecipes(UObject* owner) override;

	//TArray<UItemInstance *> ResolveRecipesForItem(UItemInstance* item) override;

	//TArray<UItemInstance *> ResolveIngredientsForItem(UItemInstance* item) override;

	//TArray<UItemInteraction *> ResolveInteractionsForItem(UItemInstance* item) override;

	//TArray<UItemUpgradeInstance *> ResolveUpgradesForItem(UItemInstance* item) override;

	//TArray<UItemRepairInstance *> ResolveRepairRequirementsForItem(UItemInstance* item) override;

	void AddInteractionAtLocation(FHitResult hitResult, UPrimitiveComponent* component, int damage, float radius, float strength) override;

	bool ResolveSkeletalMeshInstance(FResolutionRequest request, TArray<UItemComponent*>& OutItemComponents);
	bool ResolveFoliageInstance(FResolutionRequest request, TArray<UItemComponent*>& OutItemComponents);
	bool ResolveStaticActorInstance(FResolutionRequest request, TArray<UItemComponent*>& OutItemComponents);
	bool ResolveDestructibleMesh(FResolutionRequest request, TArray<UItemComponent*>& OutItemComponents);
	bool ResolveCharacter(FResolutionRequest request, TArray<UItemComponent*>& OutItemComponents);
	bool ResolveCollision(FResolutionRequest request, TArray<UItemComponent*>& OutItemComponents);
	bool ResolveUsingRootComponent(FResolutionRequest request, TArray<UItemComponent*>& OutItemComponents);
	bool ResolveInstanceMesh(FResolutionRequest request, TArray<UItemComponent*>& OutItemComponents);

	//bool PrepareComponent(UItemAliasQueryByAliasResult* result, FResolutionRequest request, TArray<UItemComponent*> &OutItemComponents);
	//bool PrepareComponent(UItemAliasQueryResult* result, FResolutionRequest request, TArray<UItemComponent*> &OutItemComponents);
	bool PrepareComponent(UItemAliasInstance* result, FResolutionRequest request, TArray<UItemComponent*>& OutItemComponents);

	void TransformFoliageInstanceToChunks();

	//static double Distance(FTransform p1, FTransform p2);
	static TArray<FFoliageInstanceRef> OrderByDistance(TArray<FFoliageInstanceRef> pointList);


	//UItemAliasQueryByAliasResult
};