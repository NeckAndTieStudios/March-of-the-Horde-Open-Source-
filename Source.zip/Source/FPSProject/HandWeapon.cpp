// Fill out your copyright notice in the Description page of Project Settings.

#include "HandWeapon.h"
#include "Common.h"
#include "FPSCharacter.h"
#include "Engine.h"

// Sets default values
AHandWeapon::AHandWeapon()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;

	//UnregisterAllComponents();
}

// Called when the game starts or when spawned
void AHandWeapon::BeginPlay()
{
	//this->GameInstance = this->GetWorld()->GetGameInstance<UGlobalGameInstance>();

	Super::BeginPlay();
}

// Called every frame
void AHandWeapon::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AHandWeapon::OnPrimaryPressed()
{
	/*auto character = Cast<AFPSCharacter>(this->GetOwner());
	if (character)  {
		auto item_component = character->GetLookAtItem();
		if (item_component) {
			auto hit = character->GetLookAtHitResult();

			UContentResolver::Instance->ResolveInteraction(EInteractionTrigger::Primary, hit, this);

			return;
		}
	}*/
	this->GetInteraction(EInteractionTrigger::Primary, this->FistSize);
	//auto owner = this->GetOwner();
	//if (owner) {
	//	auto character = Cast<AFPSCharacter>(owner);
	//	if (character) {
	//		if (character->ActiveCamera) {
	//			/*loca = character->ActiveCamera->GetComponentLocation();*/
	//			FCollisionQueryParams collision_params(FName(TEXT("HandWeapon")), true, this);
	//			collision_params.bReturnPhysicalMaterial = true;

	//			FCollisionObjectQueryParams object_params;
	//			object_params.AddObjectTypesToQuery(ECC_WorldStatic);
	//			object_params.AddObjectTypesToQuery(ECC_WorldDynamic);
	//			object_params.AddObjectTypesToQuery(ECC_PhysicsBody);
	//			object_params.AddObjectTypesToQuery(ECC_Destructible);

	//			FHitResult hit_result;

	//			auto direction = character->ActiveCamera->GetComponentRotation();
	//			auto trace_start = character->ActiveCamera->GetComponentLocation();
	//			auto trace_end = trace_start + direction.RotateVector(FVector(character->ArmLength, 0.f, 0.f));

	//			DrawDebugLine(GetWorld(), trace_start, trace_end, FColor::Purple, true, this->FistSize);

	//			//if (GetWorld()->LineTraceSingleByObjectType(hit_result, trace_start, trace_end, object_params, collision_params) && hit_result.IsValidBlockingHit())
	//			if (GetWorld()->SweepSingleByObjectType(hit_result, trace_start, trace_end, FQuat(), object_params, FCollisionShape::MakeSphere(this->FistSize), collision_params) && hit_result.IsValidBlockingHit())
	//			{
	//				trace_end = hit_result.ImpactPoint;

	//				this->GameInstance->ContentResolver->ResolveInteraction(EInteractionTrigger::Primary, hit_result, character);
	//			}
	//		}
	//	}
	//}
}

void AHandWeapon::OnSecondaryPressed()
{
	this->GetInteraction(EInteractionTrigger::Secondary, this->FistSize);
}

//void AHandWeapon::On_TriggerReleased()
//{
//
//}