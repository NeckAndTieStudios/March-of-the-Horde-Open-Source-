// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/GameInstance.h"
#include "GlobalBulletSettings.h"
#include "GameSettings.h"
#include "DecalPool.h"
#include "HitInstance.h"
#include "ContentResolver.h"
#include "Database.h"
#include "ActorPool.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "SQLiteDatabase.h"
#include "ItemCache.h"
#include "GlobalGameInstance.generated.h"

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FSurfaceEffectCache
{
	GENERATED_BODY()

public:
	USurfaceEffect* Effect;
};

/**
 *
 */
UCLASS(Blueprintable, BlueprintType)
class FPSPROJECT_API UGlobalGameInstance : public UGameInstance
{
	GENERATED_BODY()

public:
	UGlobalGameInstance();

	virtual void Init();
	virtual void Shutdown();

	UPROPERTY(BlueprintReadWrite)
		UActorPool* StaticMeshActorPool;

	UPROPERTY(BlueprintReadWrite)
		UDecalPool* DecalPool;

	UPROPERTY(BlueprintReadWrite)
		UContentResolver* ContentResolver;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TSubclassOf<UDecalPool> DecalPoolClass;

	UPROPERTY(BlueprintReadWrite)
		UGameSettings* Settings;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TSubclassOf<UGameSettings> GameSettings;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TSubclassOf<UContentResolver> ContentResolverClass;

	UFUNCTION(BlueprintCallable)
		FGlobalBulletSettings GetBySurfaceType(uint8 surfaceType);

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (TitleProperty = "Name"))
		TArray<FGlobalBulletSettings> SurfaceMap;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (TitleProperty = "Name"))
		TArray<FHitInstance> HitSettingsMap;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float WorldTime;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		UDatabaseLoader* DatabaseLoader;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		USoundCue* MenuSoundCue;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (TitleProperty = "Name"))
		TArray<FItemData> Recipes;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<USurfaceEffect*> SurfaceTypeInstances;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<USurfaceEffect*> DatabaseInstances;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TMap<int, USurfaceEffect*> SurfaceEffects;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		UItemCache* ItemCache;

	UFUNCTION(BlueprintCallable)
		bool MoveISMInstance(UHierarchicalInstancedStaticMeshComponent* source, int32 InstanceID, UStaticMesh* targetMesh, UItemComponent* item_component, UHierarchicalInstancedStaticMeshComponent*& target, int32& targetInstanceID, UHierarchicalInstancedStaticMeshComponent* parent = NULL, int32 reuse_instance = -1, bool use_hidden_instance = false);



};