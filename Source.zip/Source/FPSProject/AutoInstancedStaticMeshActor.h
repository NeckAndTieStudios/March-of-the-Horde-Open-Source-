// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "InstancedComponentsEntry.h"
#include "ItemComponent.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
//#include "WorldStaticMeshComponent.h"
#include "AutoInstancedStaticMeshActor.generated.h"

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FGetItemComponentForInstanceResult
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UItemComponent * Component;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UObject * Data;
};

UCLASS()
class FPSPROJECT_API AAutoInstancedStaticMeshActor : public AActor
{
	GENERATED_BODY()

private:


public:
	AAutoInstancedStaticMeshActor();

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TMap<FString, FInstancedComponentsEntry> InstancedComponents;

	static AAutoInstancedStaticMeshActor* GetInstance(UWorld* world);

	static FGetItemComponentForInstanceResult GetItemComponentForInstance(UHierarchicalInstancedStaticMeshComponent* parent, int instanceID, EInstancedCategory category, AAutoInstancedStaticMeshActor* actor = NULL);
	//static UObject* GetWSMCForInstance(UHierarchicalInstancedStaticMeshComponent* parent, int instanceID, AAutoInstancedStaticMeshActor* actor = NULL);
	static UHierarchicalInstancedStaticMeshComponent* CreateComponent(UStaticMesh* mesh, EComponentMobility::Type mobility, FName collisionProfileName, AAutoInstancedStaticMeshActor* actor);
	static FInstancedComponentsEntry* GetInstanceComponent(UObject* component, UStaticMesh* mesh, EComponentMobility::Type mobility, FName collisionProfileName, AAutoInstancedStaticMeshActor* actor, EInstancedCategory category);

	template< class T >
	static T* GetDataForInstance(UHierarchicalInstancedStaticMeshComponent* parent, int instanceID, EInstancedCategory category, AAutoInstancedStaticMeshActor* actor = NULL)
	{
		T* result = NULL;

		//auto container_name = parent->GetStaticMesh();
		//FString container_reference = UCommon::GetReferencePath(container_name).Append(TEXT("_category_")).Append(FString::FromInt(category));
		FString container_reference = AAutoInstancedStaticMeshActor::GetComponentKey(parent, category);

		if (actor == NULL) {
			actor = AAutoInstancedStaticMeshActor::GetInstance(parent->GetWorld());
		}

		if (actor) {
			auto entry = actor->InstancedComponents.Find(container_reference);
			if (entry) {
				if (entry->Component == parent && entry->ComponentData.Num() > instanceID) {
					auto t_value = Cast<T>(entry->ComponentData[instanceID]);
					if (t_value)
					{
						result = t_value;
					}
				}
			}
		}

		return result;
	}

	static FString GetComponentKey(UObject* mesh_owner, UStaticMesh* mesh, EInstancedCategory category);
	static FString GetComponentKey(UHierarchicalInstancedStaticMeshComponent* component, EInstancedCategory category);

	// Use this to destroy interactice WSMC like a camp fire.
	// UE requires the owning actor to call this
	UFUNCTION(BlueprintCallable)
		void DestroyComponent(USceneComponent* target);

};