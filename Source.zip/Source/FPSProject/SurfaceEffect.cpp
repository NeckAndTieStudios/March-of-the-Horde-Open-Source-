// Fill out your copyright notice in the Description page of Project Settings.

#include "SurfaceEffect.h"
#include "Engine.h"
#include "Weighting.h"
#include "Common.h"
#include "Classes/Kismet/GameplayStatics.h"
#include "GlobalGameInstance.h"
#include "SurfaceEffectSound.h"
#include "Engine/DecalActor.h"
#include "Components/DecalComponent.h"
#include "WorldStaticMeshComponent.h"
#include "BuildingComponent.h"
#include "Engine/StaticMeshActor.h"
#include "Components/StaticMeshComponent.h"
//
//TArray<USurfaceEffect*> USurfaceEffect::SurfaceTypeInstances;
//TArray<USurfaceEffect*> USurfaceEffect::MappedInstances; moved to GI

void USurfaceEffect::PlaySoundAtLocation(FVector location)
{
	if (this->Sounds.Num() > 0) {
		//auto weightings = static_cast<TArray<FWeighting>>(this->Sounds);
		TArray<FWeighting> weightings;

		for (int i = 0; i < this->Sounds.Num(); i++) {
			FWeighting weighting = FWeighting();
			weighting.Weighting = this->Sounds[i]->Weighting;
			weightings.Add(weighting);
		}

		auto index = UCommon::Roulette(weightings);
		if (index >= 0) {
			auto sound = this->Sounds[index];

			if (sound->Cue) {
				UGameplayStatics::PlaySoundAtLocation(this->GetWorld(), sound->Cue, location);
			}
			else {
				//GEngine->AddOnScreenDebugMessage(-1, 30.0f, FColor::Red, FString("FAILED TO PLAY sound: ").Append(FString::FromInt(index)));
			}
		}
		else {
			//GEngine->AddOnScreenDebugMessage(-1, 30.0f, FColor::Red, FString("FAILED TO PLAY sound: ").Append(FString::FromInt(index)));
		}
	}
}

void USurfaceEffect::SpawnRandomParticleAtLocation(FVector location, FRotator rotation, FVector forwardVector, FVector impactNormal)
{
	if (this->Particles.Num() > 0) {
		//auto weightings = static_cast<TArray<FWeighting>>(this->Sounds);
		TArray<FWeighting> weightings;

		for (int i = 0; i < this->Particles.Num(); i++) {
			FWeighting weighting = FWeighting();
			weighting.Weighting = this->Particles[i]->Weighting;
			weightings.Add(weighting);
		}

		auto index = UCommon::Roulette(weightings);
		if (index >= 0) {
			auto particle = this->Particles[index];

			if (particle->Particle) {
				this->SpawnParticleAtLocation(location, rotation + particle->Rotation, forwardVector, impactNormal, particle->Scale, particle->Particle);
			}
			else {
				//GEngine->AddOnScreenDebugMessage(-1, 30.0f, FColor::Red, FString("FAILED TO PLAY sound: ").Append(FString::FromInt(index)));
			}
		}
		else {
			//GEngine->AddOnScreenDebugMessage(-1, 30.0f, FColor::Red, FString("FAILED TO PLAY sound: ").Append(FString::FromInt(index)));
		}
	}
	////GEngine->AddOnScreenDebugMessage(-1, 30.0f, FColor::Red, FString("Hit particle"));

	//if (item && item->Alias) {
	//	bool custom_despawn = (uint8)(item->Alias->ParticleFlags & EParticleFlag::CustomDespawnOnly) != 0;
	//	bool custom_hit = (uint8)(item->Alias->ParticleFlags & EParticleFlag::CustomHitOnly) != 0;
	//	bool custom_pickup = (uint8)(item->Alias->ParticleFlags & EParticleFlag::CustomPickupOnly) != 0;
	//	bool interactive_despawn = (uint8)(item->Alias->ParticleFlags & EParticleFlag::InteractionDespawnOnly) != 0;
	//	bool interactive_hit = (uint8)(item->Alias->ParticleFlags & EParticleFlag::InteractionHitOnly) != 0;
	//	bool interactive_pickup = (uint8)(item->Alias->ParticleFlags & EParticleFlag::InteractionPickupOnly) != 0;

	//	if ((IsHit && custom_hit) || (IsInteract && custom_pickup) || (IsDespawn && custom_despawn)) {
	//		USurfaceEffect::SpawnParticleAtLocation(location, rotation + item->Alias->ParticleRotation, forwardVector, impactNormal, item->Alias->ParticleScale, item->Alias->Particle);
	//	}
	//	if ((IsHit && interactive_hit) || (IsInteract && interactive_pickup) || (IsDespawn && interactive_despawn)) {
	//		USurfaceEffect::SpawnParticleAtLocation(location, rotation + this->HitParticleRotation, forwardVector, impactNormal, this->HitParticleScale, this->HitParticle);
	//	}
	//}

	///*auto particle = this->HitParticle;
	//if (item && item->Alias && item->Alias->Particle && allowCustomParticle) {
	//	particle = item->Alias->Particle;
	//}
	//if (particle) {
	//	auto component = UGameplayStatics::SpawnEmitterAtLocation(this->GetWorld(), particle, location, rotation + this->HitParticleRotation, this->HitParticleScale, true, EPSCPoolMethod::AutoRelease);

	//	component->SetWorldScale3D(this->HitParticleScale);

	//	auto reflection = forwardVector.MirrorByVector(impactNormal) * 500.f;
	//	component->SetVectorParameter(FName("ReflectedParticles"), reflection);

	//	component->Activate();
	//}*/
}

void USurfaceEffect::SpawnHitParticleAtLocation(FVector location, FRotator rotation, FVector forwardVector, FVector impactNormal, UItemInstance* item, bool IsHit, bool IsDespawn, bool IsInteract)
{
	//GEngine->AddOnScreenDebugMessage(-1, 30.0f, FColor::Red, FString("Hit particle"));

	if (item && item->Alias) {
		bool custom_despawn = (uint8)(item->Alias->ParticleFlags & EParticleFlag::CustomDespawnOnly) != 0;
		bool custom_hit = (uint8)(item->Alias->ParticleFlags & EParticleFlag::CustomHitOnly) != 0;
		bool custom_pickup = (uint8)(item->Alias->ParticleFlags & EParticleFlag::CustomPickupOnly) != 0;
		bool interactive_despawn = (uint8)(item->Alias->ParticleFlags & EParticleFlag::InteractionDespawnOnly) != 0;
		bool interactive_hit = (uint8)(item->Alias->ParticleFlags & EParticleFlag::InteractionHitOnly) != 0;
		bool interactive_pickup = (uint8)(item->Alias->ParticleFlags & EParticleFlag::InteractionPickupOnly) != 0;

		if ((IsHit && custom_hit) || (IsInteract && custom_pickup) || (IsDespawn && custom_despawn)) {
			USurfaceEffect::SpawnParticleAtLocation(location, rotation + item->Alias->ParticleRotation, forwardVector, impactNormal, item->Alias->ParticleScale, item->Alias->Particle);
		}
		if ((IsHit && interactive_hit) || (IsInteract && interactive_pickup) || (IsDespawn && interactive_despawn)) {
			USurfaceEffect::SpawnParticleAtLocation(location, rotation + this->HitParticleRotation, forwardVector, impactNormal, this->HitParticleScale, this->HitParticle);
		}
	}

	/*auto particle = this->HitParticle;
	if (item && item->Alias && item->Alias->Particle && allowCustomParticle) {
		particle = item->Alias->Particle;
	}
	if (particle) {
		auto component = UGameplayStatics::SpawnEmitterAtLocation(this->GetWorld(), particle, location, rotation + this->HitParticleRotation, this->HitParticleScale, true, EPSCPoolMethod::AutoRelease);

		component->SetWorldScale3D(this->HitParticleScale);

		auto reflection = forwardVector.MirrorByVector(impactNormal) * 500.f;
		component->SetVectorParameter(FName("ReflectedParticles"), reflection);

		component->Activate();
	}*/
}

void USurfaceEffect::SpawnParticleAtLocation(FVector location, FRotator rotation, FVector forwardVector, FVector impactNormal, FVector scale, UParticleSystem* particleSystem)
{
	if (particleSystem) {
		auto component = UGameplayStatics::SpawnEmitterAtLocation(this->GetWorld(), particleSystem, location, rotation, scale, true, EPSCPoolMethod::AutoRelease);

		component->SetWorldScale3D(scale);

		//auto reflection = forwardVector.MirrorByVector(impactNormal) * 500.f;
		//component->SetVectorParameter(FName("ReflectedParticles"), reflection);

		component->Activate();
	}
}

void USurfaceEffect::SpawnDecalAtLocation(FVector location, FRotator rotation, FVector forwardVector, FVector impactNormal, UObject* owner, int itemIndex)
{
	if (this->Decals.Num() > 0) {
		//auto weightings = static_cast<TArray<FWeighting>>(decals);;
		TArray<FWeighting> weightings;

		for (int i = 0; i < this->Decals.Num(); i++) {
			FWeighting weighting = FWeighting();
			weighting.Weighting = this->Decals[i]->Weighting;
			weightings.Add(weighting);
		}

		auto index = UCommon::Roulette(weightings);
		if (index >= 0) {
			auto decal = this->Decals[index];
			if (decal->Decal)
			{
				FTransform tfm = FTransform(rotation, location);

				if (decal->Decal->IsA(UStaticMesh::StaticClass()))
				{
					auto gi = Cast<UGlobalGameInstance>(this->GetWorld()->GetGameInstance());
					if (gi) {
						auto smc = NewObject<UStaticMeshComponent>(owner);

						//auto smc = actor->GetStaticMeshComponent();
						tfm.SetScale3D(decal->DecalSize);
						smc->SetStaticMesh(Cast<UStaticMesh>(decal->Decal));
						smc->SetWorldTransform(tfm);
						smc->SetCollisionEnabled(ECollisionEnabled::NoCollision);

						smc->RegisterComponent();

						//actor->SetActorHiddenInGame(false);

						/*AActor* owning_actor = Cast<AActor>(owner);
						if (owning_actor) {
							actor->SetOwner(owning_actor);
							actor->AttachToActor(owning_actor, FAttachmentTransformRules::KeepRelativeTransform);
						}*/


						//AStaticMeshActor* actor = Cast<AStaticMeshActor>(gi->StaticMeshActorPool->Aquire());
						//if (actor) {
						//	auto smc = actor->GetStaticMeshComponent();
						//	tfm.SetScale3D(decal->DecalSize);
						//	smc->SetStaticMesh(Cast<UStaticMesh>(decal->Decal));
						//	smc->SetWorldTransform(tfm);
						//	smc->SetCollisionEnabled(ECollisionEnabled::NoCollision);
						//	actor->SetActorHiddenInGame(false);

						//	AActor* owning_actor = Cast<AActor>(owner);
						//	if (owning_actor) {
						//		actor->SetOwner(owning_actor);
						//		actor->AttachToActor(owning_actor, FAttachmentTransformRules::KeepRelativeTransform);
						//	}

						//	//auto bc = Cast<UBuildingComponent>(owner);
						//	//if (bc) {
						//	//	auto decal_entry = FWordStaticMeshDecal(actor);
						//	//	bc->AddDecal(itemIndex, decal_entry);
						//	//}
						//	//else {
						//	//	auto wsmc = Cast<UWorldStaticMeshComponent>(owner);
						//	//	if (wsmc) {
						//	//		auto decal_entry = FWordStaticMeshDecal(actor);
						//	//		wsmc->DecalInstances.Add(decal_entry);
						//	//	}
						//	//	else {
						//	//		auto hism = Cast<UHierarchicalInstancedStaticMeshComponent>(owner);
						//	//		if (hism) {
						//	//			auto component = AAutoInstancedStaticMeshActor::GetItemComponentForInstance(hism, itemIndex, EInstancedCategory::Foliage);
						//	//			if (component.Component) {
						//	//				auto decal_entry = FWordStaticMeshDecal(actor);
						//	//				component.Component->DecalInstances.Add(decal_entry);
						//	//			}
						//	//		}
						//	//	}
						//	//}
						//}

						//auto mesh = Cast<UStaticMesh>(this->Decal);
						//auto actor = AAutoInstancedStaticMeshActor::GetInstance(this->GetWorld());
						//auto entry = AAutoInstancedStaticMeshActor::GetInstanceComponent(mesh, EComponentMobility::Static, TEXT("NoCollision"), actor, EInstancedCategory::Decals);

						//if (entry && entry->Component) {
						//	FTransform tfm = FTransform(rotation, location);
						//	auto instance_id = entry->Component->AddInstance(tfm);


						//	/*int required_slots = (instance_id - entry->ComponentData.Num()) + 1;
						//	if (required_slots > 0) {
						//		while (required_slots-- > 0) {
						//			entry->ComponentData.Add(NULL);
						//		}
						//	}
						//	entry->ComponentData[instance_id] = owner;*/

						//	if (owner && owner->IsA(UWorldStaticMeshComponent::StaticClass()))
						//	{
						//		auto wsmc = Cast<UWorldStaticMeshComponent>(owner);
						//		auto decal_entry = FWordStaticMeshDecal(entry->Component, instance_id);
						//		wsmc->DecalInstances.Add(decal_entry);

						//		int required_slots = (instance_id - entry->ComponentData.Num()) + 1;
						//		if (required_slots > 0) {
						//			while (required_slots-- > 0) {
						//				entry->ComponentData.Add(NULL);
						//			}
						//		}
						//		entry->ComponentData[instance_id] = owner;
						//	}
						//}
					}
					else {
						//GEngine->AddOnScreenDebugMessage(-1, 30.0f, FColor::Red, FString("NO GAME INSTANCE"));
					}
				}
				else if (decal->Decal->IsA(UMaterialInterface::StaticClass()))
				{
					/*ADecalActor* decalActor = GetWorld()->SpawnActor<ADecalActor>(location, rotation);
					if (decalActor)
					{
						auto mat = Cast<UMaterialInterface>(decal.Decal);
						decalActor->SetDecalMaterial(mat);
						decalActor->SetLifeSpan(200.0f);
						decalActor->GetDecal()->DecalSize = decal.DecalSize;
					}*/
					auto comp = NewObject<UDecalComponent>(owner);
					if (comp) {
						auto mat = Cast<UMaterialInterface>(decal->Decal);
						comp->SetDecalMaterial(mat);
						comp->DecalSize = decal->DecalSize;
						comp->SetWorldLocationAndRotation(location, rotation);
						comp->RegisterComponent();

						auto sc = Cast<USceneComponent>(owner);
						if (sc) {
							comp->AttachToComponent(sc, FAttachmentTransformRules::KeepWorldTransform);
						}
					}
				}
			}
		}
	}
}