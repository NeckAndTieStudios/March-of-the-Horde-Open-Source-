// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "GameFramework/SpringArmComponent.h"
#include "Camera/CameraComponent.h"
#include "Weapon.h"
#include "Barrel.h"
#include "HitComponent.h"
#include "InstancedFoliageActor.h"
#include "HandWeapon.generated.h"

UCLASS()
class FPSPROJECT_API AHandWeapon : public AWeapon
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	AHandWeapon();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	//UPROPERTY(EditAnywhere, BlueprintReadOnly)
		//UGlobalGameInstance * GameInstance;

public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite) moved to character
		float ArmLength = 150.0f;*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float FistSize = 7.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float StrikeSpeed = 700.f; //m/s

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float StrikeDamage = 10.f;


	//UFUNCTION(BlueprintCallable) 4.19->4.20
	void OnPrimaryPressed() override;

	void OnSecondaryPressed() override;
};
