// Fill out your copyright notice in the Description page of Project Settings.

#include "HandControllerComponent.h"
#include "Engine.h"
#include "InstancedFoliageActor.h"
#include "DrawDebugHelpers.h"
#include "ContentResolver.h"
#include "WorldStaticMeshComponent.h"
#include "Buildings.h"
#include "GlobalGameInstance.h"
#include "AutoInstancedStaticMeshActor.h"

// Sets default values
UHandControllerComponent::UHandControllerComponent()
{
	PrimaryComponentTick.bCanEverTick = true; // will be disabled when not required

	// InitializeComponent
	bWantsInitializeComponent = true;
}

// Called when the game starts or when spawned
void UHandControllerComponent::BeginPlay()
{
	Super::BeginPlay();

	//this->GameInstance = this->GetWorld()->GetGameInstance<UGlobalGameInstance>();

	TArray<AActor *> actors;
	UGameplayStatics::GetAllActorsOfClass(this->GetWorld(), AInstancedFoliageActor::StaticClass(), actors);

	if (actors.Num() > 0) {
		this->InstancedFoliageActor = Cast<AInstancedFoliageActor>(actors[0]);
	}

	SetComponentTickEnabled(false);
}

// Called every frame
void UHandControllerComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

}

//USceneComponent* UHandControllerComponent::PlaceItem(AFPSCharacter * character, UItemInstance* item, FTransform location, USceneComponent* attachTo, UPARAM(ref) TArray<UItemWidget*> &collection)
//{
//	//FTakeIngredientFromInventoryRequest
//	/*auto world = this->GetWorld();
//	return UBuildings::PlaceItem(world, character, item, location, attachTo);*/
//
//
//	return UBuildings::PlaceItem(this->GetWorld(), character, item, location, attachTo);
//
//	//auto ingredients = item->GetIngredients();
//	//if (ingredients.Num() > 0) {
//	//	TArray<FTakeIngredientFromInventoryRequest> repair_requests;
//	//	for (int i = 0; i < ingredients.Num(); i++) {
//	//		FTakeIngredientFromInventoryRequest req(ingredients[i]);
//	//		repair_requests.Add(req);
//	//	}
//
//	//	auto building = AFPSCharacter::TryTakeFromInventory<FTakeIngredientFromInventoryRequest, USceneComponent*>(character, repair_requests, [this, character, item, location, attachTo](TArray<UItemWidget*> results, TArray<FTakeIngredientFromInventoryRequest> requests) {
//	//		return UBuildings::PlaceItem(this->GetWorld(), character, item, location, attachTo);
//	//	}, NULL);
//	//	return building;
//	//}
//	//else {
//	//	// cannot be repaired
//	//}
//	//return NULL;
//
//
//
//	//if (item && item->Alias && item->Alias->DefaultComponent.Len() > 0) {
//	//	auto bp = UContentResolver::Instance->ResolveBlueprint(item->Alias->DefaultComponent);
//	//	if (bp && bp->IsChildOf(UWorldStaticMeshComponent::StaticClass())) {
//	//		auto world = this->GetWorld();
//	//		auto actor = AAutoInstancedStaticMeshActor::GetInstance(world);
//	//		if (actor) {
//	//			UObject* owner = attachTo;
//	//			if (!owner) {
//	//				owner = actor;
//	//			}
//	//			auto cmp = NewObject<UWorldStaticMeshComponent>(owner, bp);
//	//			cmp->SetWorldTransform(location);
//	//			//cmp->AttachTo(actor);
//	//			cmp->RegisterComponent();
//
//	//			if (item->IsAttachment && attachTo)
//	//			{
//	//				cmp->AttachToComponent(attachTo, FAttachmentTransformRules::KeepRelativeTransform);
//
//	//				auto wsmc = Cast<UWorldStaticMeshComponent>(attachTo);
//	//				if (wsmc) {
//	//					wsmc->PrimaryAttachment = cmp;
//	//				}
//	//			}
//
//	//			if (cmp->ItemComponent) {
//	//				cmp->ItemComponent->ItemInstance = item->Clone(cmp);
//	//				cmp->ItemComponent->ItemInstance->Stack = 1;
//	//			}
//
//	//			item->Stack--;
//	//			return cmp;
//	//		}
//	//	}
//	//}
//	//return NULL;
//	//if (GEngine) {
//	//	GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, TEXT("HAND PlaceItem"));
//	//}
//
//	//if (character->ActiveCamera) {
//	//	auto held_item = item->GetActor();
//
//	//	/*loca = character->ActiveCamera->GetComponentLocation();*/
//	//	FCollisionQueryParams collision_params(FName(TEXT("HandControllerComponent")), true, held_item);
//	//	collision_params.bReturnPhysicalMaterial = true;
//	//	collision_params.AddIgnoredActor(held_item);
//
//	//	FCollisionObjectQueryParams object_params;
//	//	object_params.AddObjectTypesToQuery(ECC_WorldStatic);
//	//	object_params.AddObjectTypesToQuery(ECC_WorldDynamic);
//	//	object_params.AddObjectTypesToQuery(ECC_PhysicsBody);
//	//	object_params.AddObjectTypesToQuery(ECC_Destructible);
//
//	//	FHitResult hit_result;
//
//	//	auto direction = character->ActiveCamera->GetComponentRotation();
//	//	auto trace_start = character->ActiveCamera->GetComponentLocation();
//	//	auto trace_end = trace_start + direction.RotateVector(FVector(distance, 0.f, 0.f));
//
//	//	DrawDebugLine(GetWorld(), trace_start, trace_end, FColor::Purple, true, 5.f);
//
//	//	if (GetWorld()->LineTraceSingleByObjectType(hit_result, trace_start, trace_end, object_params, collision_params) && hit_result.IsValidBlockingHit())
//	//	{
//	//		trace_end = hit_result.ImpactPoint;
//
//	//		if (item->Alias) {
//	//			switch (static_cast<EItemPlaceableType>(item->Alias->ItemPlaceableTypeID)) {
//	//			case EItemPlaceableType::SpawnActor: {
//	//				AActor * actor = NULL;
//
//	//				// try to find and create the replacement actor
//	//				FString foliage_replacement = FString(item->Alias->ActorBlueprint);
//
//	//				UObject* obj = StaticLoadObject(UObject::StaticClass(), nullptr, *foliage_replacement);
//	//				UBlueprint* bp = Cast<UBlueprint>(obj);
//	//				UClass* actor_class = (UClass*)bp->GeneratedClass;
//	//				if (actor_class) {
//	//					FTransform transform;
//	//					transform.SetLocation(trace_end);
//	//					actor = this->GetWorld()->SpawnActor<AActor>(actor_class, transform, FActorSpawnParameters());
//	//				}
//
//	//				if (actor) {
//	//					// foliage instance replacement actors should already have an UItemComponent instance attached, otherwise it's considered to be ignored
//	//					UItemComponent* item_component = Cast<UItemComponent>(actor->GetComponentByClass(UItemComponent::StaticClass()));
//	//					if (item_component && !item_component->ItemInstance) {
//	//						item_component->ItemInstance = item->Clone(GetWorld());
//	//					}
//	//				}
//
//	//				break;
//	//			}
//	//			case EItemPlaceableType::SpawnFoliage: {
//	//				if (item->Alias) {
//	//					if (item->Alias->FoliageIndex > -1) {
//	//						if (this->InstancedFoliageActor) {
//	//							auto components = this->InstancedFoliageActor->GetComponentsByClass(UInstancedStaticMeshComponent::StaticClass());
//
//	//							if (components.Num() > 0 && item->Alias->FoliageIndex < components.Num()) {
//	//								auto mesh = Cast<UInstancedStaticMeshComponent>(components[item->Alias->FoliageIndex]);
//	//								if (mesh) {
//	//									FTransform transform;
//
//	//									transform.SetLocation(hit_result.ImpactPoint);
//	//									transform.SetScale3D(FVector(1));
//
//	//									mesh->AddInstance(transform);
//	//								}
//	//							}
//	//						}
//	//					}
//	//				}
//	//				break;
//	//			}
//	//			}
//	//		}
//	//	}
//	//}
//}

void UHandControllerComponent::SecondaryAction(AMOTHCharacter* character)
{
	auto camera = character->GetCamera();
	if (camera) {
		/*loca = character->ActiveCamera->GetComponentLocation();*/
		FCollisionQueryParams collision_params(FName(TEXT("HandControllerComponent")), true, character);
		collision_params.bReturnPhysicalMaterial = true;

		FCollisionObjectQueryParams object_params;
		object_params.AddObjectTypesToQuery(ECC_WorldStatic);
		object_params.AddObjectTypesToQuery(ECC_WorldDynamic);
		object_params.AddObjectTypesToQuery(ECC_PhysicsBody);
		object_params.AddObjectTypesToQuery(ECC_Destructible);

		FHitResult hit_result;

		auto direction = camera->GetComponentRotation();
		auto trace_start = camera->GetComponentLocation();
		auto trace_end = trace_start + direction.RotateVector(FVector(character->ArmLength, 0.f, 0.f));

		DrawDebugLine(GetWorld(), trace_start, trace_end, FColor::Purple, true, 5.f);

		if (GetWorld()->LineTraceSingleByObjectType(hit_result, trace_start, trace_end, object_params, collision_params) && hit_result.IsValidBlockingHit())
		{
			trace_end = hit_result.ImpactPoint;

			this->GetWorld()->GetGameInstance<UGlobalGameInstance>()->ContentResolver->ResolveInteraction(EInteractionTrigger::Secondary, hit_result, character);
		}
	}
}