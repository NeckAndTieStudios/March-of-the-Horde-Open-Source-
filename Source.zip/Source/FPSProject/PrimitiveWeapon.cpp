// Fill out your copyright notice in the Description page of Project Settings.

#include "PrimitiveWeapon.h"
#include "Common.h"
#include "FPSCharacter.h"
#include "Engine.h"

// Sets default values
APrimitiveWeapon::APrimitiveWeapon()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;

	//UnregisterAllComponents();
}

// Called when the game starts or when spawned
void APrimitiveWeapon::BeginPlay()
{
	//this->GameInstance = this->GetWorld()->GetGameInstance<UGlobalGameInstance>();

	Super::BeginPlay();
}

// Called every frame
void APrimitiveWeapon::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void APrimitiveWeapon::OnPrimaryPressed()
{
	if (this->CanTriggerPrimary) {
		this->GetInteraction(EInteractionTrigger::Primary, this->StrikeRadialSize);
	}
	else {
		Super::OnPrimaryPressed();
	}
}

void APrimitiveWeapon::OnSecondaryPressed()
{
	if (this->CanTriggerSecondary) {
		this->GetInteraction(EInteractionTrigger::Secondary, this->StrikeRadialSize);
	}
	else {
		Super::OnSecondaryPressed();
	}
}