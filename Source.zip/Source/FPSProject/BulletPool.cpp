// Fill out your copyright notice in the Description page of Project Settings.

#include "BulletPool.h"
#include "Engine.h"
#include "DrawDebugHelpers.h"

DEFINE_STAT(STAT_RequestBulletTypeFromPool);
DEFINE_STAT(STAT_ReturnBulletTypeToPool);

BulletPool::BulletPool(int block_size, UWorld* world, TSubclassOf<class ABullet> ProjectileClass, bool allow_increase)
{
	this->ProjectileClass = ProjectileClass;
	this->block_size = block_size;
	this->pool = new TQueue<class ABullet*>();
	this->world = world;
	this->allow_increase = allow_increase;
	this->allocate(); //preallocate
}

BulletPool::~BulletPool()
{
}

void BulletPool::allocate()
{
	/*if (GEngine) {
		GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("Allocating more bullets to the pool"));
	}*/
	for (int i = 0; i < this->block_size; i++)
	{
		auto bullet = this->world->SpawnActor<ABullet>(ProjectileClass, FVector(0), FRotator(0));

		if (!bullet) {
			if (GEngine) {
				GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("Unable to allocate bullets to the pool"));
			}
			return;
		}

		//bullet->OnBulletDestroyed.AddRaw(this, &BulletPool::ReleaseByArg);
		//bullet->OnBulletDestroyed = &ReleaseByArg;
		bullet->OnBulletDestroyed.BindRaw(this, &BulletPool::ReleaseByArg, bullet);

		bullet->ID = this->capacity;
		bullet->Leased = true;
		bullet->SetActorTickEnabled(false);
		
		this->pool->Enqueue(bullet);
		this->capacity++;
	}
}

ABullet * BulletPool::Aquire(AActor* owner)
{
	SCOPE_CYCLE_COUNTER(STAT_RequestBulletTypeFromPool);
	ABullet * bullet = NULL;

	if (this->pool->IsEmpty())
	{
		if (!this->allow_increase)
		{
			return bullet;
		}
		// more allocation required
		this->allocate();
	}

	this->pool->Dequeue(bullet);

	if (bullet)
	{
		this->leased++;
		bullet->BulletOwner = owner;
	}

	return bullet;
}

void BulletPool::Release(ABullet * bullet)
{
	SCOPE_CYCLE_COUNTER(STAT_ReturnBulletTypeToPool);
	if (bullet->Leased)
	{
		this->leased--;
		bullet->Leased = false;
		bullet->BulletOwner = NULL;
		this->pool->Enqueue(bullet);
	}
	else {
		DrawDebugString(this->world, bullet->CurrentPosition + FVector(0, 0, 0), FString("BULLET WAS ALREADY RELEASED:").Append(FString::FromInt(bullet->ID)), (AActor *)0, FColor::Red);
	}
}

void BulletPool::ReleaseByArg(ABullet * bullet)
{
	//auto bullet = Cast<ABullet>(actor);
	if (bullet)
	{
		this->Release(bullet);
	}
}

int BulletPool::GetCapacity()
{
	return this->capacity;
}

int BulletPool::GetLeased()
{
	return this->leased;
}