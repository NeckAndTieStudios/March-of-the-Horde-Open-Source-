// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ItemLootFormula.generated.h"

UENUM(BlueprintType)
enum class EItemLootFormula : uint8
{
	None = 0 UMETA(DisplayName = "None"),
	Wood = 1 UMETA(DisplayName = "Wood"),
	BarkFibre = 2 UMETA(DisplayName = "Bark Fibre"),
	Eggs = 3 UMETA(DisplayName = "Eggs"),
	Feathers = 4 UMETA(DisplayName = "Feathers"),
	Sapling = 5 UMETA(DisplayName = "Sapling"),
	Pinecones = 6 UMETA(DisplayName = "Pinecones"),
	CustomValue = 7 UMETA(DisplayName = "Custom Value")

	//MAX = Pinecones UMETA(Hidden),
	//DEFAULT = None UMETA(DisplayName = "DEFAULT (None)")
};