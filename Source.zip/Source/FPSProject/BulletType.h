// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"

UENUM(BlueprintType)
enum class EBulletType : uint8
{
	_9mm = 0 UMETA(DisplayName="9mm"),

	MAX = _9mm UMETA(Hidden)
};