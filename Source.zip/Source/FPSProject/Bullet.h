// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Engine/StaticMeshActor.h"
#include "ParticleHelper.h"
#include "Particles/ParticleSystem.h"
#include "Particles/ParticleSystemComponent.h"
#include "AssetItemComponent.h"
#include "FOnBulletDestroyedArgs.h"
//#include "GlobalGameInstance.h"
#include "Components/SplineComponent.h"
#include "Components/SplineMeshComponent.h"
#include "BulletType.h"
#include "Bullet.generated.h"

DECLARE_STATS_GROUP(TEXT("Bullet"), STATGROUP_Bullet, STATCAT_Advanced);
DECLARE_CYCLE_STAT_EXTERN(TEXT("BulletTick"), STAT_BulletTick, STATGROUP_Bullet, FPSPROJECT_API);
DECLARE_CYCLE_STAT_EXTERN(TEXT("BulletHit"), STAT_BulletHit, STATGROUP_Bullet, FPSPROJECT_API);
DECLARE_CYCLE_STAT_EXTERN(TEXT("BulletPenetrate"), STAT_BulletPenetrate, STATGROUP_Bullet, FPSPROJECT_API);
DECLARE_CYCLE_STAT_EXTERN(TEXT("BulletRicochet"), STAT_BulletRicochet, STATGROUP_Bullet, FPSPROJECT_API);
DECLARE_CYCLE_STAT_EXTERN(TEXT("BulletCalculateTraceLength"), STAT_BulletCalculateTraceLength, STATGROUP_Bullet, FPSPROJECT_API);
DECLARE_CYCLE_STAT_EXTERN(TEXT("BulletAddInteractionAtLocation"), STAT_BulletAddInteractionAtLocation, STATGROUP_Bullet, FPSPROJECT_API);
DECLARE_CYCLE_STAT_EXTERN(TEXT("BulletRespawn"), STAT_BulletRespawn, STATGROUP_Bullet, FPSPROJECT_API);
DECLARE_CYCLE_STAT_EXTERN(TEXT("BulletRestart"), STAT_BulletRestart, STATGROUP_Bullet, FPSPROJECT_API);
DECLARE_CYCLE_STAT_EXTERN(TEXT("BulletGetSettingsFromHit"), STAT_BulletGetSettingsFromHit, STATGROUP_Bullet, FPSPROJECT_API);
DECLARE_CYCLE_STAT_EXTERN(TEXT("BulletAddSmokeTracerPoint"), STAT_BulletAddSmokeTracerPoint, STATGROUP_Bullet, FPSPROJECT_API);
DECLARE_CYCLE_STAT_EXTERN(TEXT("BulletOnDestroy"), STAT_BulletOnDestroy, STATGROUP_Bullet, FPSPROJECT_API);

//DECLARE_MULTICAST_DELEGATE_OneParam(FOnBulletDestroyed, AStaticMeshActor *);
//DECLARE_DELEGATE_OneParam(FOnBulletDestroyed, AStaticMeshActor *);

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FPenetrationComponent
{
	GENERATED_USTRUCT_BODY()

public:

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int PenetrationId = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		USplineMeshComponent* Component;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UMaterialInstanceDynamic* Material;

	FPenetrationComponent() { }
	FPenetrationComponent(int penetrationId, USplineMeshComponent* component, UMaterialInstanceDynamic* material)
	{
		PenetrationId = penetrationId;
		Component = component;
		Material = material;
	}
};

UCLASS()
class FPSPROJECT_API ABullet : public AStaticMeshActor
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	ABullet();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	// lifetime of the bullet in seconds, updated each tick by incrementing the delta time
	float Time;

	//// initial position of the bullet - typically used for debugging
	//FVector InitialPosition;
	//FVector CurrentPosition;
	//FRotator CurrentRotation;

	// tracks how many frames have been skipped
	int FramesSkipped = 0;

	FTimerHandle TracerTimeoutHandle;

	void OnHit(FHitResult hit_result, FVector trace_start, FVector trace_end);
	bool OnRicochet(FVector actor_location, FHitResult hit_result, FVector trace_start, FVector trace_end, UAssetItemComponent* assetComponent, FGlobalBulletSettings bulletSettings, FBulletTypeSettings bulletTypeSetting);
	bool OnPenetrate(FVector actor_location, FHitResult hit_result, FVector trace_start, FVector trace_end, UAssetItemComponent* assetComponent, FGlobalBulletSettings bulletSettings, FBulletTypeSettings bulletTypeSetting);
	void OnDestroy();

	//UPROPERTY(EditAnywhere)
	//UGlobalGameInstance * GameInstance;

	UPROPERTY(EditAnywhere)
		USplineComponent* PenetrationTracerSpline;

	float PenetrationTracerLength = 0;

	//FTimerHandle TracerSplineTimerHandle;

	//void OnTracerSplineTimer();
	//float smokeStart;

	UPROPERTY(EditAnywhere)
		UMaterialInstanceDynamic* smokeMaterial;

	float _instancePenetrationTracerMaxLength;

	void AddSmokeTracerPoint(FVector location, int penetrationId);
	void AddInteractionAtLocation(FVector location, FGlobalBulletSettings surfaceSettings, UPrimitiveComponent* component, FRotator direction);
	FGlobalBulletSettings GetSettingsFromHit(FHitResult hit, UAssetItemComponent* assetComponent);
public:

	// number of ricochets 
	float Ricochets = 0.f;

	// number of penetrations 
	float Penetrations = 0.f;

	int CurrentTracerCount = 0;

	// distance in meters from the initial bullet location
	float Distance;

	bool IsDestroyed = false;

	//bool IsSmoking = false;

	int ID = 0;
	bool Leased = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		AActor* BulletOwner = NULL;

	void Restart(bool reset_tracer);
	void Respawn(FVector location, FRotator rotation);

	// initial position of the bullet - typically used for debugging
	UPROPERTY(EditAnywhere)
		FVector InitialPosition;
	UPROPERTY(EditAnywhere)
		FVector CurrentPosition;
	UPROPERTY(EditAnywhere)
		FRotator CurrentRotation;

	UFUNCTION(BlueprintCallable)
		void ClearTracerSpline(int penetrationId);

	float InitialSpeed;

	bool CollisionProjectileActive;

	DECLARE_DELEGATE(FOnBulletDestroyed);
	FOnBulletDestroyed OnBulletDestroyed;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UMaterialInstanceDynamic * SmokeMaterial;*/

	UPROPERTY(EditAnywhere)
		EBulletType Type;

	UPROPERTY(EditAnywhere)
		UStaticMeshComponent* MuzzleTracer;

	UPROPERTY(EditAnywhere)
		UStaticMesh* SmokeTracer;

	UPROPERTY(EditAnywhere)
		UStaticMesh* SmokeTracerCap;

	UPROPERTY(EditAnywhere)
		float PenetrationTracerMinimumSpeed = 20.f;

	UPROPERTY(EditAnywhere)
		float PenetrationTracerMaxLengthMin = 5.0f;

	UPROPERTY(EditAnywhere)
		float PenetrationTracerMaxLengthMax = 7.5f;

	UPROPERTY(EditAnywhere)
		TArray<FPenetrationComponent> PenetrationComponents;
	UPROPERTY(EditAnywhere)
		TArray<USplineMeshComponent*> Components;

	/*UPROPERTY(EditAnywhere)
	TSubclassOf<class USplineComponent> LineTraceSplineClass;*/

	//typedef void(ABullet::*OnBulletDestroyedDelegate)(ABullet*);
	//OnBulletDestroyedDelegate OnBulletDestroyed;

	// How many frames we can skip at a time. This decreases the accuracy of the curve.
	// 0 = 100% accuracy, each tick is a new line
	// 5 = A new line every 5 ticks
	UPROPERTY(EditAnywhere)
		int Accuracy = 0;

	// Called every frame
	virtual void Tick(float DeltaTime) override;

	//USceneComponent* RootComponent;

	// max distance that the bullet can travel in meters
	// 0 to disable
	UPROPERTY(EditAnywhere)
		float MaxDistance = 1500.f;

	// max time the bullet can live for in seconds
	// 0 to disable
	UPROPERTY(EditAnywhere)
		float MaxLifeTime = 15.f;

	// max number of ricochets the bullet can perform
	// 0 to disable
	UPROPERTY(EditAnywhere)
		float MaxRicochets = 2.f;

	// max number of penetrations the bullet can perform
	// 0 to disable
	UPROPERTY(EditAnywhere)
		float MaxPenetrations = 2.f;

	// how fast the bullet falls vertically in meters per second (m/s)
	UPROPERTY(EditAnywhere)
		float FallGravity = 9.8;

	// the horizontal resistance applied to the speed each tick in meters per second (m/s)
	UPROPERTY(EditAnywhere)
		float HorizontalResistance = 0.0f;

	// how fast the bullet travels in meters per second (m/s)
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float Speed = 350.f;

	// coefficient of speed
	UPROPERTY(EditAnywhere)
		float SpeedCoefficient = 1.f;

	UPROPERTY(EditAnywhere)
		float Damage = 10.f;

	UPROPERTY(EditAnywhere)
		float DamageRadius = 32.f;

	UPROPERTY(EditAnywhere)
		float ImpactForce = 1.f;

	UPROPERTY(EditAnywhere)
		float RadialSize = 5.f;

	UFUNCTION(BlueprintImplementableEvent, Category = "Bullet Events")
		void OnPenetrateStarted(FHitResult hit_result);

	UFUNCTION(BlueprintImplementableEvent, Category = "Bullet Events")
		void OnPenetrateCompleted(FHitResult hit_result);

	UFUNCTION(BlueprintImplementableEvent, Category = "Bullet Events")
		void OnRicochet(FHitResult hit_result);

	UFUNCTION(BlueprintImplementableEvent, Category = "Bullet Events")
		void OnHit(FHitResult hit_result);

	UFUNCTION(BlueprintImplementableEvent, Category = "Bullet Events")
		void OnSmokeTraceStart(FPenetrationComponent component);

	void OnClearTracer();
};
