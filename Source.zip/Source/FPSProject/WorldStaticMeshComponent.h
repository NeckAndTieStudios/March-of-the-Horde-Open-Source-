// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/SceneComponent.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "Engine/StaticMeshActor.h"
#include "AutoInstancedStaticMeshActor.h"
#include "ItemComponent.h"
#include "DestructibleComponent.h"
#include "DestructibleMesh.h"
#include "DestructibleActor.h"
#include "InstancedComponentsEntry.h"
#include "SoundCueWeighting.h"
#include "WordStaticMeshDecal.h"
#include "InteractionTrigger.h"
#include "FPSCharacter.h" 
#include "Breakpoints.h" 
#include "WorldStaticMeshComponent.generated.h"

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FWordStaticMeshBreakpoint
{
	GENERATED_BODY()

public:
	// The World Static Mesh Component will pick the mesh when it's health is this or above
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Breakpoint")
		float ForHealthAndAbove = 0.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Breakpoint")
		UStaticMesh* Mesh;
};

//USTRUCT(Blueprintable, BlueprintType)
//struct FPSPROJECT_API FWordStaticMeshDecal
//{
//	GENERATED_BODY()
//
//public:
//	//UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		//UHierarchicalInstancedStaticMeshComponent* Component;
//
//	//UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		//int InstanceID;
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		AActor* Decal;
//
//	FWordStaticMeshDecal() { }
//	FWordStaticMeshDecal(AActor* decal)
//	{
//		this->Decal = decal;
//	}
//	/*FWordStaticMeshDecal(UHierarchicalInstancedStaticMeshComponent* component, int instanceID)
//	{
//		this->Component = component;
//		this->InstanceID = instanceID;
//	}*/
//};
//
//USTRUCT(Blueprintable, BlueprintType)
//struct FPSPROJECT_API FGoreBreakpoint
//{
//	GENERATED_BODY()
//
//public:
//	// The material to adjust
//	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Breakpoint")
//		FString ParameterName;
//
//	// When the material should begin transitioning in. The material is considered 0% opacity at this value.
//	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Breakpoint")
//		float Start = 0.f;
//
//	// When the material should be at 100% opacity
//	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Breakpoint")
//		float Max = 100;
//
//	// Allows the opacity to exceet 100% (1.0f)
//	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Breakpoint")
//		bool AllowPastMax = false;
//
//	/*UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Breakpoint")
//		UMaterialInstance* Material;*/
//};

//UENUM(BlueprintType)
//enum class EReplacementActorTrigger : uint8
//{
//	NoTrigger = 0 UMETA(DisplayName = "No Trigger"),
//	OnDestroyed = 1 UMETA(DisplayName = "On Destruction"),
//	OnHit = 2 UMETA(DisplayName = "On Hit")
//};

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable, BlueprintType/*Cannot construct objects of type when calling ConstructObject in a BP*/)
class FPSPROJECT_API UWorldStaticMeshComponent : public UHierarchicalInstancedStaticMeshComponent
{
	GENERATED_BODY()

		UPROPERTY()
		bool IsCreating = true;

	FTimerHandle TiltTimerHandle;

	FRotator TiltTarget;
	FRotator TiltCurrent;
	float TiltStart;

public:
	UWorldStaticMeshComponent();

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<FWordStaticMeshBreakpoint> MeshBreakpoints;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<FGoreBreakpoint> GoreBreakpoints;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UItemComponent* ItemComponent;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FRotator CurrentRotator;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FTransform Offset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float Gore = 0.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float Health = 100.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UInstancedStaticMeshComponent* InstanceComponent;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		AAutoInstancedStaticMeshActor* InstanceActor;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		AStaticMeshActor* GoreActor = NULL;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int InstanceID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool ExchangeInProcess;

	UFUNCTION(BlueprintCallable)
		void SetMeshBreakpoints(TArray<FWordStaticMeshBreakpoint> breakpoints);

	UFUNCTION(BlueprintCallable)
		bool UpdateMeshFromBreakpoints(bool silent);

	UFUNCTION(BlueprintCallable)
		void UpdateGore();

	UFUNCTION(BlueprintCallable)
		void UpdateGoreMaterial(UMeshComponent* mesh);

	UFUNCTION(BlueprintCallable)
		void ShowSelf();
	UFUNCTION(BlueprintCallable)
		void HideSelf();

	UFUNCTION(BlueprintCallable)
		UInstancedStaticMeshComponent* GetCurrentComponent();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect")
		UParticleSystem * HitParticle;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FTransform MeshTransform;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect")
		FRotator HitParticleOffset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect")
		FVector HitParticleScale;
	/*
		UPROPERTY(EditDefaultsOnly, Category = Actor)
			EReplacementActorTrigger ReplacementActorTrigger;*/

			//// the type of actor to spawn when this instance has been destroyed
			//UPROPERTY(EditDefaultsOnly, Category = Actor)
			//	TSubclassOf<class AActor> ReplacementActor;

	// the type of actor to spawn when this instance has been destroyed
	UPROPERTY(Category = "Destruction", EditAnywhere, BlueprintReadWrite)
		UDestructibleMesh* DestructibleMesh;

	// the type of actor to spawn when this instance has been destroyed
	UPROPERTY(Category = "Destruction", EditAnywhere, BlueprintReadWrite)
		float DamageAmount = 100.f;

	// the type of actor to spawn when this instance has been destroyed
	UPROPERTY(Category = "Destruction", EditAnywhere, BlueprintReadWrite)
		float ImpulseStrength = 1000.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Destruction")
		TArray<FSoundCueWeighting> DestructionSounds;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Destruction")
		TArray<FSoundCueWeighting> MeshChangeSounds;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<FWordStaticMeshDecal> DecalInstances;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<FString> CompatibleSockets;

	// if true, this instance will be destroyed if it is attached to a parent WSMC that has been destroyed
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool DestroyWithParent = true;

	// if true, this instance will be destroyed if it is attached to a parent WSMC that has been destroyed
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool RepairInProcess = false;

	// if set, allows upgrading based of the specified items upgrade stages
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool ClearDecalsOnMeshChange = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool ClearDecalsOnDespawn = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UWorldStaticMeshComponent* PrimaryAttachment = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool PreventParentTick = true;

	/*UFUNCTION(BlueprintImplementableEvent)
		void OnComponentAdded(UActorComponent* Component);*/
	UFUNCTION(BlueprintImplementableEvent)
		void OnChildComponentAttached(USceneComponent* ChildComponent);

	virtual void BeginPlay() override;
	virtual void OnRegister() override;
	virtual void OnUnregister() override;
	void BeginDestroy() override;

	virtual void OnChildAttached(USceneComponent* ChildComponent) override;
	virtual void PostDuplicate(bool bDuplicateForPIE) override;

	void StartTilt();
	void Tilt();

	UFUNCTION(BlueprintCallable)
		void StopTilt();

	void MigrateToWorld();

	UFUNCTION(BlueprintCallable)
		bool RemoveWSMCInstance(AAutoInstancedStaticMeshActor* actor, FTransform& OutTransform, UObject*& OutData);

	UFUNCTION(BlueprintCallable)
		void MigrateToWorldMesh(UObject* mesh_component, UStaticMesh* mesh, bool silent);

	UFUNCTION(BlueprintCallable)
		void MigrateToSelf();

	UFUNCTION(BlueprintImplementableEvent)
		void OnMeshChanging(UObject* new_owner, UHierarchicalInstancedStaticMeshComponent* new_component, int new_id);

	UFUNCTION(BlueprintCallable)
		void OnDamage(AActor* initiator, FHitResult hitresult);
	UFUNCTION(BlueprintCallable)
		void OnDamaged(AActor* initiator, FHitResult hitresult, bool killed, float damage, EInteractionTrigger trigger);

	UFUNCTION(BlueprintCallable)
		void OnMeshChanged(bool creating, bool silent);

	UFUNCTION(BlueprintCallable)
		void DestroyMesh(AActor* initiator, bool is_parent_destroyed, bool silent, bool spawn_dm);

	UFUNCTION(BlueprintCallable)
		void ClearDecals();

	UFUNCTION(BlueprintCallable)
		void Animate();

	UFUNCTION(BlueprintCallable)
		bool TryRepair(AMOTHCharacter* character, UWorldStaticMeshComponent* parent_or_child, FItemData item);

	UFUNCTION(BlueprintCallable)
		bool TryUpgrade(AMOTHCharacter* character);

	UFUNCTION(BlueprintCallable)
		bool Pickup(AMOTHCharacter* character);

	UFUNCTION(BlueprintCallable)
		UObject* NewSubObject(UObject* Outer, UClass* Class)
	{
		if (Outer && Class) {
			auto s = NewObject<UObject>(Outer, Class, NAME_None, RF_StrongRefOnFrame);

			if (s->IsA(USceneComponent::StaticClass()))
			{
				auto a = Cast<USceneComponent>(s);
				a->RegisterComponent();
			}

			return s;
		}
		return NULL;
	}

	UFUNCTION(BlueprintCallable)
		UObject* NewSubObjectInWorld(UObject* Outer, UClass* Class)
	{
		if (Outer && Class) {
			auto s = NewObject<UObject>(this->GetWorld(), Class, NAME_None, RF_StrongRefOnFrame);

			if (s->IsA(USceneComponent::StaticClass()))
			{
				auto a = Cast<USceneComponent>(s);
				//PSC->SetupAttachment(AttachToComponent, AttachPointName);
				a->RegisterComponentWithWorld(this->GetWorld());
			}

			return s;
		}
		return NULL;
	}

	UFUNCTION(BlueprintCallable)
		UObject* NewSubObjectInWorldAttached(UObject* Outer, UClass* Class, USceneComponent* AttachToComponent)
	{
		if (/*Outer &&*/ Class) {
			auto s = NewObject<UObject>(Outer ? Outer : this->GetWorld(), Class, NAME_None, RF_StrongRefOnFrame);

			if (s->IsA(USceneComponent::StaticClass()))
			{
				auto a = Cast<USceneComponent>(s);
				a->SetupAttachment(AttachToComponent);
				a->RegisterComponentWithWorld(this->GetWorld());
			}

			return s;
		}
		return NULL;
	}

	//virtual void PostLoad() override;

	UFUNCTION(BlueprintCallable)
		bool DetermineBreakpoint(TArray<FWordStaticMeshBreakpoint> breakpoints, FWordStaticMeshBreakpoint &breakpoint);
};
//
//
//USTRUCT()
//struct FCustomInstancedStaticMeshInstanceData
//{
//	GENERATED_USTRUCT_BODY()
//
//		UPROPERTY(EditAnywhere, Category = Instances)
//		FMatrix Transform;
//
//	UPROPERTY(EditAnywhere, Category = Instances)
//		float Health = 100.f;
//
//	FCustomInstancedStaticMeshInstanceData()
//		: Transform(FMatrix::Identity)
//	{
//	}
//
//	FCustomInstancedStaticMeshInstanceData(const FMatrix& InTransform)
//		: Transform(InTransform)
//	{
//	}
//
//	friend FArchive& operator<<(FArchive& Ar, FCustomInstancedStaticMeshInstanceData& InstanceData)
//	{
//		// @warning BulkSerialize: FInstancedStaticMeshInstanceData is serialized as memory dump
//		// See TArray::BulkSerialize for detailed description of implied limitations.
//		Ar << InstanceData.Transform;
//		return Ar;
//	}
//};
//
//USTRUCT()
//struct FInheritedInstancedStaticMeshInstanceData : public FInstancedStaticMeshInstanceData
//{
//	GENERATED_USTRUCT_BODY()
//
//		UPROPERTY(EditAnywhere, Category = Instances)
//		float Health = 100.f;
//};