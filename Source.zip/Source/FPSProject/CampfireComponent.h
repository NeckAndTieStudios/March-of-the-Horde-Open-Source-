// Fill out your copyright notice in the Description page of Project Settings.

#pragma once
#include "WorldStaticMeshComponent.h"
#include "CampfireComponent.generated.h"

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable, BlueprintType/*Cannot construct objects of type when calling ConstructObject in a BP*/)
class FPSPROJECT_API UCampfireComponent : public UWorldStaticMeshComponent
{
	GENERATED_BODY()

public:

};