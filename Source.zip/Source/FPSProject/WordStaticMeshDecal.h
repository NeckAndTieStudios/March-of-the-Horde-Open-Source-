// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "WordStaticMeshDecal.generated.h"

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FWordStaticMeshDecal
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		AActor* Decal;

	FWordStaticMeshDecal() { }
	FWordStaticMeshDecal(AActor* decal)
	{
		this->Decal = decal;
	}
};