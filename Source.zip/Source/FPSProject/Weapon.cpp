// Fill out your copyright notice in the Description page of Project Settings.

#include "Weapon.h"
#include "ContentResolver.h"
#include "FPSCharacter.h"
#include "Engine.h"


// Sets default values
AWeapon::AWeapon()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;

	//UnregisterAllComponents();

	//auto default_weapon_class = this->WeaponComponentClass;
	//if (!default_weapon_class) {
	//	default_weapon_class = UPrimitiveComponent::StaticClass();
	//}
	//this->WeaponComponent = Cast<UPrimitiveComponent>(CreateDefaultSubobject(FName("WeaponComponent"), UPrimitiveComponent::StaticClass(), default_weapon_class, true, false, false));
	////this->WeaponComponent = CreateDefaultSubobject<UPrimitiveComponent>(FName("WeaponComponent"));

	//this->SetRootComponent(this->WeaponComponent);

	//this->SkeletalMesh = CreateDefaultSubobject<USkeletalMeshComponent>(FName("SkeletalMesh"));
	//this->SkeletalMesh->AttachToComponent(this->RootComponent, FAttachmentTransformRules(EAttachmentRule::KeepRelative, true));
	//this->SkeletalMesh->RegisterComponent();
	/*this->SpringArm = CreateDefaultSubobject<USpringArmComponent>(FName("SpringArm"));
	this->Camera = CreateDefaultSubobject<UCameraComponent>(FName("Camera"));
	this->Barrel = CreateDefaultSubobject<ABarrel>(FName("Barrel"));

	this->SpringArm->SetupAttachment(this->SkeletalMesh);
	this->Camera->SetupAttachment(this->SpringArm);*/

	//this->Camera->SetRelativeScale3D(FVector(0.1f));


}

// Called when the game starts or when spawned
void AWeapon::BeginPlay()
{
	Super::BeginPlay();

}

// Called every frame
void AWeapon::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void AWeapon::OnPrimaryPressed()
{
	if (GEngine) {
		//GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, TEXT("WEAPON OnPrimaryPressed"));
	}
	this->PrimaryPressed();
}

void AWeapon::OnPrimaryReleased()
{
	if (GEngine) {
		//GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, TEXT("WEAPON OnPrimaryReleased"));
	}
	this->PrimaryReleased();
}

void AWeapon::OnSecondaryPressed()
{
	if (GEngine) {
		//GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, TEXT("WEAPON OnSecondaryPressed"));
	}
	this->SecondaryPressed();
}

void AWeapon::OnSecondaryReleased()
{
	if (GEngine) {
		//GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, TEXT("WEAPON OnSecondaryReleased"));
	}
	this->SecondaryReleased();
}

TArray<UItemComponent*> AWeapon::GetInteraction(EInteractionTrigger trigger, float radialSize)
{
	auto owner = this->GetOwner();
	if (owner) {
		auto character = Cast<AMOTHCharacter>(owner);
		if (character) {
			character->LookForInteractable(true);

			auto item_component = character->LookAtItem;
			if (item_component) {
				auto hit = character->LookAtHitResult;

				return UContentResolver::Instance->ResolveInteraction(trigger, hit, this);
			}

			auto trace = character->Trace(FName(TEXT("Weapon")), radialSize, ETraceType::SphereMulti);
			if (trace.IsValidBlockingHit()) {
				return UContentResolver::Instance->ResolveInteraction(trigger, trace, this);
			}

			//auto camera = character->GetCamera();
			//if (camera) {
			//	/*loca = character->ActiveCamera->GetComponentLocation();*/
			//	FCollisionQueryParams collision_params(FName(TEXT("Weapon")), true, this);
			//	collision_params.bReturnPhysicalMaterial = true;

			//	collision_params.AddIgnoredActor(character);

			//	FCollisionObjectQueryParams object_params;
			//	// working
			//	object_params.AddObjectTypesToQuery(ECC_Visibility);
			//	object_params.AddObjectTypesToQuery(ECC_Pawn);

			//	// ?? rat trap is one of these
			//	object_params.AddObjectTypesToQuery(ECC_WorldStatic);
			//	//object_params.AddObjectTypesToQuery(ECC_WorldDynamic);
			//	//object_params.AddObjectTypesToQuery(ECC_PhysicsBody);
			//	//object_params.AddObjectTypesToQuery(ECC_Destructible);
			//	//object_params.AddObjectTypesToQuery(ECC_Camera); // collides with character movement cylinder

			//	//FHitResult hit_result;

			//	auto direction = camera->GetComponentRotation();
			//	auto trace_start = camera->GetComponentLocation();
			//	auto trace_end = trace_start + direction.RotateVector(FVector(character->ArmLength, 0.f, 0.f));

			//	//DrawDebugLine(GetWorld(), trace_start, trace_end, FColor::Purple, true, radialSize);

			//	//if (GetWorld()->LineTraceSingleByObjectType(hit_result, trace_start, trace_end, object_params, collision_params) && hit_result.IsValidBlockingHit())
			//	TArray< FHitResult > HitResults;
			//	if (GetWorld()->SweepMultiByObjectType(HitResults, trace_start, trace_end, FQuat(), object_params, FCollisionShape::MakeSphere(radialSize), collision_params) && /*hit_result.IsValidBlockingHit()*/HitResults.Num() > 0)
			//	{
			//		trace_end = HitResults[0].ImpactPoint;

			//		/*auto initiator = character->HeldActor;
			//		if (!initiator) {
			//			initiator = character;
			//		}*/
			//		return UContentResolver::Instance->ResolveInteraction(trigger, HitResults[0], this);
			//	}
			//}
		}
	}

	TArray<UItemComponent*> components;
	return components;
}