// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ItemWidget.h"
#include "CharacterInventoryWidget.generated.h"

USTRUCT(BlueprintType)
struct FCharacterInventoryWidget
{
	GENERATED_USTRUCT_BODY()
public:

	UPROPERTY(EditAnywhere, Category = Item, BlueprintReadWrite)
		TArray<UItemWidget *> Widgets;
};