// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"
#include "Weighting.h"
#include "SoundCueWeighting.h"
#include "ItemComponent.h"
#include "Components/SceneComponent.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
//#include "AutoInstancedStaticMeshActor.h"
#include "InstancedComponentsEntry.h"
//#include "ItemWidget.h"
#include "AutoInstancedStaticMeshActor.h"
#include "Common.generated.h"

class AAutoInstancedStaticMeshActor;
class UItemWidget;

const int ITEM_MAX_STACK = 999;

UCLASS()
class FPSPROJECT_API AMothInstanceMeshChunkActor : public AActor
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	AMothInstanceMeshChunkActor()
	{

	}

protected:

public:

	UFUNCTION(BlueprintCallable, BlueprintNativeEvent) USceneComponent* GetChunkComponent();
	USceneComponent* GetChunkComponent_Implementation()
	{
		return NULL;
	}
};

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FSocketTransformation
{
	GENERATED_USTRUCT_BODY()

private:

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FName Socket;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FTransform Transform;
};

UCLASS()
class FPSPROJECT_API UCommon : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:

	UFUNCTION(BlueprintCallable, Category = "World")
		static void AddInteractionAtLocation(FVector location, UPrimitiveComponent* component, FRotator direction, float damageRadius, float speed, float damage);

	UFUNCTION(BlueprintCallable, Category = "World")
		static float RoundFloat(float input, int decimals);

	//UFUNCTION(BlueprintCallable, Category = "World")
	static FString GetReferencePath(UObjectBaseUtility* object);

	UFUNCTION(BlueprintCallable, Category = "World") // base utility cannot do this
		static FString GetReferencePathForObject(UObject* object);

	// https://en.wikipedia.org/wiki/Fitness_proportionate_selection
	// this is a modified version of this
	// the only difference is that when ALL weights are the same we fallback to a random pick where the weight > 0
	UFUNCTION(BlueprintCallable, Category = "Random")
		static int Roulette(TArray<FWeighting> items);

	UFUNCTION(BlueprintCallable, Category = "Casting")
		static TArray<FWeighting> CastToWeightedItemArray(TArray<FSoundCueWeighting> items)
	{
		//return reinterpret_cast<TArray<FWeighting>&>(items);
		//return static_cast<TArray<FWeighting>>(items);
		TArray<FWeighting> weightings;

		for (int i = 0; i < items.Num(); i++) {
			FWeighting weighting = FWeighting();
			weighting.Weighting = items[i].Weighting;
			weightings.Add(weighting);
		}
		return weightings;
	}

	UFUNCTION(BlueprintCallable, Category = "Instancing")
		static FGetItemComponentForInstanceResult GetItemComponentForInstance(UHierarchicalInstancedStaticMeshComponent* parent, int instanceID, EInstancedCategory category, AAutoInstancedStaticMeshActor* actor = NULL);

	UFUNCTION(BlueprintCallable, Category = "World")
		static void PlayWeightedSound(TArray<FSoundCueWeighting> items, UWorld* world, FVector location);

	UFUNCTION(BlueprintCallable, Category = "World")
		static void PlayWeightedSoundByComponent(TArray<FSoundCueWeighting> items, USceneComponent* component, FVector location);

	UFUNCTION(BlueprintCallable, Category = "World")
		static FTransform GetSocketWorldLocationForInstance(FTransform instanceTransform, FTransform socketTransform);

	UFUNCTION(BlueprintCallable, Category = "World")
		static TArray<FTransform> SortByClosestTransform(FTransform origin, TArray<FTransform> points);

	UFUNCTION(BlueprintCallable, Category = "World")
		static TArray<FSocketTransformation> SortByClosestSocketTransformation(FTransform origin, TArray<FSocketTransformation> points);

	UFUNCTION(BlueprintCallable, Category = "World")
		static FRotator GetComponentNormalRotation(FVector UpVector, USceneComponent* component, FHitResult hitResult);
	UFUNCTION(BlueprintCallable, Category = "World")
		static FRotator GetComponentRotation(FVector start, FVector target, USceneComponent* component);

	UFUNCTION(BlueprintCallable, Category = "World")
		static TArray<FItemData> TryFindSlotForItem(UItemContainer* collection, UPARAM(ref) FItemData& item, bool allow_max_stack, UObject* outer, float amount = -1);
	
/*
	UFUNCTION(BlueprintCallable, Category = "World")
		static TArray<FItemData> TryFindSlotForItemInstance(UItemContainer* collection, FItemData item, bool allow_max_stack, UObject* outer);*/

	template<typename T, typename T_cb_OnUpdated, typename T_cb_GetItem>
	static TArray<FItemData> FindSlotForItem(UItemContainer* collection, UPARAM(ref) FItemData& item, bool allow_max_stack, UObject* outer,
		//UItemInstance*(*cb_GetItem)(T element),
		//void(*cb_OnUpdated)(TArray<UItemWidget*> &src_collection, T element, bool bIsNewSlot, UItemInstance* item, int slot, float receivedAmount)
		T_cb_GetItem cb_GetItem,
		T_cb_OnUpdated cb_OnUpdated,
		float amount = -1
	)
	{
		TArray<FItemData> slots;
		bool has_more = false;
		auto wc_item = item; // ->Clone(outer);

		auto min_capacity = collection->Items.Num(); // FMath::Max(collection.Num(), min_capacity);

		float current_stack = amount == -1 ? wc_item.Stack : amount;

		// try find an existing stack
		for (int slot = 0; slot < min_capacity; slot++) {
			auto element = &collection->Items[slot];
			//auto tb_item = cb_GetItem(element);
			//auto tb_item = cb_GetItem(element);
			if (/*tb_item &&*/ element->ItemID == wc_item.ItemID /*&& !collection[slot]->IsLocked*/) {
				float free_space = (allow_max_stack ? ITEM_MAX_STACK : element->MaxStack) - element->Stack;
				if (free_space > 0) {
					float deduction_amt = FMath::Min(free_space, current_stack);

					wc_item.Stack -= deduction_amt;
					current_stack -= deduction_amt;
					element->Stack += deduction_amt;

					//collection[slot]->OnUpdated(collection, slot, false, deduction_amt);
					cb_OnUpdated(collection, *element, false, *element, slot, deduction_amt);
					slots.Add(collection->Items[slot]);
				}
			}
			if (current_stack <= 0) {
				// cancel the loop if we have consumed the stack
				break;
			}
		}

		if (current_stack > 0) {
			// else if we still have quantity to consume, then try to find a free slot
			for (int slot = 0; slot < min_capacity; slot++) {
				auto element = &collection->Items[slot];
				//auto tb_item = cb_GetItem(element);
				if (collection->Items.Num() == slot || element->ItemID <= 0 || element->Stack <= 0 /*|| collection[slot]->ItemInstance->Thumbnail == NULL*/) {
					// needs a new slot created
					auto clone = wc_item; // ->Clone(outer);
					//clone.MaxStack = allow_max_stack ? ITEM_MAX_STACK : clone.DefaultMaxStack; // restore the initial stack as this has now become a inventory item

					float stack = FMath::Min(current_stack, (allow_max_stack ? ITEM_MAX_STACK : clone.MaxStack));

					wc_item.Stack -= stack;
					current_stack -= stack;
					clone.Stack = stack;

					//collection[slot]->OnSetItem(clone);
					//collection[slot]->OnUpdated(collection, slot, true, stack);
					cb_OnUpdated(collection, *element, true, clone, slot, stack);
					slots.Add(collection->Items[slot]);
				}
				if (current_stack <= 0) {
					// cancel the loop if we have consumed the stack
					break;
				}
			}
		}

		if (current_stack > 0) {
			// try to put into main inventory
			// else drop item ...
			//GEngine->AddOnScreenDebugMessage(-1, 10.0f, FColor::Magenta, FString::Printf(TEXT("Cannot fit into toolbelt: %f"), wc_item->Stack));

			//has_more = true;
		}

		item.Stack = wc_item.Stack;

		// clear item.
		if (item.Stack <= 0) {
			item.ItemID = 0;
		}

		return slots;
	}

	static FVector ParseVector(const FString& reference);
	static FRotator ParseRotator(const FString& reference);

	static double Distance(FTransform p1, FTransform p2);

	static void Test();

	UFUNCTION(BlueprintCallable, Category = "World")
		static TArray<FItemData> TryFindItemByContainer(UItemContainer* container, int itemID, float &available);

	UFUNCTION(BlueprintCallable) static TArray<FItemData> GetLoot(/*const FItemData& item*/int itemID, const EInteractionTrigger& trigger, UItemCache* cache)
	{
		return FItemData::GetLoot(itemID, trigger, cache);
	}

	UFUNCTION(BlueprintCallable)
		static TArray<FItemData> GetRecipes(int itemID, UItemCache* cache)
	{
		return FItemData::GetRecipes(itemID, cache);
	}

	UFUNCTION(BlueprintCallable) static TArray<FItemData> GetIngredients(int itemID, UItemCache* cache);

	UFUNCTION(BlueprintCallable)
		static TArray<UItemRepairInstance*> GetRepairRequirements(int itemID, UItemCache* cache)
	{
		return FItemData::GetRepairRequirements(itemID, cache);
	}

	/*UFUNCTION(BlueprintCallable)
		static TArray<FItemData> GetInteractions(int itemID)
	{
		return FItemData::GetInteractions(itemID);
	}*/

	UFUNCTION(BlueprintCallable)
		static TArray<UItemAliasInstance*> GetAliases(int itemID, UItemCache* cache)
	{
		return FItemData::GetAliases(itemID, cache);
	}

	//UFUNCTION(BlueprintCallable) static void CalculateItemStack(UPARAM(ref) FItemData& itemDataInstance, EInteractionTrigger trigger, FItemData damagedItem, float toolDamage, UPARAM(ref) TMap<int, float>& parentStackRemainder)
	UFUNCTION(BlueprintCallable) static void CalculateItemStack(UPARAM(ref) FItemData& itemDataInstance, EInteractionTrigger trigger, FItemData damagedItem, float toolDamage, UPARAM(ref) FItemData& rootStackItem, UItemCache* cache)
	{
		return FItemData::CalculateStack(itemDataInstance, trigger, damagedItem, toolDamage, rootStackItem, cache);
	}

	UFUNCTION(BlueprintCallable) static UObject* NewSubObject(UObject* Outer, UClass* Class, USceneComponent* parent = NULL)
	{
		if (Outer && Class) {
			auto s = NewObject<UObject>(Outer, Class);

			if (s->IsA(USceneComponent::StaticClass()))
			{
				auto a = Cast<USceneComponent>(s);

				if (parent) {
					a->AttachToComponent(parent, FAttachmentTransformRules::KeepWorldTransform);
				}

				a->RegisterComponent();
			}

			return s;
		}
		return NULL;
	}

	UFUNCTION(BlueprintCallable) static UObject* NewSubObjectNoRegister(UObject* Outer, UClass* Class )
	{
		if (Outer && Class) {
			auto s = NewObject<UObject>(Outer, Class);

			return s;
		}
		return NULL;
	}

	UFUNCTION(BlueprintCallable) static void RegisterSubObject(USceneComponent* component)
	{
		component->RegisterComponent();
	}

	UFUNCTION(BlueprintCallable) void DestroySubObject(USceneComponent* component)
	{
		component->DestroyComponent(); // UE BP's cannot call this so we need this wrapper like we do with NewSubObject
	}

	UFUNCTION(BlueprintCallable) static UInstancedStaticMeshComponent* GetFoliageComponent(FHitResult hitresult)
	{
		auto ism = Cast<UInstancedStaticMeshComponent>(hitresult.Component);
		if (!IsValid(ism)) {
			auto ca = Cast<AMothInstanceMeshChunkActor>(hitresult.Actor);
			if (IsValid(ca)) {
				auto component = ca->GetChunkComponent();
				ism = Cast<UInstancedStaticMeshComponent>(component);
			}
		}
		return ism;
	}

	UFUNCTION(BlueprintCallable) static FString GetFoliageID(FHitResult hitresult)
	{
		auto component = UCommon::GetFoliageComponent(hitresult);
		if (IsValid(component)) {
			auto actor = component->GetOwner();
			return actor->GetName()
				.Append("_").Append(component->GetName())
				.Append("_").Append(FString::FromInt(hitresult.Item));
		}
		return FString();
	}
};
