// Fill out your copyright notice in the Description page of Project Settings.

#include "DecalPool.h"
#include "Engine.h"
#include "GameSettings.h"
#include "DrawDebugHelpers.h"

// TODO object pool with push/pull?

UDecalPool::UDecalPool()
{
}
UDecalPool::~UDecalPool()
{
	//GetOuter()->GetWorld()->GetTimerManager().ClearTimer(this->CheckLimitHandle);
}

void UDecalPool::BeginWatching()
{
	GetOuter()->GetWorld()->GetTimerManager().SetTimer(this->CheckLimitHandle, this, &UDecalPool::CheckLimit, 5, false);
}

void UDecalPool::Register(UDecalComponent* decal)
{
	if (decal) {
		this->pool.Add(decal);
	}
	else {
		//if (GEngine) {
		//	//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("Decal pool detected invalid decal"));
		//}
	}
}

int UDecalPool::GetCapacity()
{
	return this->pool.Num();
}

void UDecalPool::CheckLimit()
{
	if (UGameSettings::Instance && UGameSettings::Instance->MaxDecals > 0) {
		int overflow = this->pool.Num() - UGameSettings::Instance->MaxDecals;
		if (overflow > 0) {
			while (overflow-- > 0) {
				UDecalComponent * decal = pool[0];
				if (decal) {
					pool.RemoveAt(0);
					if (!decal->IsPendingKillOrUnreachable()) {
						//this->OnUnload(decal);
						//decal->FadeOut
						decal->DestroyComponent();
					}
				}
				else {
					/*if (GEngine) {
						GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("Potential decal pool leak"));
					}*/
					break;
				}
			}
		}
	}
}

UDecalPool* UDecalPool::Instance = NULL;