// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ItemPlaceableType.generated.h"

UENUM(BlueprintType)
enum class EItemPlaceableType : uint8
{
	None = 0 UMETA(DisplayName = "None"),
	SpawnActor = 1 UMETA(DisplayName = "Spawn Actor"),
	SpawnFoliage = 2 UMETA(DisplayName = "Spawn Foliage"),

	MAX = SpawnFoliage UMETA(Hidden),
	DEFAULT = None UMETA(DisplayName = "DEFAULT (None)")
};