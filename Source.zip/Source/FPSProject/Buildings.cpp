#include "Buildings.h"
#include "ContentResolver.h"
#include "FoliageInstancedStaticMeshComponent.h"
#include "InstancedFoliageActor.h"
#include "WorldStaticMeshComponent.h"
#include "Engine/CollisionProfile.h"

USceneComponent* UBuildings::PlaceItem(AMOTHCharacter* character, UItemInstance* item, FTransform location, USceneComponent* attachTo, UWorld* world)
{
	USceneComponent* result = NULL;
	UStaticMesh* mesh = NULL;

	if (item && item->Alias) {
		if (!world) {
			world = character->GetWorld();
		}

		switch (static_cast<EItemPlaceableType>(item->Alias->ItemPlaceableTypeID)) {

		case EItemPlaceableType::SpawnFoliage:
		{
			mesh = UContentResolver::Instance->FindObjectByReference<UStaticMesh>(item->Alias->Name);
			if (mesh) {
				result = UBuildings::PlaceFoliage(world, mesh, location);
			}
			break;
		}

		case EItemPlaceableType::SpawnActor:
		{
			if (item->Alias->ActorBlueprint.Len() > 0) {
				auto bp = UContentResolver::Instance->ResolveBlueprint(item->Alias->ActorBlueprint);
				if (bp && bp->IsChildOf(AStaticMeshActor::StaticClass())) {
					auto sma = item->GetWorld()->SpawnActor<AStaticMeshActor>(bp, location);

					auto cmp = sma->GetStaticMeshComponent();
					result = cmp;
				}
			}

			//mesh = UContentResolver::Instance->FindObjectByReference<UStaticMesh>(item->Alias->Name);
			//if (IsValid(mesh)) {
			//	auto sma = item->GetWorld()->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), location);
			//	auto cmp = sma->GetStaticMeshComponent();
			//	cmp->SetCollisionProfileName(UCollisionProfile::BlockAllDynamic_ProfileName);
			//	cmp->SetMobility(EComponentMobility::Movable);
			//	cmp->SetStaticMesh(mesh);
			//	cmp->SetMobility(EComponentMobility::Static);
			//	cmp->SetGenerateOverlapEvents(true); // so snap points work
			//	result = cmp;
			//}

			//if (item->Alias->DefaultComponent.Len() > 0) {
			//	auto bp = UContentResolver::Instance->ResolveBlueprint(item->Alias->DefaultComponent);
			//	if (bp && bp->IsChildOf(UWorldStaticMeshComponent::StaticClass())) {
			//		//auto world = this->GetWorld();
			//		auto actor = AAutoInstancedStaticMeshActor::GetInstance(world);
			//		if (actor) {
			//			UObject* owner = attachTo;
			//			if (!owner) {
			//				owner = actor;
			//			}
			//			auto cmp = NewObject<UWorldStaticMeshComponent>(owner, bp);
			//			cmp->SetWorldTransform(location);
			//			//cmp->AttachTo(actor);
			//			cmp->RegisterComponent();

			//			if (item->IsAttachment && attachTo)
			//			{
			//				cmp->AttachToComponent(attachTo, FAttachmentTransformRules::KeepRelativeTransform);

			//				auto wsmc = Cast<UWorldStaticMeshComponent>(attachTo);
			//				if (wsmc) {
			//					wsmc->PrimaryAttachment = cmp;
			//				}
			//			}

			//			if (cmp->ItemComponent) {
			//				cmp->ItemComponent->ItemInstance = item->Clone(cmp);
			//				cmp->ItemComponent->ItemInstance->Stack = 1;
			//			}

			//			//item->Stack--;
			//			result = cmp;
			//		}
			//	}
			//}
			break;
		}
		}
	}

	return result;
}

USceneComponent* UBuildings::PlaceFoliage(UWorld* world, UStaticMesh* mesh, FTransform transform) //, FName collisionProfileName)
{
	TArray<AInstancedFoliageActor*> actors;
	for (TActorIterator<AInstancedFoliageActor> foliageIterator(world); foliageIterator; ++foliageIterator) {
		actors.Add(*foliageIterator);
	}

	UFoliageInstancedStaticMeshComponent* existing_component = NULL;
	for (int i = 0; i < actors.Num(); i++) {
		AInstancedFoliageActor* foliageActor = actors[i];
		if (foliageActor) {
			auto components = foliageActor->GetComponentsByClass(UFoliageInstancedStaticMeshComponent::StaticClass());
			if (components.Num() > 0) {
				for (int c = 0; c < components.Num(); c++) {
					auto component = Cast<UFoliageInstancedStaticMeshComponent>(components[c]);
					auto component_mesh = component->GetStaticMesh();
					if (mesh == component_mesh) {
						existing_component = component;
						break;
					}
				}
			}
		}
	}

	if (!existing_component && actors.Num() > 0) {
		auto parent = actors[0];
		existing_component = NewObject<UFoliageInstancedStaticMeshComponent>(parent, UFoliageInstancedStaticMeshComponent::StaticClass());

		existing_component->SetMobility(EComponentMobility::Static);
		existing_component->SetCollisionProfileName(FName("NoCollision"));
		existing_component->SetStaticMesh(mesh);
		existing_component->RegisterComponent();
	}

	if (existing_component) {
		existing_component->AddInstance(transform);
	}

	return existing_component;
}

void UBuildings::DeductFromContainer(UItemContainer* container, FItemData& widget, float amount)
{
	if (widget.ItemID > 0) {
		widget.Stack -= amount;
	}
	/*if (widget) {
		widget->OnUpdated(collection, widget->ItemSlot, false, -1);
	}*/
}