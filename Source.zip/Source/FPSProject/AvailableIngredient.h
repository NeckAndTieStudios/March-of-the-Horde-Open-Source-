// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ContentResolver.h"
#include "ItemWidget.h"
#include "AvailableIngredient.generated.h"

USTRUCT(BlueprintType)
struct FAvailableIngredientContainerItem
{
	GENERATED_USTRUCT_BODY()
public:
	UPROPERTY(EditAnywhere, Category = Item, BlueprintReadWrite)
		UItemContainer* Container;

	UPROPERTY(EditAnywhere, Category = Item, BlueprintReadWrite)
		int SlotID;
};

USTRUCT(BlueprintType)
struct FAvailableIngredient
{
	GENERATED_USTRUCT_BODY()
public:
	UPROPERTY(EditAnywhere, Category = Item, BlueprintReadWrite)
		float Available;

	UPROPERTY(EditAnywhere, Category = Item, BlueprintReadWrite)
		FItemData Ingredient;

	UPROPERTY(EditAnywhere, Category = Item, BlueprintReadWrite)
		TArray<FAvailableIngredientContainerItem> Items;

	FAvailableIngredient() {}

	FAvailableIngredient(float available, FItemData ingredient)
	{
		this->Available = available;
		this->Ingredient = ingredient;
	}
};