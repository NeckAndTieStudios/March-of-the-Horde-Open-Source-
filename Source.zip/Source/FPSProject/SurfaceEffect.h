// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Particles/ParticleSystem.h"
#include "SurfaceEffectSound.h"
#include "Materials/MaterialInterface.h"
#include "SurfaceEffect.generated.h"

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable)
class FPSPROJECT_API USurfaceEffect : public UObject
{
	GENERATED_BODY()

public:

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect")
		int SurfaceEffectID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect")
		FString Name;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect")
		UParticleSystem * HitParticle;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect")
		float HitParticleMinSpeed;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect")
		FRotator HitParticleRotation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect")
		FVector HitParticleScale;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect")
		bool AllowHitImpulse;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect")
		bool AllowDamage;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect")
		bool DestroyActorOnHit;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect")
		UMaterialInterface * DecalType;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect")
		FVector DecalSize;*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect")
		TArray<USurfaceEffectSound*> Sounds;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect")
		TArray<USurfaceEffectDecal *> Decals;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect")
		TArray<USurfaceEffectParticle*> Particles;


	/*UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect")
		UObject* Decal;*/
/*
	static TArray<USurfaceEffect*> SurfaceTypeInstances;
	static TArray<USurfaceEffect*> MappedInstances;*/

	UFUNCTION(BlueprintCallable)
		void PlaySoundAtLocation(FVector location);

	UFUNCTION(BlueprintCallable)
		void SpawnHitParticleAtLocation(FVector location, FRotator rotation, FVector forwardVector, FVector impactNormal, UItemInstance* item, bool IsHit, bool IsDespawn, bool IsInteract);

	UFUNCTION(BlueprintCallable)
		void SpawnParticleAtLocation(FVector location, FRotator rotation, FVector forwardVector, FVector impactNormal, FVector scale, UParticleSystem* particleSystem);

	UFUNCTION(BlueprintCallable)
		void SpawnDecalAtLocation(FVector location, FRotator rotation, FVector forwardVector, FVector impactNormal, UObject* owner, int itemIndex);

	UFUNCTION(BlueprintCallable)
		void SpawnRandomParticleAtLocation(FVector location, FRotator rotation, FVector forwardVector, FVector impactNormal);
};