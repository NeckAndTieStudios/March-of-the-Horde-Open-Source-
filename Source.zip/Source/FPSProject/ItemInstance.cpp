// Fill out your copyright notice in the Description page of Project Settings.

#include "ItemInstance.h"
#include "ContentResolver.h"
#include "Classes/Engine/World.h"
#include "Engine/StaticMeshActor.h"
#include "Classes/Engine/StaticMesh.h"
#include "DestructibleComponent.h"
#include "DestructibleMesh.h"
#include "ItemCache.h"
#include "GlobalGameInstance.h"
#include "Engine.h"

//FItemInstanceLootCacheEntry::FItemInstanceLootCacheEntry() {}
//FItemInstanceLootCacheEntry::FItemInstanceLootCacheEntry(TArray<UItemInstance *> entries)
//{
//	Entries = entries;
//}

bool UItemInstance::CanBeDamaged()
{
	return this->Data.Health > 0;
}

UItemInstance* UItemInstance::Clone(UObject* outer)
{
	UItemInstance* instance = NewObject<UItemInstance>(outer);

	/*instance->Data.MaxStack = this->MaxStack;
	instance->Data.HealthMax = this->HealthMax;
	instance->Data.Health = this->Health;
	instance->Data.Stack = this->Stack;
	instance->Data.ItemLootFormulaID = this->ItemLootFormulaID;
	instance->Data.ItemLootFormulaValue = this->ItemLootFormulaValue;
	instance->Data.InteractionMode = this->Data.InteractionMode;
	instance->Data.IsAttachment = this->Data.IsAttachment; // TODO: use reflection
	instance->Data.IsPickupAllowed = this->Data.IsPickupAllowed; // TODO: use reflection
	instance->Data.IsClippable = this->Data.IsClippable; // TODO: use reflection
	instance->Data.IsPlaceable = this->Data.IsPlaceable;
	instance->Data.IsLootable = this->Data.IsLootable;
	instance->Data.DisplayName = this->Data.DisplayName;
	instance->Data.Weight = this->Data.Weight; // TODO: use reflection*/

	instance->Data = this->Data;

	//instance->_actor = this->_actor; // maybe not do this, may have the give item check for LootSelf
	instance->ItemID = this->ItemID;
	instance->ItemGroupID = this->ItemGroupID;
	instance->BaseHealth = this->BaseHealth;
	instance->DefaultMaxStack = this->DefaultMaxStack;
	//instance->LootSelf = this->LootSelf;
	instance->Thumbnail = this->Thumbnail;
	instance->FoliageTypeID = this->FoliageTypeID;
	instance->FoliageScaleIndex = this->FoliageScaleIndex;
	instance->ToolTypeID = this->ToolTypeID;
	instance->BaseLevel = this->BaseLevel;
	//instance->Recipes = this->Recipes;
	//instance->Ingredients = this->Ingredients;
	//instance->Interactions = this->Interactions;
	instance->CraftDuration = this->CraftDuration; // TODO: use reflection
	instance->RepairDuration = this->RepairDuration; // TODO: use reflection
	instance->BuildOffset = this->BuildOffset; // TODO: use reflection
	instance->BuildTargetSockets = this->BuildTargetSockets; // TODO: use reflection
	instance->BuildOnGround = this->BuildOnGround; // TODO: use reflection
	instance->BuildSocketRequired = this->BuildSocketRequired; // TODO: use reflection
	instance->UpgradeStage = this->UpgradeStage; // TODO: use reflection

	instance->Punchable = this->Punchable; // TODO: use reflection
	instance->IsKickable = this->IsKickable; // TODO: use reflection
	instance->ShowUI = this->ShowUI; // TODO: use reflection
	instance->IsHarvestable = this->IsHarvestable; // TODO: use reflection
	instance->IsHoldable = this->IsHoldable; // TODO: use reflection
	instance->HandOffsetLocation = this->HandOffsetLocation; // TODO: use reflection
	instance->HandOffsetRotation = this->HandOffsetRotation; // TODO: use reflection
	instance->InteractionDelay = this->InteractionDelay; // TODO: use reflection
	instance->FireBurnTime = this->FireBurnTime;
	instance->FuelProduced = this->FuelProduced;

	//instance->PreviewMesh = this->PreviewMesh; // TODO: use reflection
	//instance->Loot = this->Loot; // keep reference? might be useful for changing loot items on the fly (across all objects of it's type, TODO: static)
	//instance->LootCache = this->LootCache; // keep reference? might be useful for changing loot items on the fly (across all objects of it's type, TODO: static)
	instance->Alias = this->Alias;
	instance->Attributes = this->Attributes;

	return instance;
}

AActor* UItemInstance::GetActor(AActor* owner)
{
	if (/*!IsValid(this->_actor) &&*/ this->Alias) {
		if (this->Alias->ActorBlueprint.Len() > 0) {
			auto bp = UContentResolver::Instance->ResolveBlueprint(this->Alias->ActorBlueprint);
			if (bp && bp->IsChildOf(AActor::StaticClass())) {
				FActorSpawnParameters spawn;
				spawn.Owner = owner;
				AActor* actor = this->GetWorld()->SpawnActor<AActor>(bp, spawn); //caller needs to deal with locations etc

				//this->_actor = actor;
				return actor;
			}
		}
		//if (this->_actor == NULL && !this->LootSelf && this->Alias->Name.Len() > 0) {
		//	UObject* obj = StaticLoadObject(UObject::StaticClass(), this, *this->Alias->Name);
		//	UStaticMesh* sm = Cast<UStaticMesh>(obj);

		//	FActorSpawnParameters spawn;
		//	AStaticMeshActor* actor = this->GetWorld()->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), spawn); //caller needs to deal with locations etc

		//	actor->SetMobility(EComponentMobility::Movable);
		//	actor->GetStaticMeshComponent()->SetStaticMesh(sm);

		//	this->_actor = actor;
		//}
	}

	return NULL;
	//return this->_actor;
}

//void UItemInstance::SetActor(AActor* actor)
//{
//	this->_actor = actor;
//}

TArray<FItemData> FItemData::GetLoot(int itemID, const EInteractionTrigger& trigger, UItemCache* cache)
{
	auto loot = cache->GetItemLoot(itemID, trigger);

	FItemData::CalculateLootTable(loot);

	return loot;
	/*TArray<UItemInstance*> loot;

	EInteractionTrigger t = trigger;
	FItemInstanceLootCacheEntry* entry = this->LootCache.Find(trigger);

	if (entry) {
		return entry->Entries;
	}

	return loot;*/
}
//TArray<UItemInstance*> UItemInstance::GetLoot(const EInteractionTrigger& trigger)
//{
//	return UItemCache::Instance->GetItemLoot(this->ItemID, trigger);
//	/*TArray<UItemInstance*> loot;
//
//	EInteractionTrigger t = trigger;
//	FItemInstanceLootCacheEntry* entry = this->LootCache.Find(trigger);
//
//	if (entry) {
//		return entry->Entries;
//	}
//
//	return loot;*/
//}

TArray<FItemData> FItemData::GetRecipes(int itemID, UItemCache* cache)
{
	return cache->GetItemRecipes(itemID);
}
//TArray<UItemInstance*> UItemInstance::GetRecipes()
//{
//	return UItemCache::Instance->GetItemRecipes(this->ItemID);
//	//if (!_loaded_Recipes && this->Recipes.Num() == 0) {
//	//	//this->Recipes = UContentResolver::Instance->ResolveRecipesForItem(this);
//	//	TArray<int> item_ids = UDatabaseLoader::GetRecipesForItem(this->ItemID);
//	//	TArray<UItemInstance*> recipes;
//
//	//	for (int item_id : item_ids) {
//	//		auto item = UItemCache::Instance->GetItemByID(item_id);
//	//		recipes.Add(item);
//	//	}
//	//	this->Recipes = recipes;
//
//	//	_loaded_Recipes = true;
//	//}
//
//	//return this->Recipes;
//}

TArray<FItemData> FItemData::GetIngredients(int itemID, UItemCache* cache)
{
	return cache->GetItemIngredients(itemID);
}
//TArray<UItemInstance*> UItemInstance::GetIngredients()
//{
//	return UItemCache::Instance->GetItemIngredients(this->ItemID);
//	/*if (!_loaded_Ingredients && this->Ingredients.Num() == 0) {
//		this->Ingredients = UContentResolver::Instance->ResolveIngredientsForItem(this);
//		_loaded_Ingredients = true;
//	}
//
//	return this->Ingredients;*/
//}

TArray<UItemAliasInstance*> FItemData::GetAliases(int itemID, UItemCache* cache)
{
	return cache->GetItemAliasesByID(itemID);
}
//TArray<UItemAliasInstance*> UItemInstance::GetAliases()
//{
//	return UItemCache::Instance->GetItemAliasesByID(this->ItemID);
//	//if (!_loaded_Aliases && this->Aliases.Num() == 0) {
//	//	//this->Aliases = UContentResolver::Instance->ResolveAliasesForItem(this);
//	//	this->Aliases = UItemCache::Instance->GetItemAliasesByID(this->ItemID);
//	//	_loaded_Aliases = true;
//	//}
//
//	//return this->Aliases;
//}

TArray<UItemRepairInstance*> FItemData::GetRepairRequirements(int itemID, UItemCache* cache)
{
	return cache->GetItemRepairRequirements(itemID);
}

TArray<UItemInteraction*> UItemInstance::GetInteractions(UItemCache* cache)
{
	return cache->GetItemInteractions(this->ItemID);
	/*if (this->ManualInteractions.Num() > 0) {
		if (!_loaded_Interactions) {
			for (int i = 0; i < this->ManualInteractions.Num(); i++) {
				auto ii = NewObject<UItemInteraction>(this);
				auto sii = this->ManualInteractions[i];

				ii->ItemInteractionID = 0;
				ii->ItemGroupID = sii.ItemGroupID;
				ii->SurfaceEffectID = sii.SurfaceEffectID;

				this->Interactions.Add(ii);
			}
			_loaded_Interactions = true;
		}
	}
	else {
		if (!_loaded_Interactions && this->Interactions.Num() == 0) {
			this->Interactions = UContentResolver::Instance->ResolveInteractionsForItem(this);
			_loaded_Interactions = true;
		}
	}

	return this->Interactions;*/
}

TArray<UItemUpgradeInstance*> UItemInstance::GetUpgrades(UItemCache* cache)
{
	//if (!_loaded_Upgrades && this->Upgrades.Num() == 0) {
	//	//this->Upgrades = UContentResolver::Instance->ResolveUpgradesForItem(this);
	//	_loaded_Upgrades = true;
	//}
	auto requirements = cache->GetItemUpgrades(this->ItemID);

	TArray<UItemUpgradeInstance*> upgrades;
	int next_upgrade_stage = this->UpgradeStage + 1;
	// find results for the next stage only
	//for (int i = this->Upgrades.Num() - 1; i >= 0; i--)
	for (int i = 0; i < requirements.Num(); i++)
	{
		if (requirements[i]->Stage == next_upgrade_stage)
		{
			upgrades.Add(requirements[i]);
		}
	}

	return upgrades;
}

void UItemInstance::Load()
{
	this->Data.Stack = this->Data.MaxStack; // default stack. used for trees without a foliage type

	this->BaseHealth = this->Data.Health;
	this->Data.HealthMax = this->Data.Health; // consolidate these? base is good, max is also logical but does not associate to skills etc

	//UItemInstance* item = this;
	//UContentResolver::Instance->ResolveAttributesForItem(item);

	auto attributes = UDatabaseLoader::GetAttributesForItem(this->ItemID);

	for (int i = 0; i < attributes.Num(); i++) {
		UItemAttributeInstance* attribute = NewObject<UItemAttributeInstance>(this);
		attribute->ItemAttributeType = static_cast<EItemAttributeType>(attributes[i]->ItemAttributeTypeID);
		this->Attributes.Add(attribute);

		switch (attribute->ItemAttributeType) {
		case EItemAttributeType::Attachment:
			this->Data.IsAttachment = true;
			break;
		case EItemAttributeType::SnapToGround:
			this->BuildOnGround = true;
			break;
		case EItemAttributeType::SocketRequiredToPlace:
			this->BuildSocketRequired = true;
			break;
		case EItemAttributeType::Punchable:
			this->Punchable = true;
			break;
		case EItemAttributeType::Kickable:
			this->IsKickable = true;
			break;
		case EItemAttributeType::PickupAllowed:
			this->Data.IsPickupAllowed = true;
			break;
		case EItemAttributeType::ShowUI:
			this->ShowUI = true;
			break;
		case EItemAttributeType::Clippable:
			this->Data.IsClippable = true;
			break;
		case EItemAttributeType::Harvestable:
			this->IsHarvestable = true;
			break;
		case EItemAttributeType::Holdable:
			this->IsHoldable = true;
			break;
		case EItemAttributeType::Lootable:
			this->Data.IsLootable = true;
			break;
		case EItemAttributeType::Placeable:
			this->Data.IsPlaceable = true;
			break;
		case EItemAttributeType::Consumable:
			this->Data.IsConsumable = true;
			break;
		}
	}

	GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache->SetItemByID(this->Data.ItemID, this->Data);

	/*for (int i = 0; i < this->Attributes.Num(); i++) {
		switch (this->Attributes[i]->ItemAttributeType) {
		case EItemAttributeType::Attachment:
			this->IsAttachment = true;
			break;
		case EItemAttributeType::SnapToGround:
			this->BuildOnGround = true;
			break;
		case EItemAttributeType::SocketRequiredToPlace:
			this->BuildSocketRequired = true;
			break;
		case EItemAttributeType::Punchable:
			this->Punchable = true;
			break;
		case EItemAttributeType::Kickable:
			this->IsKickable = true;
			break;
		case EItemAttributeType::PickupAllowed:
			this->IsPickupAllowed = true;
			break;
		case EItemAttributeType::ShowUI:
			this->ShowUI = true;
			break;
		case EItemAttributeType::Clippable:
			this->IsClippable = true;
			break;
		case EItemAttributeType::Harvestable:
			this->IsHarvestable = true;
			break;
		case EItemAttributeType::Holdable:
			this->IsHoldable = true;
			break;
		case EItemAttributeType::Lootable:
			this->IsLootable = true;
			break;
		case EItemAttributeType::Placeable:
			this->IsPlaceable = true;
			break;
		}
	}*/

	//int max_interaction_triggers = static_cast<int>(EInteractionTrigger::MAX);
	//for (int i = 1; i <= max_interaction_triggers; i++) {
	//	EInteractionTrigger trigger = static_cast<EInteractionTrigger>(i);

	//	//auto loot = UContentResolver::Instance->ResolveLootForItem(this, trigger);
	//	TArray<UItemInstance*> loot;

	//	auto results = UDatabaseLoader::GetLootForItem(this->ItemID, trigger);
	//	for (int r = 0; r < results.Num(); r++) {
	//		auto lootInstance = results[r]->AsItemInstance(this); // parent item instance so the Alias is shared
	//		loot.Add(lootInstance);
	//	}

		//this->CalculateLootTable(loot);
	//	this->LootCache.Add(trigger, FItemInstanceLootCacheEntry(loot));
	//}

	/*this->GetRecipes();
	this->GetIngredients();
	this->GetInteractions();
	this->GetUpgrades();*/
}

void UItemInstance::PostCacheLoad()
{
	auto itemcache = GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache;
	//this->GetRecipes();
	//this->GetIngredients();
	this->GetInteractions(itemcache);
	this->GetUpgrades(itemcache);
	//this->GetAliases();
}

//void UItemInteraction::Load()
//{
//	if (this->SurfaceEffectID >= 0) {
//
//	}
//}

UItemInteraction* UItemInstance::GetInteractionByItem(int hitByItemGroupID)
{
	UItemInteraction* result = NULL;

	auto itemcache = GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache;
	auto interactions = this->GetInteractions(itemcache);
	for (int i = 0; i < interactions.Num(); i++)
	{
		auto interaction = interactions[i];

		if (interaction->ItemGroupID == hitByItemGroupID) {
			result = interaction;
			break;
		}
	}

	return result;
}

float UItemInstance::GetHealth(float min, float max)
{
	return FMath::FloorToFloat(FMath::RandRange(min, max));
}

//void UItemInstance::CalculateStack(EInteractionTrigger trigger, UItemInstance* damagedItem, float toolDamage, UPARAM(ref) TMap<int, float>& parentStackRemainder)
//{
//	float damage_percent = toolDamage / damagedItem->BaseHealth;
//
//	//FItemInstanceLootCacheEntry* entry = damagedItem->LootCache.Find(trigger);
//	//auto entries = this->GetLoot(trigger);
//	auto entries = FItemData::GetLoot(this->ItemID, trigger);
//
//	//if (entry) {
//	//auto entries = entry->Entries;
//	for (int i = 0; i < entries.Num(); i++) {
//		auto item = &entries[i];
//
//		if (item->ItemID == this->ItemID && item->Stack > 0.0f) {
//			float number_of_loot = item->MaxStack * damage_percent;
//			float stack = number_of_loot; // FMath::FloorToFloat(number_of_loot);
//										  //stack = FMath::Max(stack, 1.0f); // < 1
//			stack = FMath::Min(stack, this->MaxStack); // dont exceed max stack
//			stack = FMath::Min(stack, item->Stack); // dont take more than available
//
//			if (parentStackRemainder.Contains(item->ItemID))
//			{
//				stack += parentStackRemainder[item->ItemID];
//				parentStackRemainder[item->ItemID] = 0.f;
//
//				if (stack < 1.f) {
//					parentStackRemainder[item->ItemID] += stack;
//				}
//			}
//			else
//			{
//				if (stack < 1.f) {
//					parentStackRemainder.Add(item->ItemID, stack);
//				}
//			}
//
//			/*stack += this->StackRemainder;
//			this->StackRemainder = 0.f;
//
//			if (stack < 1.f) {
//				this->StackRemainder += stack;
//			}
//*/
//			stack = FMath::FloorToFloat(stack);
//
//			// TODO: Store the overflow and add it to the next operation maybe? otherwise it will never dispense for low end tools, rather they probably need to keep hitting till they get at least one.
//
//			this->Stack = stack;
//
//			item->Stack -= this->Stack; // remove from the loot available
//			return;
//		}
//	}
//	//}
//}

//void FItemData::CalculateStack(UPARAM(ref) FItemData& itemDataInstance, EInteractionTrigger trigger, FItemData damagedItem, float toolDamage, UPARAM(ref) TMap<int, float>& parentStackRemainder)
//static void CalculateStack(UPARAM(ref) FItemData& itemDataInstance, EInteractionTrigger trigger, FItemData damagedItem, float toolDamage, UPARAM(ref) FItemData& rootStackItem);
void FItemData::CalculateStack(UPARAM(ref) FItemData& itemDataInstance, EInteractionTrigger trigger, FItemData damagedItem, float toolDamage, UPARAM(ref) FItemData& rootStackItem, UItemCache* cache)
{
	//float damage_percent = toolDamage / damagedItem.BaseHealth;
	float damage_percent = toolDamage / damagedItem.HealthMax;

	//FItemInstanceLootCacheEntry* entry = damagedItem->LootCache.Find(trigger);
	//auto entries = this->GetLoot(trigger);
	auto entries = FItemData::GetLoot(itemDataInstance.ItemID, trigger, cache);

	//if (entry) {
	//auto entries = entry->Entries;
	for (int i = 0; i < entries.Num(); i++) {
		auto item = &entries[i];

		if (item->ItemID == itemDataInstance.ItemID && item->Stack > 0.0f) {
			float number_of_loot = item->MaxStack * damage_percent;
			float stack = number_of_loot; // FMath::FloorToFloat(number_of_loot);
										  //stack = FMath::Max(stack, 1.0f); // < 1
			stack = FMath::Min(stack, itemDataInstance.MaxStack); // dont exceed max stack
			stack = FMath::Min(stack, item->Stack); // dont take more than available

			if (rootStackItem.StackRemainder.Contains(item->ItemID))
			{
				stack += rootStackItem.StackRemainder[item->ItemID];
				rootStackItem.StackRemainder[item->ItemID] = 0.f;

				if (stack < 1.f) {
					rootStackItem.StackRemainder[item->ItemID] += stack;
				}
			}
			else
			{
				if (stack < 1.f) {
					rootStackItem.StackRemainder.Add(item->ItemID, stack);
				}
			}

			/*stack += this->StackRemainder;
			this->StackRemainder = 0.f;

			if (stack < 1.f) {
				this->StackRemainder += stack;
			}
*/
			stack = FMath::FloorToFloat(stack);

			// TODO: Store the overflow and add it to the next operation maybe? otherwise it will never dispense for low end tools, rather they probably need to keep hitting till they get at least one.

			itemDataInstance.Stack = stack;

			item->Stack -= itemDataInstance.Stack; // remove from the loot available
			return;
		}
	}
	//}
}

void FItemData::CalculateLootTable(TArray<FItemData>& loot)
{
	for (int i = 0; i < loot.Num(); i++) {
		auto item = &loot[i];

		if (item->ItemLootFormulaID == static_cast<int>(EItemLootFormula::None))
		{
			item->Stack = 1.f;
			item->MaxStack = item->Stack;
		}
		//else  if (item->ItemLootFormulaID == static_cast<int>(EItemLootFormula::Wood))
		//{
		//	item->Stack = (this->BaseHealth / 100) * this->FoliageScaleIndex;
		//	item->Stack = FMath::CeilToFloat(item->Stack); // round up to the closest int
		//	item->MaxStack = item->Stack;
		//}
		//else if (item->ItemLootFormulaID == static_cast<int>(EItemLootFormula::BarkFibre))
		//{
		//	item->Stack = (this->BaseHealth / 100) * ((4 + 1)/*Max scale index + 1*/ - this->FoliageScaleIndex);
		//	item->Stack = FMath::CeilToFloat(item->Stack); // round up to the closest int
		//	item->MaxStack = item->Stack;
		//}
		//else if (item->ItemLootFormulaID == static_cast<int>(EItemLootFormula::Eggs))
		//{
		//	item->Stack = (this->FoliageScaleIndex - 1) + FMath::RandRange(0, 2);
		//	item->Stack = FMath::CeilToFloat(item->Stack); // round up to the closest int
		//	item->MaxStack = item->Stack;
		//}
		//else if (item->ItemLootFormulaID == static_cast<int>(EItemLootFormula::Feathers))
		//{
		//	item->Stack = (this->FoliageScaleIndex - 1) * this->FoliageScaleIndex;
		//	item->Stack = FMath::CeilToFloat(item->Stack); // round up to the closest int
		//	item->MaxStack = item->Stack;
		//}
		//else if (item->ItemLootFormulaID == static_cast<int>(EItemLootFormula::Sapling))
		//{
		//	item->Stack = FMath::RandRange(0, this->FoliageScaleIndex * 2); // 0-(ix*2) =      this->FoliageScaleIndex + (rand(-this->FoliageScaleIndex, this->FoliageScaleIndex)) =  4 + -4 == 0 , 4 + 4 = 8 
		//	item->Stack = FMath::CeilToFloat(item->Stack); // round up to the closest int
		//	item->MaxStack = item->Stack;
		//}
		//else if (item->ItemLootFormulaID == static_cast<int>(EItemLootFormula::Pinecones))
		//{
		//	item->Stack = FMath::RandRange(0, this->FoliageScaleIndex * 2); // 0-(ix*2) =      this->FoliageScaleIndex + (rand(-this->FoliageScaleIndex, this->FoliageScaleIndex)) =  4 + -4 == 0 , 4 + 4 = 8 
		//	item->Stack = FMath::CeilToFloat(item->Stack); // round up to the closest int
		//	item->MaxStack = item->Stack;
		//}
		else if (item->ItemLootFormulaID == static_cast<int>(EItemLootFormula::CustomValue))
		{
			item->Stack = item->ItemLootFormulaValue;
			item->MaxStack = item->Stack;
		}
		else if (item->ItemLootFormulaID == -1)
		{
			item->Stack = 999;
			item->MaxStack = item->Stack;
		}
		else
		{
			//GEngine->AddOnScreenDebugMessage(-1, 30.0f, FColor::Red, FString("Unsupported ItemLootFormula: ").Append(FString::FromInt(item->ItemLootFormulaID)));
		}
	}
}

void UItemInstance::SpawnDestructibleMesh(FTransform transform)
{
	if (this->Alias && this->Alias->DestructibleMesh) {
		auto actor = AAutoInstancedStaticMeshActor::GetInstance(this->GetWorld());

		auto destructible_component = NewObject<UDestructibleComponent>(actor);
		//destructible_component->AttachToComponent(this, FAttachmentTransformRules::KeepRelativeTransform);
		destructible_component->SetDestructibleMesh(this->Alias->DestructibleMesh);
		destructible_component->SetWorldTransform(transform);
		destructible_component->RegisterComponent();
		//destructible_component->RegisterComponentWithWorld(this->GetWorld());
		destructible_component->ApplyRadiusDamage(1000, transform.GetLocation(), 100.f, 1000.f, true);
	}
}