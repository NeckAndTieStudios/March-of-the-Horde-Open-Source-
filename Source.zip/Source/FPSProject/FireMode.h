// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "FireMode.generated.h"

UENUM(BlueprintType)
enum class EFireMode : uint8 {
	Single = 0,
	Burst = 1,
	Auto = 2,

	MIN = Single UMETA(Hidden),
	MAX = Auto UMETA(Hidden)
};
