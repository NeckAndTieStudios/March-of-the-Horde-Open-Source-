// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Materials/MaterialInterface.h"
#include "Sound/SoundCue.h"

#include "Common.h"
#include "BulletType.h"

#include "GlobalBulletSettings.generated.h"

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FBulletTypeSettings
{
	GENERATED_USTRUCT_BODY()

public:

	EBulletType Type;

	UPROPERTY(EditAnywhere)
		FString Name;

#define stringify( name ) # name
	FString GetBulletTypeName(EBulletType EnumValue)
	{
		const UEnum* EnumPtr = FindObject<UEnum>(ANY_PACKAGE, TEXT(stringify(EBulletType)), true);
		if (!EnumPtr)
			return TEXT("Unknown");

		return EnumPtr->GetDisplayNameTextByIndex((uint8)EnumValue).ToString();
	}

#pragma region Ricochet
	// allows the bullet to ricochet off objects
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface - Bullets")
		bool Ricochet = false;

	// the min angle the ricochet angle can be. < 0 to disable. the range of the face is 0-90*, where 90 is the surface of the asset and 0 is looking top down
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface - Bullets", meta = (EditCondition = "Ricochet"))
		float RicochetAngleMin = -1.f;// 45.f;

	// the max angle the ricochet angle can be. < 0 to disable. the range of the face is 0-90*, where 90 is the surface of the asset and 0 is looking top down
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface - Bullets", meta = (EditCondition = "Ricochet"))
		float RicochetAngleMax = -1.f;//90.f;

	// the percentage of speed lost upon a ricochet
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface - Bullets", meta = (EditCondition = "Ricochet"))
		float RicochetSpeedReductionPercentage = .05;

	// the percentage change of a bullet ricocheting
	// 0.00-1.00
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface - Bullets", meta = (EditCondition = "Ricochet"))
		float RicochetChance = 1.f; /// 0.5f;
#pragma endregion

#pragma region Penetration
	// allows the bullet to penetrate objects
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface - Bullets")
		bool Penetration = false;

	// the percentage change of a bullet penetrating an object
	// 0.00-1.00
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface - Bullets", meta = (EditCondition = "Penetration"))
		float PenetrationChance = 1.f;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface - Bullets", meta = (EditCondition = "Penetration"))
	float PenetrationAngleMin = 0.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface - Bullets", meta = (EditCondition = "Penetration"))
	float PenetrationAngleMax = 90.f;*/

	// base penetration depth of a bullet, in cm
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface - Bullets", meta = (EditCondition = "Penetration"))
		float PenetrationDepthBase = 50.f;

	// the percentage of speed lost upon a penetraton
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface - Bullets", meta = (EditCondition = "Penetration"))
		float PenetrationSpeedReductionPercentage = .3;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface - Bullets", meta = (EditCondition = "Penetration"))
		float PenetrationPercentage = 60;
#pragma endregion

	FBulletTypeSettings()
	{
		Name = "Unknown";
		Name = GetBulletTypeName(Type);
	}
	FBulletTypeSettings(uint8 bulletType)
	{
		Type = (EBulletType)bulletType;
		Name = GetBulletTypeName(Type);
	}
};

/**
 *
 */
USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FGlobalBulletSettings
{
	GENERATED_USTRUCT_BODY()

public:

#pragma region Surface
	UPROPERTY(EditAnywhere, Category = "Surface")
		FString Name = "Unknown surface setting";

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface")
		bool IsMineable = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface")
		bool AllowHitImpulse = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface")
		bool AllowDamage = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface", meta = (EditCondition = "AllowHitImpulse || AllowDamage"))
		bool DestroyOnFirstHit = false;
#pragma endregion

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface - Bullets", meta = (TitleProperty = "Name"))
		TArray<FBulletTypeSettings> BulletTypeSettings;

#pragma region Surface Decals
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface - Decals")
		UParticleSystem * ParticleType = NULL;

	// allows configuration of the particle rotation. some particles may be at 0, or a 45d offset to center between the center of a vector
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface - Decals")
		FRotator ParticleRotation = FRotator(0.f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface - Decals")
		float ParticleScale = 1.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface - Decals")
		UMaterialInterface * DecalType = NULL;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface - Decals")
		FVector DecalSize = FVector(16, 32, 32);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface - Decals")
		TArray<FSoundCueWeighting> ImpactSounds;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface - Decals")
		float MinimumParticleSpeed = 20.f;
#pragma endregion

	FGlobalBulletSettings()
	{
		for (int i = 0; i < (uint8)EBulletType::MAX; i++) {
			BulletTypeSettings.Add(FBulletTypeSettings(i));
		}
	}
	FGlobalBulletSettings(FString name)
	{
		Name = name;

		for (int i = 0; i < (uint8)EBulletType::MAX; i++) {
			BulletTypeSettings.Add(FBulletTypeSettings(i));
		}
	}

	FBulletTypeSettings GetBulletTypeSetting(uint8 bulletType)
	{
		if (BulletTypeSettings.Num() > bulletType)
			return BulletTypeSettings[bulletType];

		auto r = FBulletTypeSettings();
		r.Penetration = true;
		r.Ricochet = true;
		return r;
	}
};
