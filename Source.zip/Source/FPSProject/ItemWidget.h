// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "ContentResolver.h"
//#include "FPSCharacter.h"
#include "Components/BoxComponent.h"
#include "ItemContainer.h"
#include "ItemWidget.generated.h"

UCLASS(Blueprintable, BlueprintType)
class FPSPROJECT_API USelectableWidget : public UUserWidget
{
	GENERATED_BODY()

public:

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsSelected;

	//UPROPERTY(EditAnywhere, BlueprintReadWrite)
	//	UItemInstance * ItemInstance;
};

UENUM(BlueprintType)
enum class EItemWidgetState : uint8
{
	Default,
	Available,
	NotAvailable
};

//UENUM(BlueprintType)
//enum class EItemContainerType : uint8
//{
//	Unknown = 0,
//	Player = 1,
//	World = 2
//};

UCLASS(Blueprintable, BlueprintType)
class FPSPROJECT_API UItemWidget : public USelectableWidget
{
	GENERATED_BODY()

public:

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		EItemWidgetState State = EItemWidgetState::Default;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (ExposeOnSpawn = "true"))
		FString ItemContainerName;*/

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (ExposeOnSpawn = "true"))
		EItemContainerType ItemContainerType = EItemContainerType::Player;*/

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (ExposeOnSpawn = "true"))
	TArray<UItemInstance *> *ItemContainer;*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (ExposeOnSpawn = "true"))
		int ItemSlot = -1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (ExposeOnSpawn = "true"))
		UItemContainer * Container = NULL;

	UFUNCTION(BlueprintCallable) virtual void SetItemInstance(FItemData data)
	{
		if (Container) {
			if (Container->Items.Num() > ItemSlot && ItemSlot > -1) {
				Container->Items[ItemSlot] = data;
			}
			else {
				if (GEngine) {
					GEngine->AddOnScreenDebugMessage(-1, 10.0f, FColor::Magenta, FString::Printf(TEXT("Invalid slot %i"), ItemSlot));
				}
			}
		}
	}


	UFUNCTION(BlueprintImplementableEvent)
		FItemData OnGetItemInstance();

	UFUNCTION(BlueprintCallable) virtual FItemData GetItemInstance()
	{
		FItemData instance = FItemData();

		auto hook = OnGetItemInstance();
		if (hook.ItemID > 0) {
			instance = hook;
		}

		if (instance.ItemID == 0 && IsValid(Container)) {
			if (Container->Items.Num() > ItemSlot && ItemSlot > -1) {
				instance = Container->Items[ItemSlot];
			}
			else {
				if (GEngine) {
					GEngine->AddOnScreenDebugMessage(-1, 10.0f, FColor::Magenta, FString::Printf(TEXT("Invalid slot %i"), ItemSlot));
				}
			}
		}

		return instance;
	}

	UFUNCTION(BlueprintCallable) void GetItemReference(FItemData& instance)
	{
		if (Container) {
			if (Container->Items.Num() > ItemSlot && ItemSlot > -1) {
				instance = Container->Items[ItemSlot];
			}
			else {
				if (GEngine) {
					GEngine->AddOnScreenDebugMessage(-1, 10.0f, FColor::Magenta, FString::Printf(TEXT("Invalid slot %i"), ItemSlot));
				}
			}
		}
	}


	/*
	UFUNCTION(BlueprintCallable)
	TArray<UItemInstance *> GetItemContainer(AFPSCharacter* character);*/

	UFUNCTION(BlueprintImplementableEvent)
		void OnClear();

	UFUNCTION(BlueprintImplementableEvent)
		void OnSetItem(FItemData item);

	UFUNCTION(BlueprintImplementableEvent)
		void OnUpdated(const TArray<UItemWidget*>& collection, int collectionIndex, bool inserted, float appendedQuantity);

	UFUNCTION(BlueprintImplementableEvent)
		void OnCraft();

	UFUNCTION(BlueprintImplementableEvent)
		void OnRepair();

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsLocked;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsHighlighted;
};

UCLASS(Blueprintable, BlueprintType)
class FPSPROJECT_API URecipeWidget : public UItemWidget //USelectableWidget
{
	GENERATED_BODY()

public:

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsRecipeEnabled;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FItemData RecipeItem = FItemData();

	UFUNCTION(BlueprintImplementableEvent)
		TArray<UItemWidget*> GetSlots();
/*
	UFUNCTION(BlueprintImplementableEvent)
		TArray<FItemData> GetContainedItems();*/
};