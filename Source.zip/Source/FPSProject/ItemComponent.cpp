// Fill out your copyright notice in the Description page of Project Settings.

#include "ItemComponent.h"
#include "ContentResolver.h"
#include "GlobalGameInstance.h"
#include "WorldStaticMeshComponent.h"
#include "FoliageInstancedStaticMeshComponent.h"
#include "InstancedFoliageActor.h"
#include "Buildings.h"
#include "BuildingComponent.h"
#include "ItemCache.h"
#include "Engine.h"

//class UWorldStaticMeshComponent;

UItemComponent::UItemComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = false;
}

void UItemComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (this->IsInteracting) {
		this->UpdateInterationTimer();
	}
}

FTransform UItemComponent::GetInstanceTransform()
{
	FTransform transform;

	auto hism = Cast<UHierarchicalInstancedStaticMeshComponent>(this->InstanceComponent);
	if (hism) {
		hism->GetInstanceTransform(this->InstanceID, transform);
	}
	else {
		this->InstanceComponent->GetInstanceTransform(this->InstanceID, transform);
	}

	return transform;
}

void UItemComponent::Despawn(FHitResult hit_result)
{
	if (this->InstanceComponent && this->ItemInstance.ItemID > 0) { // && this->ItemInstance->Alias) {
		//UStaticMesh* mesh = this->InstanceComponent->GetStaticMesh();
		//FTransform transform = this->GetInstanceTransform();

		this->OnDespawn(hit_result);
	}
	auto parent = this->GetAttachParent();
	if (parent->GetClass() == UStaticMeshComponent::StaticClass())
	{
		this->OnDespawn(hit_result);
	}

	this->ClearDecals();
}

bool UItemComponent::TrySpawnDeathActor(UStaticMesh* mesh, FTransform transform, FHitResult hit_result)
{
	bool result = false;
	auto def = GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache->GetLocalItemByID(this->ItemInstance.ItemID);
	if (def->Alias->ActorBlueprint.Len() > 0) {
		UClass* actor_class = UContentResolver::Instance->ResolveBlueprint(def->Alias->ActorBlueprint);
		if (actor_class) {
			this->DeathActor = this->GetWorld()->SpawnActor<AActor>(actor_class, transform, FActorSpawnParameters());

			auto staticMeshComponent = Cast<UStaticMeshComponent>(this->DeathActor->GetComponentByClass(UStaticMeshComponent::StaticClass()));
			if (staticMeshComponent && !staticMeshComponent->GetStaticMesh()) {
				staticMeshComponent->SetMobility(EComponentMobility::Movable); // required due to unreal only adding collision to movable objects at runtime
				staticMeshComponent->SetStaticMesh(mesh);
				staticMeshComponent->SetMobility(EComponentMobility::Static); // required due to unreal only adding collision to movable objects at runtime
			}

			//// used to prevent more hits - can also be removed easily
			//auto dead_component = NewObject<UItemComponent>(this->DeathActor);
			//dead_component->ItemInstance = this->ItemInstance->Clone(this->DeathActor);
			//dead_component->RegisterComponent();
			//dead_component->Despawn();

			auto new_component = Cast <UItemComponent>(this->DeathActor->GetComponentByClass(UItemComponent::StaticClass()));
			new_component->ItemInstance = this->ItemInstance; // ->Clone(this->DeathActor);
			new_component->DeathActor = this->DeathActor;
			new_component->OnKilled(hit_result);
			result = true;
		}
	}
	return result;
}

void UItemComponent::ApplyDamage(FHitResult hit_result, float damage, AActor* initiator, EInteractionTrigger trigger)
{
	if (this->ItemInstance.ItemID > 0) // && !this->is_killed) allow hit particles, sounds etc. if the item has not been taken off screen don't take anything else.
	{
		// apply to attachments first
		if (this->WorldStaticMeshComponent) {
			if (this->WorldStaticMeshComponent->PrimaryAttachment) {
				auto wsmc = this->WorldStaticMeshComponent->PrimaryAttachment;
				if (wsmc->ItemComponent && wsmc->ItemComponent->ItemInstance.IsAttachment) {
					wsmc->ItemComponent->ApplyDamage(hit_result, damage, initiator, trigger);
					return;
				}
			}
			/*TArray<USceneComponent*> children;
			this->WorldStaticMeshComponent->GetChildrenComponents(false, children);
			if (children.Num() > 0) {
				for (int i = 0; i < children.Num(); i++) {
					auto wsmc = Cast<UWorldStaticMeshComponent>(children[i]);
					if (wsmc && wsmc->ItemComponent && wsmc->ItemComponent->ItemInstance->IsAttachment) {
						wsmc->ItemComponent->ApplyDamage(hit_result, damage, initiator, trigger);
						return;
					}
				}
			}*/
		}
		//auto building = Cast<UBuildingComponent>(this->InstanceComponent);
		//if(building && building->Children)

		//bool was_alive = this->ItemInstance->Health > 0.f;
		this->ItemInstance.Health -= damage;
		bool killed = !this->is_killed && this->ItemInstance.Health <= 0;

		/*if (killed) {
		}*/

		this->OnDamage(hit_result, damage, killed, initiator, trigger);

		if (killed) {
			this->AnimateSelf(killed);
			//this->OnKilled(hit_result);
			this->is_killed = true;
		}
		else {
			auto ap = this->GetAttachParent();
			if (ap) {
				this->TryUpdateMesh(ap);
			}
		}
	}
}

FItemInstanceRemoveResult UItemComponent::RemoveInstance(bool remove_children)
{
	FItemInstanceRemoveResult result = FItemInstanceRemoveResult();

	//if (this->ItemInstance->Alias) {
		//if (request.trigger == EInteractionTrigger::Any || request.trigger == EInteractionTrigger::Primary) {
		// try to find and create the replacement actor
	if (this->InstanceComponent && this->InstanceID > -1) {
		UStaticMesh* mesh = this->InstanceComponent->GetStaticMesh();
		result.Mesh = mesh;

		// store the values since they could change before the game thread exec's
		auto current_component = this->InstanceComponent;
		auto current_component_index = this->InstanceID;

		auto hisma = Cast<UHierarchicalInstancedStaticMeshComponent>(current_component);
		if (hisma) {
			hisma->GetInstanceTransform(current_component_index, result.Transform, true);
		}
		else {
			current_component->GetInstanceTransform(current_component_index, result.Transform, true);
		}

		AsyncTask(ENamedThreads::GameThread, [this, result, current_component, current_component_index, remove_children]()
			{
				//FTransform invisible = FTransform(FRotator(), FVector(0, 0, -100000), FVector::OneVector);
				FTransform invisible = FTransform(result.Transform);
				//invisible.SetScale3D(FVector(0, 0, 0));
				auto loc = invisible.GetLocation();
				invisible.SetLocation(FVector(loc.X, loc.Y, -100000));

				auto bc = Cast<UBuildingComponent>(current_component);
				if (bc) {
					if (remove_children) {
						bc->UpdateInstanceTransform(current_component_index, invisible, true, false);
					}
					else {
						bc->UpdateInstanceTransformSingle(current_component_index, invisible, true, false);
					}
					bc->MarkRenderStateDirty();
				}
				else {
					auto hism = Cast<UHierarchicalInstancedStaticMeshComponent>(current_component);
					if (hism) {
						//hism->RemoveInstance(current_component_index);
						hism->UpdateInstanceTransform(current_component_index, invisible, true, false);
						hism->MarkRenderStateDirty();
					}
					else {
						//current_component->RemoveInstance(current_component_index);
						current_component->UpdateInstanceTransform(current_component_index, invisible, true, false);
						current_component->MarkRenderStateDirty();
					}
				}
				//auto actor = AAutoInstancedStaticMeshActor::GetInstance(this->GetWorld());
				//FString container_reference = AAutoInstancedStaticMeshActor::GetComponentKey(current_component, result.Mesh, EInstancedCategory::Foliage);
				//// as soon as RemoveInstance is called UE will shrink its instances array, thus we need to also decrement this single operation
				//auto entry = actor->InstancedComponents.Find(container_reference);
				//if (entry) {
				//	if (entry->ComponentData.Num() > current_component_index) { // FIX ME
				//	// send out the current data
				//		auto OutData = entry->ComponentData[current_component_index];

				//		//// KEEP IN SYNC WITH UE's INSTANCE BODIES
				//		//int max_instances = entry->ComponentData.Num();
				//		//int LastInstanceIndex = max_instances - 1;
				//		//if (current_component_index == LastInstanceIndex)
				//		//{
				//		//	entry->ComponentData.RemoveAt(current_component_index);
				//		//}
				//		//else
				//		//{
				//		//	entry->ComponentData.RemoveAtSwap(current_component_index);
				//		//}

				//		// update the indicies since it should now have shrunk
				//		//max_instances = entry->ComponentData.Num();
				//		/*for (int i = 0; i < max_instances; i++)
				//		{
				//			auto wsmc = Cast<UWorldStaticMeshComponent>(entry->ComponentData[i]);
				//			if (wsmc) {
				//				wsmc->InstanceID = i;
				//				if (wsmc->ItemComponent) {
				//					wsmc->ItemComponent->InstanceID = i;
				//				}
				//			}
				//		}*/
				//	}
				//	else {
				//		if (GEngine)
				//		{
				//			GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("Instances out of sync."));
				//		}
				//	}
				//}

				if (this->InstanceComponent == current_component && this->InstanceID == current_component_index) {
					this->InstanceComponent = NULL;
					this->InstanceID = -1;
				}
			});
	}
	//}
//}
	return result;
}

FString UItemComponent::GetInteractionText()
{
	if (builtInteractionText.Len() == 0) {
		this->BuildInteractionTextForCurrentActor();
	}
	return this->builtInteractionText;
	//FString result = this->InteractionText;
	//if (this->ItemInstance.ItemID > 0) {

	//	FString prefix = FString();
	//	if (this->ItemInstance.IsPickupAllowed) {
	//		if (prefix.Len() > 0) {
	//			prefix = prefix.Append(FString("\n"));
	//		}
	//		prefix = prefix.Append(FString("[E] Pickup "));
	//	}
	//	if (this->ItemInstance.IsClippable) {
	//		if (prefix.Len() > 0) {
	//			prefix = prefix.Append(FString("\n"));
	//		}
	//		prefix = prefix.Append(FString("[RM] Clip "));
	//	}
	//	if (this->ItemInstance.IsLootable) {
	//		if (prefix.Len() > 0) {
	//			prefix = prefix.Append(FString("\n"));
	//		}
	//		prefix = prefix.Append(FString("[E] Loot "));
	//	}
	//	if (prefix.Len() > 0) {
	//		prefix = prefix.Append(FString("\n"));
	//	}

	//	return prefix.Append(this->InteractionTextPrefix).Append(this->ItemInstance.DisplayName);

	//	//if (this->InteractionTextAppendItemName) {
	//	//	result = result.Append(this->ItemInstance->DisplayName);
	//	//}
	//	//if (result.Len() > 0) {
	//	//	if (this->ItemInstance->IsPickupAllowed) {
	//	//		return FString("[E] ").Append(this->ItemInstance->DisplayName);
	//	//	}
	//	//	/*switch (this->InteractionTrigger) {
	//	//	case EInteractionTrigger::Pickup:
	//	//		return FString("[E] ").Append(result);
	//	//	}*/
	//	//}
	//}
	//else {
	//	result = FString(this->InteractionTextPrefix).Append(this->InteractionText);
	//}
	//return result;
}


void UItemComponent::BuildInteractionTextWithArgs(AActor* actor, TArray<UItemComponent*> components, FString prefix, FString input, FString action, FString variant, FString name, FString suffix)
{
	// prefix			- unused 
	// input prefix		- [E]  or the (A) controller button
	// action			- "Search unopened", "Open"
	// prefix/variant	- Dirty
	// item name		- Locker
	// suffix/health	- 100/100
	//
	// e.g.:
	//	[E] Search Locker - 100/100
	//	[E] Open door - 45/100
	//	[E] Drink from water container - 50%
	//
	FString text = TEXT("");

	if (prefix.Len() > 0) {
		text = text.Append(prefix);
	}

	if (input.Len() > 0) {
		if (text.Len() > 0) {
			text = text.Append(FString(" ")).Append(input);
		}
		else {
			text = text.Append(input);
		}
	}

	if (action.Len() > 0) {
		if (text.Len() > 0) {
			text = text.Append(FString(" ")).Append(action);
		}
		else {
			text = text.Append(action);
		}
	}

	if (variant.Len() > 0) {
		if (text.Len() > 0) {
			text = text.Append(FString(" ")).Append(variant);
		}
		else {
			text = text.Append(variant);
		}
	}

	if (name.Len() > 0) {
		if (text.Len() > 0) {
			text = text.Append(FString(" ")).Append(name);
		}
		else {
			text = text.Append(name);
		}
	}

	if (suffix.Len() > 0) {
		if (text.Len() > 0) {
			text = text.Append(FString(" - ")).Append(suffix);
		}
		else {
			text = text.Append(suffix);
		}
	}

	this->builtInteractionText = text;
}

void UItemComponent::OnFocusReceived_Implementation(AActor* initiator)
{

}

void UItemComponent::OnFocus(AActor* initiator)
{
	this->HasFocus = true;
	OnFocusReceived(initiator);
	this->RebuildInteractionTextForCurrentActor();
}

void UItemComponent::OnFocusOut(AActor* initiator)
{
	this->StopInterationTimer();
	this->OnFocusLost(initiator);
	this->HasFocus = false;
	this->HasActiveFocus = false;
	this->RebuildInteractionTextForCurrentActor();
}

void UItemComponent::OnInteractionCancel(AActor* initiator)
{
	if (this->ItemInstance.InteractionMode == EInteractionMode::PressAndHold) {
		this->StopInterationTimer();
	}
	this->OnInteractionCancelled(initiator);
}

void UItemComponent::StartInterationTimer(bool silent) {
	/*if (!GetWorld()->GetTimerManager().IsTimerActive(InteractionWaitTimeHandle)) {
		this->InteractionWaitTimeStart = GetWorld()->GetTimeSeconds();
		GetWorld()->GetTimerManager().SetTimer(InteractionWaitTimeHandle, this, &UItemComponent::UpdateInterationTimer, 0.05f, true, 0.f);
	}*/
	if (!this->IsInteracting) {
		this->IsInteracting = true;

		this->InteractionWaitTimeValue = 0.f;
		this->InteractionWaitTimeStart = GetWorld()->GetTimeSeconds();
		this->InteractionIsSilent = silent;

		this->SetComponentTickEnabled(true);
	}
}

void UItemComponent::StopInterationTimer() {
	/*if (GetWorld()->GetTimerManager().IsTimerActive(InteractionWaitTimeHandle)) {
		GetWorld()->GetTimerManager().ClearTimer(InteractionWaitTimeHandle);

		this->InteractionWaitTimeValue = 0.f;
		this->InteractionWaitTimeStart = 0.f;
	}*/
	if (this->IsInteracting) {
		this->IsInteracting = false;

		this->InteractionWaitTimeValue = 0.f;
		this->InteractionWaitTimeStart = 0.f;

		this->SetComponentTickEnabled(false);
	}
}

void UItemComponent::OnFocusLost_Implementation(AActor* initiator)
{
	InteractionInstance = NULL;
}

void UItemComponent::UpdateInterationTimer() {
	auto current = GetWorld()->GetTimeSeconds();
	//this->InteractionWaitTimeValue = FMath::Min(FMath::CeilToFloat((current - this->InteractionWaitTimeStart) * 10.f) / 10.f, this->InteractionWaitTime);
	this->InteractionWaitTimeValue = FMath::Min(current - this->InteractionWaitTimeStart, this->InteractionWaitTime);

	if (this->InteractionWaitTimeValue >= this->InteractionWaitTime) {
		this->StopInterationTimer();

		// INTERACTION COMPLETE
		this->OnInteractionComplete(this->InteractionInstance);
	}
}

void UItemComponent::ClearDecals()
{
	for (int i = this->DecalInstances.Num() - 1; i >= 0; i--)
	{
		auto gi = Cast<UGlobalGameInstance>(this->GetWorld()->GetGameInstance());
		gi->StaticMeshActorPool->Release(this->DecalInstances[i].Decal);
		this->DecalInstances.RemoveAt(i);
	}
}

void UItemComponent::Clip(const FString new_mesh)
{
	auto mesh = UContentResolver::Instance->FindObjectByReference<UStaticMesh>(new_mesh);
	if (mesh) {
		FTransform transform = this->GetInstanceTransform();

		/*TActorIterator<AInstancedFoliageActor> foliageIterator(GetWorld());
		AInstancedFoliageActor* foliageActor = *foliageIterator;*/

		this->RemoveInstance();

		UBuildings::PlaceFoliage(GetWorld(), mesh, transform); // , this->InstanceComponent->GetCollisionProfileName());

		/*TArray<AInstancedFoliageActor*> actors;
		for (TActorIterator<AInstancedFoliageActor> foliageIterator(GetWorld()); foliageIterator; ++foliageIterator) {
			actors.Add(*foliageIterator);
		}

		UFoliageInstancedStaticMeshComponent* existing_component = NULL;
		for (int i = 0; i < actors.Num(); i++) {
			AInstancedFoliageActor* foliageActor = actors[i];
			if (foliageActor) {
				auto components = foliageActor->GetComponentsByClass(UFoliageInstancedStaticMeshComponent::StaticClass());
				if (components.Num() > 0) {
					for (int c = 0; c < components.Num(); c++) {
						auto component = Cast<UFoliageInstancedStaticMeshComponent>(components[c]);
						auto component_mesh = component->GetStaticMesh();
						if (mesh == component_mesh) {
							existing_component = component;
							break;
						}
					}
				}
			}
		}

		if (!existing_component && actors.Num() > 0) {
			auto parent = actors[0];
			existing_component = NewObject<UFoliageInstancedStaticMeshComponent>(parent, UFoliageInstancedStaticMeshComponent::StaticClass());

			existing_component->SetMobility(EComponentMobility::Static);
			existing_component->SetCollisionProfileName(this->InstanceComponent->GetCollisionProfileName());
			existing_component->SetStaticMesh(mesh);
			existing_component->RegisterComponent();
		}

		if (existing_component) {
			existing_component->AddInstance(transform);
		}*/
	}
}

UItemAliasInstance* UItemComponent::GetAliasByHealth(bool exactMatch)
{
	UItemAliasInstance* result = NULL;
	auto itemcache = GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache;
	auto aliases = FItemData::GetAliases(this->ItemInstance.ItemID, itemcache);
	UItemInstance* local = NULL;

	int health = 0;
	for (auto alias : aliases)
	{
		if (alias->HealthBreakpoint > 0) { // alias included in 
			if (exactMatch) {
				if (this->ItemInstance.Health >= alias->HealthBreakpoint && alias->HealthBreakpoint > health) {
					result = alias;
					health = (int)alias->HealthBreakpoint;
				}
			}
			else {
				if (!local) {
					local = GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache->GetLocalItemByID(this->ItemInstance.ItemID);
				}
				if (this->ItemInstance.Health <= alias->HealthBreakpoint && alias->HealthBreakpoint < local->Alias->HealthBreakpoint) {
					//if (this->ItemInstance.Health <= alias->HealthBreakpoint && alias->HealthBreakpoint < local->Alias->HealthBreakpoint) {
					result = alias;
					break;
				}
			}
		}
	}
	return result;
};

bool UItemComponent::TryUpdateMesh(USceneComponent* component)
{
	bool animated = false;
	auto new_alias = this->GetAliasByHealth();
	if (new_alias && this->ItemInstance.AliasName != new_alias->Name) {
		auto mesh = Cast<UStaticMesh>(new_alias->GetInstance());
		if (mesh) {
			auto smc = Cast<UStaticMeshComponent>(component);
			if (smc && smc->GetStaticMesh() != mesh) {
				smc->SetCollisionProfileName(UCollisionProfile::BlockAllDynamic_ProfileName);
				smc->SetMobility(EComponentMobility::Movable);
				smc->SetStaticMesh(mesh);
				smc->SetMobility(EComponentMobility::Static);
				smc->SetGenerateOverlapEvents(true); // so snap points work
				this->ItemInstance.AliasName = new_alias->Name;
				this->AnimateSelf(false);
				animated = true;
			}
		}
	}
	return animated;
}

bool UItemComponent::TryRepair(AMOTHCharacter* character, USceneComponent* component, FItemData item)
{
	if (this->ItemInstance.ItemID > 0 && component && component->IsA(UStaticMeshComponent::StaticClass())) {
		auto smc = Cast<UStaticMeshComponent>(component);
		if (smc) {
			auto itemcache = GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache;
			auto repairs = FItemData::GetRepairRequirements(this->ItemInstance.ItemID, itemcache);
			//auto repairs = UContentResolver::Instance->ResolveRepairRequirementsForItem(this->ItemInstance);

			if (repairs.Num() > 0) {
				TArray<FTakeRepairFromInventoryRequest> repair_requests;
				for (int i = 0; i < repairs.Num(); i++) {
					FTakeRepairFromInventoryRequest req(repairs[i]);
					repair_requests.Add(req);
				}

				return AMOTHCharacter::TryTakeFromInventory<FTakeRepairFromInventoryRequest, bool>(character, repair_requests, [character, item, smc, this](TArray<FTryFindItemByInventoryResult> results, TArray<FTakeRepairFromInventoryRequest> requests) {
					//item.Health = FMath::Min(item.Health + 10, item.HealthMax);

					auto alias = this->GetAliasByHealth(true); // allow exact match since we are going up
					if (alias) {
						auto mesh = UContentResolver::Instance->FindObjectByReference<UStaticMesh>(alias->Name);
						auto fn = mesh->GetFullName();
						GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, fn);
						if (IsValid(mesh) && !smc->GetStaticMesh()->GetFullName().Equals(fn)) {
							smc->SetCollisionProfileName(UCollisionProfile::BlockAllDynamic_ProfileName);
							smc->SetMobility(EComponentMobility::Movable);
							smc->SetStaticMesh(mesh);
							smc->SetMobility(EComponentMobility::Static);
							smc->SetGenerateOverlapEvents(true); // so snap points work

							this->ItemInstance.AliasName = alias->Name;
							this->AnimateSelf(false);
						}
					}

					/*parent_or_child->RepairInProcess = true;

					item->Health = FMath::Min(item->Health + 10, item->HealthMax);

					parent_or_child->UpdateMeshFromBreakpoints(false);

					parent_or_child->RepairInProcess = false;

					parent_or_child->Animate();*/

					this->OnRepaired(character, item);

					return true;
					}, false);
			}
			else {
				// cannot be repaired
			}
		}
		else {
			// setup/component not supported
		}
	}
	else {
		// cannot be repaired
	}
	return false;
}
//
//bool UItemComponent::TryRepair(AFPSCharacter* character, USceneComponent* component, UItemInstance* item)
//{
//	if (this->ItemInstance && component && component->IsA(UStaticMeshComponent::StaticClass())) {
//		auto smc = Cast<UStaticMeshComponent>(component);
//		if (smc) {
//			auto repairs = UContentResolver::Instance->ResolveRepairRequirementsForItem(this->ItemInstance);
//
//			if (repairs.Num() > 0) {
//				TArray<FTakeRepairFromInventoryRequest> repair_requests;
//				for (int i = 0; i < repairs.Num(); i++) {
//					FTakeRepairFromInventoryRequest req(repairs[i]);
//					repair_requests.Add(req);
//				}
//
//				return AFPSCharacter::TryTakeFromInventory<FTakeRepairFromInventoryRequest, bool>(character, repair_requests, [character, item, smc, this](TArray<UItemWidget*> results, TArray<FTakeRepairFromInventoryRequest> requests) {
//					item->Health = FMath::Min(item->Health + 10, item->HealthMax);
//
//					auto alias = this->GetAliasByHealth(true); // allow exact match since we are going up
//					if (alias) {
//						auto mesh = UContentResolver::Instance->FindObjectByReference<UStaticMesh>(alias->Name);
//						auto fn = mesh->GetFullName();
//						GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, fn);
//						if (IsValid(mesh) && !smc->GetStaticMesh()->GetFullName().Equals(fn)) {
//							smc->SetCollisionProfileName(UCollisionProfile::BlockAllDynamic_ProfileName);
//							smc->SetMobility(EComponentMobility::Movable);
//							smc->SetStaticMesh(mesh);
//							smc->SetMobility(EComponentMobility::Static);
//							smc->SetGenerateOverlapEvents(true); // so snap points work
//
//							this->ItemInstance->Alias = alias;
//							this->AnimateSelf(false);
//						}
//					}
//
//					/*parent_or_child->RepairInProcess = true;
//
//					item->Health = FMath::Min(item->Health + 10, item->HealthMax);
//
//					parent_or_child->UpdateMeshFromBreakpoints(false);
//
//					parent_or_child->RepairInProcess = false;
//
//					parent_or_child->Animate();*/
//
//					this->OnRepaired(character, item);
//
//					return true;
//					}, false);
//			}
//			else {
//				// cannot be repaired
//			}
//		}
//		else {
//			// setup/component not supported
//		}
//	}
//	else {
//		// cannot be repaired
//	}
//	return false;
//}

void UItemComponent::AnimateAtLocation(FTransform transform, UItemAliasInstance* alias, bool killed)
{
	// play sound
	if (alias->BreakpointSurfaceEffectID > 0) {
		auto gi = this->GetWorld()->GetGameInstance<UGlobalGameInstance>();
		if (gi) {
			auto effect_item = gi->SurfaceEffects.Find(alias->BreakpointSurfaceEffectID);
			if (effect_item) {
				auto effect = *effect_item;
				if (effect->Sounds.Num() > 0) {
					effect->PlaySoundAtLocation(transform.GetLocation() + this->GetComponentLocation());
					//UCommon::PlayWeightedSound(effect->Sounds, this->GetWorld(), transform.GetLocation() + this->GetComponentLocation());
				}
			}
			/*if (this->MeshChangeSounds.Num() > 0) {
				UCommon::PlayWeightedSound(this->MeshChangeSounds, this->GetWorld(), transform.GetLocation());
			}*/
		}
	}

	// spawn particle
	if (alias->Particle) {
		auto component = UGameplayStatics::SpawnEmitterAtLocation(this->GetWorld(), alias->Particle, transform.GetLocation(), alias->ParticleRotation + transform.Rotator(), alias->ParticleScale, false, EPSCPoolMethod::AutoRelease);

		component->SetWorldScale3D(FVector(1));

		component->Activate();
	}
}

bool UItemComponent::TryUpgrade(AMOTHCharacter * character, USceneComponent * component)
{
	if (this->ItemInstance.ItemID > 0) {
		auto smc = Cast<UStaticMeshComponent>(component);
		if (smc) {
			//auto upgrades = UContentResolver::Instance->ResolveUpgradesForItem(this->ItemInstance);
			auto instance = character->GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache;
			auto upgrades = instance->GetItemUpgrades(this->ItemInstance.ItemID);

			if (upgrades.Num() > 0) {
				TArray<FTakeUpgradeFromInventoryRequest> upgrade_requests;
				for (int i = 0; i < upgrades.Num(); i++) {
					FTakeUpgradeFromInventoryRequest req(upgrades[i]);
					upgrade_requests.Add(req);
				}

				return AMOTHCharacter::TryTakeFromInventory<FTakeUpgradeFromInventoryRequest, bool>(character, upgrade_requests, [this, smc, character](TArray<FTryFindItemByInventoryResult> results, TArray<FTakeUpgradeFromInventoryRequest> requests) {

					int upgrade_to_itemid = requests[0].UpgradeInstance->UpgradedItemID;
					//auto item = UContentResolver::Instance->ResolveItemByID(upgrade_to_itemid);
					auto instance = character->GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache;
					auto item = instance->GetItemByID(upgrade_to_itemid);

					//if (item && item->Alias) {
					//	auto mesh = UContentResolver::Instance->FindObjectByReference<UStaticMesh>(item->Alias->Name);
					//	if (IsValid(mesh) && smc->GetStaticMesh() != mesh) {
					//		smc->SetCollisionProfileName(UCollisionProfile::BlockAllDynamic_ProfileName);
					//		smc->SetMobility(EComponentMobility::Movable);
					//		smc->SetStaticMesh(mesh);
					//		smc->SetMobility(EComponentMobility::Static);
					//		smc->SetGenerateOverlapEvents(true); // so snap points work
					//		this->ItemInstance->Alias = item->Alias;
					//		this->AnimateSelf(false);
					//	}
					//	//auto parent = this->GetAttachParent();
					//	//this->DestroyMesh(character, true, false, true);

					//	//UBuildings::PlaceItem(character, item, this->GetComponentTransform(), parent, this->GetWorld());

					//	this->OnUpgraded(character, item);

					//	return true;
					//}

					return false;
					}, false);
			}
			else {
				// cannot be upgraded
			}
		}
		else {
			// no supported
		}
	}
	else {
		// cannot be upgraded
	}
	return false;
}

//bool UItemComponent::TryUpgrade(AFPSCharacter* character, USceneComponent* component)
//{
//	if (this->ItemInstance) {
//		auto smc = Cast<UStaticMeshComponent>(component);
//		if (smc) {
//			auto upgrades = UContentResolver::Instance->ResolveUpgradesForItem(this->ItemInstance);
//
//			if (upgrades.Num() > 0) {
//				TArray<FTakeUpgradeFromInventoryRequest> upgrade_requests;
//				for (int i = 0; i < upgrades.Num(); i++) {
//					FTakeUpgradeFromInventoryRequest req(upgrades[i]);
//					upgrade_requests.Add(req);
//				}
//
//				return AFPSCharacter::TryTakeFromInventory<FTakeUpgradeFromInventoryRequest, bool>(character, upgrade_requests, [this, smc, character](TArray<UItemWidget*> results, TArray<FTakeUpgradeFromInventoryRequest> requests) {
//
//					int upgrade_to_itemid = requests[0].UpgradeInstance->UpgradedItemID;
//					auto item = UContentResolver::Instance->ResolveItemByID(upgrade_to_itemid);
//
//					if (item && item->Alias) {
//						auto mesh = UContentResolver::Instance->FindObjectByReference<UStaticMesh>(item->Alias->Name);
//						if (IsValid(mesh) && smc->GetStaticMesh() != mesh) {
//							smc->SetCollisionProfileName(UCollisionProfile::BlockAllDynamic_ProfileName);
//							smc->SetMobility(EComponentMobility::Movable);
//							smc->SetStaticMesh(mesh);
//							smc->SetMobility(EComponentMobility::Static);
//							smc->SetGenerateOverlapEvents(true); // so snap points work
//							this->ItemInstance->Alias = item->Alias;
//							this->AnimateSelf(false);
//						}
//						//auto parent = this->GetAttachParent();
//						//this->DestroyMesh(character, true, false, true);
//
//						//UBuildings::PlaceItem(character, item, this->GetComponentTransform(), parent, this->GetWorld());
//
//						this->OnUpgraded(character, item);
//
//						return true;
//					}
//
//					return false;
//					}, false);
//			}
//			else {
//				// cannot be upgraded
//			}
//		}
//		else {
//			// no supported
//		}
//	}
//	else {
//		// cannot be upgraded
//	}
//	return false;
//}

void UItemComponent::GenerateItemsBasic(FString DatabaseContainerName, UItemContainer * container)
{
	// if these throw errors make sure the game instance is set. sometimes i see people changing these values!
	auto world = GetWorld();
	//if (!world) return;
	auto gameinstance = world->GetGameInstance<UGlobalGameInstance>();
	//if (!gameinstance || !gameinstance->ItemCache) return;

	// get items from cache using the db container name.
	auto itemcache = gameinstance->ItemCache;
	auto db_container = itemcache->GetItemContainer(DatabaseContainerName);

	if (IsValid(db_container) && db_container->Items.Num() > 0) {
		int numItemsToGenerate = FMath::RandRange(db_container->ItemsMin, db_container->ItemsMax); // pull from item container db table
		//auto amount_to_generate = FMath::Min(numItemsToGenerate, db_container->Items.Num()); // limit to the amount of items - not doing this, the DB should control this.
		for (int i = 0; i < numItemsToGenerate; i++) {

			auto rand_item_index = (int)FMath::RandRange(0, db_container->Items.Num() - 1);
			auto db_item = db_container->Items[rand_item_index];
			auto rand_item = itemcache->GetItemByID(db_item->ItemID);

			// find a new random slot in the container. if a slot is found to already have an item make sure to get a new index
			int container_index = -1;
			int tries = 0;
			while ((container_index == -1 || (container_index > -1 && container_index < container->Items.Num() && container->Items[container_index].ItemID > 0)) && tries++ < container->Items.Num()) {
				if (db_container->ItemContainerTypeID == (int)EItemContainerType::SequentialSlots) {
					container_index++;
				}
				else if (db_container->ItemContainerTypeID == (int)EItemContainerType::RandomisedSlots) {
					container_index = (int)FMath::RandRange(0, container->Items.Num() - 1);
				}
			}

			if (container_index < container->Items.Num()) {
				rand_item.Stack = (float)((int)FMath::RandRange(1.f, db_item->Stack));
				if (rand_item.Stack > 0) {
					container->Items[container_index] = rand_item;
				}
			}
		}
	}
}

//FItemData UItemComponent::GetItem(int ItemID)
//{
//	//auto def = GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache->GetLocalItemByID(this->ItemInstance.ItemID);
//	return GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache->GetItemByID(ItemID);
//}
//
//UItemInstance* UItemComponent::GetLocalItem(int ItemID)
//{
//	//auto def = GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache->GetLocalItemByID(this->ItemInstance.ItemID);
//	return GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache->GetLocalItemByID(ItemID);
//}

UItemCache* UItemComponent::GetItemCache()
{
	//auto def = GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache->GetLocalItemByID(this->ItemInstance.ItemID);
	return GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache;
}