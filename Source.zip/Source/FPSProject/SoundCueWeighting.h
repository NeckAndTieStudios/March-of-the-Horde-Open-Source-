// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Sound/SoundCue.h"
#include "Weighting.h"
#include "SoundCueWeighting.generated.h"

/**
*
*/
USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FSoundCueWeighting : public FWeighting
{
	GENERATED_USTRUCT_BODY()

public:
	//// defines how many chances the item has of being used
	//// 0 to disable
	//UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weighting")
	//	float Weight = 0.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weighting")
		USoundCue * SoundCue = NULL;

	FSoundCueWeighting()
	{
		Weighting = 0.f;
	}
	FSoundCueWeighting(float weight, USoundCue * soundCue)
	{
		Weighting = weight;
		SoundCue = soundCue;
	}
};