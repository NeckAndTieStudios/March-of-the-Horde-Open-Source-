// Fill out your copyright notice in the Description page of Project Settings.

#include "AutoInstancedStaticMeshComponent.h"
#include "Classes/Engine/StaticMesh.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h" 

#include "AutoInstancedStaticMeshActor.h"
#include "Common.h" 

UAutoInstancedStaticMeshComponent::UAutoInstancedStaticMeshComponent()
{

}

void UAutoInstancedStaticMeshComponent::BeginPlay()
{
	Super::BeginPlay();
	auto owner = this->GetOwner();
	if (owner) {
		//bool destroy = false;
		// find an existing actor for our static mesh
		auto components = owner->GetComponentsByClass(UStaticMeshComponent::StaticClass());
		for (int c = 0; c < components.Num(); c++) {
			auto component = Cast<UStaticMeshComponent>(components[c]);
			if (component) {
				UStaticMesh* mesh = component->GetStaticMesh();
				if (mesh) {
					auto world = this->GetWorld();
					if (world) {
						/*=============================== USE THIS TO SEND TO A CHUNK - the actor needs to be created in this level rather than on the world
							component->GetComponentLevel()
						*/

						//gameInstance->InstancedComponents
						//FString reference_path = UCommon::GetReferencePath(mesh);
						//FString container_reference = AAutoInstancedStaticMeshActor::GetComponentKey(component, mesh, EInstancedCategory::Buildings);

						auto actor = AAutoInstancedStaticMeshActor::GetInstance(world);

						//UHierarchicalInstancedStaticMeshComponent* instance_component;
						//auto entry = actor->InstancedComponents.Find(container_reference);
						//if (entry == nullptr) {
						//	instance_component = NewObject<UHierarchicalInstancedStaticMeshComponent>(actor, UHierarchicalInstancedStaticMeshComponent::StaticClass());
						//	instance_component->SetMobility(EComponentMobility::Movable);
						//	instance_component->SetStaticMesh(mesh);
						//	//instance_component->MarkRenderStateDirty();
						//	/*UMaterialInterface* mi = mesh->GetMaterial(0);  TURN ON "Use with Instanced Static Meshes" within original material
						//	instance_component->SetMaterial(0, mi);*/
						//	instance_component->SetMobility(component->Mobility);
						//	instance_component->SetCollisionProfileName(component->GetCollisionProfileName());
						//	instance_component->bMultiBodyOverlap = true;
						//	instance_component->RegisterComponent();


						//	FInstancedComponentsEntry new_entry(instance_component, EInstancedCategory::Buildings);
						//	actor->InstancedComponents.Add(container_reference, new_entry);
						//}
						//else {
						//	// add instance at this transform
						//	instance_component = entry->Component;
						//}


						auto entry = AAutoInstancedStaticMeshActor::GetInstanceComponent(component, mesh, this->Mobility, component->GetCollisionProfileName(), actor, EInstancedCategory::Buildings);

						//if (entry && entry->Component) {

						//existing->Add
						if (entry && entry->Component) {
							//instance_component->AddInstance(owner->GetActorTransform());
							entry->Component->AddInstance(component->GetComponentTransform());
						}
					}
				}
			}
		}

		owner->Destroy();
	}
}