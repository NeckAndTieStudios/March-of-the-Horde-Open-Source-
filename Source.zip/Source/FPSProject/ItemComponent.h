// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ItemInstance.h"
#include "InteractionTrigger.h"
#include "Components/SceneComponent.h"
#include "Components/ActorComponent.h"
#include "Components/InstancedStaticMeshComponent.h" 
#include "Components/HierarchicalInstancedStaticMeshComponent.h" 
//#include "WorldStaticMeshComponent.h" 
#include "WordStaticMeshDecal.h" 
#include "ItemAliasInstance.h" 
//#include "GlobalGameInstance.h" 
#include "UnrealNetwork.h"
#include "Engine/ActorChannel.h"
#include "Engine/StaticMeshActor.h"
#include "ItemComponent.generated.h"

class UWorldStaticMeshComponent;

USTRUCT(Blueprintable, BlueprintType)
struct FItemInstanceRemoveResult
{
	GENERATED_USTRUCT_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FTransform Transform;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UStaticMesh* Mesh;

	FItemInstanceRemoveResult() {}
	FItemInstanceRemoveResult(FTransform transform, UStaticMesh* mesh)
	{
		this->Transform = transform;
		this->Mesh = mesh;
	}
};

UENUM(BlueprintType)
enum class EItemContainerType : uint8
{
	SequentialSlots = 1 UMETA(DisplayName = "Sequential Slots"),
	RandomisedSlots = 2 UMETA(DisplayName = "Randomised Slots"),

	MAX = RandomisedSlots UMETA(Hidden)
};

UENUM(BlueprintType)
enum class EMasterInteractionMode : uint8
{
	NeverDisplay = 0 UMETA(DisplayName = "Never Display"),
	AlwaysDisplay = 1 UMETA(DisplayName = "Always Display"),
	OnlyWhenFocused = 2 UMETA(DisplayName = "Only When Focused"),
	DirectFocus = 3 UMETA(DisplayName = "Only when in direct focus of the character"),

	MAX = OnlyWhenFocused UMETA(Hidden)
};

UENUM(BlueprintType)
enum class EFocusRequirement : uint8
{
	Always = 0 UMETA(DisplayName = "Always"),
	DirectFocus = 1 UMETA(DisplayName = "DirectFocus"),
	Legacy = 2 UMETA(DisplayName = "Legacy - IsPrimaryUIComponent"),
	Never = 3 UMETA(DisplayName = "Never")
};

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable)
class FPSPROJECT_API UItemComponent : public USceneComponent
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	UItemComponent();

	bool is_destroyed = false;
	bool is_killed = false;

	// when the component should receive focus notifications
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		EFocusRequirement FocusRequirement = EFocusRequirement::Legacy;

	// when the component should be considered the active component in focus
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		EFocusRequirement ActiveFocusRequirement = EFocusRequirement::Legacy;

	// when the component should be included in building the UI text
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		EFocusRequirement UIDisplayRequirement = EFocusRequirement::Legacy;

	/// True when this component should take preference to the UI over additional UItemComponents in the same actor hierarchy, leaving the other components to process all but Look InteractionTriggers 
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsPrimaryUIComponent = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float InteractionWaitTimeStart;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float InteractionWaitTimeValue;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool InteractionTextAppendItemName = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsInteracting = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UObject* InteractionInstance = NULL;


	UPROPERTY(EditAnywhere, Category = Interactable, BlueprintReadWrite, Replicated)
		int LookAtInvalidate = 0;

	UPROPERTY(EditAnywhere, Category = Interactable, BlueprintReadWrite, Replicated)
		int LastLookAtInvalidate = 0;

	UFUNCTION(BlueprintCallable)
		void InvalidateLookItem()
	{
		LookAtInvalidate++;
	}

protected:
	//// Called when the game starts or when spawned
	//virtual void BeginPlay() override;

	UPROPERTY()
		FTimerHandle OnDespawnHandle;

	//UPROPERTY()
		//FTimerHandle InteractionWaitTimeHandle;

public:
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		EInteractionTrigger InteractionTrigger = EInteractionTrigger::Any;*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Replicated)
		FItemData ItemInstance;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		AActor* DeathActor;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UInstancedStaticMeshComponent* InstanceComponent;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UWorldStaticMeshComponent* WorldStaticMeshComponent;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int InstanceID;

	UFUNCTION(BlueprintImplementableEvent)
		void OnDamage(FHitResult hit_result, float damage, bool killed, AActor* initiator, EInteractionTrigger trigger);

	UFUNCTION(BlueprintCallable)
		void Despawn(FHitResult hit_result);

	UFUNCTION(BlueprintImplementableEvent)
		void OnDespawn(FHitResult hit_result);

	UFUNCTION(BlueprintCallable)
		FItemInstanceRemoveResult RemoveInstance(bool remove_children = false);

	UFUNCTION(BlueprintCallable)
		FTransform GetInstanceTransform();

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable)
		void OnKilled(FHitResult hit_result);

	/*UFUNCTION(BlueprintImplementableEvent)
	void OnDestroyed(FHitResult hit_result);*/

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FRotator CurrentRotation;*/


	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString InteractionText = TEXT("Test Item");

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString InteractionInput = TEXT("");

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString InteractionAction = TEXT("");

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString InteractionVariant = TEXT("");

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString InteractionSuffix = TEXT("");

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float InteractionWaitTime;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString InteractionTextPrefix = TEXT("");

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int InteractionTextOrder = 100;*/

		/// if set this instances value for InteractionText will be used across all other components in the actor
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI Text Building")
		EMasterInteractionMode MasterInteractionText = EMasterInteractionMode::NeverDisplay;

	/// if set this instances value for InteractionInput will be used across all other components in the actor
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI Text Building")
		EMasterInteractionMode MasterInteractionInput = EMasterInteractionMode::NeverDisplay;

	/// if set this instances value for InteractionAction will be used across all other components in the actor
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI Text Building")
		EMasterInteractionMode MasterInteractionAction = EMasterInteractionMode::NeverDisplay;

	/// if set this instances value for InteractionVariant will be used across all other components in the actor
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI Text Building")
		EMasterInteractionMode MasterInteractionVariant = EMasterInteractionMode::NeverDisplay;

	/// if set this instances value for InteractionSuffix will be used across all other components in the actor
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI Text Building")
		EMasterInteractionMode MasterInteractionSuffix = EMasterInteractionMode::NeverDisplay;

	/// if set this component, when building interaction text, will try to invlove any children item components that are set as masters.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI Text Building")
		bool IncludeChildrensComponents = true;

	FString builtInteractionText = TEXT("");

	UFUNCTION(BlueprintCallable)
		virtual void BuildInteractionTextWithArgs(AActor* actor, TArray<UItemComponent*> components, FString prefix, FString input, FString action, FString variant, FString name, FString suffix);

	UFUNCTION(BlueprintCallable) void BuildInteractionText(AActor* actor, TArray<UItemComponent*> components)
	{
		/*FString text = InteractionText;
		FString input = InteractionInput;
		FString action = InteractionAction;
		FString variant = InteractionVariant;
		FString suffix = InteractionSuffix;*/
		FString text = FString();
		FString input = FString();
		FString action = FString();
		FString variant = FString();
		FString suffix = FString();

		bool has_text = false;
		bool has_input = false;
		bool has_action = false;
		bool has_variant = false;
		bool has_suffix = false;

		// add the component this is in focus of the trace in front of all other components
		components.Insert(this, 0);

		for (auto component : components) {
			if (component->UIDisplayRequirement == EFocusRequirement::Never
				//|| (component->UIDisplayRequirement == EFocusRequirement:: && !component->HasActiveFocus) 
				|| (component->UIDisplayRequirement == EFocusRequirement::DirectFocus && !component->HasActiveFocus)
			) {
				continue;
			}

			if (has_text == false) {
				if (component->MasterInteractionText == EMasterInteractionMode::AlwaysDisplay
					|| (component->HasFocus && component->MasterInteractionText == EMasterInteractionMode::OnlyWhenFocused)
					|| (component->HasActiveFocus && component->MasterInteractionText == EMasterInteractionMode::DirectFocus)
				) {
					text = component->InteractionText;
					has_text = true;
				}
			}

			if (has_input == false) {
				if (component->MasterInteractionInput == EMasterInteractionMode::AlwaysDisplay 
					|| (component->HasFocus && component->MasterInteractionInput == EMasterInteractionMode::OnlyWhenFocused)
					|| (component->HasActiveFocus && component->MasterInteractionInput == EMasterInteractionMode::DirectFocus)
				) {
				//if (component->MasterInteractionInput) {
					input = component->InteractionInput;
					has_input = true;
				}
			}

			if (has_action == false) {
				if (component->MasterInteractionAction == EMasterInteractionMode::AlwaysDisplay 
					|| (component->HasFocus && component->MasterInteractionAction == EMasterInteractionMode::OnlyWhenFocused)
					|| (component->HasActiveFocus && component->MasterInteractionAction == EMasterInteractionMode::DirectFocus)
				) {
				//if (component->MasterInteractionAction) {
					action = component->InteractionAction;
					has_action = true;
				}
			}

			if (has_variant == false) {
				if (component->MasterInteractionVariant == EMasterInteractionMode::AlwaysDisplay 
					|| (component->HasFocus && component->MasterInteractionVariant == EMasterInteractionMode::OnlyWhenFocused)
					|| (component->HasActiveFocus && component->MasterInteractionVariant == EMasterInteractionMode::DirectFocus)
				) {
				//if (component->MasterInteractionVariant) {
					variant = component->InteractionVariant;
					has_variant = true;
				}
			}

			if (has_suffix == false) {
				if (component->MasterInteractionSuffix == EMasterInteractionMode::AlwaysDisplay 
					|| (component->HasFocus && component->MasterInteractionSuffix == EMasterInteractionMode::OnlyWhenFocused)
					|| (component->HasActiveFocus && component->MasterInteractionSuffix == EMasterInteractionMode::DirectFocus)
				) {
				//if (component->MasterInteractionSuffix) {
					suffix = component->InteractionSuffix;
					has_suffix = true;
				}
			}
		}

		BuildInteractionTextWithArgs(actor, components, InteractionTextPrefix, input, action, variant, text, suffix);
	}

	UFUNCTION(BlueprintCallable, BlueprintNativeEvent) TArray<USceneComponent*> GetSceneComponents(AActor* actor);
	TArray<USceneComponent*> GetSceneComponents_Implementation(AActor* actor)
	{
		TArray<USceneComponent*> components;
		//sma->GetStaticMeshComponent()->GetChildrenComponents(this->IncludeChildrensComponents, components);
		
		//actor->GetRootComponent()->GetChildrenComponents(this->IncludeChildrensComponents, components);

		if (this->IncludeChildrensComponents) {
			actor->GetRootComponent()->GetChildrenComponents(this->IncludeChildrensComponents, components);
		}
		else {
			//this->GetChildrenComponents(false, components);
			components.Add(this);
		}

		return components;
	}

	UFUNCTION(BlueprintCallable) FString BuildInteractionTextForActor(AActor* actor)
	{
		FString interactionText = FString();
		bool any = false;
		//auto sma = Cast<AStaticMeshActor>(actor);
		//auto sma = Cast<AStaticMeshActor>(actor);
		//if (sma) {
		if (actor) {
			//TArray<USceneComponent*> components;
			////sma->GetStaticMeshComponent()->GetChildrenComponents(this->IncludeChildrensComponents, components);
			//actor->GetRootComponent()->GetChildrenComponents(this->IncludeChildrensComponents, components);
			TArray<USceneComponent*> components = GetSceneComponents(actor);

			UItemComponent* primary_component = NULL;
			//UItemComponent* focused_component = NULL; // this allows the focus component to take preference over the first primary component found.
			//UItemComponent* focused_fallback = NULL; // this allows the focus component to take preference over the first primary component found.

			TArray<UItemComponent*> item_components;
			for (auto component : components)
			{
				auto ic = Cast<UItemComponent>(component);
				if (IsValid(ic) && ic->GetOwner() == actor) {
					item_components.Add(ic);

					bool applies = false;

					if (ic->UIDisplayRequirement == EFocusRequirement::Always) {
						applies = true;
					}
					else if (ic->UIDisplayRequirement == EFocusRequirement::Legacy && ic->IsPrimaryUIComponent) {
						applies = true;
					}
					else if (ic->UIDisplayRequirement == EFocusRequirement::DirectFocus && ic->HasActiveFocus) {
						applies = true;
					}

					if (applies) {
						primary_component = ic;

						/*if (ic->HasFocus) {
							focused_component = ic;
						}
						if (!focused_component && !focused_fallback && ic->ApplyToAllMeshesInActor) {
							focused_fallback = ic;
						}*/
					}
				}
			}

			/*if (!focused_component && focused_fallback) {
				focused_component = focused_fallback;
			}
			if (focused_component) {
				primary_component = focused_component;
			}*/

			if (IsValid(primary_component)) {
				//primary_component->BuildInteractionText(sma, item_components);
				primary_component->BuildInteractionText(actor, item_components);

				// replicate the generated build text to all components
				for (auto component : item_components)
				{
					if (component != primary_component)
						component->builtInteractionText = primary_component->builtInteractionText;
				}

				interactionText = primary_component->builtInteractionText;
			}
		}
		return interactionText;
	}

	UFUNCTION(BlueprintCallable) FString BuildInteractionTextForCurrentActor()
	{
		auto actor = this->GetOwner();
		return BuildInteractionTextForActor(actor);
	}

	UFUNCTION(BlueprintCallable) FString RebuildInteractionTextForCurrentActor()
	{
		builtInteractionText.Empty();
		return this->BuildInteractionTextForCurrentActor();
	}

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<FWordStaticMeshDecal> DecalInstances;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool InteractionIsSilent;


	UFUNCTION(BlueprintCallable)
		virtual void ApplyDamage(FHitResult hit_result, float damage, AActor * initiator, EInteractionTrigger trigger);


	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
		void OnInteraction(EInteractionTrigger trigger, FHitResult hit_result, AActor * initiator);

	// Called when the character looks away from an interactable item
	UFUNCTION(BlueprintCallable)
		virtual void OnInteractionCancel(AActor * initiator);

	// Called when the character looks away from an interactable item
	UFUNCTION(BlueprintImplementableEvent)
		void OnInteractionCancelled(AActor * initiator);

	UFUNCTION(BlueprintCallable)
		virtual void OnFocus(AActor * initiator);
	UFUNCTION(BlueprintCallable)
		virtual void OnFocusOut(AActor * initiator);

	UFUNCTION(BlueprintImplementableEvent)
		void OnAddedToOwner(AActor * parent);
	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
		void OnInstanceLoaded();

	UFUNCTION(BlueprintCallable)
		virtual FString GetInteractionText();

	UFUNCTION(BlueprintCallable)
		virtual void StartInterationTimer(bool silent);
	UFUNCTION(BlueprintCallable)
		virtual void StopInterationTimer();
	UFUNCTION(BlueprintCallable)
		virtual void UpdateInterationTimer();

	UFUNCTION(BlueprintCallable)
		void ClearDecals();

	UFUNCTION(BlueprintCallable)
		void Clip(const FString new_mesh);

	UFUNCTION(BlueprintCallable)
		bool TrySpawnDeathActor(UStaticMesh * mesh, FTransform transform, FHitResult hit_result);

	UFUNCTION(BlueprintCallable) UObject* NewSubObject(UObject * Outer, UClass * Class, USceneComponent * parent = NULL)
	{
		if (Outer && Class) {
			auto s = NewObject<UObject>(Outer, Class);

			if (s->IsA(USceneComponent::StaticClass()))
			{
				auto a = Cast<USceneComponent>(s);

				if (parent) {
					a->AttachToComponent(parent, FAttachmentTransformRules::KeepWorldTransform);
				}

				a->RegisterComponent();
			}

			return s;
		}
		return NULL;
	}

	UFUNCTION(BlueprintCallable) void DestroySubObject(USceneComponent * component)
	{
		component->DestroyComponent(); // UE BP's cannot call this so we need this wrapper like we do with NewSubObject
	}

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable)
		void OnInteractionComplete(UObject * instance);


	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool ApplyToAllMeshesInActor = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool HasFocus = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool HasActiveFocus = false;

	UFUNCTION(BlueprintCallable, BlueprintNativeEvent)
		void OnFocusReceived(AActor * initiator);

	UFUNCTION(BlueprintCallable, BlueprintNativeEvent)
		void OnFocusLost(AActor * initiator);

	UFUNCTION(BlueprintCallable)
		UItemAliasInstance* GetAliasByHealth(bool exactMatch = false);


	UFUNCTION(BlueprintImplementableEvent)
		void OnRepaired(AMOTHCharacter * character, FItemData item);

	UFUNCTION(BlueprintImplementableEvent)
		void OnUpgraded(AMOTHCharacter * character, FItemData item);

	UFUNCTION(BlueprintCallable)
		bool TryRepair(AMOTHCharacter * character, USceneComponent * component, FItemData item);


	/*UFUNCTION(BlueprintImplementableEvent)
		void OnRepaired(AFPSCharacter* character, UItemInstance* item);

	UFUNCTION(BlueprintImplementableEvent)
		void OnUpgraded(AFPSCharacter* character, UItemInstance* item);

	UFUNCTION(BlueprintCallable)
		bool TryRepair(AFPSCharacter* character, USceneComponent* component, UItemInstance* item);*/

	UFUNCTION(BlueprintCallable)
		bool TryUpdateMesh(USceneComponent * component);

	UFUNCTION(BlueprintCallable)
		bool TryUpgrade(AMOTHCharacter * character, USceneComponent * component);

	UFUNCTION(BlueprintCallable) void AnimateAtLocation(FTransform transform, UItemAliasInstance * alias, bool killed);

	UFUNCTION(BlueprintCallable) void AnimateSelf(bool killed)
	{
		if (this->ItemInstance.ItemID > 0) {
			/*auto def = GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache->GetLocalItemByID(this.ItemInstance.ItemID);
			this->AnimateAtLocation(this->GetComponentTransform(), def->Alias, killed);*/
		}
	}/*

	UFUNCTION(BlueprintCallable) FItemData GetItem(int ItemID);
	UFUNCTION(BlueprintCallable) UItemInstance* GetLocalItem(int ItemID);*/
	UFUNCTION(BlueprintCallable) UItemCache* GetItemCache();

	UFUNCTION(BlueprintCallable) void AddDecal(FWordStaticMeshDecal decal)
	{
		DecalInstances.Add(decal);
	}

	void GetLifetimeReplicatedProps(TArray< FLifetimeProperty > & OutLifetimeProps) const
	{
		Super::GetLifetimeReplicatedProps(OutLifetimeProps);

		DOREPLIFETIME(UItemComponent, ItemInstance);
	}

	virtual bool ReplicateSubobjects(UActorChannel * Channel, FOutBunch * Bunch, FReplicationFlags * RepFlags) override
	{
		bool wroteSomething = Super::ReplicateSubobjects(Channel, Bunch, RepFlags);

		return wroteSomething;
	}
	UFUNCTION(BlueprintImplementableEvent) void OnPostReplicate();

	virtual void PostRepNotifies() override
	{
		Super::PostRepNotifies();
		GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString(TEXT("UItemComponent.PostRepNotifies")));
		UE_LOG(LogTemp, Warning, TEXT("UItemComponent.PostRepNotifies"));
		this->OnPostReplicate();
	}

	UFUNCTION(BlueprintCallable) void GenerateItemsBasic(FString DatabaseContainerName, UItemContainer * container);
};
