// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "GameFramework/Actor.h"
#include "DatabaseModels.h"
#include "ItemInstance.h"
#include "IngredientForItemCacheEntry.h"
#include "ItemUpgrade.h"
#include "SQLiteDatabase.h"
#include "Database.generated.h"

USTRUCT(Blueprintable, BlueprintType)
struct FResolutionRequest
{
	GENERATED_USTRUCT_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		EInteractionTrigger trigger;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FHitResult hit_result;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		AActor* initiator;

	FResolutionRequest() {}
	FResolutionRequest(EInteractionTrigger trigger, FHitResult hit_result, AActor* initiator)
	{
		this->trigger = trigger;
		this->hit_result = hit_result;
		this->initiator = initiator;
	}
};

USTRUCT(Blueprintable, BlueprintType)
struct FInstanceMeshComponentEntry
{
	GENERATED_USTRUCT_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UInstancedStaticMeshComponent* Component;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int InstanceID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<USceneComponent*> Components;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString UniqueID;

	FInstanceMeshComponentEntry() {
		Component = NULL;
		InstanceID = -1;
	}
	FInstanceMeshComponentEntry(UInstancedStaticMeshComponent* component, int instanceID, FString uniqueID)
	{
		this->Component = component;
		this->InstanceID = instanceID;
		this->UniqueID = uniqueID;
	}
};

UINTERFACE(BlueprintType)
class FPSPROJECT_API UInstanceMeshReceiver : public UInterface
{
	GENERATED_UINTERFACE_BODY()

		/*UInstanceMeshReceiver(const class FObjectInitializer& ObjectInitializer)
		: Super(ObjectInitializer)
	{

	}*/
};
class FPSPROJECT_API IInstanceMeshReceiver
{
	GENERATED_IINTERFACE_BODY()

public:
	//classes using this interface must implement ReactToHighNoon
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Instance Mesh")
		bool OnRegistering(FInstanceMeshComponentEntry entry, FResolutionRequest request);

};

UCLASS()
class UItemContainerCache : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString Name;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemContainerID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemContainerTypeID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float ItemsMin;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float ItemsMax;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<UItemContainerCacheItem*> Items;
};

UCLASS()
class UItemContainerCacheItem : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemContainerItemID;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemContainerID;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemID;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float Stack;
};

//class UGlobalGameInstance;
//
UCLASS()
class FPSPROJECT_API AInstanceMeshReplicator : public AActor
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	AInstanceMeshReplicator()
	{
		this->bAlwaysRelevant = true;
		this->SetReplicates(true);
	}

protected:
	// Called when the game starts or when spawned
	//virtual void BeginPlay() override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Replicated, ReplicatedUsing = OnRep_InstanceMeshComponents)
		TArray<FInstanceMeshComponentEntry> InstanceMeshComponents;

	UFUNCTION() virtual void OnRep_InstanceMeshComponents()
	{
		//GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString(TEXT("InstanceMeshComponents replicated")));
		UE_LOG(LogTemp, Warning, TEXT("foliage OnRep_InstanceMeshComponents"));
		this->InvalidateLookItem();
	}

	void GetLifetimeReplicatedProps(TArray< FLifetimeProperty >& OutLifetimeProps) const
	{
		Super::GetLifetimeReplicatedProps(OutLifetimeProps);
		DOREPLIFETIME(AInstanceMeshReplicator, InstanceMeshComponents);
		DOREPLIFETIME(AInstanceMeshReplicator, LookAtInvalidate);
	}
public:

	UPROPERTY(EditAnywhere, Category = Interactable, BlueprintReadWrite, Replicated)
		int LookAtInvalidate = 0;

	UPROPERTY()
		int LastLookAtInvalidate = 0;

	UFUNCTION(BlueprintCallable)
		void InvalidateLookItem()
	{
		LookAtInvalidate++;
	}

	bool Find(FString name, FInstanceMeshComponentEntry &record)
	{
		for (auto entry : InstanceMeshComponents)
		{
			if (entry.UniqueID == name) {
				record = entry;
				return true;
			}
		}

		return false;
	}

	void Add(FInstanceMeshComponentEntry entry)
	{
		InstanceMeshComponents.Add(entry);
	}

	//UPROPERTY(EditAnywhere, BlueprintReadWrite, Replicated, ReplicatedUsing = OnRep_InstanceMeshComponents)
		//TMap<FString, FInstanceMeshComponentEntry> InstanceMeshComponents;


	/*void GetLifetimeReplicatedProps(TArray< FLifetimeProperty >& OutLifetimeProps) const
	{
		Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	}*/
};

UCLASS()
class UDatabaseLoader : public UObject
{
	GENERATED_BODY()

public:
	static const FString DatabaseName;
	static const FString DatabasePath;
	/*
		UPROPERTY()
			TMap<int, FIngredientForItemCacheEntry> IngredientsForItemCache;
		UPROPERTY()
			TMap<int, FInteractionForItemCacheEntry> InteractionsForItemCache;*/

	sqlite3* SqliteDatabase;

	static UDatabaseLoader* Instance;

	template< class T >
	static bool AppendAll(UObject* outer, FString table, TArray<T*>& collection)
	{
		if (!USQLiteDatabase::IsDatabaseRegistered(DatabaseLoader::DatabaseName))
		{
			if (!USQLiteDatabase::RegisterDatabase(DatabaseLoader::DatabaseName, DatabaseLoader::DatabasePath, true))
			{
				return false;
			}
		}

		FString query = TEXT("SELECT ");
		for (TFieldIterator<UProperty> Prop(T::StaticClass()); Prop; ++Prop) {
			if (query.Len() > 7) {
				query = query.Append(TEXT(", "));
			}

			query.Append(Prop->GetName());
		}
		query.Append(TEXT(" from "));
		query.Append(table);
		query.Append(TEXT(";"));

		auto results = USQLiteDatabase::RunQueryAndGetResults(DatabaseLoader::DatabaseName, query);
		if (results.Success) {
			for (int i = 0; i < results.Results.Num(); i++) {
				T* model = NewObject<T>(outer);
				auto row = results.Results[i];
				USQLiteDatabase::AssignResultsToObjectProperties(row, model);
				collection.Add(model);
			}

			return true;
		}

		return false;
	}

	//static UItemAliasQueryByAliasResult * FindItemByID(int itemId);
	static TArray<UItemAliasQueryResult*> FindItemsByID(int itemId);
	static UItemAliasQueryResult* FindItemByID(int itemId);

	//static TArray<UItemAliasQueryByAliasResult *> FindItemsByAlias(const FString& alias);
	static TArray<UItemAliasQueryResult*> FindItemsByAlias(const FString& alias);

	static TArray<FItemLootQueryResult> GetLootForItem(int ItemID, EInteractionTrigger trigger, int hitByItemID = 0, int hitByItemTypeID = 0);

	//static TArray<UItemRecipeQueryResult*> GetRecipes();
	static TArray<int> GetRecipes();


	//static TArray<UItemRecipeQueryResult*> GetRecipesForItem(int ItemID);
	// returns recipes that this item is inside of
	static TArray<int> GetRecipesForItem(int ItemID);

	//static TArray<int> GetRecipesForItem(int ItemID);

	//static TArray<UItemIngredientQueryResult*> GetIngredientsForItem(int ItemID);
	static TMap<int, float> GetIngredientsForItem(int ItemID);

	static TArray<UItemInteraction*> GetInteractionsForItem(int ItemID);

	//static UToolBeltConfigQueryResult* GetToolBeltConfig();

	//static TArray<UItemAliasQueryByIDResult *> FindAliasByItem(UItemInstance* item);
	static TArray<UItemAliasQueryResult*> FindAliasByItem(UItemInstance* item);

	static TArray<UItemAttributeQueryResult*> GetAttributesForItem(int ItemID);

	static TArray<USurfaceTypeModel*> GetSurfaceTypes();

	static TArray<USurfaceEffectModel*> GetSurfaceEffects();

	static TArray<USurfaceEffectSoundModel*> GetSurfaceEffectSounds(int surfaceEffectID);

	static TArray<USurfaceEffectDecalModel*> GetSurfaceEffectDecals(int surfaceEffectID);

	static TArray<USurfaceEffectParticleModel*> GetSurfaceEffectParticles(int surfaceEffectID);

	static TArray<UItemUpgradeInstance*> GetUpgradeRequirements(int itemID);

	static TArray<UItemRepairInstance*> GetRepairRequirements(int itemID);

	static TArray<UItemContainerCache*> GetItemContainers();
};