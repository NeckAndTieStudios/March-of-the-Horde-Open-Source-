// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ParticleDefinitions.h"
#include "DestructibleMesh.h"
#include "ItemAliasInstance.generated.h"


UENUM(BlueprintType, meta = (Bitflags))
enum class EParticleFlag : uint8
{
	CustomDespawnOnly = 1 UMETA(DisplayName = "Custom Particle - Despawn Only"),
	CustomHitOnly = 2 UMETA(DisplayName = "Custom Particle - Hit Only"),
	CustomPickupOnly = 4 UMETA(DisplayName = "Custom Particle - Pickup Only"),

	InteractionDespawnOnly = 8 UMETA(DisplayName = "Interaction Particle - Despawn Only"),
	InteractionHitOnly = 16 UMETA(DisplayName = "Interaction Particle - Hit Only"),
	InteractionPickupOnly = 32 UMETA(DisplayName = "Interaction Particle - Pickup Only"),

	MAX = InteractionPickupOnly UMETA(Hidden),
	DEFAULT = InteractionDespawnOnly | InteractionHitOnly UMETA(DisplayName = "DEFAULT (Interaction Despawn+Hit)")
};
ENUM_CLASS_FLAGS(EParticleFlag);

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable)
class FPSPROJECT_API UItemAliasInstance : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString Name;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString DefaultComponent; //keep in sync with UItemAliasQueryByIDResult,UItemAliasQueryByAliasResult

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString FoliageReplacement; //keep in sync with UItemAliasQueryByIDResult,UItemAliasQueryByAliasResult

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int FoliageIndex; //keep in sync with UItemAliasQueryByIDResult,UItemAliasQueryByAliasResult

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemPlaceableTypeID; //keep in sync with UItemAliasQueryByIDResult,UItemAliasQueryByAliasResult

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString ActorBlueprint; //keep in sync with UItemAliasQueryByIDResult,UItemAliasQueryByAliasResult

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect")
		UParticleSystem * Particle;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect")
		FRotator ParticleRotation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Surface Effect")
		FVector ParticleScale;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		EParticleFlag ParticleFlags = EParticleFlag::DEFAULT;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UDestructibleMesh* DestructibleMesh;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UObject* Instance;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Buildings")
		int HealthBreakpoint = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Buildings")
		int BreakpointSurfaceEffectID = 0;

	void Load();

	UFUNCTION(BlueprintCallable)
		UObject* GetInstance();
};