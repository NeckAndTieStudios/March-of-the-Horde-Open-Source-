#include "Foliage.h" 

UMOTHFoliageInstanceStaticMeshComponent::UMOTHFoliageInstanceStaticMeshComponent()
{

}