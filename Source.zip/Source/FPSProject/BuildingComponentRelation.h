// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BuildingComponentInstanceData.h"
#include "BuildingComponentRelation.generated.h"

UCLASS()
class FPSPROJECT_API UBuildingComponentRelation : public UObject
{
	GENERATED_BODY()


public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FBuildingComponentInstanceData Entry = FBuildingComponentInstanceData();

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UBuildingComponent* Component;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int32 InstanceID;*/

	void SetInstanceData(FBuildingComponentInstanceData data)
	{
		this->Entry = data;
		//data.ParentChildRecord = this;
	}
};