// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ContentResolver.h"
#include "CraftQueueItem.generated.h"

USTRUCT(BlueprintType)
struct FCraftQueueItem
{
	GENERATED_USTRUCT_BODY()
public:
	UPROPERTY(EditAnywhere, Category = Item, BlueprintReadWrite)
		int Stack;

	UPROPERTY(EditAnywhere, Category = Item, BlueprintReadWrite)
		bool WasLocked;

	FCraftQueueItem() {}

	FCraftQueueItem(int stack, bool wasLocked)
	{
		this->Stack = stack;
		this->WasLocked = wasLocked;
	}
};