// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ItemAttributeType.generated.h"

UENUM(BlueprintType)
enum class EItemAttributeType : uint8
{
	None = 0 UMETA(DisplayName = "None"),
	Attachment = 1 UMETA(DisplayName = "Attachment"),
	SnapToGround = 2 UMETA(DisplayName = "Snap To Ground"),
	SocketRequiredToPlace = 3 UMETA(DisplayName = "Socket Required to Place"),
	Punchable = 4 UMETA(DisplayName = "Can be punched"),
	Kickable = 5 UMETA(DisplayName = "Can be kicked"),
	PickupAllowed = 6 UMETA(DisplayName = "Can be picked up"),
	ShowUI = 7 UMETA(DisplayName = "UI can show stats to the player"),
	Clippable = 8 UMETA(DisplayName = "Can be clipped"),
	Harvestable = 9 UMETA(DisplayName = "Can be harvested"),
	Holdable = 10 UMETA(DisplayName = "Can be held in the players hand"),
	Lootable = 11 UMETA(DisplayName = "Can be looted by a player"),
	Placeable = 12 UMETA(DisplayName = "Can be placed in the world"),
	Consumable = 13 UMETA(DisplayName = "Can be consumed"),

	MAX = Placeable UMETA(Hidden),
	DEFAULT = None UMETA(DisplayName = "DEFAULT (None)")
};