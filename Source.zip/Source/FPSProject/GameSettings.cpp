// Fill out your copyright notice in the Description page of Project Settings.

#include "GameSettings.h"

UGameSettings* UGameSettings::Instance = NULL;// = new UGameSettings();
//
//UGameSettings::UGameSettings()
//{
//}
//
//UGameSettings::~UGameSettings()
//{
//}
//
