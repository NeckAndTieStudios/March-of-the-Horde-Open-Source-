// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Common.h"
#include "HitLoot.h"
#include "HitInstance.generated.h"

//UENUM(BlueprintType)
//enum class EDestroyAction : uint8
//{
//	FadeOut = 0 UMETA(DisplayName = "Fade Out"),
//
//	MAX = FadeOut UMETA(Hidden),
//	DEFAULT = FadeOut UMETA(DisplayName = "DEFAULT (FadeOut)")
//};


//UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable)
//class FPSPROJECT_API UDestroyActionComponent : public UActorComponent
//{
//	GENERATED_BODY()
//
//public:
//	// Sets default values for this actor's properties
//	UDestroyActionComponent();
//
//protected:
//	// Called when the game starts or when spawned
//	virtual void BeginPlay() override;
//
//public:
//	// Called every frame
//	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
//
//
//};

UENUM(BlueprintType)
enum class EHitTrigger : uint8
{
	Any = 10 UMETA(DisplayName = "Any"), // fix numbers
	None = 11 UMETA(DisplayName = "None"), // fix numbers

	Harvest = 0 UMETA(DisplayName = "Harvest"),
	Hit = 1 UMETA(DisplayName = "Hit"),
	//Pickup = 2 UMETA(DisplayName = "Pickup"),
	Place = 2 UMETA(DisplayName = "Place"),

	MAX = Place UMETA(Hidden),
	DEFAULT = None UMETA(DisplayName = "DEFAULT (None)")
};

UENUM(BlueprintType)
enum class ELootType : uint8
{
	// the player receives the loot upon interaction
	Interaction = 0 UMETA(DisplayName = "Interaction"),

	// the player receives the loot as a ground item
	Dropped = 1 UMETA(DisplayName = "Dropped"),

	MAX = Dropped UMETA(Hidden),
	DEFAULT = Interaction UMETA(DisplayName = "DEFAULT (Interaction)")
};

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FHitInstanceActor
{
	GENERATED_USTRUCT_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString Name = "Unknown";

	// if set it will spawn this class in place of the instance foliage/mesh actor. if left unset the system will reuse the static mesh with default settings
	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (TitleProperty = "Name"))
		TSubclassOf<class AStaticMeshActor> ReplacementClass;

	// Distance in cm
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Interactable")
		float InteractionRange = 200.f;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EDestroyAction DestroyAction = EDestroyAction::DEFAULT;*/
};

/**
*
*/
USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FHitInstance
{
	GENERATED_USTRUCT_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float Health = 100.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsDestroyed = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString Name = "Unknown";

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<FHitInstanceActor> ApplicableActors;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		EHitTrigger HitTrigger = EHitTrigger::DEFAULT;


	UPROPERTY(BlueprintReadWrite, EditAnywhere, meta = (TitleProperty = "Name"))
		TArray<FHitLoot> HitLoot;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsActive = false;
};