// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"
#include "CoreMinimal.h"
#include "FPSCharacter.h"
#include "ItemInstance.h"
#include "ItemContainer.h"
#include "Components/SceneComponent.h"
#include "ItemWidget.h"
#include "Buildings.generated.h"

UCLASS(meta = (ShowWorldContextPin))
class FPSPROJECT_API UBuildings : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:

	UFUNCTION(BlueprintCallable, Category = "World")
		static void DeductFromContainer(UItemContainer* container, UPARAM(ref) FItemData& widget, float amount);

	UFUNCTION(BlueprintCallable, Category = "World")
		static USceneComponent* PlaceItem(AMOTHCharacter* character, UItemInstance* item, FTransform location, USceneComponent* attachTo, UWorld* world = NULL);

	UFUNCTION(BlueprintCallable, Category = "World")
		static USceneComponent* PlaceFoliage(UWorld* world, UStaticMesh* mesh, FTransform transform);
};