// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
//#include "GlobalGameInstance.h"
#include "HitInstance.h"
#include "HitComponent.generated.h"

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FHitInteraction
{
	GENERATED_USTRUCT_BODY()

public:
	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FHitInstance HitInstance;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FHitInstanceActor HitInstanceActor;*/
};

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable)
class FPSPROJECT_API UHitComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	//// Sets default values for this actor's properties
	//UHitComponent();

	//bool is_destroyed = false;

protected:
	//// Called when the game starts or when spawned
	//virtual void BeginPlay() override;

	//UPROPERTY()
	//	FTimerHandle OnDespawnHandle;

public:
	//// Called every frame
	//virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	//UPROPERTY(EditAnywhere, BlueprintReadWrite)
	//	EHitTrigger HitTrigger = EHitTrigger::Any;

	//UPROPERTY(EditAnywhere, BlueprintReadWrite)
	//	float Health = 100.f;

	///*UPROPERTY(EditAnywhere, BlueprintReadOnly)
	//	UGlobalGameInstance * GameInstance;*/

	//UPROPERTY(EditAnywhere, BlueprintReadWrite)
	//	FHitInstance HitInstance;

	//UPROPERTY(EditAnywhere, BlueprintReadWrite)
	//	FHitInstanceActor HitInstanceActor;

	//UFUNCTION(BlueprintImplementableEvent)
	//	void OnHit(FHitResult hit_result, float damage, bool killed, AActor * initiator);

	//UFUNCTION(BlueprintCallable)
	//	void Despawn();

	//UFUNCTION(BlueprintImplementableEvent)
	//	void OnDespawn();

	//UFUNCTION(BlueprintImplementableEvent)
	//	void OnKilled();

	//UPROPERTY(EditAnywhere, BlueprintReadWrite)
	//	FRotator CurrentRotation;

	//UFUNCTION(BlueprintCallable)
	//	void ApplyDamage(FHitResult hit_result, float damage, AActor * initiator);

	//UFUNCTION(BlueprintImplementableEvent)
	//	void OnInteraction(EHitTrigger trigger, FHitResult hit_result, float damage, AActor * initiator, FHitInteraction interaction);
	//UFUNCTION(BlueprintImplementableEvent)
	//	void OnInteractionCancel(AActor * initiator);
	//UFUNCTION(BlueprintImplementableEvent)
	//	void OnFocus(AActor * initiator);
	//UFUNCTION(BlueprintImplementableEvent)
	//	void OnFocusOut(AActor * initiator);

	//static UHitComponent * GetInteraction(UGlobalGameInstance * gameInstance, FHitResult hit_result, EHitTrigger hitTrigger, AActor * initiator, FHitInteraction * interaction, UHitComponent * existingHitComponent);
	//static void ApplyInteraction(UGlobalGameInstance * gameInstance, FHitResult hit_result, float damage, EHitTrigger hitTrigger, AActor * initiator, UHitComponent * existingHitComponent);
};