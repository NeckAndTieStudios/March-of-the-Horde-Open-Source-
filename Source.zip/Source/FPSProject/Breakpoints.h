// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
//#include "Engine/StaticMesh.h"
#include "Classes/Engine/StaticMesh.h"
#include "Classes/Kismet/GameplayStatics.h"
#include "Engine.h" 
#include "Breakpoints.generated.h"

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FMeshBreakpoint
{
	GENERATED_BODY()

public:
	// The World Static Mesh Component will pick the mesh when it's health is this or above
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Breakpoint")
		float ForHealthAndAbove = 0.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Breakpoint")
		UStaticMesh* Mesh;
};

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FGoreBreakpoint
{
	GENERATED_BODY()

public:
	// The material to adjust
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Breakpoint")
		FString ParameterName;

	// When the material should begin transitioning in. The material is considered 0% opacity at this value.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Breakpoint")
		float Start = 0.f;

	// When the material should be at 100% opacity
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Breakpoint")
		float Max = 100;

	// Allows the opacity to exceet 100% (1.0f)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Breakpoint")
		bool AllowPastMax = false;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Breakpoint")
		UMaterialInstance* Material;*/
};