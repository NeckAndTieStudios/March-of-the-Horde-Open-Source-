// Fill out your copyright notice in the Description page of Project Settings.

#include "WorldStaticMeshComponent.h"
#include "Classes/Engine/StaticMesh.h"
#include "Classes/Kismet/GameplayStatics.h"

#include "AutoInstancedStaticMeshActor.h"
#include "Common.h" 
#include "ItemComponent.h" 
#include "Buildings.h" 
#include "GlobalGameInstance.h" 
#include "ItemCache.h" 
#include "Engine.h" 

//#include "DetailLayoutBuilder.h" 

//UBuildingComponent::UBuildingComponent()
//{
//	//this->bMultiBodyOverlap = true;
//}
//UBuildingComponent::UBuildingComponent()
//{
//}
////void UBuildingComponent::ApplyComponentInstanceData(class FInstancedStaticMeshComponentInstanceData* ComponentInstanceData)
////{
////	Super::ApplyComponentInstanceData(ComponentInstanceData);
////}
////void UBuildingComponent::ApplyComponentCustomInstanceData(class FCustomInstancedStaticMeshComponentInstanceData* ComponentInstanceData)
////{
////	//Super::ApplyComponentInstanceData(ComponentInstanceData);
////
////	UInstancedStaticMeshComponent::ApplyComponentInstanceData(ComponentInstanceData);
////
////	BuildTreeIfOutdated(false, false);
////}
//
////class FInstancedStaticMeshComponentInstanceData;
//
//FActorComponentInstanceData* UBuildingComponent::GetComponentInstanceData() const
//{
//	auto data = Super::GetComponentInstanceData();
//	//auto res = reinterpret_cast<FCustomInstancedStaticMeshComponentInstanceData*>(data);
//	////const auto res = Cast<FInstancedStaticMeshComponentInstanceData>(data);
//
//	//for (int i = 0; i < res->PerInstanceSMData.Num(); i++) {
//	//	//if(res->PerInstanceSMData->St)
//	//}
//
//	return data;
//}
//
//void UBuildingComponent::OnRegister()
//{
//	Super::OnRegister();
//	//////this->PerInstanceSMData.Empty();
//	////this->ClearInstances();
//	//for (int i = 0; i < CustomPerInstanceSMData.Num(); i++) {
//	//	//this->PerInstanceSMData
//	//	auto data = FInstancedStaticMeshInstanceData();
//	//	data.Transform = CustomPerInstanceSMData[i].Transform;
//	//	PerInstanceSMData.Add(data);
//	//	//this->AddInstance(FTransform(CustomPerInstanceSMData[i].Transform));
//	//}
//
//	// //sync per instance sm data to custom array
//	//for (int i = 0; i < PerInstanceSMData.Num(); i++) {
//	//	//this->PerInstanceSMData
//	//	auto data = FCustomInstancedStaticMeshInstanceData();
//	//	//data.Transform = CustomPerInstanceSMData[i].Transform;
//	//	//PerInstanceSMData.Add(data);
//	//	//CustomPerInstanceSMData.Add(FTransform(CustomPerInstanceSMData[i].Transform));
//	//	CustomPerInstanceSMData.Add(data);
//	//}
//
//	 //sync per instance sm data to custom array
//	//for (int i = 0; i < PerInstanceSMData.Num(); i++) {
//
//	//	FInstancedStaticMeshInstanceData data = FInheritedInstancedStaticMeshInstanceData();
//	//	data.Transform = PerInstanceSMData[i].Transform;
//
//	//	auto tf = FTransform(PerInstanceSMData[i].Transform);
//	//	//SetupNewInstanceData(data, i, tf);
//	//}
//
//	//// Force recreation of the render data
//	//InstanceUpdateCmdBuffer.Edit();
//	//MarkRenderStateDirty();
//}
//int32 UBuildingComponent::AddInstance(const FTransform& InstanceTransform)
//{
//	auto index = Super::AddInstance(InstanceTransform);
//
//	// sync to custom array
//	//CustomPerInstanceSMData.Add(FCustomInstancedStaticMeshInstanceData());
//
//	return index;
//}

UWorldStaticMeshComponent::UWorldStaticMeshComponent()
{
	this->bMultiBodyOverlap = true;

	this->ShowSelf();
}

void UWorldStaticMeshComponent::BeginPlay()
{
	Super::BeginPlay();
	//
	//#if WITH_EDITOR
	//	if (this->InstanceBodies.Num() == 0)
	//	{
	//		FTransform transform = FTransform();
	//		this->AddInstance(transform);
	//	}
	//#endif

	this->MeshTransform = this->GetComponentTransform();
	this->TiltCurrent = FRotator(0, 0, 0);

	// move to a chunk actor or the world actor
	//if (this->Gore == 0.f) {
	if (this->Health > 0.f) {
		this->MigrateToWorld();
	}
	else {
		//this->SetVisibility(false, true);
		this->ClearInstances();
	}
	//}

	//this->SetComponentTickEnabled(true);

	if (this->ItemComponent && this->ItemComponent->ItemInstance.ItemID == 0 && this->ItemID > 0) {
		//this->ItemComponent->ItemInstance->ItemID = this->ItemID;

		//auto item = UContentResolver::Instance->ResolveItemByID(this->ItemID);
		auto instance = this->GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache;
		auto item = instance->GetItemByID(this->ItemID);
		if (item.ItemID > 0) {
			this->ItemComponent->ItemInstance = item;// ->Clone(this);
		}
	}

	if (this->PreventParentTick) {
		auto owner = this->GetOwner();
		if (owner && owner->IsActorTickEnabled()) {
			owner->SetActorTickEnabled(false);
		}
	}
}

void UWorldStaticMeshComponent::SetMeshBreakpoints(TArray<FWordStaticMeshBreakpoint> breakpoints)
{
	this->MeshBreakpoints = breakpoints;
	this->MeshBreakpoints.Sort([](const FWordStaticMeshBreakpoint& LHS, const FWordStaticMeshBreakpoint& RHS) { return LHS.ForHealthAndAbove > RHS.ForHealthAndAbove; });
}

void UWorldStaticMeshComponent::StopTilt()
{
	if (GetWorld()->GetTimerManager().IsTimerActive(TiltTimerHandle)) {
		GetWorld()->GetTimerManager().ClearTimer(TiltTimerHandle);
	}
}

void UWorldStaticMeshComponent::Tilt()
{
	auto time_now = GetWorld()->GetTimeSeconds();
	auto percentage = (this->TiltStart + 2.0) / time_now;

	float range = 1.f;/*
	auto yaw = FMath::RandRange(-range, range);
	auto pitch = FMath::RandRange(-range, range);
	auto roll = FMath::RandRange(-range, range);
*/

//auto rotation = FMath::FInterpTo(this->TiltCurrent, this->TiltTarget, GetWorld()->GetDeltaSeconds(), 0.1);

	auto s = GetWorld()->GetDeltaSeconds();
	auto Yaw = FMath::FInterpTo(this->TiltCurrent.Yaw, this->TiltTarget.Yaw, s, 10.f);
	auto Pitch = FMath::FInterpTo(this->TiltCurrent.Pitch, this->TiltTarget.Pitch, s, 10.f);
	auto Roll = FMath::FInterpTo(this->TiltCurrent.Roll, this->TiltTarget.Roll, s, 10.f);

	if (FMath::IsNearlyEqual(Yaw, this->TiltTarget.Yaw)
		&& FMath::IsNearlyEqual(Pitch, this->TiltTarget.Pitch)
		&& FMath::IsNearlyEqual(Roll, this->TiltTarget.Roll)) {
		GetWorld()->GetTimerManager().ClearTimer(TiltTimerHandle);
		return;
	}

	auto rotation = FRotator(Pitch, Yaw, Roll);
	FTransform tf = FTransform(this->MeshTransform.Rotator() + this->CurrentRotator + rotation, this->MeshTransform.GetLocation(), this->MeshTransform.GetScale3D());

	if (this->InstanceComponent) {
		this->InstanceComponent->UpdateInstanceTransform(this->InstanceID, tf, true);
	}
	else {
		this->UpdateInstanceTransform(this->InstanceID, tf, true);
	}

	this->TiltCurrent = rotation;
}

UInstancedStaticMeshComponent* UWorldStaticMeshComponent::GetCurrentComponent()
{
	if (this->InstanceComponent) {
		return this->InstanceComponent;
	}
	return this;
}

bool UWorldStaticMeshComponent::RemoveWSMCInstance(AAutoInstancedStaticMeshActor* actor, FTransform& OutTransform, UObject*& OutData)
{
	/*auto oldmesh = this->InstanceComponent->GetStaticMesh();
	FString oldreference_path = UCommon::GetReferencePath(oldmesh);
	FString oldinstance_key = oldreference_path;*/
	FString container_reference = AAutoInstancedStaticMeshActor::GetComponentKey(this->InstanceComponent, this->InstanceComponent->GetStaticMesh(), EInstancedCategory::Buildings);

	// store the transormation as this is where the new instance needs to be incase it has been moved
	FTransform transform;
	if (this->InstanceComponent->GetInstanceTransform(this->InstanceID, transform))
	{
		OutTransform = transform;
		this->InstanceComponent->RemoveInstance(this->InstanceID);

		// as soon as RemoveInstance is called UE will shrink its instances array, thus we need to also decrement this single operation
		auto entry = actor->InstancedComponents.Find(container_reference);
		if (entry) {
			// send out the current data
			OutData = entry->ComponentData[this->InstanceID];

			// KEEP IN SYNC WITH UE's INSTANCE BODIES
			int max_instances = entry->ComponentData.Num();
			int LastInstanceIndex = max_instances - 1;
			if (this->InstanceID == LastInstanceIndex)
			{
				entry->ComponentData.RemoveAt(this->InstanceID);
			}
			else
			{
				entry->ComponentData.RemoveAtSwap(this->InstanceID);
			}

			// update the indicies since it should now have shrunk
			max_instances = entry->ComponentData.Num();
			for (int i = 0; i < max_instances; i++)
			{
				auto wsmc = Cast<UWorldStaticMeshComponent>(entry->ComponentData[i]);
				if (wsmc) {
					wsmc->InstanceID = i;
					if (wsmc->ItemComponent) {
						wsmc->ItemComponent->InstanceID = i;
					}
				}
			}
		}

		this->ItemComponent->InstanceComponent = NULL;
		this->ItemComponent->InstanceID = 0;
		this->InstanceComponent = NULL;
		this->InstanceID = 0;
		return true;
	}

	return false;
}

void UWorldStaticMeshComponent::MigrateToSelf()
{
	this->ExchangeInProcess = true;
	if (this->InstanceComponent)
	{
		auto world = this->GetWorld();
		if (world) {
			auto mesh = this->InstanceComponent->GetStaticMesh();
			auto actor = AAutoInstancedStaticMeshActor::GetInstance(world);
			//FTransform transforma;
			//this->InstanceComponent->GetInstanceTransform(this->InstanceID, transforma);

			FTransform transform; UObject* data;
			this->RemoveWSMCInstance(actor, transform, data);
			//if (this->RemoveWSMCInstance(actor, transform, data))
			{
				//this->Rename(NULL, actor);

				//this->RegisterComponent();

				this->SetStaticMesh(mesh);

				//FTransform tf = FTransform();
				//this->InstanceID = this->AddInstance(tf);
				this->InstanceID = 0;
				this->ShowSelf();

				//FTransform tf = FTransform(this->MeshTransform.Rotator() + this->CurrentRotator + this->TiltCurrent);
				FTransform tf = FTransform(this->CurrentRotator + this->TiltCurrent);
				this->UpdateInstanceTransform(this->InstanceID, tf, false);

				if (this->ItemComponent) {
					this->ItemComponent->InstanceComponent = this;
					this->ItemComponent->InstanceID = this->InstanceID;
					this->ItemComponent->WorldStaticMeshComponent = this;
				}

				//auto instance_id = this->AddInstanceWorldSpace(this->MeshTransform);
				//auto m = this->GetStaticMesh();

				//this->MeshTransform = FTransform(FRotator(0, 0, 0));
				//FTransform tf = FTransform(this->MeshTransform.Rotator() + this->TiltCurrent, this->MeshTransform.GetLocation(), this->MeshTransform.GetScale3D());
				//auto instance_id = this->AddInstance(tf);
				//this->TiltCurrent = FRotator(0, 0, 0);
				//this->MarkRenderStateDirty();

				//this->OnMeshChanging(this->GetOwner(), this, instance_id);

				//this->InstanceID = instance_id;
				//this->InstanceComponent = NULL;
				//this->InstanceActor = NULL;

				/*if (this->ItemComponent) {
					this->ItemComponent->InstanceID = instance_id;
				}*/

				//this->MeshTransform = transform;
				//this->OnMeshChanged(this->IsCreating);
				////this->UpdateGore();
			}
			/*else {
				GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Failed to remove instance MigrateToSelf!"));
			}*/
		}
	}
	this->ExchangeInProcess = false;
}

void UWorldStaticMeshComponent::MigrateToWorldMesh(UObject* mesh_component, UStaticMesh* mesh, bool silent)
{
	this->ExchangeInProcess = true;

	auto world = this->GetWorld();
	if (world) {
		auto actor = AAutoInstancedStaticMeshActor::GetInstance(world);

		if (actor) {
			//FTransform target_transform = this->GetComponentTransform();
			//FTransform target_transform = this->MeshTransform;
			if (this->InstanceComponent /*&& this->InstanceID*/)
			{
				FTransform transform; UObject* data;
				if (this->RemoveWSMCInstance(actor, transform, data))
				{
					//target_transform = transform;
				}
				else {
					//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Failed to remove instance MigrateToWorldMesh!"));
				}
			}

			//gameInstance->InstancedComponents

			auto entry = AAutoInstancedStaticMeshActor::GetInstanceComponent(this, mesh, this->Mobility, this->GetCollisionProfileName(), actor, EInstancedCategory::Buildings);

			//UHierarchicalInstancedStaticMeshComponent* instance_component;
			//auto entry = actor->InstancedComponents.Find(reference_path);
			//if (entry == nullptr) {
			//	/*=============================== USE THIS TO SEND TO A CHUNK - the actor needs to be created in this level rather than on the world
			//	component->GetComponentLevel()
			//	*/
			//	instance_component = NewObject<UHierarchicalInstancedStaticMeshComponent>(actor, UHierarchicalInstancedStaticMeshComponent::StaticClass());
			//	instance_component->SetMobility(EComponentMobility::Movable);
			//	instance_component->SetStaticMesh(mesh);
			//	//instance_component->MarkRenderStateDirty();
			//	/*UMaterialInterface* mi = mesh->GetMaterial(0);  TURN ON "Use with Instanced Static Meshes" within original material
			//	instance_component->SetMaterial(0, mi);*/
			//	instance_component->SetMobility(this->Mobility);
			//	instance_component->SetCollisionProfileName(this->GetCollisionProfileName());
			//	instance_component->RegisterComponent();

			//	FInstancedComponentsEntry new_entry(instance_component);
			//	actor->InstancedComponents.Add(reference_path, new_entry);
			//	//entry = &new_entry;
			//	entry = actor->InstancedComponents.Find(reference_path);
			//}
			//else {
			//	// add instance at this transform
			//	instance_component = entry->Component;
			//}

			if (entry && entry->Component) {
				FTransform tf = FTransform(this->MeshTransform.Rotator() + this->TiltCurrent, this->MeshTransform.GetLocation(), this->MeshTransform.GetScale3D());
				auto instance_id = entry->Component->AddInstance(tf);

				this->OnMeshChanging(actor, entry->Component, instance_id);

				this->InstanceID = instance_id;
				this->InstanceComponent = entry->Component;
				this->InstanceActor = actor;

				int required_slots = (this->InstanceID - entry->ComponentData.Num()) + 1;
				if (required_slots > 0) {
					while (required_slots-- > 0) {
						entry->ComponentData.Add(NULL);
					}
				}
				entry->ComponentData[this->InstanceID] = this;

				if (this->ItemComponent) {
					this->ItemComponent->InstanceComponent = this->InstanceComponent;
					this->ItemComponent->InstanceID = instance_id;
					this->ItemComponent->WorldStaticMeshComponent = this;
				}

				//this->InstanceComponent->GetInstanceTransform(this->InstanceID, this->MeshTransform);
				//this->MeshTransform = target_transform;
				this->OnMeshChanged(this->IsCreating, silent);
				this->UpdateGore();
			}
			else {
				//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("No component!"));
			}
		}
		else {
			UE_LOG(LogTemp, Error, TEXT("WSMC: No parent actor has been placed in the world!"));
		}
	}

	this->ExchangeInProcess = false;
}

void UWorldStaticMeshComponent::ShowSelf()
{
	/*FTransform transform;
	if (this->GetInstanceTransform(0, transform)) {
		transform.SetScale3D(FVector(1, 1, 1));
		this->UpdateInstanceTransform(0, transform, false);
		this->MarkRenderStateDirty();
	}*/
	if (this->GetNumRenderInstances() == 0) {
		FTransform tf = FTransform();
		tf.SetScale3D(FVector::OneVector);
		this->AddInstance(tf);
	}
}

void UWorldStaticMeshComponent::HideSelf()
{
	/*FTransform transform;
	if (this->GetInstanceTransform(0, transform)) {
		transform.SetScale3D(FVector(0, 0, 0));
		this->UpdateInstanceTransform(0, transform, false);
		this->MarkRenderStateDirty();
	}*/
	this->ClearInstances();
}

void UWorldStaticMeshComponent::PostDuplicate(bool bDuplicateForPIE)
{
	Super::PostDuplicate(bDuplicateForPIE);
	//if (this->GetNumRenderInstances() > 0) {
		//this->MigrateToWorld();
	//}
}

void UWorldStaticMeshComponent::MigrateToWorld()
{
	this->HideSelf();
	//this->ShowSelf();
	//this->ClearInstances();
	//this->RemoveInstance(0);

	auto mesh = this->GetStaticMesh();
	//if (mesh) {
	if (!mesh) {
		UE_LOG(LogTemp, Error, TEXT("WSMC: Mesh must be set in order to call MigrateToWorld!"));
	}
	else {
		this->MigrateToWorldMesh(this, mesh, true);
		//}

		this->IsCreating = false;
	}
}

void UWorldStaticMeshComponent::OnRegister()
{
	Super::OnRegister();

	//this->MeshBreakpoints.Sort([](const FWordStaticMeshBreakpoint& LHS, const FWordStaticMeshBreakpoint& RHS) { return LHS.ForHealthAndAbove > RHS.ForHealthAndAbove; });

	SetMeshBreakpoints(this->MeshBreakpoints); // initial sort
	this->UpdateMeshFromBreakpoints(true);

	/*this->MigrateToWorld(); cannot do this yet*/

	this->GoreBreakpoints.Sort([](const FGoreBreakpoint& LHS, const FGoreBreakpoint& RHS) { return LHS.Start > RHS.Start; });
	this->UpdateGore();

	/*if (this->GetNumRenderInstances() > 0) {
		this->MigrateToWorld();
	}*/
}

void UWorldStaticMeshComponent::OnUnregister()
{
	Super::OnUnregister();
}

void UWorldStaticMeshComponent::UpdateGoreMaterial(UMeshComponent* mesh)
{
	for (int i = 0; i < this->GoreBreakpoints.Num(); i++)
	{
		FGoreBreakpoint breakpoint = this->GoreBreakpoints[i];

		if (this->Gore == 0.f)
		{
			mesh->SetScalarParameterValueOnMaterials(FName(*breakpoint.ParameterName), 0.f);
		}
		else if (this->Gore >= breakpoint.Start)
		{
			float value = breakpoint.AllowPastMax ? this->Gore : FMath::Min(breakpoint.Max, this->Gore);
			float range = breakpoint.Max - breakpoint.Start;
			float offsetted = value - breakpoint.Start;
			float percentage = offsetted / range;

			mesh->SetScalarParameterValueOnMaterials(FName(*breakpoint.ParameterName), percentage);
		}
	}
}

void UWorldStaticMeshComponent::UpdateGore()
{
	//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Instance: ").Append(FString::FromInt(this->InstanceID)));

	if (this->Gore > 0.f && this->GoreBreakpoints.Num() > 0) {
		// ensure we have a StaticMeshActor
		// set the actors mesh and the rotation from the instance
		// remove instance
		// apply material instances

		if (this->InstanceComponent) {
			// transition back to this instance mesh, then we can assign per-component... easier than using a seperate actor atm
			this->MigrateToSelf();
		}

		//if (this->GoreActor == NULL) {
		if (this->InstanceComponent == NULL) {
			// PIE is only expected to be here

				//this->InstanceComponent->SetMaterial(0, )
			this->UpdateGoreMaterial(this);
		}
		//else {
		//	auto world = this->GetWorld();
		//	if (world) {
		//		auto mesh = this->InstanceComponent->GetStaticMesh();
		//		auto actor = AAutoInstancedStaticMeshActor::GetInstance(world);
		//		FTransform transform; UObject* data;
		//		if (this->RemoveWSMCInstance(actor, transform, data))
		//		{
		//			this->GoreActor = world->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), transform);

		//			this->GoreActor->GetStaticMeshComponent()->SetStaticMesh(mesh);

		//			/*USceneComponent* scenecomponent = Cast<USceneComponent>(data);
		//			if (scenecomponent) {
		//				scenecomponent->AttachToComponent(this->GoreActor->GetStaticMeshComponent(), FAttachmentTransformRules::KeepRelativeTransform);
		//			}*/
		//			/*if (this->ItemComponent && this->ItemComponent->ItemInstance) {
		//				auto component = NewObject<UItemComponent>(this->GoreActor);
		//				component->ItemInstance = this->ItemComponent->ItemInstance->Clone(this->GoreActor);
		//				component->RegisterComponent();
		//			}*/
		//			//this->AttachToComponent(this->GoreActor->GetStaticMeshComponent(), FAttachmentTransformRules::KeepRelativeTransform);
		//			//this->GoreActor->AddOwnedComponent(this);

		//			this->Rename(NULL, this->GoreActor);
		//			this->RegisterComponent();
		//			//this->GoreActor->AddOwnedComponent(this);
		//		}
		//	}
		//}
		//}

		//if (this->GoreActor) {
		//	for (int i = 0; i < this->GoreBreakpoints.Num(); i++)
		//	{
		//		FGoreBreakpoint breakpoint = this->GoreBreakpoints[i];

		//		if (this->Gore >= breakpoint.Start)
		//		{
		//			float value = breakpoint.AllowPastMax ? this->Gore : FMath::Min(breakpoint.Max, this->Gore);
		//			float range = breakpoint.Max - breakpoint.Start;
		//			float offsetted = value - breakpoint.Start;
		//			float percentage = offsetted / range;

		//			//this->SetScalarParameterValueOnMaterials(FName(*breakpoint.ParameterName), percentage);
		//			this->GoreActor->GetStaticMeshComponent()->SetScalarParameterValueOnMaterials(FName(*breakpoint.ParameterName), percentage);
		//		}
		//	}
		//}
	}
}

void UWorldStaticMeshComponent::StartTilt()
{
	if (!GetWorld()->GetTimerManager().IsTimerActive(TiltTimerHandle)) {

		float range = 1.f;
		auto yaw = FMath::RandRange(-range, range);
		auto pitch = FMath::RandRange(-range, range);
		auto roll = FMath::RandRange(-range, range);

		this->TiltTarget = FRotator(pitch, yaw, roll);
		this->TiltStart = GetWorld()->GetTimeSeconds();
		GetWorld()->GetTimerManager().SetTimer(TiltTimerHandle, this, &UWorldStaticMeshComponent::Tilt, 0.1f, true, 0.f);
	}
}

bool UWorldStaticMeshComponent::UpdateMeshFromBreakpoints(bool silent)
{
	bool updated = false;
	FWordStaticMeshBreakpoint breakpoint;

	if (this->InstanceComponent /*&& this->InstanceID > 0*/)
	{
		if (this->ItemComponent && this->ItemComponent->ItemInstance.ItemID > 0) {
			if (this->DetermineBreakpoint(this->MeshBreakpoints, breakpoint))
			{
				if (breakpoint.Mesh != this->InstanceComponent->GetStaticMesh()) {
					//this->InstanceComponent->SetStaticMesh(breakpoint.Mesh);
					this->MigrateToWorldMesh(this->InstanceComponent, breakpoint.Mesh, silent);
					updated = true;
				}
			}
		}
	}
	else if (this->ItemComponent) {
		if (this->ItemComponent && this->ItemComponent->ItemInstance.ItemID > 0) {
			if (this->DetermineBreakpoint(this->MeshBreakpoints, breakpoint))
			{
				if (breakpoint.Mesh != this->GetStaticMesh()) {
					this->SetStaticMesh(breakpoint.Mesh);

					//this->MeshTransform = this->GetComponentTransform();

					updated = true;
					this->OnMeshChanged(false, silent);
					//this->UpdateGore();
				}
			}
		}
	}
	else {
		if (this->DetermineBreakpoint(this->MeshBreakpoints, breakpoint))
		{
			if (breakpoint.Mesh != this->GetStaticMesh()) {
				this->SetStaticMesh(breakpoint.Mesh);
				updated = true;

				/*if (this->MeshChangeSounds.Num() > 0) {
					UCommon::PlayWeightedSound(this->MeshChangeSounds, this->GetWorld(), this->GetComponentLocation());
				}*/
				//#if WITH_EDITOR
									//this->ShowSelf();
				//#endif
			}
		}
	}

	this->UpdateGore();
	return updated;
}

//
//bool UWorldStaticMeshComponent::UpdateMeshFromBreakpoints()
//{
//	bool updated = false;
//	if (this->GoreActor) {
//		if (this->ItemComponent && this->ItemComponent->ItemInstance) {
//			for (int i = 0; i < this->MeshBreakpoints.Num(); i++)
//			{
//				FWordStaticMeshBreakpoint breakpoint = this->MeshBreakpoints[i];
//
//				if (breakpoint.Mesh && this->ItemComponent->ItemInstance->Health >= breakpoint.ForHealthAndAbove)
//				{
//					if (breakpoint.Mesh != this->InstanceComponent->GetStaticMesh()) {
//						this->GoreActor->GetStaticMeshComponent()->SetStaticMesh(breakpoint.Mesh);
//						updated = true;
//					}
//					break;
//				}
//			}
//		}
//	}
//	else if (this->InstanceComponent /*&& this->InstanceID > 0*/)
//	{
//		if (this->ItemComponent && this->ItemComponent->ItemInstance) {
//			for (int i = 0; i < this->MeshBreakpoints.Num(); i++)
//			{
//				FWordStaticMeshBreakpoint breakpoint = this->MeshBreakpoints[i];
//
//				if (breakpoint.Mesh && this->ItemComponent->ItemInstance->Health >= breakpoint.ForHealthAndAbove)
//				{
//					if (breakpoint.Mesh != this->InstanceComponent->GetStaticMesh()) {
//						//this->InstanceComponent->SetStaticMesh(breakpoint.Mesh);
//						this->MigrateToWorldMesh(breakpoint.Mesh);
//						updated = true;
//					}
//					break;
//				}
//			}
//		}
//	}
//	else if (this->ItemComponent) {
//		if (this->ItemComponent && this->ItemComponent->ItemInstance) {
//			for (int i = 0; i < this->MeshBreakpoints.Num(); i++)
//			{
//				FWordStaticMeshBreakpoint breakpoint = this->MeshBreakpoints[i];
//
//				if (breakpoint.Mesh && this->ItemComponent->ItemInstance->Health >= breakpoint.ForHealthAndAbove)
//				{
//					if (breakpoint.Mesh != this->GetStaticMesh()) {
//						this->SetStaticMesh(breakpoint.Mesh);
//
//						//this->MeshTransform = this->GetComponentTransform();
//
//						updated = true;
//						this->OnMeshChanged(false, false);
//						//this->UpdateGore();
//					}
//					break;
//				}
//			}
//		}
//	}
//	else {
//		// PIE ?
//			//this->SetStaticMesh(this->MeshBreakpoints[0].Mesh);
//
//		for (int i = 0; i < this->MeshBreakpoints.Num(); i++)
//		{
//			FWordStaticMeshBreakpoint breakpoint = this->MeshBreakpoints[i];
//
//			if (breakpoint.Mesh && this->Health >= breakpoint.ForHealthAndAbove)
//			{
//				if (breakpoint.Mesh != this->GetStaticMesh()) {
//					this->SetStaticMesh(breakpoint.Mesh);
//					updated = true;
//
//					/*if (this->MeshChangeSounds.Num() > 0) {
//						UCommon::PlayWeightedSound(this->MeshChangeSounds, this->GetWorld(), this->GetComponentLocation());
//					}*/
//					//#if WITH_EDITOR
//										//this->ShowSelf();
//					//#endif
//				}
//				break;
//			}
//		}
//	}
//
//	this->UpdateGore();
//	return updated;
//}

bool UWorldStaticMeshComponent::DetermineBreakpoint(TArray<FWordStaticMeshBreakpoint> breakpoints, FWordStaticMeshBreakpoint &breakpoint)
{
	for (int i = 0; i < breakpoints.Num(); i++)
	{
		FWordStaticMeshBreakpoint bp = breakpoints[i];

		if (bp.Mesh)
		{
			if (
				(this->ItemComponent && this->ItemComponent->ItemInstance.ItemID > 0 && this->ItemComponent->ItemInstance.Health >= bp.ForHealthAndAbove)
				||
				(!this->ItemComponent && this->Health >= breakpoint.ForHealthAndAbove)
				) {
				breakpoint = bp;

				return true;
			}
		}
	}
	return false;
}

void UWorldStaticMeshComponent::OnChildAttached(USceneComponent* ChildComponent)
{
	Super::OnChildAttached(ChildComponent);
}

void UWorldStaticMeshComponent::DestroyMesh(AActor* initiator, bool is_parent_destroyed, bool silent, bool spawn_dm)
{
	if (this->ItemComponent && this->ItemComponent->ItemInstance.ItemID > 0 && this->ItemComponent->ItemInstance.Health > 0.f) {
		this->ItemComponent->ItemInstance.Health = 0.f;
	}
	this->Health = 0.f;

	if (this->ClearDecalsOnDespawn) {
		this->ClearDecals();
	}

	// destroy children first
	TArray<USceneComponent*> children;
	this->GetChildrenComponents(false, children);
	for (int i = 0; i < children.Num(); i++)
	{
		if (children[i]->IsA(UWorldStaticMeshComponent::StaticClass()))
		{
			auto wsmc = Cast<UWorldStaticMeshComponent>(children[i]);
			if (wsmc->DestroyWithParent && (wsmc->Health > 0.f || (wsmc->ItemComponent && wsmc->ItemComponent->ItemInstance.ItemID > 0 && wsmc->ItemComponent->ItemInstance.Health > 0.f))) {
				wsmc->DestroyMesh(initiator, true, silent, spawn_dm);
			}
		}
	}

	if (this->InstanceComponent) {
		//this->InstanceComponent->GetInstanceTransform(this->InstanceID, this->MeshTransform);

		/*this->InstanceComponent->RemoveInstance(this->InstanceID);
		this->InstanceComponent = NULL;
		this->InstanceID = -1;*/

		FTransform transform; UObject* data;
		if (!this->RemoveWSMCInstance(this->InstanceActor, transform, data))
		{
			//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Failed to remove instance MigrateToWorldMesh!"));
		}
	}

	this->ClearInstances();

	if (this->DestructibleMesh && initiator && spawn_dm) {
		FTransform tf = FTransform(this->MeshTransform.Rotator() + this->CurrentRotator, this->MeshTransform.GetLocation(), this->MeshTransform.GetScale3D());

		auto destructible_component = NewObject<UDestructibleComponent>(this);
		destructible_component->AttachToComponent(this, FAttachmentTransformRules::KeepRelativeTransform);
		destructible_component->SetDestructibleMesh(this->DestructibleMesh);
		destructible_component->SetWorldTransform(tf);
		destructible_component->RegisterComponent();

		this->UpdateGoreMaterial(destructible_component);
		//auto loc = this->DestructibleMesh->GetBounds().GetBox().GetCenter();
		//destructible_component->ApplyDamage(this->DamageAmount, tf.GetLocation(), FVector::ZeroVector, this->ImpulseStrength);
		destructible_component->ApplyRadiusDamage(this->DamageAmount, tf.GetLocation(), 100.f, this->ImpulseStrength, true);
	}

	this->OnMeshChanged(false, silent);

	// remove us from the attachment link
	auto parent_wsmc = Cast<UWorldStaticMeshComponent>(this->GetAttachParent());
	if (parent_wsmc && parent_wsmc->PrimaryAttachment == this) {
		parent_wsmc->PrimaryAttachment = NULL;
	}

	if (this->ItemComponent) {
		if (!this->ItemComponent->IsPendingKill()) {
			this->ItemComponent->DestroyComponent();
		}
		this->ItemComponent = NULL;
	}

	if (!this->IsPendingKill()) {
		this->DestroyComponent();
	}
}

void UWorldStaticMeshComponent::BeginDestroy()
{
	/*if (!this->IsPendingKill() && this->IsRooted()) {
		this->DestroyMesh(NULL, false, true, false);
	}*/
	Super::BeginDestroy();
}

void UWorldStaticMeshComponent::OnDamage(AActor* initiator, FHitResult hitresult)
{
	this->UpdateMeshFromBreakpoints(false);
}

void UWorldStaticMeshComponent::OnDamaged(AActor* initiator, FHitResult hitresult, bool killed, float damage, EInteractionTrigger trigger)
{
	//bool update_mesh = true;

	if (this->ItemComponent && this->ItemComponent->ItemInstance.ItemID > 0)
	{
		if (this->ItemComponent->ItemInstance.Health <= 0) {
			//update_mesh = false;
			this->DestroyMesh(initiator, false, false, true);
		}
	}

	/*if (update_mesh) {
		this->UpdateMeshFromBreakpoints();
	}*/
}

void UWorldStaticMeshComponent::OnMeshChanged(bool creating, bool silent)
{
	if (!this->RepairInProcess) {
		if (!creating && !silent)
		{
			this->Animate();
		}

		if (this->ClearDecalsOnMeshChange) {
			this->ClearDecals();
		}
	}
}

void UWorldStaticMeshComponent::Animate()
{
	// play sound
	if (this->MeshChangeSounds.Num() > 0) {
		UCommon::PlayWeightedSound(this->MeshChangeSounds, this->GetWorld(), this->GetComponentLocation());
	}

	// spawn particle
	{
		auto component = UGameplayStatics::SpawnEmitterAtLocation(this->GetWorld(), this->HitParticle, this->MeshTransform.GetLocation(), this->HitParticleOffset + this->MeshTransform.Rotator() + this->CurrentRotator, this->HitParticleScale, false, EPSCPoolMethod::AutoRelease);

		component->SetWorldScale3D(FVector(1));

		component->Activate();
	}
}

void UWorldStaticMeshComponent::ClearDecals()
{
	for (int i = this->DecalInstances.Num() - 1; i >= 0; i--)
	{
		auto gi = Cast<UGlobalGameInstance>(this->GetWorld()->GetGameInstance());
		gi->StaticMeshActorPool->Release(this->DecalInstances[i].Decal);
		this->DecalInstances.RemoveAt(i);

		/*auto instance_id = this->DecalInstances[i].InstanceID;

		this->DecalInstances[i].Component->RemoveInstance(instance_id);
		this->DecalInstances.RemoveAt(i);*/


		//auto actor = AAutoInstancedStaticMeshActor::GetInstance(this->GetWorld());
		//auto entry = AAutoInstancedStaticMeshActor::GetInstanceComponent(this->GetStaticMesh(), EComponentMobility::Static, TEXT("NoCollision"), actor, EInstancedCategory::Decals);
		//if (entry && entry->Component) {

		//	// KEEP IN SYNC WITH UE's INSTANCE BODIES
		//	int max_instances = entry->ComponentData.Num();
		//	int LastInstanceIndex = max_instances - 1;
		//	if (instance_id == LastInstanceIndex)
		//	{
		//		entry->ComponentData.RemoveAt(instance_id);
		//	}
		//	else
		//	{
		//		entry->ComponentData.RemoveAtSwap(instance_id);
		//	}

		//	// update the indicies since it should now have shrunk
		//	max_instances = entry->ComponentData.Num();
		//	for (int i = 0; i < max_instances; i++)
		//	{
		//		auto wsmc = Cast<UWorldStaticMeshComponent>(entry->ComponentData[i]);
		//		if (wsmc) {
		//			for (int x = 0; x < wsmc->DecalInstances.Num(); x++)
		//			{
		//				if (wsmc->DecalInstances[x].InstanceID >= instance_id) {
		//					wsmc->DecalInstances[x].InstanceID--;
		//				}
		//			}
		//		}
		//	}

		//}
	}
}

bool UWorldStaticMeshComponent::TryRepair(AMOTHCharacter* character, UWorldStaticMeshComponent* parent_or_child, FItemData item)
{
	if (this->ItemComponent && this->ItemComponent->ItemInstance.ItemID > 0) {
		//auto repairs = UContentResolver::Instance->ResolveRepairRequirementsForItem(this->ItemComponent->ItemInstance);
		auto itemcache = GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache;
		auto repairs = FItemData::GetRepairRequirements(this->ItemComponent->ItemInstance.ItemID, itemcache);

		if (repairs.Num() > 0) {
			TArray<FTakeRepairFromInventoryRequest> repair_requests;
			for (int i = 0; i < repairs.Num(); i++) {
				FTakeRepairFromInventoryRequest req(repairs[i]);
				repair_requests.Add(req);
			}

			return AMOTHCharacter::TryTakeFromInventory<FTakeRepairFromInventoryRequest, bool>(character, repair_requests, [parent_or_child, item](TArray<FTryFindItemByInventoryResult> results, TArray<FTakeRepairFromInventoryRequest> requests) {

				parent_or_child->RepairInProcess = true;

				//item.Health = FMath::Min(item.Health + 10, item.HealthMax);

				parent_or_child->UpdateMeshFromBreakpoints(false);

				parent_or_child->RepairInProcess = false;

				parent_or_child->Animate();

				return true;
			}, false);
		}
		else {
			// cannot be repaired
		}
	}
	else {
		// cannot be repaired
	}
	return false;
}

bool UWorldStaticMeshComponent::TryUpgrade(AMOTHCharacter* character)
{
	if (this->ItemComponent && this->ItemComponent->ItemInstance.ItemID > 0) {
		//auto upgrades = UContentResolver::Instance->ResolveUpgradesForItem(this->ItemComponent->ItemInstance);
		auto instance = this->GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache;
		auto upgrades = instance->GetItemUpgrades(this->ItemComponent->ItemInstance.ItemID);

		if (upgrades.Num() > 0) {
			TArray<FTakeUpgradeFromInventoryRequest> upgrade_requests;
			for (int i = 0; i < upgrades.Num(); i++) {
				FTakeUpgradeFromInventoryRequest req(upgrades[i]);
				upgrade_requests.Add(req);
			}

			return AMOTHCharacter::TryTakeFromInventory<FTakeUpgradeFromInventoryRequest, bool>(character, upgrade_requests, [this, character, instance](TArray<FTryFindItemByInventoryResult> results, TArray<FTakeUpgradeFromInventoryRequest> requests) {
				int upgrade_to_itemid = requests[0].UpgradeInstance->UpgradedItemID;
				//auto item = UContentResolver::Instance->ResolveItemByID(upgrade_to_itemid);
				auto item = instance->GetLocalItemByID(upgrade_to_itemid);

				if (item && item->Alias) {
					auto parent = this->GetAttachParent();
					this->DestroyMesh(character, true, false, true);

					UBuildings::PlaceItem(character, item, this->GetComponentTransform(), parent, this->GetWorld());

					return true;
				}

				return false;
			}, false);

			//TArray<UItemWidget*> required;

			////ensure the upgrade can be fulfilled 
			//bool can_fulfill = true;
			//for (int i = 0; i < upgrades.Num(); i++)
			//{
			//	auto upgrade = upgrades[i];
			//	if (upgrade->Stack > 0.f) {
			//		// is in inventory?

			//		TArray<UItemWidget*> slots;
			//		float available = 0.f;

			//		slots = character->TryFindItemByInventory(character->Inventories[CHARACTER_INVENTORY_MAIN].Widgets, upgrade->RequiredItemID, available);

			//		if (slots.Num() > 0) {
			//			required.Append(slots);
			//		}

			//		if (available < upgrade->Stack) { // keep looking for more
			//			for (int t = 0; t < UGameSettings::Instance->ToolBelts; t++) {
			//				FString toolbelt = (CHARACTER_INVENTORY_TOOLBELT);
			//				toolbelt = toolbelt.Append(FString::FromInt(t + 1));

			//				auto inventory = character->Inventories.Find(toolbelt);
			//				if (inventory) {
			//					slots = character->TryFindItemByInventory(inventory->Widgets, upgrade->RequiredItemID, available);

			//					if (slots.Num() > 0) {
			//						required.Append(slots);
			//					}

			//					if (available >= upgrade->Stack) { // if there is enough, no need to continue looking
			//						break;
			//					}
			//				}
			//			}
			//		}

			//		// we are done looking for this requirement, if there is enough we can no longer proceed
			//		if (available < upgrade->Stack) {
			//			can_fulfill = false;
			//			break;
			//		}
			//	}
			//}

			//if (can_fulfill) {
			//	int upgrade_to_itemid = upgrades[0]->UpgradedItemID;
			//	auto item = UContentResolver::Instance->ResolveItemByID(upgrade_to_itemid);

			//	if (item && item->Alias) {
			//		auto parent = this->GetAttachParent();
			//		this->DestroyMesh(character, true);

			//		auto world = this->GetWorld();
			//		UBuildings::PlaceItem(world, character, item, this->GetComponentTransform(), parent);

			//		// deduct

			//		for (int i = 0; i < upgrades.Num(); i++)
			//		{
			//			auto upgrade = upgrades[i];
			//			float remaining = upgrade->Stack;

			//			for (int x = 0; x < required.Num(); x++) {
			//				auto slot = required[x];
			//				if (slot->ItemInstance->ItemID == upgrade->RequiredItemID) {
			//					float amount_to_deduct = FMath::Min(slot->ItemInstance->Stack, remaining);

			//					slot->ItemInstance->Stack -= amount_to_deduct;
			//					remaining -= amount_to_deduct;

			//					if (remaining <= 0.f) {
			//						break;
			//					}
			//				}
			//			}
			//		}

			//		return true;
			//	}
			//	else {
			//		// cannot be upgraded
			//		// add to log for us to investigate / debug in debug mode too
			//	}
			//}
		}
		else {
			// cannot be upgraded
		}
	}
	else {
		// cannot be upgraded
	}
	return false;
}

bool UWorldStaticMeshComponent::Pickup(AMOTHCharacter* character)
{
	if (this->ItemComponent && /*this->ItemComponent->ItemInstance &&*/ this->ItemComponent->ItemInstance.ItemID > 0) {
		if (character->GiveItemByID(this->ItemComponent->ItemInstance.ItemID, 1.0f, true)) {
			this->DestroyMesh(character, false, true, false);
		}
	}

	return false;
}