// Fill out your copyright notice in the Description page of Project Settings.

#include "GunWeapon.h"


// Sets default values
AGunWeapon::AGunWeapon()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;

	//UnregisterAllComponents();

	//this->SkeletalMesh = CreateDefaultSubobject<USkeletalMeshComponent>(FName("SkeletalMesh"));
	this->SpringArm = CreateDefaultSubobject<USpringArmComponent>(FName("SpringArm"));
	this->Camera = CreateDefaultSubobject<UCameraComponent>(FName("Camera"));
	this->Barrel = CreateDefaultSubobject<ABarrel>(FName("Barrel"));

	//this->SpringArm->SetupAttachment(this->SkeletalMesh);
	this->Camera->SetupAttachment(this->SpringArm);

	//this->Camera->SetRelativeScale3D(FVector(0.1f));
}

// Called when the game starts or when spawned
void AGunWeapon::BeginPlay()
{
	Super::BeginPlay();
	
	/*if (!this->Barrel && this->BarrelClass) {
		this->SetBarrel()
	}*/
}

// Called every frame
void AGunWeapon::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void AGunWeapon::SetBarrel(TSubclassOf<ABarrel> barrel_class, FTransform location, FName socket)
{
	if (this->Barrel) {
		this->Barrel->Destroy();
		this->Barrel = NULL;
	}
	this->Barrel = this->GetWorld()->SpawnActor<ABarrel>(barrel_class, location);
	this->Barrel->AttachToActor(this, FAttachmentTransformRules::KeepRelativeTransform, socket);
}
