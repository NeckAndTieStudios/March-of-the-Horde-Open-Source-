// Fill out your copyright notice in the Description page of Project Settings.

#include "ItemWidget.h"

//
//TArray<UItemInstance *> UItemWidget::GetItemContainer(AFPSCharacter* character)
//{
//	return character->Inventories[this->ItemContainerName].Widgets->;
//	/*if (this->ItemContainerName == TEXT("Inventory"))
//	{
//		return character->Inventory;
//	}
//	else if (this->ItemContainerName == TEXT("Toolbelt 1"))
//	{
//		return character->ToolBeltInventory;
//	}
//	TArray<UItemInstance *> local;
//	return local;*/
//}

//TArray<UItemWidget*> URecipeWidget::GetSlots()
//{
//	TArray<UItemWidget*> slots;
//	return slots;
//}