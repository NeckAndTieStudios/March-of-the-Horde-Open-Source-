// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ItemAliasInstance.h"
#include "InteractionTrigger.h"
#include "ItemAttributeInstance.h"
#include "Engine/Texture2D.h"
#include "SurfaceEffect.h"
#include "ItemUpgrade.h"
#include "ItemInstance.generated.h"

//USTRUCT()
//struct FItemInstanceLootCacheEntry
//{
//	GENERATED_USTRUCT_BODY()
//public:
//	UPROPERTY()
//		TArray<UItemInstance *> Entries;
//
//	FItemInstanceLootCacheEntry();
//	FItemInstanceLootCacheEntry(TArray<UItemInstance *> entries);
//};

class UItemCache;

UENUM(BlueprintType)
enum class EInteractionMode : uint8
{
	None = 0,
	PressAndHold = 1,
	PressAndWait = 2
};

USTRUCT(Blueprintable, BlueprintType)
struct FItemData
{
	GENERATED_USTRUCT_BODY()

private:
	TMap<int, float> StackRemainder;

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemID = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float Weight = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float Stack = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float MaxStack = 999;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString DisplayName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float Health = 100.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString AliasName = FString(TEXT(""));

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		EInteractionMode InteractionMode;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float HealthMax = 100.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemLootFormulaID = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float ItemLootFormulaValue;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsAttachment = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsPickupAllowed = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsClippable = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsLootable = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsPlaceable = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsConsumable = false;
	/*
		UPROPERTY(BlueprintReadWrite)
			TMap<int, float> StackRemainder;*/

	static void CalculateStack(UPARAM(ref) FItemData& itemDataInstance, EInteractionTrigger trigger, FItemData damagedItem, float toolDamage, UPARAM(ref) FItemData& rootStackItem, UItemCache* cache);
	//static void CalculateStack(UPARAM(ref) FItemData& itemDataInstance, EInteractionTrigger trigger, FItemData damagedItem, float toolDamage, UPARAM(ref) TMap<int, float>& parentStackRemainder);

	//UFUNCTION(BlueprintCallable)
	static TArray<FItemData> GetLoot(/*const FItemData& item*/int itemID, const EInteractionTrigger& trigger, UItemCache* cache);

	//UFUNCTION(BlueprintCallable)
	static TArray<FItemData> GetRecipes(int itemID, UItemCache* cache);

	//UFUNCTION(BlueprintCallable)
	static TArray<FItemData> GetIngredients(int itemID, UItemCache* cache);

	//UFUNCTION(BlueprintCallable)
	static TArray<UItemRepairInstance*> GetRepairRequirements(int itemID, UItemCache* cache);

	//UFUNCTION(BlueprintCallable)
	static TArray<FItemData> GetInteractions(int itemID, UItemCache* cache);

	//UFUNCTION(BlueprintCallable)
	static TArray<UItemAliasInstance*> GetAliases(int itemID, UItemCache* cache);

	static void CalculateLootTable(TArray<FItemData>& loot);
};

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable, BlueprintType)
class FPSPROJECT_API UItemInteraction : public UObject
{
	GENERATED_BODY()

private:

public:
	UItemInteraction() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemInteractionID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemGroupID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int SurfaceEffectID;

	//UPROPERTY(EditAnywhere, BlueprintReadWrite)
	//USurfaceEffect* SurfaceEffect = NULL;

	//void Load();
};

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FManualItemInteraction
{
	GENERATED_USTRUCT_BODY()

private:

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemGroupID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int SurfaceEffectID;
};

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable)
class FPSPROJECT_API UItemInstance : public UObject
{
	GENERATED_BODY()

private:
	//AStaticMeshActor * _actor = NULL;
	//AActor * _actor = NULL;

	/*UPROPERTY()
		TMap<EInteractionTrigger, FItemInstanceLootCacheEntry> LootCache;

	UPROPERTY()
		TArray<UItemInstance *> Recipes;

	UPROPERTY()
		TArray<UItemInstance *> Ingredients;

	UPROPERTY()
		TArray<UItemInteraction *> Interactions;

	UPROPERTY()
		TArray<UItemUpgradeInstance *> Upgrades;

	UPROPERTY()
		TArray<UItemAliasInstance *> Aliases;*/

		//bool _loaded_Recipes = false;
		//bool _loaded_Ingredients = false;
		//bool _loaded_Interactions = false;
		//bool _loaded_Upgrades = false;
		//bool _loaded_Aliases = false;

public:
	UItemInstance() {}

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TMap<int, float> StackRemainder;*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemID = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FItemData Data = FItemData();

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float BaseHealth = 0.f;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float Health = 100.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float Stack = 0.f;*/

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
		float DefaultMaxStack = 0.f; // currently the DB value, but should only be written to within this class

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float MaxStack = 0.f;*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UTexture2D* Thumbnail;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool LootSelf;*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemGroupID = 0;

	//EItemLootFormula ItemLootFormula;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<UItemInstance *> Loot;*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UItemAliasInstance* Alias;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int FoliageTypeID = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int FoliageScaleIndex = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ToolTypeID = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int BaseLevel = 0;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString DisplayName;*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int CraftDuration = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int RepairDuration = 0;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float Weight = 0.f;*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FVector BuildOffset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<FName> BuildTargetSockets;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool BuildOnGround = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool BuildSocketRequired = false;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsAttachment = false;*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool Punchable = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsKickable = false;

	//UPROPERTY(EditAnywhere, BlueprintReadWrite)
	//	bool IsPickupAllowed = false;
/*
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsClippable = false;*/

	//UPROPERTY(EditAnywhere, BlueprintReadWrite)
	//	bool IsLootable = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool ShowUI = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsHarvestable = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsHoldable = false;

	//UPROPERTY(EditAnywhere, BlueprintReadWrite)
	//	bool IsPlaceable = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FVector HandOffsetLocation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FRotator HandOffsetRotation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float InteractionDelay = 0.f;
/*
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		EInteractionMode InteractionMode;*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float FireBurnTime = 0.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float FuelProduced = 0.f;
/*
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float HealthMax = 100.f;*/

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemLootFormulaID = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float ItemLootFormulaValue;
*/
	//// where the item resides e.g. a slot (UItemWidget)
	//UPROPERTY(EditAnywhere, BlueprintReadWrite)
	//	UObject * Container;

	UFUNCTION(BlueprintCallable)
		bool CanBeDamaged();

	UFUNCTION(BlueprintCallable)
		UItemInstance* Clone(UObject* outer);

	UFUNCTION(BlueprintCallable)
		AActor* GetActor(AActor* owner);

	/*UFUNCTION(BlueprintCallable)
		void SetActor(AActor* actor);*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<UItemAttributeInstance*> Attributes;
	/*
		UPROPERTY(EditAnywhere, BlueprintReadWrite)
			TArray<FManualItemInteraction> ManualInteractions;*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int UpgradeStage;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UStaticMesh* PreviewMesh;*/

		/*UFUNCTION(BlueprintCallable)
			TArray<UItemInstance*> GetLoot(const EInteractionTrigger& trigger);

		UFUNCTION(BlueprintCallable)
			TArray<UItemInstance*> GetRecipes();

		UFUNCTION(BlueprintCallable)
			TArray<UItemInstance*> GetIngredients();

		UFUNCTION(BlueprintCallable)
			TArray<UItemAliasInstance*> GetAliases();*/

	UFUNCTION(BlueprintCallable)
		TArray<UItemUpgradeInstance*> GetUpgrades(UItemCache* cache);

	UFUNCTION(BlueprintCallable)
		TArray<UItemInteraction*> GetInteractions(UItemCache* cache);

	UFUNCTION(BlueprintCallable)
		UItemInteraction* GetInteractionByItem(int hitByItemGroupID);

	UFUNCTION(BlueprintCallable)
		void Load();
	/*
		UFUNCTION(BlueprintCallable)
			void CalculateLootTable(const TArray<UItemInstance*>& loot);*/
			/*
				UFUNCTION(BlueprintCallable)
					void CalculateStack(EInteractionTrigger trigger, UItemInstance* damagedItem, float toolDamage, UPARAM(ref) TMap<int, float>& parentStackRemainder);*/

	UFUNCTION(BlueprintCallable)
		void SpawnDestructibleMesh(FTransform transform);

	static float GetHealth(float min, float max);

	virtual void PostCacheLoad();

	/*bool IsSupportedForNetworking() const override
	{
		return true;
	}*/
};