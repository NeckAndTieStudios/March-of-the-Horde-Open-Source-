// Fill out your copyright notice in the Description page of Project Settings.

#include "Common.h"
#include "DestructibleComponent.h"
#include "ItemWidget.h"
#include "ItemContainer.h"
#include "Engine.h"

void UCommon::AddInteractionAtLocation(FVector location, UPrimitiveComponent* component, FRotator direction, float damageRadius, float speed, float damage)
{
	if (component)
	{
		UDestructibleComponent* dm = Cast<UDestructibleComponent>(component);
		if (dm)
		{
			dm->ApplyRadiusDamage(damage, location, damageRadius, speed, false);
		}

		if (component && component->Mobility == EComponentMobility::Movable && component->IsSimulatingPhysics())
		{
			component->AddImpulseAtLocation(FRotationMatrix(direction).GetScaledAxis(EAxis::X) * speed, location);
		}
	}
}

TArray<FItemData> UCommon::GetIngredients(int itemID, UItemCache* cache)
{
	return FItemData::GetIngredients(itemID, cache);
}

FString UCommon::GetReferencePath(UObjectBaseUtility* object)
{
	auto classname = object->GetClass()->GetName();
	auto name = classname.Append(FString("'")).Append(object->GetPathName()).Append(FString("'"));

	return name;
}

FString UCommon::GetReferencePathForObject(UObject* object)
{
	return UCommon::GetReferencePath(object);
}

float UCommon::RoundFloat(float input, int decimals)
{
	int padded = input * decimals;
	return (float)padded / decimals;
}

int UCommon::Roulette(TArray<FWeighting> items)
{
	int items_length = items.Num();

	// calculate the total weight
	float weight_sum = 0.f;
	bool weights_are_the_same = items_length > 0; // generally always true by default
	for (int i = 0; i < items_length; i++) {
		weight_sum += items[i].Weighting;

		if (weights_are_the_same && i > 0) {
			if (items[i - 1].Weighting != items[i].Weighting || items[i - 1].Weighting <= 0 || items[i].Weighting <= 0) { // if the previous value was different, or if the weight is <= 0 then there is nothing to pick from anyway
				weights_are_the_same = false;
			}
		}
	}

	// if all weights are the same, assume equality and return a random pick
	if (weights_are_the_same) {
		int index = rand() % items_length;
		return index;
	}

	// get a random value
	float value = (FMath::Rand() / double(RAND_MAX)) * weight_sum;

	// locate the random value based on the weights
	for (int i = 0; i < items_length; i++) {
		value -= items[i].Weighting;
		//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString::FromInt(i).Append(":").Append(FString::SanitizeFloat(items[i].Weighting)));
		if (value < 0) {
			return i;
		}
	}

	// when rounding errors occur, we return the last item's index 
	return -1;
}

FGetItemComponentForInstanceResult UCommon::GetItemComponentForInstance(UHierarchicalInstancedStaticMeshComponent* parent, int instanceID, EInstancedCategory category, AAutoInstancedStaticMeshActor* actor)
{
	return AAutoInstancedStaticMeshActor::GetItemComponentForInstance(parent, instanceID, category, actor);
}

void UCommon::PlayWeightedSoundByComponent(TArray<FSoundCueWeighting> items, USceneComponent* component, FVector location)
{
	return UCommon::PlayWeightedSound(items, component->GetWorld(), location);
}

void UCommon::PlayWeightedSound(TArray<FSoundCueWeighting> items, UWorld* world, FVector location)
{
	//auto weightings = static_cast<TArray<FWeighting>>(items);

	TArray<FWeighting> weightings;

	for (int i = 0; i < items.Num(); i++) {
		FWeighting weighting = FWeighting();
		weighting.Weighting = items[i].Weighting;
		weightings.Add(weighting);
	}

	auto index = UCommon::Roulette(weightings);
	if (index >= 0) {
		auto sound = items[index];

		if (sound.SoundCue) {
			UGameplayStatics::PlaySoundAtLocation(world, sound.SoundCue, location);
		}
		else {
			//GEngine->AddOnScreenDebugMessage(-1, 30.0f, FColor::Red, FString("FAILED TO PLAY sound: ").Append(FString::FromInt(index)));
		}
	}
	else {
		//GEngine->AddOnScreenDebugMessage(-1, 30.0f, FColor::Red, FString("FAILED TO PLAY sound: ").Append(FString::FromInt(index)));
	}
}

void UCommon::Test()
{
	auto b = UCommon::ParseVector("FVector(0, -130, 0)");
	auto a = UCommon::ParseVector("FVector(50, 0, -103)");
	auto c = UCommon::ParseVector("FVector(0, 0, -121)");


	auto r_a = UCommon::ParseRotator("FRotator(0, 140, 0)");
}

FVector UCommon::ParseVector(const FString& reference)
{
	FVector result;

	FString text = *reference;
	text.RemoveFromStart(TEXT("FVector("));
	text.RemoveFromEnd(TEXT(")"));

	int index = -1;
	if (text.FindChar(',', index)) {
		if (index > 0) { // intentional - 0 should at least be 1 digit
			//FString x = text.LeftChop(index);
			FString x = text.Left(index);
			result.X = FCString::Atof(*x);

			text.RemoveAt(0, index + 1);

			if (text.FindChar(',', index)) {
				if (index > 0) { // intentional - 0 should at least be 1 digit
					FString y = text.Left(index);
					result.Y = FCString::Atof(*y);

					text.RemoveAt(0, index + 1);

					// no commar left, use remaining
					text = text.TrimStart();
					result.Z = FCString::Atof(*text);
				}
			}
		}
	}

	return result;
}

FRotator UCommon::ParseRotator(const FString& reference)
{
	FRotator result(0, 0, 0);

	FString text = *reference;
	text.RemoveFromStart(TEXT("FRotator("));
	text.RemoveFromEnd(TEXT(")"));

	int index = -1;
	if (text.FindChar(',', index)) {
		if (index > 0) { // intentional - 0 should at least be 1 digit
			//FString p = text.LeftChop(index);
			FString p = text.Left(index);
			result.Pitch = FCString::Atof(*p);

			text.RemoveAt(0, index + 1);

			if (text.FindChar(',', index)) {
				if (index > 0) { // intentional - 0 should at least be 1 digit
					FString y = text.Left(index);
					result.Yaw = FCString::Atof(*y);

					/*if (result.Yaw >= 0) {
						GEngine->AddOnScreenDebugMessage(-1, 30.0f, FColor::Red, FString("Yaw"));
					}*/

					text.RemoveAt(0, index + 1);

					// no commar left, use remaining
					text = text.TrimStart();
					result.Roll = FCString::Atof(*text);
				}
			}
		}
	}

	return result;
}

FTransform UCommon::GetSocketWorldLocationForInstance(FTransform instanceTransform, FTransform socketTransform)
{
	auto CachedRotator = instanceTransform.GetRotation().GetNormalized();

	const FTransform RelativeTransform(CachedRotator, instanceTransform.GetLocation(), FVector(1, 1, 1)); // don't use scaling, so it matches how AddLocalRotation/Offset work
	const FTransform NewRelTransform = socketTransform * RelativeTransform;

	return NewRelTransform;
}

double UCommon::Distance(FTransform p1, FTransform p2)
{
	return FVector::Distance(p1.GetLocation(), p2.GetLocation());
	//return Math.Sqrt(Math.Pow(p2.X - p1.X, 2) + Math.Pow(p2.Y - p1.Y, 2));
}

TArray<FTransform> UCommon::SortByClosestTransform(FTransform origin, TArray<FTransform> points)
{
	if (points.Num() <= 1) {
		return points;
	}

	TArray<float> map;

	// calculate the distances
	for (int i = 0; i < points.Num(); i++) {
		//auto distance = FVector::Distance(origin.GetLocation(), points[i].GetLocation());
		auto distance = UCommon::Distance(origin, points[i]);
		map.Add(distance);
	}

	// build closest array
	TArray<FTransform> closest;
	TArray<FTransform> queue = points;

	float last_distance = 0;
	int selection;
	while (queue.Num() > 0) {
		selection = -1;

		bool first = true;
		for (int i = 0; i < queue.Num(); i++) {
			auto distance = map[i];

			if (!first) {
				if (last_distance > distance) {
					selection = i;
					last_distance = distance;
				}
			}
			else {
				selection = i;
				last_distance = distance;
				first = false;
			}
		}

		if (selection > -1) {
			closest.Add(queue[selection]);
			queue.RemoveAt(selection);
			map.RemoveAt(selection);
		}
	}

	return closest;
}

TArray<FSocketTransformation> UCommon::SortByClosestSocketTransformation(FTransform origin, TArray<FSocketTransformation> points)
{
	if (points.Num() <= 1) {
		return points;
	}

	TArray<float> map;

	// calculate the distances
	for (int i = 0; i < points.Num(); i++) {
		//auto distance = FVector::Distance(origin.GetLocation(), points[i].GetLocation());
		auto distance = UCommon::Distance(origin, points[i].Transform);
		map.Add(distance);
	}

	// build closest array
	TArray<FSocketTransformation> closest;
	TArray<FSocketTransformation> queue = points;

	float last_distance = 0;
	int selection;
	while (queue.Num() > 0) {
		selection = -1;

		bool first = true;
		for (int i = 0; i < queue.Num(); i++) {
			auto distance = map[i];

			if (!first) {
				if (last_distance > distance) {
					selection = i;
					last_distance = distance;
				}
			}
			else {
				selection = i;
				last_distance = distance;
				first = false;
			}
		}

		if (selection > -1) {
			closest.Add(queue[selection]);
			queue.RemoveAt(selection);
			map.RemoveAt(selection);
		}
	}

	return closest;
}


FRotator UCommon::GetComponentNormalRotation(FVector UpVector, USceneComponent* component, FHitResult hitResult)
{
	//const FVector UpVector = component->GetUpVector();
	FVector RotationAxis = FVector::CrossProduct(UpVector, hitResult.ImpactNormal);
	RotationAxis.Normalize();

	float RotationAngleRad = acosf(FVector::DotProduct(UpVector, hitResult.ImpactNormal));
	FQuat Quat = FQuat(RotationAxis, RotationAngleRad);
	FQuat NewQuat = Quat * component->GetComponentQuat();
	FRotator NewRotator = NewQuat.Rotator();
	NewRotator.Yaw = 0;
	return NewRotator;
	//Component->SetRelativeRotation(NewRotator);
}


FRotator UCommon::GetComponentRotation(FVector start, FVector target, USceneComponent* component)
{
	//const FVector UpVector = component->GetUpVector();
	FVector RotationAxis = FVector::CrossProduct(start, target);
	RotationAxis.Normalize();

	float RotationAngleRad = acosf(FVector::DotProduct(start, target));
	FQuat Quat = FQuat(RotationAxis, RotationAngleRad);
	FQuat NewQuat = Quat * component->GetComponentQuat();
	FRotator NewRotator = NewQuat.Rotator();
	NewRotator.Yaw = 0;
	return NewRotator;
	//Component->SetRelativeRotation(NewRotator);
}

//TArray<FItemData> UCommon::TryFindSlotForItemInstance(UItemContainer* collection, FItemData item, bool allow_max_stack, UObject* outer)
//{
//	return UCommon::FindSlotForItem<FItemData>(collection, item, allow_max_stack, outer,
//		[](FItemData element) {
//			return element;
//		},
//		[](UItemContainer* ref_collection, FItemData element, bool is_new_slot, FItemData item, int slot, float receivedAmount) {
//			if (is_new_slot) { 
//				if (slot < ref_collection->Items.Num()) {
//					ref_collection->Items[slot] = item;
//				}
//				else {
//					// add?
//				}
//			}
//		}
//	);
//}

TArray<FItemData> UCommon::TryFindSlotForItem(UItemContainer* collection, UPARAM(ref) FItemData& item, bool allow_max_stack, UObject* outer, float amount)
{
	return UCommon::FindSlotForItem<FItemData>(collection, item, allow_max_stack, outer,
		[](FItemData element) {
			return element;// ->ItemInstance;
		},
		[](UItemContainer *  ref_collection, FItemData element, bool is_new_slot, FItemData item, int slot, float deduction_amt) {
			if (is_new_slot) {
				if (slot < ref_collection->Items.Num()) {
					ref_collection->Items[slot] = item;
				}
				else {
					// add?
				}
			}

			//if (is_new_slot) { element->OnSetItem(item); }
			//element->OnUpdated(ref_collection, slot, false, deduction_amt);
		}, amount
	);
	//TArray<UItemWidget*> slots;
	//bool has_more = false;
	//auto wc_item = item->Clone(outer);

	//min_capacity = FMath::Max(collection.Num(), min_capacity);

	//// try find an existing stack
	//for (int slot = 0; slot < min_capacity; slot++) {
	//	auto tb_item = collection[slot]->ItemInstance;
	//	if (collection[slot]->ItemInstance && collection[slot]->ItemInstance->ItemID == wc_item->ItemID /*&& !collection[slot]->IsLocked*/) {
	//		float free_space = (allow_max_stack ? ITEM_MAX_STACK : tb_item->MaxStack) - tb_item->Stack;
	//		if (free_space > 0) {
	//			float deduction_amt = FMath::Min(free_space, wc_item->Stack);

	//			wc_item->Stack -= deduction_amt;
	//			tb_item->Stack += deduction_amt;

	//			collection[slot]->OnUpdated(collection, slot, false, deduction_amt);
	//			slots.Add(collection[slot]);
	//		}
	//	}
	//	if (wc_item->Stack <= 0) {
	//		// cancel the loop if we have consumed the stack
	//		break;
	//	}
	//}

	//if (wc_item->Stack > 0) {
	//	// else if we still have quantity to consume, then try to find a free slot
	//	for (int slot = 0; slot < min_capacity; slot++) {
	//		if (collection.Num() == slot || collection[slot]->ItemInstance == NULL || collection[slot]->ItemInstance->Stack <= 0 /*|| collection[slot]->ItemInstance->Thumbnail == NULL*/) {
	//			// needs a new slot created
	//			auto clone = wc_item->Clone(outer);
	//			clone->MaxStack = allow_max_stack ? ITEM_MAX_STACK : clone->DefaultMaxStack; // restore the initial stack as this has now become a inventory item

	//			float stack = FMath::Min(clone->Stack, (allow_max_stack ? ITEM_MAX_STACK : clone->MaxStack));

	//			wc_item->Stack -= stack;
	//			clone->Stack = stack;

	//			collection[slot]->OnSetItem(clone);
	//			collection[slot]->OnUpdated(collection, slot, true, stack);
	//			slots.Add(collection[slot]);
	//		}
	//		if (wc_item->Stack <= 0) {
	//			// cancel the loop if we have consumed the stack
	//			break;
	//		}
	//	}
	//}

	//if (wc_item->Stack > 0) {
	//	// try to put into main inventory
	//	// else drop item ...
	//	//GEngine->AddOnScreenDebugMessage(-1, 10.0f, FColor::Magenta, FString::Printf(TEXT("Cannot fit into toolbelt: %f"), wc_item->Stack));

	//	//has_more = true;
	//}

	//item->Stack = wc_item->Stack;

	//return slots;
}

TArray<FItemData> UCommon::TryFindItemByContainer(UItemContainer* container, int itemID, float &available)
{
	TArray<FItemData> results;
	for (int x = 0; x < container->Items.Num(); x++)
	{
		auto item = container->Items[x];
		if (/*item &&*/ item.ItemID == itemID)
		{
			if (item.Stack > 0)
			{
				available += item.Stack;

				results.Add(item);
			}
		}
	}
	return results;
}