// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Runtime/Foliage/Public/FoliageInstancedStaticMeshComponent.h"
#include "Foliage.generated.h"

UCLASS(ClassGroup = Rendering, meta = (BlueprintSpawnableComponent), BlueprintType)
class FPSPROJECT_API UMOTHFoliageInstanceStaticMeshComponent : public UFoliageInstancedStaticMeshComponent
{
	GENERATED_BODY()

public:
	UMOTHFoliageInstanceStaticMeshComponent();

	/*
	ENSURE YOU UPDATE THE "INTERACTIVE_FoliageCompBP" which needs to copy these settings to each chunk created
	*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "MOTH")
		float Health = 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "MOTH")
		bool SetHealthBasedOnScale = true;
	
	UFUNCTION(BlueprintCallable) virtual void CopySettingsFromOtherComponent(UMOTHFoliageInstanceStaticMeshComponent* other)
	{
		this->Health = other->Health;
		this->SetHealthBasedOnScale = other->SetHealthBasedOnScale;
	}
};