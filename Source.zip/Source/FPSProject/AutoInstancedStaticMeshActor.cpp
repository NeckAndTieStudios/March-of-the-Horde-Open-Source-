// Fill out your copyright notice in the Description page of Project Settings.

#include "AutoInstancedStaticMeshActor.h"
#include "CoreMinimal.h"
#include "Engine.h"
#include "Common.h"
#include "WorldStaticMeshComponent.h"

AAutoInstancedStaticMeshActor::AAutoInstancedStaticMeshActor()
{
	/*if (InstancedComponents.Num() > 0)
	{
		GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("Detected existing mesh instances"));
	}*/
}

AAutoInstancedStaticMeshActor* AAutoInstancedStaticMeshActor::GetInstance(UWorld* world)
{
	/*=============================== USE THIS TO SEND TO A CHUNK - the actor needs to be created in this level rather than on the world
	component->GetComponentLevel()
	*/

	TArray<AAutoInstancedStaticMeshActor*> actors;
	for (TActorIterator<AAutoInstancedStaticMeshActor> foliageIterator(world); foliageIterator; ++foliageIterator) {
		return *foliageIterator;
	}

	/*for (TObjectIterator<AAutoInstancedStaticMeshActor> Itr; Itr; ++Itr)
	{
		if (Itr->IsA(AAutoInstancedStaticMeshActor::StaticClass()) && !Itr->IsPendingKill() && !Itr->IsActorBeingDestroyed())
		{
			return *Itr;
		}
		else
		{
			continue;
		}
	}*/

	return world->SpawnActor<AAutoInstancedStaticMeshActor>(AAutoInstancedStaticMeshActor::StaticClass());
}

FGetItemComponentForInstanceResult AAutoInstancedStaticMeshActor::GetItemComponentForInstance(UHierarchicalInstancedStaticMeshComponent* parent, int instanceID, EInstancedCategory category, AAutoInstancedStaticMeshActor* actor)
{
	FGetItemComponentForInstanceResult result = FGetItemComponentForInstanceResult();

	//auto oldmesh = parent->GetStaticMesh();
	//FString oldreference_path = UCommon::GetReferencePath(oldmesh);
	//FString oldinstance_key = oldreference_path;
	//oldinstance_key.AppendInt(instanceID);

	/*if (actor == NULL) {
		actor = Cast<AAutoInstancedStaticMeshActor>(parent->GetOwner());
	}*/
	if (actor == NULL) {
		actor = AAutoInstancedStaticMeshActor::GetInstance(parent->GetWorld());
	}

	if (actor) {
		FString container_reference = AAutoInstancedStaticMeshActor::GetComponentKey(parent, category);
		auto entry = actor->InstancedComponents.Find(container_reference);
		if (entry) {
			if (entry->Component == parent && entry->ComponentData.Num() > instanceID) {
				auto scene_component = Cast<USceneComponent>(entry->ComponentData[instanceID]);
				if (scene_component)
				{
					if (scene_component->IsA(UWorldStaticMeshComponent::StaticClass()))
					{
						auto wsmc = Cast<UWorldStaticMeshComponent>(scene_component);

						result.Component = wsmc->ItemComponent;
						result.Data = scene_component;
					}
					if (scene_component->IsA(UItemComponent::StaticClass()))
					{
						result.Component = Cast<UItemComponent>(scene_component);
						result.Data = scene_component;
					}

					if (result.Component == NULL) {
						TArray<USceneComponent*> children;
						scene_component->GetChildrenComponents(false, children);

						for (int i = 0; i < children.Num(); i++)
						{
							if (children[i]->IsA(UItemComponent::StaticClass()))
							{
								UItemComponent* itemcomponent = Cast<UItemComponent>(children[i]);
								if (itemcomponent->InstanceID == instanceID)
								{
									result.Component = itemcomponent;
									result.Data = scene_component;
									break;
								}
							}
						}
					}
				}
			}
		}
	}

	/*
		auto oldmesh = parent->GetStaticMesh();
		FString oldreference_path = UCommon::GetReferencePath(oldmesh);
		FString oldinstance_key = oldreference_path;
		oldinstance_key.AppendInt(instanceID);

		auto actor = Cast<AAutoInstancedStaticMeshActor>(parent->GetOwner());
		if (actor) {
			auto res = actor->InstancedComponentData.Find(oldinstance_key);
			if (res) {
				auto wsmc = Cast<UWorldStaticMeshComponent>(*res);
				if (wsmc)
				{
					TArray<USceneComponent*> children;
					wsmc->GetChildrenComponents(false, children);

					for (int i = 0; i < children.Num(); i++)
					{
						if (children[i]->IsA(UItemComponent::StaticClass()))
						{
							UItemComponent* itemcomponent = Cast<UItemComponent>(children[i]);
							if (itemcomponent->InstanceID == instanceID)
							{
								result = itemcomponent;
								break;
							}
						}
					}
				}
			}
		}*/

	return result;
}

UHierarchicalInstancedStaticMeshComponent* AAutoInstancedStaticMeshActor::CreateComponent(UStaticMesh* mesh, EComponentMobility::Type mobility, FName collisionProfileName, AAutoInstancedStaticMeshActor* actor)
{
	auto instance_component = NewObject<UHierarchicalInstancedStaticMeshComponent>(actor, UHierarchicalInstancedStaticMeshComponent::StaticClass());
	instance_component->SetMobility(EComponentMobility::Movable);
	instance_component->SetStaticMesh(mesh);
	//instance_component->MarkRenderStateDirty();
	/*UMaterialInterface* mi = mesh->GetMaterial(0);  TURN ON "Use with Instanced Static Meshes" within original material
	instance_component->SetMaterial(0, mi);*/
	instance_component->SetMobility(mobility);
	instance_component->SetCollisionProfileName(collisionProfileName);
	instance_component->bMultiBodyOverlap = true;
	instance_component->RegisterComponent();

	return instance_component;
}

FInstancedComponentsEntry* AAutoInstancedStaticMeshActor::GetInstanceComponent(UObject* component, UStaticMesh* mesh, EComponentMobility::Type mobility, FName collisionProfileName, AAutoInstancedStaticMeshActor* actor, EInstancedCategory category)
{
	FInstancedComponentsEntry* entry;
	UHierarchicalInstancedStaticMeshComponent* instance_component;

	if (!component) {
		instance_component = AAutoInstancedStaticMeshActor::CreateComponent(mesh, mobility, collisionProfileName, actor);

		FString container_reference = AAutoInstancedStaticMeshActor::GetComponentKey(instance_component, mesh, category);
		FInstancedComponentsEntry new_entry(instance_component, category);
		entry = &actor->InstancedComponents.Add(container_reference, new_entry);
	}
	else {
		FString container_reference = AAutoInstancedStaticMeshActor::GetComponentKey(component, mesh, category);

		UE_LOG(LogTemp, Error, TEXT("___ %s ____ "), *container_reference);

		entry = actor->InstancedComponents.Find(container_reference);
		if (entry == nullptr || entry->Category != category) {
			/*=============================== USE THIS TO SEND TO A CHUNK - the actor needs to be created in this level rather than on the world
			component->GetComponentLevel()
			*/
			instance_component = AAutoInstancedStaticMeshActor::CreateComponent(mesh, mobility, collisionProfileName, actor);

			FInstancedComponentsEntry new_entry(instance_component, category);
			entry = &actor->InstancedComponents.Add(container_reference, new_entry);
		}
		else {
			// add instance at this transform
			instance_component = entry->Component;
		}
	}
	return entry;
}

FString AAutoInstancedStaticMeshActor::GetComponentKey(UObject* mesh_owner, UStaticMesh* mesh, EInstancedCategory category)
{
	return UCommon::GetReferencePath(mesh)
		.Append(TEXT("_category_"))
		.Append(FString::FromInt(static_cast<int>(category)))
		.Append(TEXT("_i_"))
		.Append(FString::FromInt(mesh_owner->GetUniqueID()));

	/*return UCommon::GetReferencePath(mesh)
		.Append(TEXT("_category_"))
		.Append(FString::FromInt(static_cast<int>(category)))
		.Append(TEXT("_i_"))
		.Append(GetNameSafe(mesh_owner));*/

		//return GetPathNameSafe(mesh_owner);
		/*return UCommon::GetReferencePath(mesh)
			.Append(TEXT("_category_"))
			.Append(FString::FromInt(static_cast<int>(category)))
			.Append(TEXT("_i_"))
			.Append(FString::FromInt(mesh_owner->GetUniqueID()));*/
}

FString AAutoInstancedStaticMeshActor::GetComponentKey(UHierarchicalInstancedStaticMeshComponent* component, EInstancedCategory category)
{
	return AAutoInstancedStaticMeshActor::GetComponentKey(component, component->GetStaticMesh(), category);
}

void AAutoInstancedStaticMeshActor::DestroyComponent(USceneComponent* target)
{
	target->DestroyComponent();
}