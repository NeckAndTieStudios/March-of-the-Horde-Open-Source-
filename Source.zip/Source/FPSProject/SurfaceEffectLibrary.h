// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "ContentResolver.h"
//#include "GlobalGameInstance.h"
#include "SurfaceEffectLibrary.generated.h"

/**
*
*/
UCLASS()
class FPSPROJECT_API USurfaceEffectLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()



public:

	UFUNCTION(BlueprintCallable, Category = "Surface Effect")
		static USurfaceEffect* GetSurfaceEffect(int surfaceEffectID, UGlobalGameInstance* gameInstance);

	UFUNCTION(BlueprintCallable, Category = "Surface Effect")
		static USurfaceEffect* GetSurfaceEffectBySurfaceType(int surfaceTypeID, UGlobalGameInstance* gameInstance);
};




//UCLASS()
//class FPSPROJECT_API U3dDecalLibrary : public UBlueprintFunctionLibrary
//{
//	GENERATED_BODY()
//
//
//
//public:
//
//	UFUNCTION(BlueprintCallable, Category = "3d Decal")
//		static void Spawn3dDecal(FVector location, FRotator rotation);
//};