// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Weapon.h"
//#include "GlobalGameInstance.h"
#include "ItemComponent.h"
#include "PrimitiveWeapon.generated.h"

UCLASS()
class FPSPROJECT_API APrimitiveWeapon : public AWeapon
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	APrimitiveWeapon();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	/*UPROPERTY(EditAnywhere, BlueprintReadOnly)
		UGlobalGameInstance * GameInstance;*/

public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float StrikeRadialSize = 7.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float StrikeSpeed = 700.f; //m/s

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float StrikeDamage = 10.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool CanTriggerPrimary = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool CanTriggerSecondary = true;

	void OnPrimaryPressed() override;
	void OnSecondaryPressed() override;
};
