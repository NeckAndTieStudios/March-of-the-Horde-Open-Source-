// Fill out your copyright notice in the Description page of Project Settings.

#include "ContentResolver.h"
#include "GlobalGameInstance.h"
#include "Engine.h"

UContentResolver* UContentResolver::Instance = NULL;

void UContentResolver::Initialise()
{

}

TArray<UItemComponent*> UContentResolver::ResolveInteraction(EInteractionTrigger trigger, FHitResult hit_result, AActor * initiator, bool process)
{
	TArray<UItemComponent*> components;
	return components;
}

//UItemInstance* UContentResolver::ResolveItemByID(int itemID)
//{
//	return NULL;
//}

//UItemInstance* UContentResolver::ResolveItemByAlias(const FString& alias)
//{
//	return NULL;
//}

//UItemAliasInstance* UContentResolver::ResolveAliasForItem(UItemInstance* item)
//{
//	return NULL;
//}

//TArray<UItemAliasInstance*> UContentResolver::ResolveAliases()
//{
//	TArray<UItemAliasInstance *> results;
//	return results;
//}

//TArray<UItemInstance *> UContentResolver::ResolveLootForItem(UItemInstance* item, EInteractionTrigger trigger)
//{
//	TArray<UItemInstance *> results;
//	return results;
//}

//TArray<UItemInstance *> UContentResolver::ResolveRecipes(UObject* owner)
//{
//	TArray<UItemInstance *> results;
//	return results;
//}

//TArray<UItemInstance *> UContentResolver::ResolveRecipesForItem(UItemInstance* item)
//{
//	TArray<UItemInstance *> results;
//	return results;
//}

//TArray<UItemInstance *> UContentResolver::ResolveIngredientsForItem(UItemInstance* item)
//{
//	TArray<UItemInstance *> results;
//	return results;
//}

//TArray<UItemInteraction *> UContentResolver::ResolveInteractionsForItem(UItemInstance* item)
//{
//	TArray<UItemInteraction *> results;
//	return results;
//}

//void UContentResolver::ResolveAttributesForItem(UItemInstance* &item)
//{
//
//}

//TArray<UItemUpgradeInstance *>  UContentResolver::ResolveUpgradesForItem(UItemInstance* item)
//{
//	TArray<UItemUpgradeInstance *> results;
//	return results;
//}
//
//TArray<UItemRepairInstance *>  UContentResolver::ResolveRepairRequirementsForItem(UItemInstance* item)
//{
//	TArray<UItemRepairInstance *> results;
//	return results;
//}

UClass* UContentResolver::ResolveBlueprint(const FString& reference)
{
	//FString class_reference = FString(reference).Append(TEXT("_C"));
	////class_reference.InsertAt(reference.Len() - 1, TEXT("_C"));
	//
	//UClass* bp_class = this->FindClass(class_reference);
	//if (!bp_class) {
	//	FString blueprint_reference = FString(TEXT("Blueprint'")).Append(reference).Append(TEXT("'"));
	//	UObject* obj = StaticLoadObject(UObject::StaticClass(), nullptr, *blueprint_reference);
	//	bp_class = Cast<UClass>(obj);
	//	if (!bp_class) {
	//		UBlueprint* bp = Cast<UBlueprint>(obj);
	//		if (bp) {
	//			bp_class = (UClass*)bp->GeneratedClass;
	//		}
	//	}
	//}


	UClass* bp_class = NULL;

	UObject* obj = StaticLoadObject(UObject::StaticClass(), nullptr, *reference);
	if (obj) {
		bp_class = Cast<UClass>(obj);
		if (!bp_class) {
			UBlueprint* bp = Cast<UBlueprint>(obj);
			if (bp) {
				bp_class = (UClass*)bp->GeneratedClass;
			}
		}
	}

	if (!bp_class) {
		FString class_reference = FString(reference);
		FString blueprint = FString("Blueprint'");

		if (class_reference.StartsWith(blueprint))
		{
			class_reference.RemoveFromStart(blueprint, ESearchCase::IgnoreCase);
			class_reference.RemoveFromEnd(FString("'"), ESearchCase::IgnoreCase);
			class_reference.Append("_C");

			bp_class = this->FindObjectByReference<UClass>(class_reference);
		}
	}

	return bp_class;
}

void UContentResolver::AddInteractionAtLocation(FHitResult hitResult, UPrimitiveComponent* component, int damage, float radius, float strength)
{

}