#pragma once

#include "CoreMinimal.h"
#include "ItemGroupType.generated.h"

UENUM(BlueprintType)
enum class EItemGroupType : uint8
{
	Bullet = 4 UMETA(DisplayName = "Bullet"), 
	Glass = 2 UMETA(DisplayName = "Glass"), 
	Hand = 6 UMETA(DisplayName = "Hand"), 
	None = 0 UMETA(DisplayName = "None"), 
	Primitive_Tool = 5 UMETA(DisplayName = "Primitive Tool"), 
	Stone = 3 UMETA(DisplayName = "Stone"), 
	Wood = 1 UMETA(DisplayName = "Wood"), 
 };