#pragma once

#include "CoreMinimal.h"
#include "ItemContainerMap.generated.h"

UENUM(BlueprintType)
enum class EItemContainerMap : uint8
{
	Unknown = 0 UMETA(DisplayName = "Unknown"), 
	Ammo_Box_Small = 14 UMETA(DisplayName = "Ammo Box - Small"), 
	Archive_Drawers = 9 UMETA(DisplayName = "Archive Drawers"), 
	Backpack = 11 UMETA(DisplayName = "Backpack"), 
	Bag = 12 UMETA(DisplayName = "Bag"), 
	Carton_Large = 8 UMETA(DisplayName = "Carton - Large"), 
	Carton_Small = 7 UMETA(DisplayName = "Carton - Small"), 
	Esky_Small = 16 UMETA(DisplayName = "Esky - Small"), 
	Forklift = 13 UMETA(DisplayName = "Forklift"), 
	Large_Toolbox = 20 UMETA(DisplayName = "Large Toolbox"), 
	Lockers = 10 UMETA(DisplayName = "Lockers"), 
	PortaPotty = 1 UMETA(DisplayName = "PortaPotty"), 
	Russian_Box = 15 UMETA(DisplayName = "Russian Box"), 
	Tool_Bench = 18 UMETA(DisplayName = "Tool Bench"), 
	Trash_bag = 6 UMETA(DisplayName = "Trash bag"), 
	Trash_bin = 19 UMETA(DisplayName = "Trash bin"), 
	Truck_Box = 3 UMETA(DisplayName = "Truck - Box"), 
	Truck_Door = 5 UMETA(DisplayName = "Truck - Door"), 
	Truck_Fuel = 2 UMETA(DisplayName = "Truck - Fuel"), 
	Truck_Toolbox = 4 UMETA(DisplayName = "Truck - Toolbox"), 
	Wooden_Crate = 17 UMETA(DisplayName = "Wooden Crate"), 
 };