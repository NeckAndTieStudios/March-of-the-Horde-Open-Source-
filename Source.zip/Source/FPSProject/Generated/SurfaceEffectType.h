#pragma once

#include "CoreMinimal.h"
#include "SurfaceEffectType.generated.h"

UENUM(BlueprintType)
enum class ESurfaceEffectType : uint8
{
	Asphalt = 14 UMETA(DisplayName = "Asphalt"), 
	Brick = 21 UMETA(DisplayName = "Brick"), 
	Cardboard = 9 UMETA(DisplayName = "Cardboard"), 
	Cloth = 13 UMETA(DisplayName = "Cloth"), 
	Dirt = 10 UMETA(DisplayName = "Dirt"), 
	Electronics = 11 UMETA(DisplayName = "Electronics"), 
	Fern_Hit = 19 UMETA(DisplayName = "Fern - Hit"), 
	Generic_Hit = 8 UMETA(DisplayName = "Generic - Hit"), 
	Glass_Hit = 3 UMETA(DisplayName = "Glass - Hit"), 
	Grass_Hit = 4 UMETA(DisplayName = "Grass - Hit"), 
	Metal = 15 UMETA(DisplayName = "Metal"), 
	Paper = 18 UMETA(DisplayName = "Paper"), 
	Plaster = 12 UMETA(DisplayName = "Plaster"), 
	Plastic = 16 UMETA(DisplayName = "Plastic"), 
	Rock_Axe = 7 UMETA(DisplayName = "Rock - Axe"), 
	Rock_Hit = 6 UMETA(DisplayName = "Rock - Hit"), 
	Shrub_Hit = 5 UMETA(DisplayName = "Shrub - Hit"), 
	Tree_Axe = 2 UMETA(DisplayName = "Tree - Axe"), 
	Tree_Hit = 1 UMETA(DisplayName = "Tree - Hit"), 
	Unknown = 0 UMETA(DisplayName = "Unknown"), 
	Wood_Basic = 17 UMETA(DisplayName = "Wood - Basic"), 
	Wood_Destroyed = 20 UMETA(DisplayName = "Wood - Destroyed"), 
 };