// Fill out your copyright notice in the Description page of Project Settings.

#include "BuildingComponent.h" 
//#include "Modules/ModuleInterface.h"
//#include "Modules/ModuleManager.h"
//#include "Presentation/PropertyEditor/PropertyEditor.h"
//#include "ComponentUtils.h"

UBuildingComponent::UBuildingComponent()
{
	//this->bMultiBodyOverlap = true;
}

#if WITH_EDITOR
void UBuildingComponent::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	if (PropertyChangedEvent.Property != NULL)
	{
		// Only permit editing archetype or instance if instance was changed by an archetype
		if (PropertyChangedEvent.Property->GetFName() == "PerInstanceSMData" && (HasAnyFlags(RF_ArchetypeObject | RF_ClassDefaultObject) || PropertyChangedEvent.HasArchetypeInstanceChanged(this)))
		{

			if (PropertyChangedEvent.ChangeType == EPropertyChangeType::ArrayRemove)
			{
				int32 RemovedAtIndex = PropertyChangedEvent.GetArrayIndex(PropertyChangedEvent.Property->GetFName().ToString());
				check(RemovedAtIndex != INDEX_NONE);

			}
		}
	}
	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void UBuildingComponent::PostEditChangeChainProperty(FPropertyChangedChainEvent& PropertyChangedEvent)
{
	if (PropertyChangedEvent.Property != NULL)
	{
		// Only permit editing archetype or instance if instance was changed by an archetype
		if (PropertyChangedEvent.Property->GetFName() == "PerInstanceSMData" && (HasAnyFlags(RF_ArchetypeObject | RF_ClassDefaultObject) || PropertyChangedEvent.HasArchetypeInstanceChanged(this)))
		{
			TArray<UObject*> ArchetypeInstances;

			if (PropertyChangedEvent.ChangeType == EPropertyChangeType::ArrayRemove)
			{
				int32 RemovedAtIndex = PropertyChangedEvent.GetArrayIndex(PropertyChangedEvent.Property->GetFName().ToString());
				check(RemovedAtIndex != INDEX_NONE);

				//if (ChildrenAreAttachments)
				//{
				//auto len = this->PerInstanceSMData.Num();
				//auto components = UBuildingComponent::GetAllComponents(this);
				//for (auto link : components)
				//{
				//	if (link.Component->PerInstanceSMData.Num() > len) {
				//		// mark in scope transaction
				//		link.Component->Modify();
				//		link.Component->RemoveInstanceSingle(RemovedAtIndex);
				//	}
				//	if (link.Component->CustomPerInstanceSMData.Num() > len) {
				//		// mark in scope transaction
				//		link.Component->Modify();
				//		link.Component->RemoveInstanceData(RemovedAtIndex);
				//	}
				//}

				PostDeleteInstance(RemovedAtIndex);

				//}

				//// building component logic
				//{
				//	this->RemoveInstanceData(RemovedAtIndex);

				//	if (ChildrenAreAttachments)
				//	{
				//		ArchetypeInstances.Empty();
				//		this->GetArchetypeInstances(ArchetypeInstances);

				//		for (UObject* obj : ArchetypeInstances)
				//		{
				//			auto abc = Cast<UHierarchicalInstancedStaticMeshComponent>(obj);
				//			if (abc) {
				//				abc->Modify();
				//				abc->InstanceReorderTable.Empty();
				//				//abc->BuildTreeIfOutdated(false, false);
				//				abc->RemoveInstance(RemovedAtIndex);
				//			}
				//		}

				//		TArray<USceneComponent*> children;

				//		// add the view port instances
				//		this->GetChildrenComponents(true, children);

				//		// remove editor instances
				//		UBuildingComponent::FindAllChildrenComponents(this, children);

				//		for (int i = 0; i < children.Num(); i++) {
				//			auto sub_building = Cast<UBuildingComponent>(children[i]);
				//			if (sub_building) {
				//				sub_building->Modify();
				//				sub_building->InstanceReorderTable.Empty();
				//				//sub_building->BuildTreeIfOutdated(false, false);
				//				sub_building->RemoveInstance(RemovedAtIndex);

				//				ArchetypeInstances.Empty();
				//				sub_building->GetArchetypeInstances(ArchetypeInstances);

				//				for (UObject* obj : ArchetypeInstances)
				//				{
				//					auto abc = Cast<UHierarchicalInstancedStaticMeshComponent>(obj);
				//					if (abc) {
				//						abc->Modify();
				//						abc->InstanceReorderTable.Empty();
				//						//abc->BuildTreeIfOutdated(false, false);
				//						abc->RemoveInstance(RemovedAtIndex);
				//					}
				//				}
				//			}
				//		}
				//	}
				//}

				// BUG FIX FOR UE HISM BUG - will crash when you have 10 instances and delete index 0. the bug is internally registered at Epic Games so no public issue was created...
				// basically the temp fix is to clear the reorder table and force it to be rebuilt (UE will do this after ;) ), the real fix is for UE to ensure all arrays are in sync 
				// by not using Super:: code since ISM has no idea about HISM arrays (or yet, at least since reflection is a thing).
				//
				//RemoveInstanceInternal(RemovedAtIndex, true);
				// InstanceReorderTable could be empty for a 'bad' HISMC, (eg. missing mesh)
				//if (InstanceReorderTable.IsValidIndex(RemovedAtIndex))
				{
					// Due to scalability it's possible that we try to remove an instance that is not valid in the reorder table as it was removed already from render
					/*int32 RenderIndex = InstanceReorderTable[RemovedAtIndex];
					if (RenderIndex != INDEX_NONE)
					{
						InstanceUpdateCmdBuffer.HideInstance(RenderIndex);
					}*/

					//this->InstanceReorderTable.RemoveAtSwap(RemovedAtIndex, 1, false);

					this->InstanceReorderTable.Empty();
					//BuildTreeIfOutdated(false, false);
				}
			}
			else if (PropertyChangedEvent.ChangeType == EPropertyChangeType::ArrayAdd)
			{
				int32 InsertedIndex = PropertyChangedEvent.GetArrayIndex(PropertyChangedEvent.Property->GetFName().ToString());
				check(InsertedIndex != INDEX_NONE);

				PostAddInstance(InsertedIndex);

				//auto transform = FTransform(this->PerInstanceSMData[InsertedIndex].Transform);

				//auto components = UBuildingComponent::GetAllComponents(this);
				//for (auto link : components)
				//{
				//	if (link.Component->PerInstanceSMData.Num() == InsertedIndex) {
				//		// mark in scope transaction
				//		link.Component->Modify();

				//		auto add_index = link.Component->AddInstanceSingle(transform);

				//		// ensure it was added where its expected to
				//		check(add_index == InsertedIndex);
				//	}
				//	link.Component->SetInstanceDefaults(InsertedIndex);
				//	
				//	// update HISM arrays
				//	link.Component->BuildTreeIfOutdated(false, false);
				//}

				//// building component logic
				//{
				//	this->SetInstanceDefaults(InsertedIndex);

				//	if (ChildrenAreAttachments)
				//	{
				//		BuildTreeIfOutdated(false, false);

				//		FTransform tfm = FTransform();
				//		this->GetInstanceTransform(InsertedIndex, tfm);

				//		ArchetypeInstances.Empty();
				//		this->GetArchetypeInstances(ArchetypeInstances);

				//		for (UObject* obj : ArchetypeInstances)
				//		{
				//			auto abc = Cast<UHierarchicalInstancedStaticMeshComponent>(obj);
				//			if (abc) {
				//				abc->Modify();
				//				abc->InstanceReorderTable.Empty();
				//				abc->BuildTreeIfOutdated(false, false);
				//				abc->AddInstance(tfm);
				//			}
				//		}

				//		TArray<USceneComponent*> children;

				//		// add the view port instances
				//		this->GetChildrenComponents(true, children);

				//		// remove editor instances
				//		UBuildingComponent::FindAllChildrenComponents(this, children); //  (no reset!)

				//		for (int i = 0; i < children.Num(); i++) {
				//			auto sub_building = Cast<UBuildingComponent>(children[i]);
				//			if (sub_building) {
				//				sub_building->Modify();
				//				sub_building->InstanceReorderTable.Empty();
				//				sub_building->BuildTreeIfOutdated(false, false);
				//				sub_building->AddInstance(tfm);

				//				ArchetypeInstances.Empty();
				//				sub_building->GetArchetypeInstances(ArchetypeInstances);

				//				for (UObject* obj : ArchetypeInstances)
				//				{
				//					auto abc = Cast<UHierarchicalInstancedStaticMeshComponent>(obj);
				//					if (abc) {
				//						abc->Modify();
				//						abc->InstanceReorderTable.Empty();
				//						abc->BuildTreeIfOutdated(false, false);
				//						abc->AddInstance(tfm);
				//					}
				//				}
				//			}
				//		}
				//	}
				//}
			}
			else if (PropertyChangedEvent.ChangeType == EPropertyChangeType::Duplicate)
			{
				int32 DuplicatedIndex = PropertyChangedEvent.GetArrayIndex(PropertyChangedEvent.Property->GetFName().ToString());
				check(DuplicatedIndex != INDEX_NONE);

				if (this->PerInstanceSMData.Num() > 0)
				{
					auto InsertedIndex = this->PerInstanceSMData.Num() - 1;
					this->PostDuplicateInstance(DuplicatedIndex, InsertedIndex);

					//auto components = this->PostAddInstance(InsertedIndex);



					//auto transform = FTransform(this->PerInstanceSMData[DuplicatedIndex].Transform);
					//auto InsertedIndex = this->PerInstanceSMData.Num() - 1;

					//auto components = UBuildingComponent::GetAllComponents(this);
					//for (auto link : components)
					//{
					//	//// if children are not synced then do not process them.
					//	//if (!ChildrenAreAttachments && (link.Type != ELinkedComponentType::Root && link.Type != ELinkedComponentType::Root))
					//	//	continue;

					//	if (link.Component->PerInstanceSMData.Num() == InsertedIndex) {
					//		// mark in scope transaction
					//		link.Component->Modify();

					//		auto add_index = link.Component->AddInstanceSingle(transform);

					//		// ensure it was added where its expected to
					//		check(add_index == InsertedIndex);
					//		// ensure the data array is synced
					//		link.Component->SetInstanceDefaults(InsertedIndex);
					//		// copy the data
					//		link.Component->CustomPerInstanceSMData[InsertedIndex] = link.Component->CustomPerInstanceSMData[DuplicatedIndex].Duplicate();
					//	}
					//}
				}

				//this->SetInstanceDefaults(this->CustomPerInstanceSMData.Num()); // will create a new record if not exists

				//auto new_index = this->CustomPerInstanceSMData.Num() - 1;

				//this->CustomPerInstanceSMData[new_index] = this->CustomPerInstanceSMData[DuplicatedIndex].Duplicate();

				//if (ChildrenAreAttachments)
				//{
				//	BuildTreeIfOutdated(false, false);

				//	FTransform tfm = FTransform();
				//	this->GetInstanceTransform(new_index, tfm);

				//	ArchetypeInstances.Empty();
				//	this->GetArchetypeInstances(ArchetypeInstances);

				//	for (UObject* obj : ArchetypeInstances)
				//	{
				//		auto abc = Cast<UBuildingComponent>(obj);
				//		if (abc) {
				//			abc->Modify();
				//			abc->InstanceReorderTable.Empty();
				//			abc->BuildTreeIfOutdated(false, false);
				//			abc->AddInstance(tfm);

				//			abc->SetInstanceDefaults(new_index); // will create a new record if not exists
				//			abc->CustomPerInstanceSMData[new_index] = abc->CustomPerInstanceSMData[DuplicatedIndex].Duplicate();
				//		}
				//	}

				//	TArray<USceneComponent*> children;

				//	// add the view port instances
				//	this->GetChildrenComponents(true, children);

				//	// remove editor instances
				//	UBuildingComponent::FindAllChildrenComponents(this, children); //  (no reset!)

				//	for (int i = 0; i < children.Num(); i++) {
				//		auto sub_building = Cast<UBuildingComponent>(children[i]);
				//		if (sub_building) {
				//			sub_building->Modify();
				//			sub_building->InstanceReorderTable.Empty();
				//			sub_building->BuildTreeIfOutdated(false, false);
				//			sub_building->AddInstance(tfm);

				//			sub_building->CustomPerInstanceSMData[new_index] = sub_building->CustomPerInstanceSMData[DuplicatedIndex].Duplicate();

				//			ArchetypeInstances.Empty();
				//			sub_building->GetArchetypeInstances(ArchetypeInstances);

				//			for (UObject* obj : ArchetypeInstances)
				//			{
				//				auto abc = Cast<UBuildingComponent>(obj);
				//				if (abc) {
				//					abc->Modify();
				//					abc->InstanceReorderTable.Empty();
				//					abc->BuildTreeIfOutdated(false, false);
				//					abc->AddInstance(tfm);

				//					abc->SetInstanceDefaults(new_index); // will create a new record if not exists
				//					abc->CustomPerInstanceSMData[new_index] = abc->CustomPerInstanceSMData[DuplicatedIndex].Duplicate();
				//				}
				//			}
				//		}
				//	}
				//}
			}
			else if (PropertyChangedEvent.ChangeType == EPropertyChangeType::ArrayClear)
			{
				auto components = UBuildingComponent::GetAllComponents(this);
				for (auto link : components)
				{
					link.Component->Modify();
					link.Component->ClearInstances();
					auto bc = Cast<UBuildingComponent>(link.Component);
					if (bc) {
						bc->CustomPerInstanceSMData.Empty();
					}
				}

				//this->CustomPerInstanceSMData.Empty();
				//if (ChildrenAreAttachments)
				//{
				//	ArchetypeInstances.Empty();
				//	this->GetArchetypeInstances(ArchetypeInstances);

				//	for (UObject* obj : ArchetypeInstances)
				//	{
				//		auto abc = Cast<UBuildingComponent>(obj);
				//		if (abc) {
				//			abc->Modify();
				//			abc->CustomPerInstanceSMData.Empty();
				//		}
				//	}

				//	TArray<USceneComponent*> children;

				//	// add the view port instances
				//	this->GetChildrenComponents(true, children);

				//	// remove editor instances
				//	UBuildingComponent::FindAllChildrenComponents(this, children); //  (no reset!)

				//	for (int i = 0; i < children.Num(); i++) {
				//		auto sub_building = Cast<UBuildingComponent>(children[i]);
				//		if (sub_building) {
				//			sub_building->Modify();
				//			sub_building->CustomPerInstanceSMData.Empty();

				//			ArchetypeInstances.Empty();
				//			sub_building->GetArchetypeInstances(ArchetypeInstances);

				//			for (UObject* obj : ArchetypeInstances)
				//			{
				//				auto abc = Cast<UBuildingComponent>(obj);
				//				if (abc) {
				//					abc->Modify();
				//					abc->CustomPerInstanceSMData.Empty();
				//				}
				//			}
				//		}
				//	}
				//}
			}
		}
	}
	//BuildTreeIfOutdated(false, false);
	Super::PostEditChangeChainProperty(PropertyChangedEvent);
}
#endif