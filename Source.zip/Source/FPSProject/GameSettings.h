// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameSettings.generated.h"

/**
 * 
 */
UCLASS(Blueprintable, BlueprintType)
class FPSPROJECT_API UGameSettings : public UObject
{
	GENERATED_BODY()

public:
	static UGameSettings * Instance;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = Bullet)
	bool BulletDebugLines = false;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = Bullet)
		bool BulletDebugInfo = false;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = Bullet)
		bool FireSound = false;

	// 0 = infinite
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = Bullet)
		float MaxDecalLifetime = 0.f;

	// 0 = use bullet speed, otherwise this fixed value
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = Bullet)
		float BulletImpulseVelocity = 0.f;

	// 0 = infinite
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = Bullet)
		float MaxDecals = 250.f;

	// Number of tool belts to render
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = Bullet)
		int ToolBelts = 2;

	//// Number of tool belt slots - populated from an external component
	//UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = Bullet)
	//	int ToolBeltSlots = 0;

	//// Number of inventory slots - populated from an external component
	//UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = Bullet)
	//	int InventorySlots = 0;
};
