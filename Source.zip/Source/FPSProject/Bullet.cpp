#include "Bullet.h"
#include "CollisionQueryParams.h"
#include "Engine/World.h"
#include "DrawDebugHelpers.h"
#include "UObject/ConstructorHelpers.h"
#include "Casts.h"
#include "PhysicalMaterials/PhysicalMaterial.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetMathLibrary.h"
#include "DestructibleComponent.h"
#include "GlobalBulletSettings.h"
#include "Engine.h"
#include "Common.h"
#include "GameSettings.h"
#include "FPSCharacter.h"
#include "GlobalGameInstance.h"

DEFINE_STAT(STAT_BulletTick);
DEFINE_STAT(STAT_BulletHit);
DEFINE_STAT(STAT_BulletPenetrate);
DEFINE_STAT(STAT_BulletRicochet);
DEFINE_STAT(STAT_BulletCalculateTraceLength);
DEFINE_STAT(STAT_BulletAddInteractionAtLocation);
DEFINE_STAT(STAT_BulletRespawn);
DEFINE_STAT(STAT_BulletRestart);
DEFINE_STAT(STAT_BulletGetSettingsFromHit);
DEFINE_STAT(STAT_BulletAddSmokeTracerPoint);
DEFINE_STAT(STAT_BulletOnDestroy);

// Sets default values
ABullet::ABullet()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	//RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootComponent"));
	////RootComponent->Mobility = EComponentMobility::Static;
	//RootComponent->SetMobility(EComponentMobility::Static);

	this->MuzzleTracer = CreateDefaultSubobject<UStaticMeshComponent>(FName("MuzzleTracer"));
	this->SmokeTracer = CreateDefaultSubobject<UStaticMesh>(FName("PenetrationTracer"));

	//// only need one material for our group of smoke tracers - they are created so fast, they can be faded out at once
	//this->smokeMaterial = UMaterialInstanceDynamic::Create(this->SmokeTracer->GetMaterial(0), RootComponent);
	//this->smokeMaterial->SetScalarParameterValue(TEXT("Opacity"), 1.f);

	this->CollisionProjectileActive = false;
}

// Called when the game starts or when spawned
void ABullet::BeginPlay()
{
	Super::BeginPlay();

	//this->GameInstance = GetWorld()->GetGameInstance<UGlobalGameInstance>();

	this->InitialPosition = this->GetActorLocation();
	this->CurrentPosition = this->InitialPosition;
	this->CurrentRotation = this->GetActorRotation();
	this->InitialSpeed = this->Speed;

	this->PenetrationTracerSpline = NewObject<USplineComponent>(this, USplineComponent::StaticClass());
	this->PenetrationTracerSpline->AttachToComponent(this->RootComponent, FAttachmentTransformRules::KeepWorldTransform);
	this->PenetrationTracerSpline->ClearSplinePoints();

	this->Restart(true);

	// only need one material for our group of smoke tracers - they are created so fast, they can be faded out at once
	this->smokeMaterial = UMaterialInstanceDynamic::Create(this->SmokeTracer->GetMaterial(0), this);
	this->smokeMaterial->SetScalarParameterValue(TEXT("Opacity"), 1.f);

	this->Distance = 0;
}

// Called when the game starts or when spawned
void ABullet::Restart(bool reset_tracer)
{
	SCOPE_CYCLE_COUNTER(STAT_BulletRestart);
	if (GEngine && UGameSettings::Instance->BulletDebugInfo) {
		GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("RESET"));
	}

	this->InitialPosition = this->CurrentPosition;

	this->Time = 0;
	//this->CollisionProjectileActive = false;

	if (this->MuzzleTracer) {
		//this->MuzzleTracer->SetWorldLocation(this->CurrentPosition);
		//this->MuzzleTracer->SetWorldRotation(this->CurrentRotation);
		this->MuzzleTracer->SetWorldLocationAndRotation(this->CurrentPosition, this->CurrentRotation);
		this->MuzzleTracer->SetVisibility(true);
	}

	if (GetWorld()->GetTimerManager().IsTimerActive(this->TracerTimeoutHandle)) {
		GetWorld()->GetTimerManager().ClearTimer(this->TracerTimeoutHandle);
	}
}

void ABullet::Respawn(FVector location, FRotator rotation)
{
	SCOPE_CYCLE_COUNTER(STAT_BulletRespawn);
	this->FramesSkipped = 0;
	this->IsDestroyed = false;
	//this->IsSmoking = false;
	this->Distance = 0;
	this->Ricochets = 0;
	this->Penetrations = 0;
	this->InitialPosition = location;
	this->CurrentPosition = location;
	this->CurrentRotation = rotation;
	this->CurrentTracerCount = 0;
	this->Speed = this->InitialSpeed;
	this->CollisionProjectileActive = false;
	//bullet->PrimaryActorTick.bCanEverTick = true;
	this->SetActorTickEnabled(true);

	this->_instancePenetrationTracerMaxLength = FMath::RandRange(this->PenetrationTracerMaxLengthMin, this->PenetrationTracerMaxLengthMax);

	this->Restart(true);
}

// calculates the length of a trace
// formula: //sqrt((b1 - a1)� + (b2 - a2)� + b3�)
// returns the dinstance in meters
// TODO: use Distance on the FHitResult
float CalculateTraceLength(FVector start, FVector end)
{
	SCOPE_CYCLE_COUNTER(STAT_BulletCalculateTraceLength);
	return FMath::Sqrt(
		FMath::Pow(end.Y - start.Y, 2) +
		FMath::Pow(end.X - start.X, 2) +
		FMath::Pow(end.Z, 2)
	) / (100.f /*cm=>meters*/ * 2.f /*number of components*/);
}

// vertical time of flight =  sqrt(-<height off ground> / -4.9)
// horizontal displacement = <x speed> * <vertical time of flight>
// speed = <final horizontal pos> / sqrt(-<height off ground> / -4.9)
// veritcal displacement = <y speed> * <vertical time of flight>

void ABullet::AddInteractionAtLocation(FVector location, FGlobalBulletSettings surfaceSettingsx, UPrimitiveComponent * component, FRotator direction)
{
	SCOPE_CYCLE_COUNTER(STAT_BulletAddInteractionAtLocation);
	//if (surfaceSettings)
	{
		// destruction
		{
			if (component)
			{
				UDestructibleComponent* dm = NULL;
				float power = (this->Speed / this->InitialSpeed) * this->ImpactForce;

				if (true) //surfaceSettings.AllowDamage)
				{
					dm = Cast<UDestructibleComponent>(component);
				}
				if (dm)
				{
					dm->ApplyRadiusDamage(this->Damage * power, location, this->DamageRadius, this->Speed, true);
				}
				//if (surfaceSettings.AllowHitImpulse && component && component->IsSimulatingPhysics())
				if (component && component->Mobility == EComponentMobility::Movable && component->IsSimulatingPhysics())
				{
					//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, surfaceSettings.Name);
					float impulseVelocity = UGameSettings::Instance->BulletImpulseVelocity;
					if (impulseVelocity == 0) {
						impulseVelocity = this->Speed;
					}
					//if (invert) {
					//	/*auto mtx = FRotationMatrix(this->CurrentRotation);
					//	mtx.Mirror(EAxis::X, EAxis::X);
					//	component->AddImpulseAtLocation(mtx.GetScaledAxis(EAxis::X) * impulseVelocity, location);*/
					//	component->AddImpulseAtLocation(FRotationMatrix(this->CurrentRotation.GetInverse()).GetScaledAxis(EAxis::X) * (impulseVelocity), location);
					//	DrawDebugSolidBox(GetWorld(), location, FVector(3.f), FColor::Purple, true, this->MaxLifeTime);
					//}
					//else {
					component->AddImpulseAtLocation(FRotationMatrix(direction).GetScaledAxis(EAxis::X) * impulseVelocity * 10, location);
					//	DrawDebugSolidBox(GetWorld(), location, FVector(3.f), FColor::Orange, true, this->MaxLifeTime);
					//}
				}
				else {
					//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("No impulse"));
				}
			}
		}
	}
}

FGlobalBulletSettings ABullet::GetSettingsFromHit(FHitResult hit, UAssetItemComponent * assetComponent)
{
	SCOPE_CYCLE_COUNTER(STAT_BulletGetSettingsFromHit);
	FGlobalBulletSettings surfaceSettings;// = NULL;
	auto physicalMaterial = hit.PhysMaterial.Get();

	if (physicalMaterial) {
		auto surfaceType = physicalMaterial->SurfaceType;
		if (assetComponent && !assetComponent->InheritBulletSettings /*&& assetComponent->BulletSettings*/) {
			if (GEngine && UGameSettings::Instance->BulletDebugInfo) {
				GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("Asset component override"));
			}
			surfaceSettings = assetComponent->BulletSettings;
		}
		else {
			surfaceSettings = GetWorld()->GetGameInstance<UGlobalGameInstance>()->GetBySurfaceType((uint8)surfaceType.GetValue());
		}
	}
	else {
		if (GEngine && UGameSettings::Instance->BulletDebugInfo) {
			GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("No physical material"));
		}
		surfaceSettings = GetWorld()->GetGameInstance<UGlobalGameInstance>()->GetBySurfaceType((uint8)EPhysicalSurface::SurfaceType_Default);
	}

	return surfaceSettings;
}

void ABullet::OnHit(FHitResult hit_result, FVector trace_start, FVector trace_end)
{
	SCOPE_CYCLE_COUNTER(STAT_BulletHit);

	this->OnHit(hit_result);

	UAssetItemComponent* assetComponent = NULL;
	auto component = hit_result.GetComponent();
	auto actor = hit_result.GetActor();
	bool has_actioned = false;
	FGlobalBulletSettings surfaceSettings;// = NULL;
	auto physicalMaterial = hit_result.PhysMaterial.Get();

	if (actor)
	{
		auto aic = Cast<UAssetItemComponent>(actor->GetComponentByClass(UAssetItemComponent::StaticClass()));
		if (aic)
		{
			assetComponent = aic;
		}
	}

	surfaceSettings = this->GetSettingsFromHit(hit_result, assetComponent);
	auto bulletTypeSettings = surfaceSettings.GetBulletTypeSetting((uint8)this->Type);

	FVector actor_location = hit_result.ImpactPoint;

	const int default_task = 1000;
	int tasks_min = default_task;
	int tasks_max = -default_task;

	/*if (bulletTypeSettings.Penetration)
	{
		tasks_min = FMath::Min(tasks_min, 1);
		tasks_max = FMath::Max(tasks_max, 1);
	}*/

	//if (bulletTypeSettings.Ricochet)
	{
		tasks_min = FMath::Min(tasks_min, 2);
		tasks_max = FMath::Max(tasks_max, 2);
	}

	if (tasks_min > 0 && tasks_max > 0 && tasks_min < default_task && tasks_max < default_task)
	{
		int task = 0;

		if (tasks_min == tasks_max)
		{
			task = tasks_min;
		}
		else
		{
			task = FMath::RandRange(tasks_min, tasks_max);
		}

		// penetrate
		if (task == 1)
		{
			if (!this->OnPenetrate(actor_location, hit_result, trace_start, trace_end, assetComponent, surfaceSettings, bulletTypeSettings))
			{
				task = 2;
			}
			else {
				has_actioned = true;
				//this->IsSmoking = true;
			}
		}

		// ricochet
		if (task == 2)
		{
			if (!this->OnRicochet(actor_location, hit_result, trace_start, trace_end, assetComponent, surfaceSettings, bulletTypeSettings))
			{
			}
			else has_actioned = true;
		}
	}

	//auto character = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0);
	if (this->HasAuthority()) {
		UContentResolver::Instance->ResolveInteraction(EInteractionTrigger::Bullet, hit_result, this);
	}
	this->AddInteractionAtLocation(hit_result.ImpactPoint, surfaceSettings, component, this->CurrentRotation);

	if (surfaceSettings.DestroyOnFirstHit)
	{
		if (!actor->IsPendingKill())
		{
			actor->Destroy();
		}
	}

	if (!has_actioned)
	{
		//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Task not actioned"));
		// bullet has been consumed by the hit actor.
		// no penetration or ricochet occurred.
		this->Speed = 0.f;
	}
}

bool ABullet::OnPenetrate(FVector actor_location, FHitResult hit_result, FVector trace_start, FVector trace_end, UAssetItemComponent * assetComponent, FGlobalBulletSettings surfaceSettings, FBulletTypeSettings bulletTypeSetting)
{
	SCOPE_CYCLE_COUNTER(STAT_BulletPenetrate);
	bool is_penetrating = false;

	if (bulletTypeSetting.Penetration && this->Speed > 0)
	{
		// can we actually penetrate the object?
			//TODO check angle is within range, then see if we can

		if (this->MaxPenetrations > 0 && this->Penetrations < this->MaxPenetrations)
		{
			int chance = rand() % 100;

			bool can_penetrate = bulletTypeSetting.PenetrationChance == 1.f || chance < (bulletTypeSetting.PenetrationChance * 100.f);

			if (can_penetrate) {
				// find the next spawn point, by looking ahead, and finding the face we collide with on the way back to our projectile
				// put a decal on either side

				// TODO real_penetration_depth = Penetration depth * (current_speed / initial_speed)

				// get the max penetration distance and look back to find our exit point
				auto exitpoint_notsnapped_end = hit_result.ImpactPoint + this->CurrentRotation.RotateVector(FVector(bulletTypeSetting.PenetrationDepthBase * 3.f, 0.f, 0.f));
				auto exitpoint_notsnapped_start = hit_result.ImpactPoint;// -this->CurrentRotation.RotateVector(FVector(surfaceSettings.PenetrationDepthBase, 0.f, 0.f));

				TArray<FHitResult> lookback_hitresults;
				FHitResult lookback_hitresult;
				FCollisionQueryParams collision_params(FName(TEXT("BULLET")), true, this);
				collision_params.bReturnPhysicalMaterial = true;

				if (UGameSettings::Instance->BulletDebugLines) {
					DrawDebugSolidBox(GetWorld(), hit_result.ImpactPoint, FVector(3.f), FColor::Green, true, this->MaxLifeTime);
					//entry
				}

				FCollisionObjectQueryParams object_params;
				object_params.AddObjectTypesToQuery(ECC_WorldStatic);
				object_params.AddObjectTypesToQuery(ECC_WorldDynamic);
				object_params.AddObjectTypesToQuery(ECC_PhysicsBody);
				object_params.AddObjectTypesToQuery(ECC_Destructible);

				//if (GetWorld()->LineTraceMultiByObjectType(lookback_hitresults, exitpoint_notsnapped_end, exitpoint_notsnapped_start, object_params, collision_params))
				if (GetWorld()->SweepMultiByObjectType(lookback_hitresults, exitpoint_notsnapped_end, exitpoint_notsnapped_start, FQuat(), object_params, FCollisionShape::MakeSphere(this->RadialSize), collision_params))
				{
					if (lookback_hitresults.Num() > 0) {
						// find the penetration AFTER the hit point
						FHitResult penetration_out = lookback_hitresults[lookback_hitresults.Num() - 1];

						if (penetration_out.ImpactPoint != this->CurrentPosition) {
							UAssetItemComponent* lookbackAssetComponent = NULL;
							AActor* lookbackActor = penetration_out.GetActor();
							if (lookbackActor)
							{
								auto aic = Cast<UAssetItemComponent>(lookbackActor->GetComponentByClass(UAssetItemComponent::StaticClass()));
								if (aic)
								{
									lookbackAssetComponent = aic;
								}
							}
							FGlobalBulletSettings lookbackBulletSettings = this->GetSettingsFromHit(penetration_out, lookbackAssetComponent);
							//FBulletTypeSettings lookbackBulletTypeSettings = lookbackBulletSettings.GetBulletTypeSetting((uint8)this->Type);

							if (false) { //lookbackBulletTypeSettings.Penetration) {
								is_penetrating = true;

								if (UGameSettings::Instance->BulletDebugLines) {
									//exit
									DrawDebugSolidBox(GetWorld(), penetration_out.ImpactPoint, FVector(3.f), FColor::Purple, true, this->MaxLifeTime);
								}

								auto penetration_component = penetration_out.GetComponent();

								UContentResolver::Instance->ResolveInteraction(EInteractionTrigger::Bullet, penetration_out, this);
								this->AddInteractionAtLocation(penetration_out.ImpactPoint, lookbackBulletSettings, penetration_out.GetComponent(), this->CurrentRotation); // front of the object

								this->OnPenetrateStarted(hit_result);
								actor_location = penetration_out.ImpactPoint;
								this->OnPenetrateCompleted(penetration_out);

								this->Penetrations++;

								this->Restart(false);

								// PenetrationSpeedReductionPercentage = the percentage to reduce
								// e.g. PenetrationSpeedReductionPercentage @ .20 = 20% reduction
								//		123 * (1 - .20) = 98.4
								//if (lookbackBulletTypeSettings.PenetrationSpeedReductionPercentage != 0.f)
									//this->Speed = this->Speed * (1.f - lookbackBulletTypeSettings.PenetrationSpeedReductionPercentage);
							}
						}
					}
				}

				this->CurrentPosition = actor_location;
				if (this->MuzzleTracer) {
					//this->MuzzleTracer->SetWorldLocation(this->CurrentPosition);
					//this->MuzzleTracer->SetWorldRotation(this->CurrentRotation);
					this->MuzzleTracer->SetWorldLocationAndRotation(this->CurrentPosition, this->CurrentRotation);
				}
			}
			else {
				if (GEngine && UGameSettings::Instance->BulletDebugInfo) {
					GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("Cannot penetrate"));
				}
			}
		}
		else {
			if (GEngine && UGameSettings::Instance->BulletDebugInfo) {
				GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("Max penetrations reached"));
			}
		}
	}
	else {
		if (GEngine && UGameSettings::Instance->BulletDebugInfo) {
			GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("No penetrate or speed is too slow"));
		}
	}

	return is_penetrating;
}

//constexpr double pi() { return FMath::Atan(1.f) * 4.f; }
# define M_PIl          3.141592653589793238462643383279502884L /* pi */
# define M_PIf          3.1415f /* pi */

bool ABullet::OnRicochet(FVector actor_location, FHitResult hit_result, FVector trace_start, FVector trace_end, UAssetItemComponent * assetComponent, FGlobalBulletSettings surfaceSettings, FBulletTypeSettings bulletTypeSetting)
{
	bool has_ricoched = false;
	SCOPE_CYCLE_COUNTER(STAT_BulletRicochet);
	if (bulletTypeSetting.Ricochet && this->Speed > 0)
	{
		if (this->MaxRicochets > 0 && this->Ricochets < this->MaxRicochets)
		{
			int chance = rand() % 100;

			bool can_ricochet = bulletTypeSetting.RicochetChance == 1.f || chance < (bulletTypeSetting.RicochetChance * 100.f);

			if (can_ricochet && hit_result.Component.IsValid()) {
				auto material = hit_result.Component->GetMaterial(0);
				if (material) {
					// turn into a class so penetration can see if the angle is in within range
					FVector difference = trace_end - trace_start;
					FVector new_offset = difference.MirrorByVector(hit_result.Normal);

					FVector new_start = hit_result.ImpactPoint + hit_result.Normal;
					FVector new_end = hit_result.ImpactPoint + new_offset;

					auto normalized_hit_point = hit_result.ImpactNormal;
					auto forward_vector = FRotationMatrix(this->CurrentRotation).GetScaledAxis(EAxis::X) * this->Speed;
					normalized_hit_point.Normalize();
					forward_vector.Normalize();

					float angle_dotp = FVector::DotProduct(normalized_hit_point, forward_vector);
					float hit_angle = FMath::RadiansToDegrees(acosf(-angle_dotp));

					if ((bulletTypeSetting.RicochetAngleMin == -1.f || hit_angle >= bulletTypeSetting.RicochetAngleMin) && (bulletTypeSetting.RicochetAngleMax == -1.f || hit_angle <= bulletTypeSetting.RicochetAngleMax)) {
						actor_location = new_start;

						this->Restart(false);

						// RicochetSpeedReductionPercentage = the percentage to reduce
						// e.g. RicochetSpeedReductionPercentage @ .20 = 20% reduction
						//		123 * (1 - .20) = 98.4
						//		100 * (1 - .05) = 95
						if (bulletTypeSetting.RicochetSpeedReductionPercentage != 0.f)
							this->Speed = this->Speed * (1.f - bulletTypeSetting.RicochetSpeedReductionPercentage);

						auto rotation_to_new_target = (new_end - new_start).Rotation();

						//this->SetActorRotation(rot);
						this->CurrentRotation = rotation_to_new_target;
						this->Ricochets++;
						/*if (this->MaxRicochets > 0 && ++this->Ricochets >= this->MaxRicochets)
						{
						this->Ricochet = false;
						}*/

						//SetActorLocation(actor_location);
						this->CurrentPosition = actor_location;
						if (this->MuzzleTracer) {
							//this->MuzzleTracer->SetWorldLocation(this->CurrentPosition);
							//this->MuzzleTracer->SetWorldRotation(this->CurrentRotation);
							this->MuzzleTracer->SetWorldLocationAndRotation(this->CurrentPosition, this->CurrentRotation);
						}

						has_ricoched = true;
					}
					else {
						if (GEngine && UGameSettings::Instance->BulletDebugInfo) {
							DrawDebugString(GetWorld(), trace_start + FVector(0, 0, 10), "CANCELLED", (AActor*)0, FColor::Red);
						}
					}
				}
			}
		}
	}
	return has_ricoched;
}

void ABullet::OnDestroy()
{
	SCOPE_CYCLE_COUNTER(STAT_BulletOnDestroy);
	if (IsDestroyed) {
		DrawDebugString(GetWorld(), this->CurrentPosition + FVector(0, 0, 0), FString("TRYING TO DESTROY A DESTROYED OBJECT"), (AActor*)0, FColor::Red);
		return;
	}

	IsDestroyed = true;

	this->MuzzleTracer->SetVisibility(false);
	this->SetActorTickEnabled(false);

	if (this->Leased)
	{
		if (this->OnBulletDestroyed.IsBound()) {
			this->OnBulletDestroyed.Execute();
		}

		if (!GetWorld()->GetTimerManager().IsTimerActive(this->TracerTimeoutHandle)) {
			GetWorld()->GetTimerManager().SetTimer(this->TracerTimeoutHandle, this, &ABullet::OnClearTracer, 5.f, true, 5.f);
		}
		//this->ClearTracerSpline(0);
		//this->TracerTimeoutHandle
	}
	else if (this->PenetrationComponents.Num() == 0) {
		Destroy();
	}
}

void ABullet::OnClearTracer()
{
	// clear all
	for (int i = this->PenetrationComponents.Num() - 1; i >= 0; i--) {
		if (this->PenetrationComponents[i].Component) {
			this->PenetrationComponents[i].Component->SetVisibility(false);
			this->PenetrationComponents[i].Component->DestroyComponent();
			this->Components.Remove(this->PenetrationComponents[i].Component);
		}
		this->PenetrationComponents.RemoveAt(i);
	}
	this->PenetrationTracerLength = 0;
	this->PenetrationTracerSpline->ClearSplinePoints();

	if (GetWorld()->GetTimerManager().IsTimerActive(this->TracerTimeoutHandle)) {
		GetWorld()->GetTimerManager().ClearTimer(this->TracerTimeoutHandle);
	}
}

void ABullet::ClearTracerSpline(int penetrationId)
{
	// clear all
	for (int i = this->PenetrationComponents.Num() - 1; i >= 0; i--) {
		if (this->PenetrationComponents[i].Component) {
			this->PenetrationComponents[i].Component->SetVisibility(false);
			this->PenetrationComponents[i].Component->DestroyComponent();
			this->Components.Remove(this->PenetrationComponents[i].Component);
		}
		this->PenetrationComponents.RemoveAt(i);
	}
	this->PenetrationTracerLength = 0;
	this->PenetrationTracerSpline->ClearSplinePoints();

	if (this->Leased)
	{
		if (this->OnBulletDestroyed.IsBound()) {
			this->OnBulletDestroyed.Execute();
		}
	}
	else Destroy();
}

// Called every frame
void ABullet::Tick(float DeltaTime)
{
	if (IsDestroyed) {
		DrawDebugString(GetWorld(), this->CurrentPosition + FVector(0, 0, 0), FString("TICKED ON DESTROYED OBJECT"), (AActor*)0, FColor::Red);
		return;
	}

	SCOPE_CYCLE_COUNTER(STAT_BulletTick);

	// increment the time since the last frame
	//
	//
	//
	//		TRY THIS: GetWorld()->GetTimeSeconds()
	//
	/////////////////////
	this->Time += DeltaTime;

	if (this->Accuracy > 0) {
		if (this->FramesSkipped++ < this->Accuracy) {
			return;
		}
		this->FramesSkipped = 0;
	}

	Super::Tick(DeltaTime);

	if (this->Speed <= 0.01f) {
		OnDestroy();
		return;
	}

	//x = vix�t + 0.5*ax*t2
	//y = viy�t + 0.5*ay*t2

	// calculate the new position displacement
	float horizontal = this->SpeedCoefficient * this->Speed * this->Time;
	float vertical = 0.f * this->Time + 0.5f * -this->FallGravity * (FMath::Pow(this->Time, 2.f));

	//// this is not really the correct distance, as it is simply the horizontal displacement, not the travel distance
	//this->Distance = this->Speed * this->Time + 0.5f * -this->FallGravity * FMath::Pow(this->Time, 2);

	FHitResult hit_result;

	FVector trace_start = this->CurrentPosition;
	FVector trace_end = trace_start + this->CurrentRotation.RotateVector(FVector(horizontal * 10.f, 0, vertical * 10.f));

	TArray<FHitResult> lookback_hitresults;
	FHitResult lookback_hitresult;
	FCollisionQueryParams collision_params(FName(TEXT("BULLET")), true, this);
	collision_params.bReturnPhysicalMaterial = true;

	FCollisionObjectQueryParams object_params;
	object_params.AddObjectTypesToQuery(ECC_WorldStatic);
	object_params.AddObjectTypesToQuery(ECC_WorldDynamic);
	object_params.AddObjectTypesToQuery(ECC_PhysicsBody);
	object_params.AddObjectTypesToQuery(ECC_Destructible);

	//bool just_hit = false;
	bool requires_new_tracer = false;
	int initial_penetrations = this->Penetrations;
	FVector initial_tick_position = this->CurrentPosition;

	if (this->GetOwner() && this->GetOwner()->GetOwner()) {
		AMOTHCharacter* character = Cast<AMOTHCharacter>(this->GetOwner()->GetOwner());

		if (character) {
			hit_result = character->TraceManual(FName(TEXT("BULLET")), this->RadialSize, ETraceType::SphereSingle, trace_start, trace_end);

			//bool allow_movement = true;
			//if (GetWorld()->LineTraceSingleByObjectType(hit_result, trace_start, trace_end, object_params, collision_params) && hit_result.IsValidBlockingHit())
			//if (GetWorld()->SweepSingleByObjectType(hit_result, trace_start, trace_end, FQuat(), object_params, FCollisionShape::MakeSphere(this->RadialSize), collision_params) && hit_result.IsValidBlockingHit())
			if (hit_result.IsValidBlockingHit())
			{
				trace_end = hit_result.ImpactPoint;
				this->OnHit(hit_result, trace_start, trace_end);
				//just_hit = true;
				requires_new_tracer = this->Penetrations != initial_penetrations;
			}
			else this->CurrentPosition = trace_end;
		}
	}

	////bool allow_movement = true;
	////if (GetWorld()->LineTraceSingleByObjectType(hit_result, trace_start, trace_end, object_params, collision_params) && hit_result.IsValidBlockingHit())
	//if (GetWorld()->SweepSingleByObjectType(hit_result, trace_start, trace_end, FQuat(), object_params, FCollisionShape::MakeSphere(this->RadialSize), collision_params) && hit_result.IsValidBlockingHit())
	//{
	//	trace_end = hit_result.ImpactPoint;
	//	this->OnHit(hit_result, trace_start, trace_end);
	//	//just_hit = true;
	//	requires_new_tracer = this->Penetrations != initial_penetrations;
	//}
	//else this->CurrentPosition = trace_end;

	{
		// increment the distance our trace has travelled
		//float length = CalculateTraceLength(trace_start, this->CurrentPosition);
		float length = hit_result.Distance;
		this->Distance += length;

		if (UGameSettings::Instance->BulletDebugLines) {
			DrawDebugLine(GetWorld(), trace_start, trace_end, FColor::Purple, true, this->MaxLifeTime);
			if (GetWorld()->GetGameViewport()) {
				GetWorld()->GetGameViewport()->GetEngineShowFlags()->SetSplines(true);
			}
		}
		else {
			if (GetWorld()->GetGameViewport()) {
				GetWorld()->GetGameViewport()->GetEngineShowFlags()->SetSplines(false);
			}
		}

		if (this->Speed >= this->PenetrationTracerMinimumSpeed) {
			if (this->PenetrationTracerSpline && this->SmokeTracer && this->Penetrations > 0) {
				if (requires_new_tracer) {
					this->PenetrationTracerSpline->AddSplineLocalPoint(this->CurrentPosition); // new tracer start
					this->PenetrationTracerLength = 0;

					this->CurrentTracerCount = 1;
				}
				else {
					if (this->PenetrationTracerLength <= this->_instancePenetrationTracerMaxLength)
					{
						this->PenetrationTracerLength += length;
						this->AddSmokeTracerPoint(this->CurrentPosition, this->Penetrations);
					}
				}
			}

			if (this->MuzzleTracer) {
				//this->MuzzleTracer->SetWorldLocation(this->CurrentPosition);
				//this->MuzzleTracer->SetWorldRotation(this->CurrentRotation);
				this->MuzzleTracer->SetWorldLocationAndRotation(this->CurrentPosition, this->CurrentRotation);
				//this->MuzzleTracer->SetVisibility(true);
			}
		}
		else {
			//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Too slow: ").Append(FString::SanitizeFloat(this->Speed)));
			this->MuzzleTracer->SetVisibility(false);
		}

		if (this->HorizontalResistance != 0.f)
			this->Speed -= this->HorizontalResistance;
	}

	if (this->MaxLifeTime > 0 && this->Time >= this->MaxLifeTime)
	{
		OnDestroy();
	}
	else if (this->MaxDistance > 0 && this->Distance >= this->MaxDistance)
	{
		OnDestroy();
	}
	else if (this->Speed <= 0.f)
	{
		this->Speed = 0.f;
		OnDestroy();
	}
}

void ABullet::AddSmokeTracerPoint(FVector location, int penetrationId)
{
	SCOPE_CYCLE_COUNTER(STAT_BulletAddSmokeTracerPoint);
	int components = this->PenetrationComponents.Num();
	if (components > 0 && this->CurrentTracerCount > 1) {
		this->PenetrationComponents[components - 1].Component->SetStaticMesh(this->SmokeTracer);
	}

	auto num_points = this->PenetrationTracerSpline->GetNumberOfSplinePoints();

	FVector start;
	FVector start_tangent;
	this->PenetrationTracerSpline->GetLocalLocationAndTangentAtSplinePoint(num_points - 1, start, start_tangent);

	this->PenetrationTracerSpline->AddSplineLocalPoint(location);

	FVector end;
	FVector end_tangent;
	this->PenetrationTracerSpline->GetLocalLocationAndTangentAtSplinePoint(num_points, end, end_tangent);

	USplineMeshComponent* segment = NewObject<USplineMeshComponent>(this, USplineMeshComponent::StaticClass());
	segment->CreationMethod = EComponentCreationMethod::UserConstructionScript;
	segment->AttachToComponent(this->RootComponent, FAttachmentTransformRules::KeepWorldTransform);

	segment->SetStaticMesh(this->SmokeTracerCap);

	segment->SetMaterial(0, this->smokeMaterial);
	segment->SetVisibility(true);
	segment->SetMobility(EComponentMobility::Movable);
	//segment->SetWorldLocationAndRotation(this->CurrentPosition, this->CurrentRotation);
	segment->MarkRenderStateDirty();

	segment->SetStartAndEnd(start, start_tangent, end, end_tangent);

	auto penetrationComponent = FPenetrationComponent(penetrationId, segment, this->smokeMaterial);
	this->PenetrationComponents.Add(penetrationComponent);
	this->Components.Add(segment);

	if (this->CurrentTracerCount == 1)
	{
		this->OnSmokeTraceStart(penetrationComponent);
	}

	this->CurrentTracerCount++;

	RegisterAllComponents();
}

