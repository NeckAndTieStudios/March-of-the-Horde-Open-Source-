// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine.h"
#include "ObjectPool.generated.h"

UCLASS(Blueprintable, BlueprintType)
class FPSPROJECT_API UObjectPool : public UObject
{
	GENERATED_BODY()

protected:
	TQueue<class UObject*> * pool;

	void allocate();

	int block_size;
	UWorld * world;
	TSubclassOf<class UObject> ObjectClass;

	void ReleaseActor(AActor* actor);
	//void ReleaseActorComponent(UActorComponent* component);

	int capacity = 0;
	int leased = 0;
	bool allow_increase = true;
public:
	UObjectPool();
	~UObjectPool();

	void Initialise(int block_size, UWorld* world, TSubclassOf<class UObject> ObjectClass, bool allow_increase);

	UObject * Aquire();
	void Release(UObject * object);

	int GetCapacity();
	int GetLeased();
};

//UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable)
//class FPSPROJECT_API UObjectPoolComponent : public UActorComponent
//{
//	GENERATED_BODY()
//
//public:
//	//UObjectPoolComponent();
//
//
//protected:
//
//
//public:
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		UObjectPool * Pool;
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		UObject * PoolReference;
//
//	virtual void OnComponentDestroyed(bool bDestroyingHierarchy) override;
//
//};


UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable)
class FPSPROJECT_API UObjectPoolSceneComponent : public USceneComponent
{
	GENERATED_BODY()

public:
	//UObjectPoolSceneComponent();

protected:


public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UObjectPool * Pool;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UObject * PoolReference;

	virtual void OnComponentDestroyed(bool bDestroyingHierarchy) override;
};