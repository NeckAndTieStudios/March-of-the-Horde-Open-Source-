// Fill out your copyright notice in the Description page of Project Settings.

#include "ObjectPool.h"
#include "DrawDebugHelpers.h"

UObjectPool::UObjectPool()
{
}

UObjectPool::~UObjectPool()
{
}

void UObjectPool::Initialise(int block_size, UWorld* world, TSubclassOf<class UObject> ObjectClass, bool allow_increase)
{
	this->ObjectClass = ObjectClass;
	this->block_size = block_size;
	this->pool = new TQueue<class UObject*>();
	this->world = world;
	this->allow_increase = allow_increase;
	this->allocate(); //preallocate
}

void UObjectPool::allocate()
{
	/*if (GEngine) {
		GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("Allocating more to an object pool"));
	}*/
	for (int i = 0; i < this->block_size; i++)
	{
		UObject* object = NULL;
		if (this->ObjectClass->IsChildOf(AActor::StaticClass())) {
			AActor* actor = this->world->SpawnActor<AActor>(this->ObjectClass, FVector(0), FRotator(0));

			actor->OnDestroyed.AddDynamic(this, &UObjectPool::ReleaseActor);
			//actor->OnDestroyed.AddRaw(this, &UObjectPool::ReleaseByArg, actor);
			actor->SetActorTickEnabled(false);

			object = actor;
		}
		else if (this->ObjectClass->IsChildOf(USceneComponent::StaticClass())) {
			USceneComponent* component = NewObject<USceneComponent>(this->ObjectClass);
			UObjectPoolSceneComponent* pool_component = NewObject<UObjectPoolSceneComponent>();

			//component->OnComponentDestroyed.AddDynamic(this, &UObjectPool::ReleaseActorComponent);
			component->SetComponentTickEnabled(false);

			FAttachmentTransformRules rules(EAttachmentRule::KeepWorld, false);
			pool_component->AttachToComponent(component, rules);

			object = component;
		}
		else {

		}

		if (object) {
			this->pool->Enqueue(object);
			this->capacity++;
		}
	}
}

UObject * UObjectPool::Aquire()
{
	//SCOPE_CYCLE_COUNTER(STAT_RequestBulletTypeFromPool);
	UObject * object = NULL;

	if (this->pool->IsEmpty())
	{
		if (!this->allow_increase)
		{
			return object;
		}
		// more allocation required
		this->allocate();
	}

	this->pool->Dequeue(object);

	if (object)
	{
		this->leased++;
	}

	return object;
}

void UObjectPool::Release(UObject * object)
{
	/*SCOPE_CYCLE_COUNTER(STAT_ReturnBulletTypeToPool);
	if (object->Leased)
	{*/
	this->leased--;
	this->pool->Enqueue(object);
	/*}
	else {
		DrawDebugString(this->world, object->CurrentPosition + FVector(0, 0, 0), FString("BULLET WAS ALREADY RELEASED:").Append(FString::FromInt(bullet->ID)), (AActor *)0, FColor::Red);
	}*/
}

//void UObjectPool::ReleaseByArg(UObject * object)
//{
//	//auto bullet = Cast<UObject>(actor);
//	if (object)
//	{
//		this->Release(object);
//	}
//}
void UObjectPool::ReleaseActor(AActor* actor)
{
	if (actor)
	{
		this->Release(actor);
	}
}

//void UObjectPool::ReleaseActorComponent(UActorComponent* component)
//{
//	if (component)
//	{
//		this->Release(component);
//	}
//}

int UObjectPool::GetCapacity()
{
	return this->capacity;
}

int UObjectPool::GetLeased()
{
	return this->leased;
}


//void UObjectPoolComponent::OnComponentDestroyed(bool bDestroyingHierarchy)
//{
//	if (this->Pool) {
//		this->Pool->Release(this->PoolReference);
//	}
//	UActorComponent::OnComponentDestroyed(bDestroyingHierarchy);
//}

void UObjectPoolSceneComponent::OnComponentDestroyed(bool bDestroyingHierarchy)
{
	if (this->Pool) {
		this->Pool->Release(this->PoolReference);
	}
	USceneComponent::OnComponentDestroyed(bDestroyingHierarchy);
}