// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/Actor.h"
#include "GameFramework/SpringArmComponent.h"
#include "Camera/CameraComponent.h"
//#include "Barrel.h"
#include "Engine/StaticMeshActor.h"
#include "InteractionTrigger.h"
#include "Weapon.generated.h"

UCLASS()
class FPSPROJECT_API AWeapon : public AActor
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	AWeapon();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	//UPROPERTY(EditAnywhere, Category = Bullet)
	//	TSubclassOf<class UPrimitiveComponent> WeaponComponentClass;

	//UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon")
	//	UPrimitiveComponent * WeaponComponent;

	//UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon")
	//	USkeletalMeshComponent * SkeletalMesh;

	//UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon")
	//	USpringArmComponent * SpringArm;

	//UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon")
	//	UCameraComponent * Camera;

	//UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon")
	//	ABarrel * Barrel;

	UFUNCTION(BlueprintCallable)
		virtual void OnPrimaryPressed();
	UFUNCTION(BlueprintCallable)
		virtual void OnPrimaryReleased();

	UFUNCTION(BlueprintCallable)
		virtual void OnSecondaryPressed();
	UFUNCTION(BlueprintCallable)
		virtual void OnSecondaryReleased();


	UFUNCTION(BlueprintImplementableEvent, Category = "Weapon")
		void PrimaryPressed();
	UFUNCTION(BlueprintImplementableEvent, Category = "Weapon")
		void PrimaryReleased();

	UFUNCTION(BlueprintImplementableEvent, Category = "Weapon")
		void SecondaryPressed();
	UFUNCTION(BlueprintImplementableEvent, Category = "Weapon")
		void SecondaryReleased();


	/*UFUNCTION(BlueprintImplementableEvent, Category = "Weapon")
		void BP_TriggerPressed();
	UFUNCTION(BlueprintImplementableEvent, Category = "Weapon")
		void BP_TriggerReleased();*/

	/*
		UFUNCTION(BlueprintImplementableEvent, Category = "Weapon Events")
			virtual void On();*/


	UFUNCTION(BlueprintCallable)
		UObject* NewSubObject(UObject* Outer, UClass* Class)
	{
		auto s = NewObject<UObject>(Outer, Class);

		if (s->IsA(USceneComponent::StaticClass()))
		{
			auto a = Cast<USceneComponent>(s);
			a->RegisterComponent();
		}

		return s;
	}

	UFUNCTION(BlueprintCallable)
		TArray<UItemComponent*> GetInteraction(EInteractionTrigger trigger, float radialSize);
};
