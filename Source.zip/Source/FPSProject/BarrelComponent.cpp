// Fill out your copyright notice in the Description page of Project Settings.

#include "BarrelComponent.h"
#include "DrawDebugHelpers.h"

DEFINE_STAT(STAT_BarrelComponentFire);
DEFINE_STAT(STAT_BarrelComponentTick);


// Sets default values
UBarrelComponent::UBarrelComponent()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryComponentTick.bCanEverTick = true;
}

// Called when the game starts or when spawned
void UBarrelComponent::BeginPlay()
{
	Super::BeginPlay();

	this->CurrentPosition = this->GetComponentLocation();
	this->CurrentRotation = this->GetComponentRotation();

	//1.f / this->FireRate
	//GetWorldTimerManager().SetTimer(this->FireTimerHandle, this, &UBarrelComponent::RepeatingFunction, 1.0f, true, 2.0f);

	if (!ProjectileClass)
	{
		DrawDebugString(GetWorld(), this->CurrentPosition + FVector(0, 0, -10), FString("No projectile specified"), (AActor *)0);
		this->SetComponentTickEnabled(false);
		this->GetOwner()->SetActorTickEnabled(false);
	}
	else {
		//this->bullet_pool = new BulletPool(MaxBullets == 0 ? 500 : MaxBullets, GetWorld(), ProjectileClass, MaxBullets == 0);
		this->barrel_locations.Init(FVector(0.f), this->Chambers);
	}
}

void UBarrelComponent::StartFire()
{
	this->IsFiring = true;

	this->CurrentPosition = this->GetComponentLocation();
	this->CurrentRotation = this->GetComponentRotation();

	SetComponentTickEnabled(true);
}

// Called every frame
void UBarrelComponent::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	SCOPE_CYCLE_COUNTER(STAT_BarrelComponentTick);
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (this->barrel_locations.Num() < this->Chambers) {
		DrawDebugString(GetWorld(), this->CurrentPosition + FVector(0, 0, -10), FString("Barrel locations have not been configured!"), (AActor*)0);
		return;
	}

	if (!this->GetOwner()->HasAuthority()) {
		DrawDebugString(GetWorld(), this->CurrentPosition + FVector(0, 0, -10), FString("No authority!"), (AActor*)0);
		return;
	}

	this->CurrentPosition = this->GetComponentLocation();
	this->CurrentRotation = this->GetComponentRotation();

	if (this->BarrelType == EBarrelType::Circular) {
		auto center = this->CurrentPosition;
		float ratio = 360.f / this->Chambers;
		auto actor_rotation = this->CurrentRotation;
		for (int point = 1; point <= this->Chambers; point++)
		{
			auto degree = point * ratio;

			auto rot = FRotator(0, 0, degree + this->Rotation);
			auto fv = actor_rotation.RotateVector(FRotationMatrix(rot).GetScaledAxis(EAxis::Z) * this->BarrelRadius);

			//DrawDebugPoint(GetWorld(), center + fv, 15.f, FColor::Red, false);

			this->barrel_locations[point - 1] = center + fv;
		}
	}

	if (this->IsFiring)
	{
		this->Time += DeltaTime;

		float time_diff = this->Time - this->LastFire;

		if (time_diff >= (1.f / this->FireRate))
		{
			this->Fire();

			this->LastFire = this->Time;

			if (this->FireMode == EBarrelFireMode::Single)
			{
				this->IsFiring = false;
			}
		}

		//DrawDebugString(GetWorld(), this->GetActorLocation() + FVector(0, 0, 0), FString("Time: ").Append(FString::SanitizeFloat(this->Time)), (AActor *)0, FColor::White, DeltaTime);
		//DrawDebugString(GetWorld(), this->GetActorLocation() + FVector(0, 0, 10), FString("Last Fire: ").Append(FString::SanitizeFloat(this->LastFire)), (AActor *)0, FColor::White, DeltaTime);
	}
	else
	{
		this->Time = 0.f;
		this->LastFire = 0.f;

		//DrawDebugString(GetWorld(), this->GetActorLocation() + FVector(0, 0, 0), FString("Not firing"), (AActor *)0, FColor::White, DeltaTime);
	}

	if (this->RotationSpeed != 0.f)
	{
		this->Rotation += this->RotationSpeed * DeltaTime;
		if (this->Rotation > 360.f)
			this->Rotation = 0.f;
	}
}

void UBarrelComponent::Fire()
{
	SCOPE_CYCLE_COUNTER(STAT_BarrelComponentFire);
	for (int i = 0; i < this->BulletsPerFire; i++)
	{
		float x_offset = FMath::RandRange(-this->SprayRange, this->SprayRange);
		float y_offset = FMath::RandRange(-this->SprayRange, this->SprayRange);

		auto rot = this->CurrentRotation;
		rot.Yaw += x_offset;
		rot.Pitch += y_offset;

		FVector location;
		if (this->BarrelType == EBarrelType::Circular) {
			this->last_fired_barrel++;
			if (last_fired_barrel > this->Chambers - 1) {
				last_fired_barrel = 0;
			}
			location = this->barrel_locations[this->last_fired_barrel];
		}
		else {
			location = this->CurrentPosition;
		}

		auto params = FActorSpawnParameters();
		params.Owner = this->GetOwner();
		auto bullet = this->GetWorld()->SpawnActor<ABullet>(ProjectileClass, location, rot, params);

		//auto bullet = this->bullet_pool->Aquire(this->GetOwner());

		if (bullet) {
			bullet->BulletOwner = this->GetOwner();
			bullet->Respawn(location, rot);
			this->BulletsFired++;
			this->OnFire(location, rot);
		}
		else {
			DrawDebugString(GetWorld(), this->CurrentPosition + FVector(0, 0, 60), FString("OUT OF AMMO!").Append(FString::SanitizeFloat(this->BulletsFired)), (AActor *)0, FColor::White, 3.f);
			break;
		}
	}

	/*DrawDebugString(GetWorld(), this->CurrentPosition + FVector(0, 0, 40), FString("FIRE BITCH: ").Append(FString::SanitizeFloat(this->BulletsFired)), (AActor *)0, FColor::White, this->Time - this->LastFire);
	DrawDebugString(GetWorld(), this->CurrentPosition + FVector(0, 0, 20), FString("Pool Capacity: ").Append(FString::SanitizeFloat(this->bullet_pool->GetCapacity())), (AActor *)0, FColor::White, this->Time - this->LastFire);
	DrawDebugString(GetWorld(), this->CurrentPosition + FVector(0, 0, 0), FString("Pool Lease: ").Append(FString::SanitizeFloat(this->bullet_pool->GetLeased())), (AActor *)0, FColor::White, this->Time - this->LastFire);*/
}

int UBarrelComponent::GetBulletsFired()
{
	return this->BulletsFired;
}

void UBarrelComponent::Reload()
{

}