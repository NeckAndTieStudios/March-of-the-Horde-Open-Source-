// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ItemUpgrade.generated.h"

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable)
class FPSPROJECT_API UItemUpgradeInstance : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemUpgradeID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int UpgradedItemID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int Stage;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemUpgradeRequirementID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int RequiredItemID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float Stack;
};

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable)
class FPSPROJECT_API UItemRepairInstance : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemRepairID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int RepairItemID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float RequiredQuantity;
};