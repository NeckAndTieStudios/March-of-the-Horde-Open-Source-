// Fill out your copyright notice in the Description page of Project Settings.

#include "Database.h"
#include "Engine.h"
#include "GameSettings.h"
#include "GlobalGameInstance.h"

const FString UDatabaseLoader::DatabaseName = FString("Game");
const FString UDatabaseLoader::DatabasePath = FString("Database/Game.db");
//TMap<int, FIngredientForItemCacheEntry> DatabaseLoader::IngredientsForItemCache;
UDatabaseLoader* UDatabaseLoader::Instance;

//TMap<int, FIngredientForItemCacheEntry> UDatabaseLoader::IngredientsForItemCache;

/*select
	i.*, ia.ItemAlias, ia.ActorBlueprint, ia.FoliageIndex, ia.ItemPlaceableTypeID, ia.Particle, ia.ParticleFlags, ia.ParticleRotation, ia.ParticleScale, ia.DefaultComponent, ia.HealthBreakpoint, ia.DestructibleMesh,
	IFNULL(fs.HealthMin, 0) HealthMin,
	IFNULL(fs.HealthMax, 0) HealthMax,
	IFNULL(f.FoliageTypeID, 0) FoliageTypeID,
	IFNULL(f.FoliageSizeID, 0) FoliageSizeID,
	IFNULL(f.SpeciesName, IFNULL(i.Name, '')) DisplayName,
	IFNULL(fs.ScaleIndex, 0) FoliageScaleIndex,
	IFNULL(t.ToolTypeID, 0) ToolTypeID,
	IFNULL(t.BaseLevel, 0) BaseLevel,
	IFNULL((
		select iu.Stage
		from ItemUpgrade iu
		where iu.UpgradedItemID = i.ItemID
		order by iu.Stage
		limit 1
	), 0) UpgradeStage
from Item i
	left join (
		select iia.*
		from ItemAlias iia
		where iia.ItemAliasID = (
			select iia2.ItemAliasID
			from ItemAlias iia2
			where iia2.ItemID = iia.ItemID
			order by iia2.Priority asc, iia2.HealthBreakpoint desc
		)
		--limit 1
	) ia on ia.ItemID = i.ItemID
	left join Foliage f on i.ItemID = f.ItemID
	left join FoliageSize fs on f.FoliageSizeID = fs.FoliageSizeID
	left join Tool t on i.ItemID = t.ItemID
where i.ItemID = 113
order by ia.Priority asc, ia.HealthBreakpoint asc*/
//
//void AInstanceMeshReplicator::BeginPlay()
//{
//	auto gameinstance = GetGameInstance<UGlobalGameInstance>();
//	if (IsValid(gameinstance)) {
//		gameinstance->InstanceMeshReplicator = this;
//	}
//
//	UE_LOG(LogTemp, Warning, TEXT("foliage AInstanceMeshReplicator::BeginPlay"));
//}

TArray<UItemAliasQueryResult*> UDatabaseLoader::FindItemsByID(int itemId)
{
	TArray<UItemAliasQueryResult*> aliases;
	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
	{
		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
		{
			return aliases;
		}
	}

	// TODO consts and precache at loadscreen 
	FString query = FString::Printf(TEXT("select \
											ia.ItemAlias, i.*, ia.ActorBlueprint, ia.FoliageIndex, ia.ItemPlaceableTypeID, ia.Particle, ia.ParticleFlags, ia.ParticleRotation, ia.ParticleScale, ia.DefaultComponent, ia.HealthBreakpoint, ia.DestructibleMesh, \
											ia.BreakpointSurfaceEffectID, \
											IFNULL(fs.HealthMin, 0) HealthMin, \
											IFNULL(fs.HealthMax, 0) HealthMax, \
											IFNULL(f.FoliageTypeID, 0) FoliageTypeID, \
											IFNULL(f.FoliageSizeID, 0) FoliageSizeID, \
											IFNULL(f.SpeciesName, IFNULL(i.Name, '')) DisplayName, \
											IFNULL(fs.ScaleIndex, 0) FoliageScaleIndex, \
											IFNULL(t.ToolTypeID, 0) ToolTypeID, \
											IFNULL(t.BaseLevel, 0) BaseLevel, \
											IFNULL(( \
												select iu.Stage \
												from ItemUpgrade iu \
												where iu.UpgradedItemID = i.ItemID \
												order by iu.Stage \
												limit 1 \
											), 0) UpgradeStage \
											from Item i \
												left join( \
													select iia.* \
													from ItemAlias iia \
													where iia.ItemAliasID = ( \
														select iia2.ItemAliasID \
														from ItemAlias iia2 \
														where iia2.ItemID = iia.ItemID \
														order by iia2.Priority asc, iia2.HealthBreakpoint desc \
													) \
												) ia on ia.ItemID = i.ItemID \
												left join Foliage f on i.ItemID = f.ItemID \
												left join FoliageSize fs on f.FoliageSizeID = fs.FoliageSizeID \
												left join Tool t on i.ItemID = t.ItemID \
											where i.ItemID = %i or %i = -1 \
											order by i.ItemID asc, ia.Priority asc, ia.HealthBreakpoint asc"), itemId, itemId);

	auto results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
	if (results.Success) {
		for (int i = 0; i < results.Results.Num(); i++) {
			//UItemAliasQueryByAliasResult * model = NewObject<UItemAliasQueryByAliasResult>(UGameSettings::Instance);
			UItemAliasQueryResult* model = NewObject<UItemAliasQueryResult>(UGameSettings::Instance);
			auto row = results.Results[i];
			USQLiteDatabase::AssignResultsToObjectProperties(row, model);
			aliases.Add(model);
		}
	}

	return aliases;
}

UItemAliasQueryResult* UDatabaseLoader::FindItemByID(int itemId)
{
	auto results = UDatabaseLoader::FindItemsByID(itemId);
	if (results.Num() == 1) return results[0];
	return NULL;
}

TArray<UItemAliasQueryResult*> UDatabaseLoader::FindItemsByAlias(const FString & alias)
{
	TArray<UItemAliasQueryResult*> collection;

	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
	{
		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
		{
			return collection;
		}
	}

	// TODO consts and precache at loadscreen 
	FString query = FString::Printf(TEXT("select \
									i.*, ia.ItemAlias, ia.ActorBlueprint, ia.FoliageIndex, ia.ItemPlaceableTypeID, ia.Particle, ia.ParticleFlags, ia.ParticleRotation, ia.ParticleScale, ia.HealthBreakpoint, ia.DefaultComponent, ia.DestructibleMesh, \
									ia.BreakpointSurfaceEffectID, \
									IFNULL(fs.HealthMin, 0) HealthMin, \
									IFNULL(fs.HealthMax, 0) HealthMax, \
									IFNULL(f.FoliageTypeID, 0) FoliageTypeID, \
									IFNULL(f.FoliageSizeID, 0) FoliageSizeID, \
									IFNULL(f.SpeciesName, IFNULL(i.Name, '')) DisplayName, \
									IFNULL(fs.ScaleIndex, 0) FoliageScaleIndex, \
									IFNULL(t.ToolTypeID, 0) ToolTypeID, \
									IFNULL(t.BaseLevel, 0) BaseLevel, \
									IFNULL(( \
										select iu.Stage \
										from ItemUpgrade iu \
										where iu.UpgradedItemID = i.ItemID \
										order by iu.Stage \
										limit 1 \
									), 0) UpgradeStage \
							from ItemAlias ia \
								inner join Item i on ia.ItemID = i.ItemID \
								left join Foliage f on i.ItemID = f.ItemID \
								left join FoliageSize fs on f.FoliageSizeID = fs.FoliageSizeID \
								left join Tool t on i.ItemID = t.ItemID \
							where ia.ItemAlias = \"%s\" or LENGTH(\"%s\") = 0 \
							order by ia.ItemID asc, ia.Priority asc, ia.HealthBreakpoint asc"), *alias, *alias);

	auto results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
	if (results.Success) {
		for (int i = 0; i < results.Results.Num(); i++) {
			UItemAliasQueryResult* model = NewObject<UItemAliasQueryResult>(UGameSettings::Instance);
			auto row = results.Results[i];
			USQLiteDatabase::AssignResultsToObjectProperties(row, model);
			collection.Add(model);
		}
	}

	return collection;
}

//TArray<UItemLootQueryResult *> UDatabaseLoader::GetLootForItem(int ItemID, EInteractionTrigger trigger, int hitByItemID, int hitByItemTypeID)
//{
//	TArray<UItemLootQueryResult *> collection;
//
//	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
//	{
//		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
//		{
//			return collection;
//		}
//	}
//
//	// TODO consts and precache at load to prevent 
//	int triggerID = static_cast<int>(trigger);
//	FString query = FString::Printf(TEXT("select \
//											i.*, \
//											IFNULL(fs.HealthMin, 0) HealthMin, \
//											IFNULL(fs.HealthMax, 0) HealthMax, \
//											IFNULL(f.FoliageTypeID, 0) FoliageTypeID, \
//											IFNULL(il.ItemLootFormulaID, 0) ItemLootFormulaID, \
//											IFNULL(il.ItemLootFormulaValue, 0) ItemLootFormulaValue, \
//											IFNULL(f.FoliageSizeID, 0) FoliageSizeID, \
//											IFNULL(f.SpeciesName, IFNULL(i.Name, '')) DisplayName, \
//											IFNULL(fs.ScaleIndex, 0) FoliageScaleIndex, \
//											IFNULL(t.ToolTypeID, 0) ToolTypeID, \
//											IFNULL(t.BaseLevel, 0) BaseLevel, \
//											IFNULL(( \
//												select iu.Stage \
//												from ItemUpgrade iu \
//												where iu.UpgradedItemID = i.ItemID \
//												order by iu.Stage \
//												limit 1 \
//											), 0) UpgradeStage \
//										from ItemLoot il \
//											inner join Item i on il.LootItemID = i.ItemID \
//											left join Foliage f on i.ItemID = f.ItemID \
//											left join FoliageSize fs on f.FoliageSizeID = fs.FoliageSizeID \
//											left join Tool t on i.ItemID = t.ItemID \
//										where il.ItemId = %i \
//											and il.InteractionTriggerID = %i \
//											and il.HitByItemId = %i \
//											and il.HitByItemTypeId = %i"), ItemID, triggerID, hitByItemID, hitByItemTypeID);
//
//	auto results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
//	if (results.Success) {
//		for (int i = 0; i < results.Results.Num(); i++) {
//			UItemLootQueryResult * model = NewObject<UItemLootQueryResult>(UGameSettings::Instance);
//			auto row = results.Results[i];
//			USQLiteDatabase::AssignResultsToObjectProperties(row, model);
//			collection.Add(model);
//		}
//	}
//
//	return collection;
//}

TArray<FItemLootQueryResult> UDatabaseLoader::GetLootForItem(int ItemID, EInteractionTrigger trigger, int hitByItemID, int hitByItemTypeID)
{
	TArray<FItemLootQueryResult> collection;

	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
	{
		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
		{
			return collection;
		}
	}

	// TODO consts and precache at load to prevent 
	int triggerID = static_cast<int>(trigger);
	FString query = FString::Printf(TEXT("select \
											i.ItemID, \
											IFNULL(il.ItemLootFormulaID, 0) ItemLootFormulaID, \
											IFNULL(il.ItemLootFormulaValue, 0) ItemLootFormulaValue \
										from ItemLoot il \
											inner join Item i on il.LootItemID = i.ItemID \
											left join Foliage f on i.ItemID = f.ItemID \
											left join FoliageSize fs on f.FoliageSizeID = fs.FoliageSizeID \
											left join Tool t on i.ItemID = t.ItemID \
										where il.ItemId = %i \
											and il.InteractionTriggerID = %i \
											and il.HitByItemId = %i \
											and il.HitByItemTypeId = %i"), ItemID, triggerID, hitByItemID, hitByItemTypeID);

	auto results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
	if (results.Success) {
		for (int i = 0; i < results.Results.Num(); i++) {
			FItemLootQueryResult result;
			result.ItemID = results.Results[i].Fields[0].IntValue;
			result.ItemLootFormulaID = results.Results[i].Fields[1].IntValue;
			result.ItemLootFormulaValue = results.Results[i].Fields[2].DoubleValue;

			collection.Add(result);
		}
	}

	return collection;
}

//
//TArray<UItemRecipeQueryResult *> UDatabaseLoader::GetRecipes()
//{
//	TArray<UItemRecipeQueryResult *> collection;
//
//	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
//	{
//		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
//		{
//			return collection;
//		}
//	}
//
//	// TODO consts and precache at load to prevent 
//	FString query = TEXT("select distinct \
//							i.*, \
//							IFNULL(fs.HealthMin, 0) HealthMin, \
//							IFNULL(fs.HealthMax, 0) HealthMax, \
//							IFNULL(f.FoliageTypeID, 0) FoliageTypeID, \
//							IFNULL(f.FoliageSizeID, 0) FoliageSizeID, \
//							IFNULL(f.SpeciesName, IFNULL(i.Name, '')) DisplayName, \
//							IFNULL(fs.ScaleIndex, 0) FoliageScaleIndex, \
//							IFNULL(t.ToolTypeID, 0) ToolTypeID, \
//							IFNULL(t.BaseLevel, 0) BaseLevel, \
//							IFNULL(( \
//								select iu.Stage \
//								from ItemUpgrade iu \
//								where iu.UpgradedItemID = i.ItemID \
//								order by iu.Stage \
//								limit 1 \
//							), 0) UpgradeStage \
//						from ItemIngredient r \
//							inner join Item i on r.ItemID = i.ItemID \
//							left join Foliage f on i.ItemID = f.ItemID \
//							left join FoliageSize fs on f.FoliageSizeID = fs.FoliageSizeID \
//							left join Tool t on i.ItemID = t.ItemID \
//						where i.CraftDuration > 0 \
//							and i.ItemID in( \
//								select r.ItemID \
//								from ItemIngredient r \
//							) \
//						order by IFNULL(f.SpeciesName, IFNULL(i.Name, ''))");
//
//	auto results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
//	if (results.Success) {
//		for (int i = 0; i < results.Results.Num(); i++) {
//			UItemRecipeQueryResult * model = NewObject<UItemRecipeQueryResult>(UGameSettings::Instance);
//			auto row = results.Results[i];
//			USQLiteDatabase::AssignResultsToObjectProperties(row, model);
//			collection.Add(model);
//		}
//	}
//
//	return collection;
//}

TArray<int> UDatabaseLoader::GetRecipes()
{
	TArray<int> collection;

	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
	{
		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
		{
			return collection;
		}
	}

	// TODO consts and precache at load to prevent 
	FString query = TEXT("select distinct i.ItemID \
						from ItemIngredient r \
							inner join Item i on r.ItemID = i.ItemID \
							left join Foliage f on i.ItemID = f.ItemID \
							left join FoliageSize fs on f.FoliageSizeID = fs.FoliageSizeID \
							left join Tool t on i.ItemID = t.ItemID \
						where i.CraftDuration > 0 \
							and i.ItemID in( \
								select r.ItemID \
								from ItemIngredient r \
							) \
						order by IFNULL(f.SpeciesName, IFNULL(i.Name, ''))");

	auto results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
	if (results.Success) {
		for (int i = 0; i < results.Results.Num(); i++) {
			auto item_id = results.Results[i].Fields[0].IntValue;
			collection.Add(item_id);
		}
	}

	return collection;
}

//
//TArray<UItemRecipeQueryResult *> UDatabaseLoader::GetRecipesForItem(int ItemID)
//{
//	TArray<UItemRecipeQueryResult *> collection;
//
//	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
//	{
//		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
//		{
//			return collection;
//		}
//	}
//
//	// TODO consts and precache at load to prevent 
//	FString query = FString::Printf(TEXT("select distinct  \
	//											i.*, \
	//											IFNULL(fs.HealthMin, 0) HealthMin, \
	//											IFNULL(fs.HealthMax, 0) HealthMax, \
	//											IFNULL(f.FoliageTypeID, 0) FoliageTypeID, \
	//											IFNULL(f.FoliageSizeID, 0) FoliageSizeID, \
	//											IFNULL(f.SpeciesName, IFNULL(i.Name, '')) DisplayName, \
	//											IFNULL(fs.ScaleIndex, 0) FoliageScaleIndex, \
	//											IFNULL(t.ToolTypeID, 0) ToolTypeID, \
	//											IFNULL(t.BaseLevel, 0) BaseLevel, \
	//											IFNULL(( \
	//												select iu.Stage \
	//												from ItemUpgrade iu \
	//												where iu.UpgradedItemID = i.ItemID \
	//												order by iu.Stage \
	//												limit 1 \
	//											), 0) UpgradeStage \
	//										from ItemIngredient r \
	//											inner join Item i on r.ItemID = i.ItemID \
	//											left join Foliage f on i.ItemID = f.ItemID \
	//											left join FoliageSize fs on f.FoliageSizeID = fs.FoliageSizeID \
	//											left join Tool t on i.ItemID = t.ItemID \
	//										where (r.RecipeItemID = %i or r.ItemID = %i) \
	//											and i.CraftDuration > 0; "), ItemID, ItemID);
	//
	//	auto results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
	//	if (results.Success) {
	//		for (int i = 0; i < results.Results.Num(); i++) {
	//			UItemRecipeQueryResult * model = NewObject<UItemRecipeQueryResult>(UGameSettings::Instance);
	//			auto row = results.Results[i];
	//			USQLiteDatabase::AssignResultsToObjectProperties(row, model);
	//			collection.Add(model);
	//		}
	//	}
	//
	//	return collection;
	//}

TArray<int> UDatabaseLoader::GetRecipesForItem(int ItemID)
{
	TArray<int> collection;

	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
	{
		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
		{
			return collection;
		}
	}

	// TODO consts and precache at load to prevent 
	FString query = FString::Printf(TEXT("select distinct i.ItemID \
										from ItemIngredient r \
											inner join Item i on r.ItemID = i.ItemID \
										where (r.RecipeItemID = %i or r.ItemID = %i) \
											and i.CraftDuration > 0; "), ItemID, ItemID);

	auto results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
	if (results.Success) {
		for (int i = 0; i < results.Results.Num(); i++) {
			auto item_id = results.Results[i].Fields[0].IntValue;
			collection.Add(item_id);
		}
	}

	return collection;
}

//TArray<UItemIngredientQueryResult *> UDatabaseLoader::GetIngredientsForItem(int ItemID)
//{
//	auto existing = UDatabaseLoader::Instance->IngredientsForItemCache.Find(ItemID);
//	if (existing)
//	{
//		return existing->Entries;
//	}
//	/*if (DatabaseLoader::RecipesForItemCache.Num() > 0)
//	{
//		return DatabaseLoader::RecipesForItemCache;
//	}*/
//
//	TArray<UItemIngredientQueryResult *> collection;
//
//	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
//	{
//		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
//		{
//			return collection;
//		}
//	}
//
//	// TODO consts and precache at load to prevent 
//	FString query = FString::Printf(TEXT("select  \
	//											i.*, \
	//											IFNULL(fs.HealthMin, 0) HealthMin, \
	//											IFNULL(fs.HealthMax, 0) HealthMax, \
	//											IFNULL(f.FoliageTypeID, 0) FoliageTypeID, \
	//											IFNULL(f.FoliageSizeID, 0) FoliageSizeID, \
	//											IFNULL(f.SpeciesName, IFNULL(i.Name, '')) DisplayName, \
	//											IFNULL(fs.ScaleIndex, 0) FoliageScaleIndex, \
	//											IFNULL(r.RequiredQuantity, 0) RequiredQuantity, \
	//											IFNULL(t.ToolTypeID, 0) ToolTypeID, \
	//											IFNULL(t.BaseLevel, 0) BaseLevel, \
	//											IFNULL(( \
	//												select iu.Stage \
	//												from ItemUpgrade iu \
	//												where iu.UpgradedItemID = i.ItemID \
	//												order by iu.Stage \
	//												limit 1 \
	//											), 0) UpgradeStage \
	//										from ItemIngredient r \
	//											inner join Item i on r.RecipeItemID = i.ItemID \
	//											left join Foliage f on i.ItemID = f.ItemID \
	//											left join FoliageSize fs on f.FoliageSizeID = fs.FoliageSizeID \
	//											left join Tool t on i.ItemID = t.ItemID \
	//										where r.ItemID = %i; "), ItemID);
	//
	//	auto results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
	//	if (results.Success) {
	//		for (int i = 0; i < results.Results.Num(); i++) {
	//			UItemIngredientQueryResult * model = NewObject<UItemIngredientQueryResult>(UGameSettings::Instance);
	//			auto row = results.Results[i];
	//			USQLiteDatabase::AssignResultsToObjectProperties(row, model);
	//			collection.Add(model);
	//		}
	//	}
	//
	//	FIngredientForItemCacheEntry entries = FIngredientForItemCacheEntry(collection);
	//	UDatabaseLoader::Instance->IngredientsForItemCache.Add(ItemID, entries);
	//
	//	return collection;
	//}
TMap<int, float> UDatabaseLoader::GetIngredientsForItem(int ItemID)
{
	/*auto existing = UDatabaseLoader::Instance->IngredientsForItemCache.Find(ItemID);
	if (existing)
	{
		return existing->Entries;
	}*/
	/*if (DatabaseLoader::RecipesForItemCache.Num() > 0)
	{
		return DatabaseLoader::RecipesForItemCache;
	}*/

	TMap<int, float> collection;

	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
	{
		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
		{
			return collection;
		}
	}

	// TODO consts and precache at load to prevent 
	FString query = FString::Printf(TEXT("select distinct i.ItemID, IFNULL(r.RequiredQuantity, 0) RequiredQuantity \
										from ItemIngredient r \
											inner join Item i on r.RecipeItemID = i.ItemID \
											left join Foliage f on i.ItemID = f.ItemID \
											left join FoliageSize fs on f.FoliageSizeID = fs.FoliageSizeID \
											left join Tool t on i.ItemID = t.ItemID \
										where r.ItemID = %i; "), ItemID);

	auto results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
	if (results.Success) {
		for (int i = 0; i < results.Results.Num(); i++) {
			auto item_id = results.Results[i].Fields[0].IntValue;
			auto required_quantity = results.Results[i].Fields[1].DoubleValue;
			collection.Add(item_id, required_quantity);
		}
	}

	return collection;
}

TArray<UItemInteraction*> UDatabaseLoader::GetInteractionsForItem(int ItemID)
{
	/*auto existing = UDatabaseLoader::Instance->InteractionsForItemCache.Find(ItemID);
	if (existing)
	{
		return existing->Entries;
	}*/
	/*if (DatabaseLoader::RecipesForItemCache.Num() > 0)
	{
		return DatabaseLoader::RecipesForItemCache;
	}*/

	TArray<UItemInteraction*> collection;

	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
	{
		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
		{
			return collection;
		}
	}

	// TODO consts and precache at load to prevent 
	FString query = FString::Printf(TEXT("select \
											r.* \
										from ItemInteraction r \
										where r.ItemID = %i; "), ItemID);

	auto results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
	if (results.Success) {
		for (int i = 0; i < results.Results.Num(); i++) {
			UItemInteraction* model = NewObject<UItemInteraction>(UGameSettings::Instance);
			auto row = results.Results[i];
			USQLiteDatabase::AssignResultsToObjectProperties(row, model);
			collection.Add(model);
		}
	}

	//FInteractionForItemCacheEntry entries = FInteractionForItemCacheEntry(collection);
	//UDatabaseLoader::Instance->InteractionsForItemCache.Add(ItemID, entries);

	return collection;
}

//UToolBeltConfigQueryResult* DatabaseLoader::GetToolBeltConfig()
//{
//	if (!USQLiteDatabase::IsDatabaseRegistered(DatabaseLoader::DatabaseName))
//	{
//		if (!USQLiteDatabase::RegisterDatabase(DatabaseLoader::DatabaseName, DatabaseLoader::DatabasePath, true))
//		{
//			return NULL;
//		}
//	}
//	FString query = TEXT("select * from ToolBeltConfig where IsActive = 1 limit 1;");
//
//	auto results = USQLiteDatabase::RunQueryAndGetResults(DatabaseLoader::DatabaseName, query);
//	if (results.Success) {
//		for (int i = 0; i < results.Results.Num(); i++) {
//			UToolBeltConfigQueryResult * model = NewObject<UToolBeltConfigQueryResult>(UGameSettings::Instance);
//			auto row = results.Results[i];
//			USQLiteDatabase::AssignResultsToObjectProperties(row, model);
//			return model;
//		}
//	}
//
//	return NULL;
//}

//TArray<UItemAliasQueryByIDResult *> UDatabaseLoader::FindAliasByItem(UItemInstance* item)
TArray<UItemAliasQueryResult*> UDatabaseLoader::FindAliasByItem(UItemInstance * item)
{
	TArray<UItemAliasQueryResult*> collection;

	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
	{
		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
		{
			return collection;
		}
	}

	FString query = FString::Printf(TEXT("select ia.* \
							from ItemAlias ia \
							where ia.ItemID = %i \
							order by Priority asc"), item->ItemID);

	auto results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
	if (results.Success) {
		for (int i = 0; i < results.Results.Num(); i++) {
			UItemAliasQueryResult* model = NewObject<UItemAliasQueryResult>(UGameSettings::Instance);
			auto row = results.Results[i];
			USQLiteDatabase::AssignResultsToObjectProperties(row, model);
			collection.Add(model);
		}
	}

	return collection;
}

TArray<UItemAttributeQueryResult*> UDatabaseLoader::GetAttributesForItem(int ItemID)
{
	TArray<UItemAttributeQueryResult*> collection;

	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
	{
		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
		{
			return collection;
		}
	}

	FString query = FString::Printf(TEXT("select ia.* \
							from ItemAttribute ia \
							where ia.ItemID = %i"), ItemID);

	auto results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
	if (results.Success) {
		for (int i = 0; i < results.Results.Num(); i++) {
			UItemAttributeQueryResult* model = NewObject<UItemAttributeQueryResult>(UGameSettings::Instance);
			auto row = results.Results[i];
			USQLiteDatabase::AssignResultsToObjectProperties(row, model);
			collection.Add(model);
		}
	}

	return collection;
}

TArray<USurfaceEffectModel*> UDatabaseLoader::GetSurfaceEffects()
{
	TArray<USurfaceEffectModel*> collection;

	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
	{
		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
		{
			return collection;
		}
	}

	FString query = TEXT("select * \
						from SurfaceEffect se \
						order by se.SurfaceEffectID");

	auto results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
	if (results.Success) {
		for (int i = 0; i < results.Results.Num(); i++) {
			USurfaceEffectModel* model = NewObject<USurfaceEffectModel>(UGameSettings::Instance);
			auto row = results.Results[i];
			USQLiteDatabase::AssignResultsToObjectProperties(row, model);
			collection.Add(model);
		}
	}

	return collection;
}

TArray<USurfaceTypeModel*> UDatabaseLoader::GetSurfaceTypes()
{
	TArray<USurfaceTypeModel*> collection;

	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
	{
		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
		{
			return collection;
		}
	}

	FString query = TEXT("select * \
						from SurfaceType st \
							inner join SurfaceEffect se on st.SurfaceEffectID = se.SurfaceEffectID \
						order by st.USurfaceTypeID");

	auto results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
	if (results.Success) {
		for (int i = 0; i < results.Results.Num(); i++) {
			USurfaceTypeModel* model = NewObject<USurfaceTypeModel>(UGameSettings::Instance);
			auto row = results.Results[i];
			USQLiteDatabase::AssignResultsToObjectProperties(row, model);
			collection.Add(model);
		}
	}

	return collection;
}

TArray<USurfaceEffectSoundModel*> UDatabaseLoader::GetSurfaceEffectSounds(int surfaceEffectID)
{
	TArray<USurfaceEffectSoundModel*> collection;

	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
	{
		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
		{
			return collection;
		}
	}

	FString query = FString::Printf(TEXT("select * \
						from SurfaceEffectSound ses \
						where SurfaceEffectID = %i \
						order by Cue; "), surfaceEffectID);

	auto results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
	if (results.Success) {
		for (int i = 0; i < results.Results.Num(); i++) {
			USurfaceEffectSoundModel* model = NewObject<USurfaceEffectSoundModel>(UGameSettings::Instance);
			auto row = results.Results[i];
			USQLiteDatabase::AssignResultsToObjectProperties(row, model);
			collection.Add(model);
		}
	}

	return collection;
}

TArray<USurfaceEffectDecalModel*> UDatabaseLoader::GetSurfaceEffectDecals(int surfaceEffectID)
{
	TArray<USurfaceEffectDecalModel*> collection;

	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
	{
		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
		{
			return collection;
		}
	}

	FString query = FString::Printf(TEXT("select * \
						from SurfaceEffectDecal sed \
						where SurfaceEffectID = %i \
						order by Decal; "), surfaceEffectID);

	auto results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
	if (results.Success) {
		for (int i = 0; i < results.Results.Num(); i++) {
			USurfaceEffectDecalModel* model = NewObject<USurfaceEffectDecalModel>(UGameSettings::Instance);
			auto row = results.Results[i];
			USQLiteDatabase::AssignResultsToObjectProperties(row, model);
			collection.Add(model);
		}
	}

	return collection;
}

TArray<USurfaceEffectParticleModel*> UDatabaseLoader::GetSurfaceEffectParticles(int surfaceEffectID)
{
	TArray<USurfaceEffectParticleModel*> collection;

	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
	{
		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
		{
			return collection;
		}
	}

	FString query = FString::Printf(TEXT("select * \
						from SurfaceEffectParticle sed \
						where SurfaceEffectID = %i \
						order by Particle; "), surfaceEffectID);

	auto results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
	if (results.Success) {
		for (int i = 0; i < results.Results.Num(); i++) {
			USurfaceEffectParticleModel* model = NewObject<USurfaceEffectParticleModel>(UGameSettings::Instance);
			auto row = results.Results[i];
			USQLiteDatabase::AssignResultsToObjectProperties(row, model);
			collection.Add(model);
		}
	}

	return collection;
}

// int UDatabaseLibrary::Roulette(TArray<FWeighting> items)
// {
	// int items_length = items.Num();

	// // calculate the total weight
	// float weight_sum = 0.f;
	// bool weights_are_the_same = items_length > 0; // generally always true by default
	// for (int i = 0; i < items_length; i++) {
		// weight_sum += items[i].Weighting;

		// if (weights_are_the_same && i > 0) {
			// if (items[i - 1].Weighting != items[i].Weighting || items[i - 1].Weighting <= 0 || items[i].Weighting <= 0) { // if the previous value was different, or if the weight is <= 0 then there is nothing to pick from anyway
				// weights_are_the_same = false;
			// }
		// }
	// }

	// // if all weights are the same, assume equality and return a random pick
	// if (weights_are_the_same) {
		// int index  = rand() % items_length;
		// return index;
	// }

	// // get a random value
	// float value = (FMath::Rand() / double(RAND_MAX)) * weight_sum;

	// // locate the random value based on the weights
	// for (int i = 0; i < items_length; i++) {
		// value -= items[i].Weighting;
		// //GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString::FromInt(i).Append(":").Append(FString::SanitizeFloat(items[i].Weighting)));
		// if (value < 0) {
			// return i;
		// }
	// }

	// // when rounding errors occur, we return the last item's index 
	// return -1;
// }

//void USQLiteContentResolver::ResolveInteraction()
//{
//
//}

//bool USQLiteContentResolver::ResolveInteraction()
//{
//	return false;
//}

TArray<UItemUpgradeInstance*> UDatabaseLoader::GetUpgradeRequirements(int itemID)
{
	TArray<UItemUpgradeInstance*> collection;

	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
	{
		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
		{
			return collection;
		}
	}
	/*
		FString query = FString::Printf(TEXT("select \
												iu.ItemID, \
												iu.UpgradedItemID, \
												iu.Stage, \
												iur.* \
											from ItemUpgrade iu \
												inner join ItemUpgradeRequirement iur on iu.ItemUpgradeID = iur.ItemUpgradeID \
											where iu.ItemID = %i \
												and iu.ItemUpgradeID = ( \
													select iui.ItemUpgradeID \
													from ItemUpgrade iui \
													where iui.ItemID = iu.ItemID \
														and iui.Stage > %i \
													order by iui.Stage \
													limit 1 \
												)"), itemID, currentStage);*/
	FString query = FString::Printf(TEXT("select \
											iu.ItemID, \
											iu.UpgradedItemID, \
											iu.Stage, \
											iur.* \
										from ItemUpgrade iu \
											inner join ItemUpgradeRequirement iur on iu.ItemUpgradeID = iur.ItemUpgradeID \
										where iu.ItemID = %i\
										order by iu.Stage"), itemID);

	auto results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
	if (results.Success) {
		for (int i = 0; i < results.Results.Num(); i++) {
			UItemUpgradeInstance* model = NewObject<UItemUpgradeInstance>(UGameSettings::Instance);
			auto row = results.Results[i];
			USQLiteDatabase::AssignResultsToObjectProperties(row, model);
			collection.Add(model);
		}
	}

	return collection;
}

TArray<UItemRepairInstance*> UDatabaseLoader::GetRepairRequirements(int itemID)
{
	TArray<UItemRepairInstance*> collection;

	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
	{
		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
		{
			return collection;
		}
	}
	/*
		FString query = FString::Printf(TEXT("select \
												iu.ItemID, \
												iu.UpgradedItemID, \
												iu.Stage, \
												iur.* \
											from ItemUpgrade iu \
												inner join ItemUpgradeRequirement iur on iu.ItemUpgradeID = iur.ItemUpgradeID \
											where iu.ItemID = %i \
												and iu.ItemUpgradeID = ( \
													select iui.ItemUpgradeID \
													from ItemUpgrade iui \
													where iui.ItemID = iu.ItemID \
														and iui.Stage > %i \
													order by iui.Stage \
													limit 1 \
												)"), itemID, currentStage);*/
	FString query = FString::Printf(TEXT("select ir.* \
										from ItemRepair ir \
										where ir.ItemID = %i"), itemID);

	auto results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
	if (results.Success) {
		for (int i = 0; i < results.Results.Num(); i++) {
			UItemRepairInstance* model = NewObject<UItemRepairInstance>(UGameSettings::Instance);
			auto row = results.Results[i];
			USQLiteDatabase::AssignResultsToObjectProperties(row, model);
			collection.Add(model);
		}
	}

	return collection;
}

TArray<UItemContainerCache*> UDatabaseLoader::GetItemContainers()
{
	TArray<UItemContainerCache*> collection;

	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
	{
		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
		{
			return collection;
		}
	}
	//UItemContainerCache

	FString query = TEXT("select ic.* \
		from ItemContainer ic \
		order by ic.ItemContainerID");

	auto results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
	if (results.Success) {
		for (auto container_row : results.Results) {
			UItemContainerCache* container = NewObject<UItemContainerCache>(UGameSettings::Instance);
			USQLiteDatabase::AssignResultsToObjectProperties(container_row, container);

			query = FString::Printf(TEXT("select ici.* \
					from ItemContainer ic \
						inner join ItemContainerItem ici on ic.ItemContainerID = ici.ItemContainerID \
					where ic.ItemContainerID = %i \
					order by ic.ItemContainerID, ici.ItemID"), container->ItemContainerID);

			auto item_results = USQLiteDatabase::RunQueryAndGetResults(UDatabaseLoader::DatabaseName, query, UDatabaseLoader::Instance->SqliteDatabase);
			if (item_results.Success) {
				for (auto item_row : item_results.Results) {
					UItemContainerCacheItem* container_item = NewObject<UItemContainerCacheItem>(container);
					USQLiteDatabase::AssignResultsToObjectProperties(item_row, container_item);
					container->Items.Add(container_item);
				}
			}

			collection.Add(container);
		}
	}

	return collection;
}