// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h" 
#include "InstancedComponentsEntry.generated.h"

UENUM(BlueprintType)
enum class EInstancedCategory : uint8
{
	Any = 0 UMETA(DisplayName = "Any"),
	Foliage = 1 UMETA(DisplayName = "Foliage"),
	Buildings = 2 UMETA(DisplayName = "Buildings"),
	Decals = 3 UMETA(DisplayName = "Decals")
};

USTRUCT(Blueprintable, BlueprintType)
struct FInstancedComponentsEntry
{
	GENERATED_USTRUCT_BODY()
public:
	UPROPERTY()
		UHierarchicalInstancedStaticMeshComponent* Component;

	// this is how we reverse lookup instances and find the UWorldStaticMeshComponent instance that is to be looking after the instance
	// the index of this array directly maps to the components instance body index. this is because when UE does 'RemoveInstance' it will shrink
	// its instances array, so we then have to shrink ours too rather than use a lookup/map and have to update all keys.
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<UObject*> ComponentData;

	UPROPERTY()
		EInstancedCategory Category;

	FInstancedComponentsEntry() {}
	FInstancedComponentsEntry(UHierarchicalInstancedStaticMeshComponent* component, EInstancedCategory category)
	{
		this->Component = component;
		this->Category = category;
	}
};