// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Database.h"
#include "ItemCache.generated.h"

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FItemCacheAlias
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<UItemAliasInstance*> Aliases;
};

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FItemCacheItem
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<FItemData> Items;
};

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FItemCacheInteraction
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<UItemInteraction*> Interactions;
};

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FItemCacheUpgrade
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<UItemUpgradeInstance*> Upgrades;
};

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FItemCacheLoot
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TMap<EInteractionTrigger, FItemCacheItem> InteractionLoot;
};

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FItemCacheRepair
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<UItemRepairInstance*> Repairs;
};
//USTRUCT(Blueprintable, BlueprintType)
//struct FPSPROJECT_API FItemContainerCache
//{
//	GENERATED_BODY()
//
//public:
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		TArray<UItemContainerCache*> Items;
//};

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable)
class FPSPROJECT_API UItemCache : public UObject
{
	GENERATED_BODY()

private:


public:
	//static UItemCache* Instance;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TMap<int, UItemInstance*> Instances;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TMap<int, FItemData> Items;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TMap<FString, int> AliasToID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TMap<int, FItemCacheAlias> ItemAliases;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TMap<int, FItemCacheItem> ItemRecipes;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TMap<int, FItemCacheInteraction> ItemInteractions;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TMap<int, FItemCacheUpgrade> ItemUpgrades;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TMap<int, FItemCacheItem> ItemIngredients;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TMap<int, FItemCacheLoot> ItemLoot;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<FItemData> Recipes;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TMap<int, FItemCacheRepair> ItemRepair;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TMap<FString, UItemContainerCache*> ItemContainers;

	UFUNCTION(BlueprintCallable) void Load()
	{
		//UItemCache::Instance = this;

		TArray<UItemInstance*> instances;
		// query everything from Item table
		// create instances
		// call init
		auto items = UDatabaseLoader::FindItemsByID(-1);
		for (auto item : items)
		{
			auto item_instance = item->AsItemInstance(this, item, false);
			item_instance->Data.ItemID = item_instance->ItemID;

			this->Instances.Add(item_instance->ItemID, item_instance);
			//this->Items.Add(item_instance.ItemID, item_instance);
			instances.Add(item_instance);
			this->Items.Add(item_instance->ItemID, item_instance->Data);
		}

		auto aliases = UDatabaseLoader::FindItemsByAlias(FString(TEXT("")));
		for (auto alias : aliases) {
			auto alias_instance = alias->AsItemAliasInstance(this);

			auto cache = this->ItemAliases.Find(alias->ItemID);
			if (cache) {
				cache->Aliases.Add(alias_instance);
			}
			else {
				FItemCacheAlias record;
				TArray<UItemAliasInstance*> arr;
				arr.Add(alias_instance);
				record.Aliases = arr;
				this->ItemAliases.Add(alias->ItemID, record);
			}
		}

		auto item_containers = UDatabaseLoader::GetItemContainers();
		for (auto container : item_containers)
		{
			auto existing = ItemContainers.Find(container->Name);
			//FItemContainerCache cache;
			//cache.Items.Add(container);
			ItemContainers.Add(container->Name, container);
		}

		for (auto item : instances)
		{
#pragma region Recipes for item
			TArray<int> recipe_ids = UDatabaseLoader::GetRecipesForItem(item->ItemID);
			TArray<FItemData> recipes;

			for (int item_id : recipe_ids) {
				auto recepe_item = this->GetItemByID(item_id);
				recipes.Add(recepe_item);
			}

			FItemCacheItem recipe_cache;
			recipe_cache.Items = recipes;
			this->ItemRecipes.Add(item->ItemID, recipe_cache);
#pragma endregion
#pragma region Interactions
			TArray<UItemInteraction*> interactions;

			/*if (item->ManualInteractions.Num() > 0) {
				for (int i = 0; i < item->ManualInteractions.Num(); i++) {
					auto ii = NewObject<UItemInteraction>(item);
					auto sii = item->ManualInteractions[i];

					ii->ItemInteractionID = 0;
					ii->ItemGroupID = sii.ItemGroupID;
					ii->SurfaceEffectID = sii.SurfaceEffectID;

					interactions.Add(ii);
				}
			}
			else {*/
			interactions = UDatabaseLoader::GetInteractionsForItem(item->ItemID);
			//}

			FItemCacheInteraction interaction_cache;
			interaction_cache.Interactions = interactions;
			this->ItemInteractions.Add(item->ItemID, interaction_cache);
#pragma endregion
#pragma region Upgrades
			auto upgrades = UDatabaseLoader::GetUpgradeRequirements(item->ItemID);
			FItemCacheUpgrade upgrade_cache;
			upgrade_cache.Upgrades = upgrades;
			this->ItemUpgrades.Add(item->ItemID, upgrade_cache);
#pragma endregion
#pragma region Repair
			auto repairs = UDatabaseLoader::GetRepairRequirements(item->ItemID);
			FItemCacheRepair repair_cache;
			repair_cache.Repairs = repairs;
			this->ItemRepair.Add(item->ItemID, repair_cache);
#pragma endregion
#pragma region Ingredients
			auto ingredient_pairs = UDatabaseLoader::GetIngredientsForItem(item->ItemID);
			TArray<FItemData> ingredients;

			for (auto pair : ingredient_pairs) {
				auto ingredient_item = this->GetItemByID(pair.Key);
				ingredient_item.Stack = pair.Value;
				ingredients.Add(ingredient_item);
			}

			FItemCacheItem ingredient_cache;
			ingredient_cache.Items = ingredients;
			this->ItemIngredients.Add(item->ItemID, ingredient_cache);
#pragma endregion
#pragma region Loot
			FItemCacheLoot loot_cache;

			int max_interaction_triggers = static_cast<int>(EInteractionTrigger::MAX);
			for (int i = 1; i <= max_interaction_triggers; i++) {
				EInteractionTrigger trigger = static_cast<EInteractionTrigger>(i);

				////auto loot = UContentResolver::Instance->ResolveLootForItem(this, trigger);
				TArray<FItemData> loot;

				auto results = UDatabaseLoader::GetLootForItem(item->ItemID, trigger);
				for (auto result : results) {
					auto ingredient_item = this->GetItemByID(result.ItemID);
					ingredient_item.ItemLootFormulaID = result.ItemLootFormulaID;
					ingredient_item.ItemLootFormulaValue = result.ItemLootFormulaValue;

					loot.Add(ingredient_item);
				}

				FItemCacheItem loot_trigger_cache;
				//item->CalculateLootTable(loot);
				loot_trigger_cache.Items = loot;
				loot_cache.InteractionLoot.Add(trigger, loot_trigger_cache);
			}
			this->ItemLoot.Add(item->ItemID, loot_cache);
#pragma endregion

		}

		for (auto item : instances)
		{
			item->Load();
			item->PostCacheLoad();

			//auto data = this->GetItemByID(item->ItemID);
			for (auto alias : FItemData::GetAliases(item->ItemID, this))
			{
				this->AliasToID.Add(alias->Name, item->ItemID);
			}
		}

#pragma region Recipes
		auto game_recipe_ids = UDatabaseLoader::GetRecipes();

		TArray<FItemData> game_recipes;

		for (int item_id : game_recipe_ids) {
			auto recipe_item = this->GetItemByID(item_id);
			game_recipes.Add(recipe_item);
		}
		this->Recipes = game_recipes;
#pragma endregion
	}

	UFUNCTION(BlueprintCallable) UItemInstance* GetLocalItemByID(int ItemID)
	{
		UItemInstance* item = NULL;

		// find by id, then clone
		auto instance = this->Instances.Find(ItemID);
		if (instance) {
			/*if (Clone) {
				item = (*instance)->Clone(this);
			}
			else {*/
			item = *instance;
			//}
		}

		return item;
	}

	UFUNCTION(BlueprintCallable) FItemData GetItemByID(int ItemID)
	{
		FItemData item = FItemData(); // = NULL;

		// find by id, then clone
		auto instance = this->Items.Find(ItemID);
		if (instance) {
			/*if (Clone) {
				item = (*instance)->Clone(this);
			}
			else {*/
			item = *instance;
			//}
		}

		return item;
	}

	UFUNCTION(BlueprintCallable) FItemData SetItemByID(int ItemID, FItemData data)
	{
		FItemData item = data; // = NULL;

		auto instance = this->Items.Find(ItemID);
		if (instance) {
			this->Items[ItemID] = data;
		}
		else {
			this->Items.Add(ItemID, item);
		}

		return item;
	}

	UFUNCTION(BlueprintCallable) FItemData GetItemByAlias(FString Alias)
	{
		FItemData item = FItemData(); // = NULL;

		// find by id, then clone
		auto id = this->AliasToID.Find(Alias);
		if (id) {
			item = this->GetItemByID(*id);
		}

		return item;
	}

	UFUNCTION(BlueprintCallable) TArray<UItemAliasInstance*> GetItemAliasesByID(int ItemID)
	{
		TArray<UItemAliasInstance*> aliases;

		// find by id, no need for clone since aliases are shared
		auto cache = this->ItemAliases.Find(ItemID);
		if (cache) {
			aliases = cache->Aliases;
		}

		return aliases;
	}

	UFUNCTION(BlueprintCallable) TArray<UItemAliasInstance*> GetItemAliasesByName(FString Alias)
	{
		TArray<UItemAliasInstance*> aliases;

		int32* id = this->AliasToID.Find(Alias);
		if (id) {
			// find by id, no need for clone since aliases are shared
			int item_id = *id;
			auto cache = this->ItemAliases.Find(item_id);
			if (cache) {
				aliases = cache->Aliases;
			}
		}

		return aliases;
	}

	UFUNCTION(BlueprintCallable) TArray<FItemData> GetItemRecipes(int ItemID)
	{
		TArray<FItemData> recipes;

		auto cache = this->ItemRecipes.Find(ItemID);
		if (cache) {
			recipes = cache->Items;
		}

		return recipes;
	}

	UFUNCTION(BlueprintCallable) TArray<UItemInteraction*> GetItemInteractions(int ItemID)
	{
		TArray<UItemInteraction*> interactions;

		auto cache = this->ItemInteractions.Find(ItemID);
		if (cache) {
			interactions = cache->Interactions;
		}

		return interactions;
	}

	UFUNCTION(BlueprintCallable) TArray<UItemUpgradeInstance*> GetItemUpgrades(int ItemID)
	{
		TArray<UItemUpgradeInstance*> upgrades;

		auto cache = this->ItemUpgrades.Find(ItemID);
		if (cache) {
			upgrades = cache->Upgrades;
		}

		return upgrades;
	}

	UFUNCTION(BlueprintCallable) TArray<UItemRepairInstance*> GetItemRepairRequirements(int ItemID)
	{
		TArray<UItemRepairInstance*> repairs;

		auto cache = this->ItemRepair.Find(ItemID);
		if (cache) {
			repairs = cache->Repairs;
		}

		return repairs;
	}

	UFUNCTION(BlueprintCallable) TArray<FItemData> GetItemIngredients(int ItemID)
	{
		TArray<FItemData> ingredients;

		auto cache = this->ItemIngredients.Find(ItemID);
		if (cache) {
			ingredients = cache->Items;
		}

		return ingredients;
	}

	UFUNCTION(BlueprintCallable) TArray<FItemData> GetItemLoot(int ItemID, const EInteractionTrigger& trigger)
	{
		TArray<FItemData> loot;

		auto item_triggers = this->ItemLoot.Find(ItemID);
		if (item_triggers) {
			auto trigger_loot = item_triggers->InteractionLoot.Find(trigger);
			if (item_triggers) {
				loot = trigger_loot->Items;
			}
		}

		return loot;
	}

	UFUNCTION(BlueprintCallable) TArray<FItemData> GetRecipes()
	{
		return this->Recipes;
	}

	UFUNCTION(BlueprintCallable) UItemContainerCache* GetItemContainer(FString containerName)
	{
		UItemContainerCache* result = NULL;

		auto item_cache = this->ItemContainers.Find(containerName);
		if (item_cache) {
			result = *item_cache;
		}

		return result;
	}
};

