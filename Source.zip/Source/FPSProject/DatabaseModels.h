// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ContentResolver.h"
#include "SurfaceEffectSound.h"
#include "DestructibleMesh.h"
#include "DatabaseModels.generated.h"

class UItemAliasQueryResult;

/*
Item
*/
UCLASS()
class UItemModel : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString Name;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString Thumbnail;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString DisplayName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemGroupID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float HealthMin;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float HealthMax;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float MaxStack;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool LootSelf;*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int FoliageTypeID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemLootFormulaID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float ItemLootFormulaValue;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int FoliageScaleIndex;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ToolTypeID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int BaseLevel;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float Health;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int CraftDuration;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int RepairDuration;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float Weight;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString BuildOffset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString BuildTargetSockets;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int BuildOnGround;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int BuildSocketRequired;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int UpgradeStage;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString HandOffsetLocation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString HandOffsetRotation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float InteractionDelay;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int InteractionMode;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float FireBurnTime;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float FuelProduced;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString PreviewMesh;*/

	static TArray<UItemModel*> Instances;

	//virtual UItemInstance * AsItemInstance(UObject * owner, UItemAliasQueryByAliasResult* existingAlias = NULL);
	virtual UItemInstance* AsItemInstance(UObject* owner, UItemAliasQueryResult* existingAlias = NULL, bool load = true);

	UTexture2D* LoadThumbnail(UObject* outer);
};

//UCLASS()
//class UItemGroupModel : public UObject
//{
//	GENERATED_BODY()
//
//public:
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		int ItemGroupID;
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		FString Name;
//};
//
//UCLASS()
//class UItemInteractionModel : public UObject
//{
//	GENERATED_BODY()
//
//public:
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		int ItemInteractionID;
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		int ItemID;
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		int ItemGroupID;
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		int SurfaceEffectID;
//};

/*
Surface
*/
UCLASS()
class USurfaceEffectModel : public UObject
{
	GENERATED_BODY()

		USurfaceEffect* effect;

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int SurfaceEffectID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString Name;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString HitParticle;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float HitParticleMinSpeed;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString HitParticleRotation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString HitParticleScale;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool AllowHitImpulse;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool AllowDamage;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool DestroyActorOnHit;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString DecalType;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString Decal;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString DecalSize;*/

	virtual USurfaceEffect* AsSurfaceEffect(UObject* outer);

	//static TArray<USurfaceEffectModel *> Instances;v
/*
	FVector ParseVector(const FString& reference);
	FRotator ParseRotator(const FString& reference);*/
	UMaterialInterface* ParseMaterial(const FString& reference);
};

UCLASS()
class USurfaceTypeModel : public USurfaceEffectModel
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int USurfaceTypeID; // configured in unreal under the project settings -> surface types

							//static TArray<USurfaceTypeModel *> Instances; // key of USurfaceTypeID

	//virtual USurfaceEffect* AsSurfaceEffect(UObject * outer) override;
};

UCLASS()
class USurfaceEffectSoundModel : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int SurfaceEffectSoundID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int SurfaceEffectID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString Cue;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float Weighting;

	USurfaceEffectSound* AsSurfaceEffectSound(UObject* outer);

	//USoundCue * ParseCue(const FString& reference);
};

UCLASS()
class USurfaceEffectDecalModel : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int SurfaceEffectDecalID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int SurfaceEffectID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString Decal;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString DecalSize;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float Weighting;

	USurfaceEffectDecal* AsSurfaceEffectDecal(UObject* outer);

	//USoundCue * ParseCue(const FString& reference);
};

UCLASS()
class USurfaceEffectParticleModel : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int SurfaceEffectParticleID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int SurfaceEffectID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString Particle;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString Rotation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString Scale;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float Weighting;

	USurfaceEffectParticle* AsSurfaceEffectParticle(UObject* outer);

	//USoundCue * ParseCue(const FString& reference);
};


/*
=============================================================================================
									Query Models
=============================================================================================
*/


/*
Item
*/

//UCLASS()
//class UItemAliasQueryByIDResult : public UObject
//{
//	GENERATED_BODY()
//
//public:
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		FString ItemAlias;
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		FString DefaultComponent; //keep in sync with AItemActor,UItemAliasQueryByIDResult, FindItemsByAlias
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		FString ActorBlueprint; //keep in sync with AItemActor,UItemAliasQueryByAliasResult, FindItemsByAlias
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		int FoliageIndex; //keep in sync with AItemActor,UItemAliasQueryByAliasResult, FindItemsByAlias
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		int ItemPlaceableTypeID; //keep in sync with AItemActor,UItemAliasQueryByAliasResult, FindItemsByAlias
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		FString Particle; //keep in sync with AItemActor,UItemAliasQueryByAliasResult, FindItemsByAlias
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		FString ParticleRotation; //keep in sync with AItemActor,UItemAliasQueryByAliasResult, FindItemsByAlias
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		FString ParticleScale; //keep in sync with AItemActor,UItemAliasQueryByAliasResult, FindItemsByAlias
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		int ParticleFlags; //keep in sync with AItemActor,UItemAliasQueryByAliasResult, FindItemsByAlias
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		FString DestructibleMesh; //keep in sync with AItemActor,UItemAliasQueryByAliasResult, FindItemsByAlias
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		int HealthBreakpoint; //keep in sync with AItemActor,UItemAliasQueryByAliasResult, FindItemsByAlias
//
//	UItemAliasInstance * AsItemAliasInstance(UObject * outer);
//};

UCLASS()
//class UItemAliasQueryByAliasResult : public UItemModel
class UItemAliasQueryResult : public UItemModel
{
	GENERATED_BODY()

public:
	//UPROPERTY(EditAnywhere, BlueprintReadWrite)
		//int ItemID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString ItemAlias;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString DefaultComponent; //keep in sync with AItemActor,UItemAliasQueryByIDResult

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString ActorBlueprint; //keep in sync with AItemActor,UItemAliasQueryByIDResult

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int FoliageIndex; //keep in sync with AItemActor,UItemAliasQueryByIDResult

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemPlaceableTypeID; //keep in sync with AItemActor,UItemAliasQueryByIDResult

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString Particle; //keep in sync with AItemActor,UItemAliasQueryByIDResult

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString ParticleRotation; //keep in sync with AItemActor,UItemAliasQueryByAliasResult, FindItemsByAlias

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString ParticleScale; //keep in sync with AItemActor,UItemAliasQueryByIDResult

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ParticleFlags; //keep in sync with AItemActor,UItemAliasQueryByIDResult

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString DestructibleMesh; //keep in sync with AItemActor,UItemAliasQueryByIDResult

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int HealthBreakpoint; //keep in sync with AItemActor,UItemAliasQueryByAliasResult, FindItemsByAlias

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int BreakpointSurfaceEffectID; //keep in sync with AItemActor,UItemAliasQueryByAliasResult, FindItemsByAlias

	UItemAliasInstance* AsItemAliasInstance(UObject* outer);
};
//
//UCLASS()
//class UItemLootQueryResult : public UItemModel
//{
//	GENERATED_BODY()
//
//public:
//	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		float LootQuantity;*/
//
//		//UItemInstance * AsItemInstance(UItemInstance * owner);
//};

USTRUCT()
struct FItemLootQueryResult
{
	GENERATED_BODY()

public:
	int ItemID;
	int ItemLootFormulaID;
	float ItemLootFormulaValue;
};

//UCLASS()
//class UItemRecipeQueryResult : public UItemModel
//{
//	GENERATED_BODY()
//
//public:
//	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		float RequiredQuantity;*/
//
//		//UItemInstance * AsItemInstance(UItemInstance * owner);
//
//		//UItemInstance * AsItemInstance(UObject * owner) override;
//};

UCLASS()
class UItemIngredientQueryResult : public UItemModel
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float RequiredQuantity;

	UItemInstance* AsItemInstance(UObject* owner, UItemAliasQueryResult* existingAlias = NULL, bool load = true) override;
	//UItemInstance * AsItemInstance(UObject * owner, UItemAliasQueryByAliasResult* existingAlias = NULL) override;
};

/*
Tool Belt
*/
//UCLASS()
//class UToolBeltConfigQueryResult : public UObject
//{
//	GENERATED_BODY()
//
//public:
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		int Slots;
//};

UCLASS()
class UItemAttributeQueryResult : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemAttributeID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemAttributeTypeID;
};

/*UCLASS()
class UItemUpgradeRequirementResult : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemUpgradeID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int UpgradedItemID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int Stage;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int ItemUpgradeRequirementID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int RequiredItemID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float Stack;
};*/