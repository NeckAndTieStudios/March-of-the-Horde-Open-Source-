// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ItemInstance.h"
#include "DatabaseModels.h"
#include "IngredientForItemCacheEntry.generated.h"

USTRUCT(Blueprintable, BlueprintType)
struct FIngredientForItemCacheEntry
{
	GENERATED_USTRUCT_BODY()
public:
	UPROPERTY()
		TArray<UItemIngredientQueryResult *> Entries;

	FIngredientForItemCacheEntry() {}
	FIngredientForItemCacheEntry(TArray<UItemIngredientQueryResult *> entries)
	{
		this->Entries = entries;
	}
};

USTRUCT(Blueprintable, BlueprintType)
struct FInteractionForItemCacheEntry
{
	GENERATED_USTRUCT_BODY()
public:
	UPROPERTY()
		TArray<UItemInteraction *> Entries;

	FInteractionForItemCacheEntry() {}
	FInteractionForItemCacheEntry(TArray<UItemInteraction *> entries)
	{
		this->Entries = entries;
	}
};