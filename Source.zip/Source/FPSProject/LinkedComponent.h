// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "LinkedComponent.generated.h"

class UBuildingComponent;

UENUM(BlueprintType)
enum class ELinkedComponentType : uint8
{
	Unknown = 0,
	Root,
	RootArch,
	RootSCS,
	Child,
	ChildArch,
	USCS,
	USCSArch
};

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FLinkedComponent
{
	GENERATED_BODY()

		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Linked Component")
		ELinkedComponentType Type = ELinkedComponentType::Unknown;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Linked Component")
		UInstancedStaticMeshComponent* Component = NULL;

	FLinkedComponent() {}
	FLinkedComponent(ELinkedComponentType type, UInstancedStaticMeshComponent* component)
		: Type(type), Component(component) {}

	/*static friend bool operator==(FLinkedComponent& A, FLinkedComponent& B)
	{
		return ((uint8)A.Type == (uint8)B.Type) && (A.Component == B.Component);
	}*/
	//static friend bool operator==(FLinkedComponent& A, USceneComponent& B)
	//{
	//	return A.Component == B;
	//}
};