// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "ItemInstance.h"
#include "Engine/ActorChannel.h"
#include "UnrealNetwork.h"
#include "ItemContainer.generated.h"

//USTRUCT(Blueprintable, BlueprintType)
//struct FInventoryConfig
//{
//	GENERATED_USTRUCT_BODY()
//public:
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		FString InventoryName;
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		int Columns;
//
//	UPROPERTY(EditAnywhere, BlueprintReadWrite)
//		int Rows;
//};


UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable, BlueprintType)
class UItemContainerComponent : public USceneComponent
{
	GENERATED_BODY()
protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override
	{
		/*GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString(TEXT("UItemContainerComponent.BeginPlay")));
		UE_LOG(LogTemp, Warning, TEXT("UItemContainerComponent.BeginPlay"));
		if (GetOwner()->HasAuthority())
		{
			GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString(TEXT("UItemContainerComponent.BeginPlay AUTH")));
			UE_LOG(LogTemp, Warning, TEXT("UItemContainerComponent.BeginPlay AUTH"));
			this->Container = NewObject<UItemContainer>(this, ItemContainerClass, FName(*FString("Container")));
			this->SetNetAddressable();
		}*/
		Super::BeginPlay();
		/*if (!GetOwner()->HasAuthority()) {
			Super::BeginPlay();
			GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString(TEXT("UItemContainerComponent.BeginPlay no auth")));
			UE_LOG(LogTemp, Warning, TEXT("UItemContainerComponent.BeginPlay no auth"));
		}
		else {
			GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString(TEXT("UItemContainerComponent.BeginPlay authed")));
			UE_LOG(LogTemp, Warning, TEXT("UItemContainerComponent.BeginPlay authed"));
			this->Container = NewObject<UItemContainer>(this->GetOwner(), ItemContainerClass);
			Super::BeginPlay();
		}*/
	}
public:
	virtual void OnRegister() override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Weapons)
		TSubclassOf<class UItemContainer> ItemContainerClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString ContainerName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Replicated, ReplicatedUsing = OnRep_Container)
		UItemContainer* Container;

	// return true to cancel/consume
	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent) bool OnRequestDrop(FItemData item, int slot);

	UFUNCTION() virtual void OnRep_Container();

	void GetLifetimeReplicatedProps(TArray<FLifetimeProperty >& OutLifetimeProps) const
	{
		Super::GetLifetimeReplicatedProps(OutLifetimeProps);

		DOREPLIFETIME(UItemContainerComponent, Container);
	}

	virtual bool ReplicateSubobjects(class UActorChannel* Channel, class FOutBunch* Bunch, FReplicationFlags* RepFlags) override;

	UFUNCTION(BlueprintImplementableEvent) void OnPostReplicate();

	virtual void PostRepNotifies() override
	{
		Super::PostRepNotifies();
		//GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString(TEXT("UItemContainerComponent.PostRepNotifies")));
		//UE_LOG(LogTemp, Warning, TEXT("UItemContainerComponent.PostRepNotifies"));
		this->OnPostReplicate();
	}
};

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent), Blueprintable, BlueprintType)
class UItemContainer : public UObject
{
	GENERATED_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Replicated)
		FString Name;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Replicated, ReplicatedUsing = OnRep_Items)
		TArray<FItemData> Items;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UItemContainerComponent* OwningComponent = NULL;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int Columns = 1;

	UFUNCTION() virtual void OnRep_Items()
	{
		//GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString(TEXT("UItemContainer.Items replicated")));
		//UE_LOG(LogTemp, Warning, TEXT("UItemContainer.Items replicated"));
	}

	//UFUNCTION(BlueprintCallable) void Setup(FInventoryConfig config)
	//{
	//	this->Name = config.InventoryName;
	//	//Items.(config.Rows * config.Columns);
	//	Items.Init(NULL, config.Rows * config.Columns);
	//}

	UFUNCTION(BlueprintCallable) void Setup(FString InventoryName, int Slots)
	{
		this->Name = InventoryName;
		//Items.(config.Rows * config.Columns);
		//Items.Init(NULL, Slots);
		Items.Init(FItemData(), Slots);
	}

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int Slots;*/

	UFUNCTION(BlueprintCallable) float CalculateWeight()
	{
		float weight = 0.f;

		for (auto item : this->Items)
		{
			/*if (item)
				weight += item->Weight * item->Stack;*/
			if (item.ItemID > 0)
				weight += item.Weight * item.Stack;
		}

		return weight;
	}

	/*bool IsNameStableForNetworking() const override
	{
		return true;
	}*/

	bool IsSupportedForNetworking() const override
	{
		return true;
	}

	void GetLifetimeReplicatedProps(TArray<FLifetimeProperty >& OutLifetimeProps) const
	{
		Super::GetLifetimeReplicatedProps(OutLifetimeProps);

		DOREPLIFETIME(UItemContainer, Name);
		DOREPLIFETIME(UItemContainer, Items);
	}

	virtual bool ReplicateSubobject(UActorChannel* Channel, FOutBunch* Bunch, FReplicationFlags* RepFlags) //override
	{
		bool changed = false;
		//changed |= Channel->Repli(Name, *Bunch, *RepFlags);
		//changed |= Channel->ReplicateSubobjectList(Items, *Bunch, *RepFlags);
		//changed |= Channel->Repli(Name, *Bunch, *RepFlags);
		//changed |= Channel->Repl(Items, *Bunch, *RepFlags);
		//changed |= Channel->ReplicateSubobjectList(Items, *Bunch, *RepFlags);
		/*for (auto item : Items)
		{
			if (item.ItemID)
			{
				changed |= Channel->ReplicateSubobject(item, *Bunch, *RepFlags);
			}
		}*/

		return changed;
	}
};
