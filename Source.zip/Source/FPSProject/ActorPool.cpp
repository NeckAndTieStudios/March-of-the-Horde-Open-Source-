// Fill out your copyright notice in the Description page of Project Settings.

#include "ActorPool.h"
#include "Engine/StaticMeshActor.h"
#include "DrawDebugHelpers.h"

UActorPool::UActorPool()
{
}
UActorPool::~UActorPool()
{
}

void UActorPool::allocate()
{
	/*if (GEngine) {
		GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("Allocating more bullets to the pool"));
	}*/
	UWorld* wp = this->GetWorld();
	if (wp) {
		for (int i = 0; i < this->BlockSize; i++)
		{
			auto actor = wp->SpawnActor<AActor>(ActorClass, FVector(0), FRotator(0));

			if (actor->IsA(AStaticMeshActor::StaticClass()))
			{
				auto sma = Cast<AStaticMeshActor>(actor);
				sma->GetStaticMeshComponent()->SetMobility(EComponentMobility::Movable);
			}

			// bind the allocated actor to this pool
			auto component = NewObject<UActorPoolComponent>(actor, UActorPoolComponent::StaticClass());
			component->Pool = this;

			//auto entry = FActorPoolEntry(actor);
			this->pool.Enqueue(actor);
			this->capacity++;
		}
	}
	else {
		/*if (GEngine) {
			GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("No world instance for actor pool"));
		}*/
	}
}

AActor * UActorPool::Aquire()
{
	AActor * actor = NULL;

	if (this->pool.IsEmpty())
	{
		if (!this->AllowIncrease)
		{
			return actor;
		}
		// more allocation required
		this->allocate();
	}

	//FActorPoolEntry entry = FActorPoolEntry();
	this->pool.Dequeue(actor);

	if (actor)
	{
		this->leased.Add(actor);
	}

	return actor;
}

int UActorPool::FindLeased(AActor * actor)
{
	for (int i = 0; i < this->leased.Num(); i++)
	{
		auto leased_actor = this->leased[i];
		if (leased_actor == actor) {
			return i;
		}
	}
	return -1;
}

bool UActorPool::IsLeased(AActor * actor)
{
	return this->FindLeased(actor) > -1;
}

void UActorPool::Release(AActor * actor)
{
	if (this->IsLeased(actor))
	{
		actor->SetActorHiddenInGame(true);
		this->leased.Remove(actor);
		this->pool.Enqueue(actor);
	}
	/*else {
		GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, TEXT("Tried releasing an actor when it was not leased"));
	}*/
}

void UActorPool::ReleaseByArg(AActor * actor)
{
	//auto bullet = Cast<AActor>(actor);
	if (actor)
	{
		this->Release(actor);
	}
}

int UActorPool::GetCapacity()
{
	return this->capacity;
}

int UActorPool::GetLeased()
{
	return this->leased.Num();
}