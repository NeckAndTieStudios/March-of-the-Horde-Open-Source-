#include "BuildingComponentInstanceData.h"
#include "BuildingComponent.h"
#include "BuildingComponentRelation.h"

void FBuildingComponentInstanceData::BeginPlay(USceneComponent* parent, int32 InstanceIndex)
{
	if (ItemComponentClass && !ItemComponent) {
		ItemComponent = NewObject<UItemComponent>(parent, ItemComponentClass);
		ItemComponent->InstanceID = InstanceIndex;
		ItemComponent->InstanceComponent = Cast<UInstancedStaticMeshComponent>(parent);
		ItemComponent->AttachToComponent(parent, FAttachmentTransformRules::KeepWorldTransform);
	}
	if (ItemClass && !ItemInstance) {
		ItemInstance = NewObject<UItemInstance>(parent, ItemClass);
		ItemInstance->Data.Health = this->Health;
	}

	this->CurrentComponent = Cast<UBuildingComponent>(parent);
	this->CurrentComponentIndex = InstanceIndex;

	auto attachment = Cast<UBuildingComponent>(parent->GetAttachParent());
	if (attachment) {
		auto entry = NewObject<UBuildingComponentRelation>(parent->GetOwner());
		this->SetParent(attachment, InstanceIndex);
		this->ParentChildRecord = entry;
		entry->SetInstanceData(*this);
		attachment->CustomPerInstanceSMData[InstanceIndex].Children.Add(entry);
	}

	/*auto bc = Cast<UBuildingComponent>(parent);
	if (bc) {
		UBuildingComponentRelation parent_entry;
		parent_entry.Component = bc;
		parent_entry.InstanceID = InstanceIndex;
		this->Parent = parent_entry;
	}*/

	/*
			auto bc = Cast<UBuildingComponent>(parent);
			if (bc) {
				UBuildingComponentRelation entry;
				entry.Component = bc;
				entry.InstanceID = InstanceIndex;
				Children.Add(entry);
			}*/
}

void FBuildingComponentInstanceData::SetParent(UBuildingComponent* parent, int32 instanceID)
{
	this->ParentComponent = parent;
	this->ParentComponentIndex = instanceID;
}

FBuildingComponentInstanceData FBuildingComponentInstanceData::Duplicate()
{
	FBuildingComponentInstanceData result = FBuildingComponentInstanceData(); // (this->Parent.Component, this->Parent.InstanceID);

	result.Health = this->Health;
	//result.Gore = this->Gore;
	result.ItemComponentClass = this->ItemComponentClass;
	result.ItemClass = this->ItemClass;
	result.ItemComponent = this->ItemComponent;
	result.ItemInstance = this->ItemInstance;

	result.CurrentComponent = this->CurrentComponent;
	result.CurrentComponentIndex = this->CurrentComponentIndex;

	/*result.Parent = this->Parent;*/

	for (auto item : this->Children) {
		/*UBuildingComponentRelation entry = NewObject
			entry.Component = item.Component;
		entry.InstanceID = item.InstanceID;*/
		result.Children.Add(item);
	}

	//auto propertyClass = FBuildingComponentInstanceData::StaticStruct();
	//for (TFieldIterator<UProperty> Prop(propertyClass); Prop; ++Prop) {
	//	UProperty* Property = *Prop;

	//	// property data type branches
	//	auto float_property = Cast<UFloatProperty>(Property);
	//	if (float_property) {
	//		auto res = float_property->GetPropertyValue(this);
	//		float_property->SetPropertyValue_InContainer(&result, res);
	//	}
	//	else {
	//		/*auto class_property = Cast<UClassProperty>(Property);
	//		if (class_property) {
	//			auto res = class_property->GetPropertyValue(this);
	//			class_property->SetPropertyValue_InContainer(&result, res);
	//		}*/
	//	}
	//}

	return result;
}


void FBuildingComponentInstanceData::SetCurrentComponent(UBuildingComponent* parent, int32 instanceID)
{
	this->CurrentComponent = parent;
	this->CurrentComponentIndex = instanceID;

	this->ItemComponent->InstanceID = instanceID;
	this->ItemComponent->InstanceComponent = parent;
}