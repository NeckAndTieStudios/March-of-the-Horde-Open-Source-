// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#include "CreatureSpawner.h"
#include "Components/BrushComponent.h"
#include "Engine/CollisionProfile.h"
#include "Kismet/KismetMathLibrary.h"

//void ACreatureCharacter::EndPlay(const EEndPlayReason::Type EndPlayReason)
//{
//	if (Spawner) {
//		Spawner->ReleaseNpc(this);
//		Spawner = NULL;
//	}
//}

void UCreatureCharacterComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (Spawner) {
		Spawner->ReleaseNpc(this->GetOwner());
		Spawner = NULL;
	}
}

void UCreatureSpawner::BeginPlay_Implementation()
{
	StartSpawn();
}

void UCreatureSpawner::EndPlay_Implementation(const EEndPlayReason::Type EndPlayReason)
{
	if (GetOwner()) { GetOwner()->GetWorldTimerManager().ClearTimer(OnTrySpawnHandle); }
}

FTransform UCreatureSpawner::GetSpawnLocation_Implementation()
{
	FTransform tnf = FTransform();

	auto CreatureSpawnerVolume = Cast<ACreatureSpawnerVolume>(this->GetOwner());
	if (CreatureSpawnerVolume) {
		// get x,y randomly, then Z from roof down for ground using a trace

		auto bounds = CreatureSpawnerVolume->GetBounds();

		auto location = UKismetMathLibrary::RandomPointInBoundingBox(CreatureSpawnerVolume->GetActorLocation(), bounds.BoxExtent);

		// trace to ground
		{
			FCollisionQueryParams collision_params(FName(TEXT("CreatureSpawnGroundTrace")), true, this->GetOwner());
			collision_params.bReturnPhysicalMaterial = true;

			FCollisionObjectQueryParams object_params;
			object_params.AddObjectTypesToQuery(ECC_WorldStatic);
			object_params.AddObjectTypesToQuery(ECC_WorldDynamic);
			object_params.AddObjectTypesToQuery(ECC_PhysicsBody);
			object_params.AddObjectTypesToQuery(ECC_Destructible);

			FHitResult hit_result;

			float size = Blueprint.GroundColliderSize;
			//auto direction = character->ActiveCamera->GetComponentRotation();
			//auto trace_start = character->ActiveCamera->GetComponentLocation();
			//auto trace_end = trace_start + direction.RotateVector(FVector(character->ArmLength, 0.f, 0.f));

			auto trace_start = FVector(location.X, location.Y, 9000);
			auto trace_end = FVector(location.X, location.Y, -9000);

			DrawDebugLine(GetWorld(), trace_start, trace_end, FColor::Purple, true, size);

			//if (GetWorld()->LineTraceSingleByObjectType(hit_result, trace_start, trace_end, object_params, collision_params) && hit_result.IsValidBlockingHit())
			if (GetWorld()->SweepSingleByObjectType(hit_result, trace_start, trace_end, FQuat(), object_params, FCollisionShape::MakeSphere(size), collision_params) && hit_result.IsValidBlockingHit())
			{
				location = hit_result.ImpactPoint;
				DrawDebugBox(this->GetWorld(), hit_result.ImpactPoint, FVector(5), FColor(255, 26, 26), true);
			}
		}

		auto loc = FVector(location.X + Blueprint.SpawnLocationOffset.X, location.Y + Blueprint.SpawnLocationOffset.Y, location.Z + Blueprint.SpawnLocationOffset.Z);
		tnf.SetLocation(loc);
		DrawDebugBox(this->GetWorld(), loc, FVector(5), FColor(26, 255, 26), true);

		//DrawDebugSolidBox(GetWorld(), CreatureSpawnerVolume->GetActorLocation(), bounds.BoxExtent, FColor::Green, true);
	}

	return tnf;
}

ACreatureSpawnerVolume::ACreatureSpawnerVolume(const FObjectInitializer & ObjectInitializer)
	: Super(ObjectInitializer)
{
	GetBrushComponent()->SetCollisionProfileName(UCollisionProfile::NoCollision_ProfileName);
	GetBrushComponent()->Mobility = EComponentMobility::Static;

	BrushColor = FColor(200, 200, 200, 255);

	bColored = true;
}

void UCreatureSpawner::StartSpawn_Implementation()
{
	GetOwner()->GetWorldTimerManager().SetTimer(OnTrySpawnHandle, this, &UCreatureSpawner::OnTrySpawn, Blueprint.SpawnInterval, true);
}

bool UCreatureSpawner::CanSpawnNpc_Implementation(FTransform transform)
{
	bool requires_creature = true;
	//if (requires_creature) {
	//	// is within player bounds?



	//	return true;
	//}
	return requires_creature;
}

void UCreatureSpawner::SpawnNpc_Implementation()
{
	auto CreatureSpawnerVolume = Cast<ACreatureSpawnerVolume>(this->GetOwner());
	if (CreatureSpawnerVolume && CreatureSpawnerVolume->Enabled && this->Blueprint.Enabled) {
		if (Blueprint.NPC) {
			auto loc = GetSpawnLocation();

			if (CanSpawnNpc(loc)) {
				auto npc = GetWorld()->SpawnActor<ACharacter>(Blueprint.NPC, loc);
				if (npc) {
					//npc->SetOwner(this->Owner);
					this->CreaturesSpawned++;
					CreatureSpawnerVolume->m_CurrentCreatures++;

					auto component = NewObject<UCreatureCharacterComponent>(npc);
					component->RegisterComponent();
					component->Spawner = this;
				}
				else {
					GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("Invalid spawn npc"));
				}
			}
			else {
				GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("Not able to spawn npc"));
			}
		}
	}
}

void UCreatureSpawner::ReleaseNpc_Implementation(AActor* creature)
{
	this->CreaturesSpawned--;
	auto CreatureSpawnerVolume = Cast<ACreatureSpawnerVolume>(this->GetOwner());
	if (CreatureSpawnerVolume) {
		CreatureSpawnerVolume->m_CurrentCreatures--;
	}
}

void UCreatureSpawner::OnTrySpawn_Implementation()
{
	auto CreatureSpawnerVolume = Cast<ACreatureSpawnerVolume>(this->GetOwner());
	if (CreatureSpawnerVolume) {

		if (CreaturesSpawned < Blueprint.MaxCreatures && (CreatureSpawnerVolume->MaxCreatures == 0 || CreatureSpawnerVolume->m_CurrentCreatures < CreatureSpawnerVolume->MaxCreatures))
			SpawnNpc();
	}
}

//ACreatureSpawnerVolume::ACreatureSpawnerVolume()
//{
//	////Super::AVolume();
//	//CreatureSpawnerComponent = CreateDefaultSubobject<UCreatureSpawner>(TEXT("CreatureSpawnerComponent"));
//	////CreatureSpawnerComponent->Vol
//	//
//	//////CreatureSpawnerComponent->SetSpawningVolume(this);
//
//	//if (UBrushComponent * MyBrushComponent = GetBrushComponent())
//	//{
//	//	MyBrushComponent->SetCollisionObjectType(ECC_WorldStatic);
//	//	MyBrushComponent->SetCollisionResponseToAllChannels(ECR_Ignore);
//
//	//	// This is important because the volume overlaps with all procedural foliage
//	//	// That means during streaming we'll get a huge hitch for UpdateOverlaps
//	//	MyBrushComponent->SetGenerateOverlapEvents(false);
//	//}
//}
//
//#if WITH_EDITOR
//
//void ACreatureSpawnerVolume::PostEditImport()
//{
//	// Make sure that this is the component's spawning volume
//	//CreatureSpawnerComponent->SetSpawningVolume(this);
//}
//
//bool ACreatureSpawnerVolume::GetReferencedContentObjects(TArray<UObject*>& Objects) const
//{
//	Super::GetReferencedContentObjects(Objects);
//
//	/*if (CreatureSpawnerComponent && CreatureSpawnerComponent->FoliageSpawner)
//	{
//		Objects.Add(CreatureSpawnerComponent->FoliageSpawner);
//	}*/
//	return true;
//}
//
//#endif
