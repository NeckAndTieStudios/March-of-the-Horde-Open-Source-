#include "ItemCache.h"

//UItemCache* UItemCache::Instance = NULL;