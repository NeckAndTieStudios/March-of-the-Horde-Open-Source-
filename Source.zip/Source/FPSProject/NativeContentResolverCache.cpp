// Fill out your copyright notice in the Description page of Project Settings.

#include "NativeContentResolverCache.h"
#include "Engine.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "BuildingComponent.h"
#include "WorldStaticMeshComponent.h"
#include "GameSettings.h"
#include "ItemAttributeType.h"
#include "GlobalGameInstance.h"
#include "Common.h"
#include "Engine/LODActor.h"
#include "Components/BoxComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/SphereComponent.h"
#include "Runtime/Engine/Classes/Animation/SkeletalMeshActor.h"
#include "ItemCache.h"

//struct FSortByUSurfaceTypeID
//{
//	FSortByUSurfaceTypeID(const int& inUSurfaceTypeID)
//		: SourceUSurfaceTypeID(inUSurfaceTypeID)
//	{
//
//	}
//
//	int SourceUSurfaceTypeID;
//
//	bool operator()(const USurfaceTypeModel* A, const USurfaceTypeModel* B) const
//	{
//		float DistanceA = FVector::DistSquared(SourceLocation, A.GetActorLocation());
//		float DistanceB = FVector::DistSquared(SourceLocation, B.GetActorLocation());
//
//		return SourceUSurfaceTypeID > b.USurfaceTypeID;
//	}
//};

bool UNativeContentResolverCache::PreLoad()
{
	/* Item * /
	FString i1 = DatabaseLoader::AppendAll<UItemModel>(this, TEXT("Item"), UItemModel::Instances) ? "1" : "0";
	FString i2 = DatabaseLoader::AppendAll<UItemAliasModel>(this, TEXT("ItemAlias"), UItemAliasModel::Instances) ? "1" : "0";
	FString i3 = DatabaseLoader::AppendAll<UItemAttributeModel>(this, TEXT("ItemAttribute"), UItemAttributeModel::Instances) ? "1" : "0";
	FString i4 = DatabaseLoader::AppendAll<UItemLootModel>(this, TEXT("ItemLoot"), UItemLootModel::Instances) ? "1" : "0";
	FString i5 = DatabaseLoader::AppendAll<UItemPlaceableModel>(this, TEXT("ItemPlaceable"), UItemPlaceableModel::Instances) ? "1" : "0";
	FString i6 = DatabaseLoader::AppendAll<UItemPlaceableTypeModel>(this, TEXT("ItemPlaceableType"), UItemPlaceableTypeModel::Instances) ? "1" : "0";
	FString i7 = DatabaseLoader::AppendAll<UItemTypeModel>(this, TEXT("ItemType"), UItemTypeModel::Instances) ? "1" : "0";

	/* Bullet * /
	FString b1 = DatabaseLoader::AppendAll<UBulletModel>(this, TEXT("Bullet"), UBulletModel::Instances) ? "1" : "0";
	FString b2 = DatabaseLoader::AppendAll<UBulletComponentModel>(this, TEXT("BulletComponent"), UBulletComponentModel::Instances) ? "1" : "0";
	FString b3 = DatabaseLoader::AppendAll<UBulletSurfaceModel>(this, TEXT("BulletSurface"), UBulletSurfaceModel::Instances) ? "1" : "0";
	FString b4 = DatabaseLoader::AppendAll<UBulletTypeModel>(this, TEXT("BulletType"), UBulletTypeModel::Instances) ? "1" : "0";

	/* Interaction Trigger * /
	auto it1 = DatabaseLoader::AppendAll<UInteractionTriggerModel>(this, TEXT("InteractionTrigger"), UInteractionTriggerModel::Instances) ? "1" : "0";

	/* Surface * /
	auto s1 = DatabaseLoader::AppendAll<USurfaceEffectModel>(this, TEXT("SurfaceEffect"), USurfaceEffectModel::Instances) ? "1" : "0";
	auto s2 = DatabaseLoader::AppendAll<USurfaceTypeModel>(this, TEXT("SurfaceType"), USurfaceTypeModel::Instances) ? "1" : "0";

	/* Tool * /
	auto t1 = DatabaseLoader::AppendAll<UToolModel>(this, TEXT("Tool"), UToolModel::Instances) ? "1" : "0";
	auto t2 = DatabaseLoader::AppendAll<UToolTypeModel>(this, TEXT("ToolType"), UToolTypeModel::Instances) ? "1" : "0";

	FString debugOnly = FString("Tables Loaded: ").Append(i1).Append(i2).Append(i3).Append(i4).Append(i5).Append(i6).Append(i7);
	debugOnly = debugOnly.Append(b1).Append(b2).Append(b3).Append(b4);
	debugOnly = debugOnly.Append(it1);
	debugOnly = debugOnly.Append(s1).Append(s2);
	debugOnly = debugOnly.Append(t1).Append(t2);
	GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, debugOnly);*/

	/*TArray<USurfaceEffectModel *> surfaceEffect;
	DatabaseLoader::AppendAll<USurfaceEffectModel>(this, TEXT("SurfaceEffect"), surfaceEffect);*/

	// transform into an array, where USurfaceTypeID is the index

	auto gi = Cast<UGlobalGameInstance>(this->GetWorld()->GetGameInstance());
	gi->DatabaseInstances.Empty();
	gi->SurfaceTypeInstances.Empty();

	auto surfaceEffects = UDatabaseLoader::GetSurfaceEffects();
	for (int i = 0; i < surfaceEffects.Num(); i++) {
		/*if (surfaceTypes[i]->SurfaceEffectID != i) {
		TODO
		}*/
		auto effect = surfaceEffects[i]->AsSurfaceEffect(gi);
		gi->DatabaseInstances.Add(effect);

		gi->SurfaceEffects.Add(effect->SurfaceEffectID, effect);
	}

	auto surfaceTypes = UDatabaseLoader::GetSurfaceTypes();
	surfaceTypes.Sort([](const USurfaceTypeModel & a, const USurfaceTypeModel & b) {
		return a.USurfaceTypeID < b.USurfaceTypeID;
		});

	for (int i = 0; i < surfaceTypes.Num(); i++) {
		/*if (surfaceTypes[i]->USurfaceTypeID != i) {
			TODO
		}*/
		auto effect = surfaceTypes[i]->AsSurfaceEffect(gi);
		gi->SurfaceTypeInstances.Add(effect);
	}

	//// update the mod settings into our runtime values
	//if (UGameSettings::Instance) {
	//	auto toolBeltConfig = DatabaseLoader::GetToolBeltConfig();
	//	if (toolBeltConfig) {
	//		UGameSettings::Instance->ToolBeltSlots = toolBeltConfig->Slots;
	//	}
	//}

	return true;
}

void UNativeContentResolverCache::Initialise()
{
	//if (UDatabaseLoader::Instance) {
	//	UDatabaseLoader::Instance->IngredientsForItemCache.Empty(); // allow new values to load 
	//}
	this->PreLoad();
	this->TransformFoliageInstanceToChunks();
}

//UItemInstance* UNativeContentResolverCache::ResolveItemByID(int itemID)
//{
//	return UItemCache::Instance->GetItemByID(itemID, this);
//	/*auto model = UDatabaseLoader::FindItemByID(itemID);
//	if (model) {
//		return model->AsItemInstance(UDatabaseLoader::Instance);
//	}*/
//	//return NULL;
//}

//UItemInstance* UNativeContentResolverCache::ResolveItemByAlias(const FString& alias)
//{
//	return UItemCache::Instance->GetItemByAlias(alias, this);
//	/*auto items = UDatabaseLoader::FindItemsByAlias(alias);
//	if (items.Num() == 1) {
//		auto item = items[0]->AsItemInstance(UDatabaseLoader::Instance);
//		item->Alias = items[0]->AsItemAliasInstance(UDatabaseLoader::Instance);
//		return item;
//	}
//	return NULL;*/
//}

//UItemAliasInstance* UNativeContentResolverCache::ResolveAliasForItem(UItemInstance* item)
//{
//	auto aliases = UItemCache::Instance->GetItemAliasesByID(item->ItemID);
//	if (aliases.Num() > 0) {
//		auto first = aliases[0];
//		return first;
//	}
//	return NULL;
//
//	/*auto results = UDatabaseLoader::FindAliasByItem(item);
//	if (results.Num() > 0) {
//		auto first = results[0];
//		return first->AsItemAliasInstance(item);
//	}
//	return NULL;*/
//}

//TArray<UItemAliasInstance*> UNativeContentResolverCache::ResolveAliases()
//{
//	TArray<UItemAliasInstance*> aliases;
//	auto results = UDatabaseLoader::FindItemsByAlias(FString::Empty);
//	if (results.Num() > 0) {
//		for (auto result : results) {
//			auto alias = result->AsItemAliasInstance(item);
//			aliases.Add(alias);
//		}
//	}
//	return aliases;
//}

TArray<UItemComponent*> UNativeContentResolverCache::ResolveInteraction(EInteractionTrigger trigger, FHitResult hit_result, AActor* initiator, bool process)
{
	//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("[UNativeContentResolverCache] ResolveInteraction"));

	FResolutionRequest request(trigger, hit_result, initiator);

	//UItemComponent* item_component = NULL;
	TArray<UItemComponent*> components;

	if (!this->ResolveUsingRootComponent(request, components))
	{
		//if (!this->ResolveCollision(request, components))
		{
			if (!this->ResolveStaticActorInstance(request, components)) // non-instance trees (split out hierarchy components and preference it)
			{
				if (!this->ResolveCharacter(request, components))
				{
					if (!this->ResolveSkeletalMeshInstance(request, components))
					{
						if (!this->ResolveDestructibleMesh(request, components))
						{
							if (!this->ResolveFoliageInstance(request, components)) //e.g. trees, flowers
							{
								//if (!this->ResolveCollision(request, components))
								//{
								if (!this->ResolveInstanceMesh(request, components)) //e.g. trees, flowers
								{
									//if (!this->ResolveCollision(request, components))
									//{

									//}
								}
								//}
							}
						}
					}
				}
			}
		}
	}

	if (process) { /* && item_component / *&& (item_component->InteractionTrigger == trigger || item_component->InteractionTrigger == EInteractionTrigger::Any)* /) {*/
	/*item_component->OnInteraction(trigger, hit_result, initiator);*/
		for (auto component : components) {
			component->OnInteraction(trigger, hit_result, initiator);
		}
	}

	return components;
}

bool UNativeContentResolverCache::ResolveUsingRootComponent(FResolutionRequest request, TArray<UItemComponent*>& OutItemComponents)
{
	bool any = false;
	auto actor = request.hit_result.GetActor();
	if (IsValid(actor) && IsValid(actor->GetRootComponent())) {
		TArray<USceneComponent*> components;
		actor->GetRootComponent()->GetChildrenComponents(true, components);

		for (auto component : components)
		{
			auto ic = Cast<UItemComponent>(component);
			if (IsValid(ic)) {
				OutItemComponents.Add(ic);
				any = true;
			}
		}
	}
	return any;
}

bool UNativeContentResolverCache::ResolveCollision(FResolutionRequest request, TArray<UItemComponent*>& OutItemComponents)
{
	TArray<USceneComponent*> components;

	auto bc = Cast<UBoxComponent>(request.hit_result.Component);
	if (bc) {
		bc->GetChildrenComponents(false, components);
	}
	else {
		auto cc = Cast<UCapsuleComponent>(request.hit_result.Component);
		if (cc) {
			cc->GetChildrenComponents(false, components);
		}
		else {
			auto sc = Cast<USphereComponent>(request.hit_result.Component);
			if (sc) {
				sc->GetChildrenComponents(false, components);
			}
		}
	}

	bool any = false;

	if (components.Num() > 0) {
		for (auto item : components) {
			auto ic = Cast<UItemComponent>(item);
			if (ic) {
				//item_component = ic;
				OutItemComponents.Add(ic);
				any = true;
			}
		}
	}

	return any;
}

//void UNativeContentResolverCache::ResolveAttributesForItem(UItemInstance* &item)
//{
//	auto attributes = UDatabaseLoader::GetAttributesForItem(item->ItemID);
//
//	for (int i = 0; i < attributes.Num(); i++) {
//		UItemAttributeInstance* attribute = NewObject<UItemAttributeInstance>(item);
//		attribute->ItemAttributeType = static_cast<EItemAttributeType>(attributes[i]->ItemAttributeTypeID);
//		item->Attributes.Add(attribute);
//	}
//}

bool UNativeContentResolverCache::ResolveDestructibleMesh(FResolutionRequest request, TArray<UItemComponent*>& OutItemComponents)
{
	auto dm = Cast<UDestructibleComponent>(request.hit_result.Component);
	if (dm) {
		if (request.trigger == EInteractionTrigger::Primary || request.trigger == EInteractionTrigger::Bullet) {
			this->AddInteractionAtLocation(request.hit_result, dm, 20, 5, 200);
		}
	}
	return false;
}

bool UNativeContentResolverCache::ResolveSkeletalMeshInstance(FResolutionRequest request, TArray<UItemComponent*>& OutItemComponents)
{
	return false; // covered using scene components
	/*bool any = false;
	auto sma = Cast<ASkeletalMeshActor>(request.hit_result.GetActor());
	if (sma) {
		TArray<USceneComponent*> components;
		sma->GetSkeletalMeshComponent()->GetChildrenComponents(true, components);

		for (auto component : components)
		{
			auto ic = Cast<UItemComponent>(component);
			if (IsValid(ic)) {
				OutItemComponents.Add(ic);
				any = true;
			}
		}
	}
	return any;*/

	//auto smc = Cast<USkeletalMeshComponent>(request.hit_result.Component);
	//if (smc) {
	//	auto item_component = Cast<UItemComponent>(request.hit_result.Actor->GetComponentByClass(UItemComponent::StaticClass()));
	//	if (IsValid(item_component)) {
	//		OutItemComponents.Add(item_component);
	//		if (item_component->ItemInstance.ItemID == 0) {
	//			//auto classname = smc->SkeletalMesh->GetClass()->GetName();
	//			//auto name = classname.Append(FString("'")).Append(smc->SkeletalMesh->GetPathName()).Append(FString("'"));
	//			auto name = UCommon::GetReferencePath(smc->SkeletalMesh);
	//			//auto results = UDatabaseLoader::FindItemsByAlias(name);
	//			auto instance = this->GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache;
	//			auto results = instance->GetItemAliasesByName(name);

	//			//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, name.Append(FString(" | Results: ")).Append(FString::FromInt(results.Num())));

	//			if (results.Num() > 0) {
	//				auto first = results[0];
	//				//this->PrepareComponent(first, request, item_component);

	//				/*if (item_component->ItemInstance) {
	//					item_component->ItemInstance->SetActor(request.hit_result.GetActor());
	//				}*/
	//			}
	//		}
	//	}
	//	if (request.trigger == EInteractionTrigger::Primary || request.trigger == EInteractionTrigger::Bullet) {
	//		this->AddInteractionAtLocation(request.hit_result, smc, 20, 5, 200);
	//	}
	//	return true;
	//}

	//return false;
}

bool UNativeContentResolverCache::ResolveCharacter(FResolutionRequest request, TArray<UItemComponent*>& OutItemComponents)
{
	auto mchr = Cast<AMOTHCharacter>(request.hit_result.GetActor());
	if (mchr) {

		if (request.trigger == EInteractionTrigger::Primary || request.trigger == EInteractionTrigger::Bullet) {
			//this->AddInteractionAtLocation(request.hit_result, smc, 20, 5, 200);
			//UGameplayStatics::ApplyDamage(chr, 20, NULL, request.initiator, NULL);

			mchr->OnDamaged(request.hit_result, request.initiator, request.trigger);
		}

		return true;
	}
	else {
		auto chr = Cast<ACharacter>(request.hit_result.GetActor());
		if (chr) {

			if (request.trigger == EInteractionTrigger::Primary || request.trigger == EInteractionTrigger::Bullet) {
				//this->AddInteractionAtLocation(request.hit_result, smc, 20, 5, 200);
				UGameplayStatics::ApplyDamage(chr, 20, NULL, request.initiator, NULL);
			}

			return true;
		}
	}
	return false;
}

bool UNativeContentResolverCache::ResolveStaticActorInstance(FResolutionRequest request, TArray<UItemComponent*>& OutItemComponents)
{
	/*bool any = false;
	auto sma = Cast<AStaticMeshActor>(request.hit_result.GetActor());
	if (sma) {
		TArray<USceneComponent*> components;
		sma->GetStaticMeshComponent()->GetChildrenComponents(true, components);

		for (auto component : components)
		{
			auto ic = Cast<UItemComponent>(component);
			if (IsValid(ic)) {
				OutItemComponents.Add(ic);
				any = true;
			}
		}
	}
	return any;*/

	return false; // covered using scene components

	////auto results = request.hit_result.GetActor()->GetComponentsByClass(UItemComponent::StaticClass());
	////TArray<UItemComponent*>& CastedArray = reinterpret_cast<TArray<UItemComponent*>&>(results);
	////OutItemComponents.Append(CastedArray);
	////return CastedArray.Num() > 0;

	//auto smc = Cast<UStaticMeshComponent>(request.hit_result.Component);
	//if (!smc && request.hit_result.Component->IsA(UBoxComponent::StaticClass())) { // collision component
	//	auto parent = request.hit_result.Component->GetAttachParent();
	//	smc = Cast<UStaticMeshComponent>(parent);
	//	//auto sma = Cast<AStaticMeshActor>(request.hit_result.Actor);
	//	/*if (sma && sma->GetStaticMeshComponent() && sma->GetStaticMeshComponent()->GetStaticMesh()) {
	//		smc = sma->GetStaticMeshComponent();
	//	}*/
	//}
	//if (smc) {
	//	/*
	//	//TArray<USceneComponent*> components;
	//	//request.hit_result.Component->GetChildrenComponents(false, components);
	//	//for (int i = 0; i < components.Num(); i++)
	//	//{
	//	//	item_component = Cast<UItemComponent>(components[i]);
	//	//	if (!item_component || !item_component->ItemInstance) {
	//	//		auto instanceMesh = smc->GetStaticMesh();
	//	//		auto classname = instanceMesh->GetClass()->GetName();
	//	//		auto name = classname.Append(FString("'")).Append(instanceMesh->GetPathName()).Append(FString("'"));
	//	//		auto results = UDatabaseLoader::FindItemsByAlias(name);

	//	//		//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, name.Append(FString(" | Results: ")).Append(FString::FromInt(results.Num())));

	//	//		if (results.Num() > 0) {
	//	//			auto first = results[0];
	//	//			this->PrepareComponent(first, request, item_component);
	//	//		}
	//	//	}
	//	//}
	//	//UHierarchicalInstancedStaticMeshComponent* hism = NULL;
	//	//AAutoInstancedStaticMeshActor* world_actor = NULL;
	//	//UWorldStaticMeshComponent* world_mesh = NULL;
	//	//UBuildingComponent* building_component = NULL;

	//	//if (smc->IsA(UBuildingComponent::StaticClass())) // currently when the WSMC has control over the gore (as it cannot be instanced)
	//	//{
	//	//	building_component = Cast<UBuildingComponent>(smc);
	//	//	//item_component = world_mesh->ItemComponent;

	//	//	if (building_component && building_component->CustomPerInstanceSMData.Num() > request.hit_result.Item) {
	//	//		auto data = building_component->CustomPerInstanceSMData[request.hit_result.Item];
	//	//		item_component = data.ItemComponent;
	//	//	}
	//	//}
	//	//else if (smc->IsA(UWorldStaticMeshComponent::StaticClass())) // currently when the WSMC has control over the gore (as it cannot be instanced)
	//	//{
	//	//	world_mesh = Cast<UWorldStaticMeshComponent>(smc);
	//	//	item_component = world_mesh->ItemComponent;
	//	//}
	//	//if (smc->IsA(UHierarchicalInstancedStaticMeshComponent::StaticClass())) // when here is no gore, but instanced components
	//	//{
	//	//	//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("HISM: ").Append(FString::FromInt(request.hit_result.Item)));

	//	//	auto hism = Cast<UHierarchicalInstancedStaticMeshComponent>(smc);
	//	//	//// use the instance id from the hit result
	//	//	////auto instance_component = request.hit_result.GetComponent()->GetChildComponent(request.hit_result.Item);
	//	//	////item_component = Cast<UItemComponent>(instance_component);
	//	//	//TArray<USceneComponent*> children;
	//	//	//request.hit_result.GetComponent()->GetChildrenComponents(false, children);

	//	//	//for (int i = 0; i < children.Num(); i++)
	//	//	//{
	//	//	//	if (children[i]->IsA(UItemComponent::StaticClass()))
	//	//	//	{
	//	//	//		UItemComponent* itemcomponent = Cast<UItemComponent>(children[i]);
	//	//	//		if (itemcomponent->InstanceID == request.hit_result.Item)
	//	//	//		{
	//	//	//			item_component = itemcomponent;
	//	//	//			break;
	//	//	//		}
	//	//	//	}
	//	//	//}

	//	//	auto result = AAutoInstancedStaticMeshActor::GetItemComponentForInstance(hism, request.hit_result.Item, EInstancedCategory::Buildings);
	//	//	item_component = result.Component;

	//	//	if (result.Data) {
	//	//		world_mesh = Cast<UWorldStaticMeshComponent>(result.Data);
	//	//	}

	//	//	//FString reference_path = UCommon::GetReferencePath(smc->GetStaticMesh());
	//	//	//world_actor = AAutoInstancedStaticMeshActor::GetInstance(this->GetWorld());
	//	//	//FString instance_key = reference_path;
	//	//	//instance_key.AppendInt(request.hit_result.Item);
	//	//	//
	//	//	//auto lsd = world_actor->InstancedComponentData.Find(instance_key);
	//	//	//if (lsd) {
	//	//	//	world_mesh = Cast<UWorldStaticMeshComponent>(*lsd);
	//	//	//	if (world_mesh) {
	//	//	//		//world_mesh->OnChildComponentAttached(smc);
	//	//	//		world_mesh->SetCurrentHISM(world_actor, hism, request.hit_result.Item);
	//	//	//	}
	//	//	//}
	//	//}
	//	//else // else an actual static mesh/actor*/
	//	{
	//		//auto actor = request.hit_result.GetActor();
	//		//item_component = Cast<UItemComponent>(actor->GetComponentByClass(UItemComponent::StaticClass()));

	//		// search the direct component children first, then fallback to the parent actor

	//		TArray<USceneComponent*> components;
	//		smc->GetChildrenComponents(false, components);

	//		for (int i = 0; i < components.Num(); i++) {
	//			if (components[i]->IsA(UItemComponent::StaticClass())) {
	//				auto item_component = Cast<UItemComponent>(components[i]);
	//				OutItemComponents.Add(item_component);
	//				//break;
	//			}
	//		}

	//		//if (!item_component) {
	//		if (OutItemComponents.Num() == 0) {
	//			auto parent = request.hit_result.Component->GetAttachParent();
	//			if (parent) {
	//				components.Empty();
	//				parent->GetChildrenComponents(false, components);

	//				for (int i = 0; i < components.Num(); i++) {
	//					if (components[i]->IsA(UItemComponent::StaticClass())) {
	//						auto item_component = Cast<UItemComponent>(components[i]);
	//						OutItemComponents.Add(item_component);
	//						//break;
	//					}
	//				}
	//			}
	//		}

	//		//if (!item_component) {
	//		//	auto actor = request.hit_result.GetActor();
	//		//	if (IsValid(actor)) {
	//		//		auto components = actor->GetComponentsByClass(UItemComponent::StaticClass());
	//		//		if (components.Num() == 1) {
	//		//			item_component = Cast<UItemComponent>(components[0]);
	//		//		}
	//		//		//for (auto cmp : components)
	//		//		//{
	//		//		//	//if (IsValid(cmp) && cmp->IsA(UItemComponent::StaticClass()) && !cmp->GetAttachParent()) {
	//		//		//	item_component = Cast<UItemComponent>(cmp);
	//		//		//	break;
	//		//		//	//}
	//		//		//}
	//		//	}
	//		//}
	//	}

	//	/*
	//	//if (OutItemComponents.Num() == 0) { // older code, using bps now: || item_component->ItemInstance.ItemID == 0) {
	//	//	//if (!item_component || item_component->ItemInstance.ItemID == 0) {
	//	//	auto instanceMesh = smc->GetStaticMesh();
	//	//	auto name = UCommon::GetReferencePath(instanceMesh);
	//	//	//auto results = UDatabaseLoader::FindItemsByAlias(name);
	//	//	auto instance = this->GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache;
	//	//	auto results = instance->GetItemAliasesByName(name);

	//	//	GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, name.Append(FString(" | Results: ")).Append(FString::FromInt(results.Num())));

	//	//	if (results.Num() > 0) {
	//	//		auto first = results[0];
	//	//		this->PrepareComponent(first, request, item_component);

	//	//		if (item_component) {
	//	//			item_component->InstanceID = request.hit_result.Item;

	//	//			if (world_mesh && item_component->ItemInstance.ItemID > 0) {
	//	//				item_component->ItemInstance.Health = world_mesh->Health;
	//	//			}

	//	//			//if (world_mesh && world_actor && hism) {
	//	//			//	//world_mesh->OnChildComponentAttached(smc);
	//	//			//	world_mesh->SetCurrentHISM(world_actor, hism, request.hit_result.Item);
	//	//			//}
	//	//		}
	//	//	}
	//	//}

	//	//if (world_mesh && request.trigger == EInteractionTrigger::Pickup)
	//	//{
	//	//	world_mesh->Gore += 5;
	//	//	world_mesh->UpdateGore();

	//	//	//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Gore | ").Append(FString::SanitizeFloat(world_mesh->Gore)));
	//	//}*/

	//	if (request.trigger == EInteractionTrigger::Primary || request.trigger == EInteractionTrigger::Bullet) {
	//		this->AddInteractionAtLocation(request.hit_result, smc, 20, 5, 200);
	//	}

	//	return true;
	//}

	//return false;
}

bool UNativeContentResolverCache::ResolveInstanceMesh(FResolutionRequest request, TArray<UItemComponent*>& OutItemComponents)
{
	bool any = false;
	bool is_looking = request.trigger == EInteractionTrigger::Look;
	bool is_primary = request.trigger == EInteractionTrigger::Primary;
	bool is_pickup = request.trigger == EInteractionTrigger::Pickup;

	bool allow_cmp_create = is_primary || is_pickup;

	if (is_primary || is_looking || is_pickup) {
		/*auto ism = Cast<UInstancedStaticMeshComponent>(request.hit_result.Component);
		if (IsValid(ism)) {
			int index = request.hit_result.Item;
			if (ism->PerInstanceSMData.IsValidIndex(index)) {
				ism->UpdateInstanceTransform(index, FTransform(FVector(0.f, 0.f, -8000.f)));
			}
		}*/
		auto chr = Cast<AMOTHCharacter>(request.initiator);
		if (!IsValid(chr) && IsValid(request.initiator)) {
			chr = Cast<AMOTHCharacter>(request.initiator->GetOwner());
		}
		if (IsValid(chr)) {

			auto components = chr->GetFoliageFromRequest(request, allow_cmp_create);
			if (components.Num() > 0) {
				OutItemComponents.Append(components);
				any = true;
				//chr->InvalidateLookItem(true);
			}
			else if(allow_cmp_create){
				chr->RequestFoliageInteractionNetwork(request);
			}

			//chr->RequestFoliageRemoval(request);
		}
	}

	//auto ism = Cast<UInstancedStaticMeshComponent>(request.hit_result.Component);
	//if (IsValid(ism)) {
	//	int index = request.hit_result.Item;
	//	if (ism->PerInstanceSMData.IsValidIndex(index)) {

	//		auto game_instance = this->GetWorld()->GetGameInstance<UGlobalGameInstance>();
	//		if (IsValid(game_instance) && IsValid(game_instance->InstanceMeshReplicator)) {
	//			auto actor = ism->GetOwner();
	//			FString foliage_ID = actor->GetName()
	//				.Append("_").Append(ism->GetName())
	//				.Append("_").Append(FString::FromInt(index));

	//			GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Found instance mesh, looking up component set using ID: ").Append(foliage_ID));

	//			auto entry = game_instance->InstanceMeshReplicator->InstanceMeshComponents.Find(foliage_ID);
	//			if (entry) {
	//				auto data = *entry;
	//				if (data.Component->GetName() == ism->GetName() && data.InstanceID == index) { // GetName() to compare network replicated items
	//					for (auto component : data.Components) {
	//						auto ic = Cast<UItemComponent>(component);
	//						if (IsValid(ic)) {
	//							OutItemComponents.Add(ic);
	//							any = true;
	//						}
	//					}
	//				}
	//				else {
	//					GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Instance Mesh failed lookup: detected ISM component lookup mismatch. this is not a normal error, something is usually wrong."));
	//				}
	//			}
	//			else {
	//				GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("New Instance Mesh registration: ").Append(foliage_ID));

	//				FInstanceMeshComponentEntry new_entry = FInstanceMeshComponentEntry(ism, index, foliage_ID);

	//				//if (game_instance->InstanceMeshReplicator->HasAuthority()) {
	//				if (game_instance->InstanceMeshReplicator->HasAuthority()) {
	//					UClass* destruction_class = UContentResolver::Instance->ResolveBlueprint("Blueprint'/Game/Blueprints/Objects/BP_FoliageDestructionComponent.BP_FoliageDestructionComponent'");
	//					if (destruction_class) {
	//						auto cmp = NewObject<USceneComponent>(game_instance->InstanceMeshReplicator, destruction_class);
	//						if (IsValid(cmp)) {

	//							if (cmp->GetClass()->ImplementsInterface(UInstanceMeshReceiver::StaticClass()))
	//							{
	//								//Don't call your functions directly, use the 'Execute_' prefix
	//								//the Execute_ReactToHighNoon and Execute_ReactToMidnight are generated on compile
	//								//you may need to compile before these functions will appear
	//								IInstanceMeshReceiver::Execute_OnRegistering(cmp, new_entry, request);
	//							}

	//							cmp->RegisterComponent();
	//							new_entry.Components.Add(cmp);

	//							auto ic = Cast<UItemComponent>(cmp);
	//							if (IsValid(ic)) {
	//								OutItemComponents.Add(ic);
	//								any = true;
	//							}
	//						}
	//					}
	//					else {
	//						GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Instance Mesh lookup warning: No destruction class."));
	//					}

	//					game_instance->InstanceMeshReplicator->InstanceMeshComponents.Add(foliage_ID, new_entry);
	//				}
	//				else {
	//					GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("No authority to register foliage."));
	//				}
	//			}
	//		}
	//	}
	//	else {
	//		GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Instance Mesh failed lookup"));
	//	}
	//}

	return any;
}


UInstanceMeshReceiver::UInstanceMeshReceiver(const class FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

bool UNativeContentResolverCache::ResolveFoliageInstance(FResolutionRequest request, TArray<UItemComponent*>& OutItemComponents)
{
	//auto ifm = Cast<UFoliageInstancedStaticMeshComponent>(request.hit_result.Component);
	//if (ifm) {
	//	auto res = AAutoInstancedStaticMeshActor::GetItemComponentForInstance(ifm, request.hit_result.Item, EInstancedCategory::Foliage);
	//	item_component = res.Component;

	//	if (!item_component) {
	//		auto instanceMesh = ifm->GetStaticMesh();

	//		auto name = UCommon::GetReferencePath(instanceMesh);
	//		//auto results = UDatabaseLoader::FindItemsByAlias(name);
	//		auto instance = this->GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache;
	//		auto results = instance->GetItemAliasesByName(name);

	//		if (results.Num() > 0) {
	//			this->PrepareComponent(results[0], request, item_component);
	//		}
	//	}

	//	if (request.trigger == EInteractionTrigger::Primary || request.trigger == EInteractionTrigger::Bullet) {
	//		this->AddInteractionAtLocation(request.hit_result, ifm, 20, 5, 200);
	//	}

	//	return true;
	//}

	return false;

	////auto ifm = Cast<UFoliageInstancedStaticMeshComponent>(request.hit_result.Component);
	//////auto instanced_actor = Cast<AInstancedFoliageActor>(request.hit_result.GetActor());
	//////if (instanced_actor && ifm) {
	//////	//instanced_actor->SelectInstance(ifm, request.hit_result.Item, true);
	//////}

	////if (ifm) {
	////	TArray<int> rem;
	////	rem.Add(request.hit_result.Item);
	////	ifm->RemoveInstances(rem);
	////}

	////return true;

	//auto ifm = Cast<UFoliageInstancedStaticMeshComponent>(request.hit_result.Component);
	//if (ifm) {
	//	////ifm->RemoveInstance(request.hit_result.Item);

	//	//ifm->bAutoRebuildTreeOnInstanceChanges = false;

	//	//TArray<int> rem;
	//	//rem.Add(request.hit_result.Item);
	//	//ifm->RemoveInstances(rem);

	//	//return true;

	//	FTransform instanceTransform;
	//	ifm->GetInstanceTransform(request.hit_result.Item, instanceTransform);

	//	auto instanceMesh = ifm->GetStaticMesh();

	//	auto name = UCommon::GetReferencePath(instanceMesh);
	//	//auto classname = instanceMesh->GetClass()->GetName();
	//	//auto name = classname.Append(FString("'")).Append(instanceMesh->GetPathName()).Append(FString("'"));

	//	auto results = UDatabaseLoader::FindItemsByAlias(name);

	//	//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, name.Append(FString(" | Results: ")).Append(FString::FromInt(results.Num())));

	//	if (results.Num() > 0) {
	//		auto first = results[0];

	//		auto res = AAutoInstancedStaticMeshActor::GetItemComponentForInstance(ifm, request.hit_result.Item, EInstancedCategory::Foliage);
	//		item_component = res.Component;

	//		//auto staticMeshComponent = Cast<UStaticMeshComponent>(actor->GetComponentByClass(UStaticMeshComponent::StaticClass()));
	//		//if (staticMeshComponent && !staticMeshComponent->GetStaticMesh()) {
	//		//	staticMeshComponent->SetMobility(EComponentMobility::Movable); // required due to unreal only adding collision to movable objects at runtime
	//		//	staticMeshComponent->SetStaticMesh(instanceMesh);
	//		//	staticMeshComponent->SetMobility(EComponentMobility::Static); // required due to unreal only adding collision to movable objects at runtime
	//		//}

	//		//// foliage instance replacement actors should already have an UItemComponent instance attached, otherwise it's considered to be ignored
	//		//item_component = Cast<UItemComponent>(actor->GetComponentByClass(UItemComponent::StaticClass()));

	//		this->PrepareComponent(first, request, item_component);

	//		if (request.trigger == EInteractionTrigger::Primary || request.trigger == EInteractionTrigger::Bullet) {
	//			this->AddInteractionAtLocation(request.hit_result, ifm, 20, 5, 200);
	//		}

	//		return true;
	//		//AActor * actor = NULL;

	//		// MOVED TO ON KILLED - potentially needs configuration for here and onkilled
	//		//if (first->ActorBlueprint.Len() > 0) {
	//		//	if (request.trigger == EInteractionTrigger::Any || request.trigger == EInteractionTrigger::Primary) {
	//		//		// try to find and create the replacement actor
	//		//		UClass* actor_class = UContentResolver::Instance->ResolveBlueprint(first->ActorBlueprint);
	//		//		if (actor_class) {
	//		//			actor = request.hit_result.Component->GetWorld()->SpawnActor<AActor>(actor_class, instanceTransform, FActorSpawnParameters());
	//		//		}
	//		//	}
	//		//}

	//		//else if (request.trigger != EInteractionTrigger::Look) {
	//		//	// transform the instance into
	//		//	actor = request.hit_result.Component->GetWorld()->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), instanceTransform, FActorSpawnParameters());
	//		//}

	//		//if (actor) {
	//		//	auto staticMeshComponent = Cast<UStaticMeshComponent>(actor->GetComponentByClass(UStaticMeshComponent::StaticClass()));
	//		//	if (staticMeshComponent && !staticMeshComponent->GetStaticMesh()) {
	//		//		staticMeshComponent->SetMobility(EComponentMobility::Movable); // required due to unreal only adding collision to movable objects at runtime
	//		//		staticMeshComponent->SetStaticMesh(instanceMesh);
	//		//		staticMeshComponent->SetMobility(EComponentMobility::Static); // required due to unreal only adding collision to movable objects at runtime
	//		//	}

	//		//	// foliage instance replacement actors should already have an UItemComponent instance attached, otherwise it's considered to be ignored
	//		//	item_component = Cast<UItemComponent>(actor->GetComponentByClass(UItemComponent::StaticClass()));

	//		//	this->PrepareComponent(first, request, item_component);

	//		//	// actor has been spawned, we can remove this foliage instance
	//		//	ifm->RemoveInstance(request.hit_result.Item);

	//		//	return true;
	//		//}

	//		//if (request.trigger != EInteractionTrigger::Look) {
	//		//	//ifm->RemoveInstance(request.hit_result.Item);		not needed anymore as the item component now works correctly
	//		//	
	//		//}
	//		//else { // request.trigger == EInteractionTrigger::Look
	//		//	// issue out a new UItemComponent on the global actor for the foliage type.
	//		//	// it should only be used for UI events. e.g. to show what instance youre looking at
	//		//	//
	//		//	// we also require that in order to harvest, a UItemComponent is required
	//		//	// as we don't want to have seperate hit code, where you look at a component, and another
	//		//	// bit of code will hit another if a button is pressed - it's too misleading.


	//		//	/*FString item_component_class_path = TEXT("");
	//		//	UObject* obj = StaticLoadObject(UObject::StaticClass(), nullptr, *item_component_class_path);
	//		//	UBlueprint* bp = Cast<UBlueprint>(obj);
	//		//	UClass* item_component_class = (UClass*)bp->GeneratedClass;
	//		//	if (item_component_class) {*/

	//		//	if (actor) {
	//		//		item_component = Cast<UItemComponent>(request.hit_result.GetActor()->GetComponentByClass(UItemComponent::StaticClass()));
	//		//		if (!item_component) {
	//		//			item_component = NewObject<UItemComponent>(request.hit_result.GetActor());
	//		//			item_component->RegisterComponent();
	//		//			item_component->OnAddedToOwner(actor);
	//		//		}
	//		//	}

	//		//	/*smc->SetMobility(EComponentMobility::Movable);
	//		//	smc->SetSimulatePhysics(true);
	//		//	smc->SetMassOverrideInKg(NAME_None, 20000.0, true);
	//		//	smc->SetMassScale(NAME_None, 1);
	//		//	GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("COMPONENT ADDED"));*/
	//		//	/*}*/
	//		//}
	//		//return true; // we found a result, regardless if we have used it or not
	//	}
	//}

	//return false;
}
//
//TArray<UItemInstance*> UNativeContentResolverCache::ResolveLootForItem(UItemInstance* item, EInteractionTrigger trigger)
//{
//	TArray<UItemInstance*> loot;
//
//	auto results = UDatabaseLoader::GetLootForItem(item->ItemID, trigger);
//	for (int i = 0; i < results.Num(); i++) {
//		auto lootInstance = results[i]->AsItemInstance(item); // parent item instance so the Alias is shared
//		loot.Add(lootInstance);
//	}
//
//	return loot;
//}

//TArray<UItemInstance*> UNativeContentResolverCache::ResolveRecipes(UObject* owner)
//{
//	TArray<UItemInstance*> loot;
//
//	auto results = UDatabaseLoader::GetRecipes();
//	for (int i = 0; i < results.Num(); i++) {
//		auto lootInstance = results[i]->AsItemInstance(owner); // parent item instance so the Alias is shared
//		loot.Add(lootInstance);
//	}
//
//	return loot;
//}

//TArray<UItemInstance*> UNativeContentResolverCache::ResolveRecipesForItem(UItemInstance* item)
//{
//	TArray<UItemInstance*> loot;
//
//	auto results = UDatabaseLoader::GetRecipesForItem(item->ItemID);
//	for (int i = 0; i < results.Num(); i++) {
//		auto lootInstance = results[i]->AsItemInstance(item); // parent item instance so the Alias is shared
//		loot.Add(lootInstance);
//	}
//
//	return loot;
//}

//TArray<UItemInstance*> UNativeContentResolverCache::ResolveIngredientsForItem(UItemInstance* item)
//{
//	TArray<UItemInstance*> loot;
//
//	auto results = UDatabaseLoader::GetIngredientsForItem(item->ItemID);
//	for (int i = 0; i < results.Num(); i++) {
//		auto lootInstance = results[i]->AsItemInstance(item); // parent item instance so the Alias is shared
//		loot.Add(lootInstance);
//	}
//
//	return loot;
//}

//TArray<UItemInteraction*> UNativeContentResolverCache::ResolveInteractionsForItem(UItemInstance* item)
//{
//	return UDatabaseLoader::GetInteractionsForItem(item->ItemID);
//}

bool UNativeContentResolverCache::PrepareComponent(UItemAliasInstance* result, FResolutionRequest request, TArray<UItemComponent*>& OutItemComponents)
//bool UNativeContentResolverCache::PrepareComponent(UItemAliasQueryByAliasResult* result, FResolutionRequest request, UItemComponent* &item_component)
{
	//if (!item_component && result->DefaultComponent.Len() > 0) {
	//	/*FString item_component_class_path = result->DefaultComponent;
	//	UObject* obj = StaticLoadObject(UObject::StaticClass(), nullptr, *item_component_class_path);
	//	UBlueprint* bp = Cast<UBlueprint>(obj);
	//	UClass* item_component_class = (UClass*)bp->GeneratedClass;*/

	//	UClass* item_component_class = UContentResolver::Instance->ResolveBlueprint(result->DefaultComponent);
	//	if (item_component_class && item_component_class->IsChildOf(UItemComponent::StaticClass())) {
	//		//auto parent_actor = request.hit_result.GetActor();
	//		auto parent_component = request.hit_result.Component.Get();

	//		auto bc = Cast<UBuildingComponent>(parent_component);
	//		if (bc) {
	//			auto parent_actor = parent_component->GetOwner();
	//			item_component = NewObject<UItemComponent>(parent_component, item_component_class);
	//			item_component->AttachToComponent(parent_component, FAttachmentTransformRules::KeepRelativeTransform);
	//			item_component->RegisterComponent();
	//			item_component->OnAddedToOwner(parent_actor);

	//			item_component->InstanceComponent = bc;
	//			item_component->InstanceID = request.hit_result.Item;

	//			item_component->SetWorldTransform(FTransform(item_component->InstanceComponent->PerInstanceSMData[item_component->InstanceID].Transform));

	//			bc->CustomPerInstanceSMData[request.hit_result.Item].ItemComponent = item_component;

	//			item_component->SetIsReplicated(true);
	//		}
	//		else {
	//			if (parent_component->IsA(UHierarchicalInstancedStaticMeshComponent::StaticClass())) {
	//				auto parent_actor = AAutoInstancedStaticMeshActor::GetInstance(this->GetWorld());
	//				item_component = NewObject<UItemComponent>(parent_actor, item_component_class);
	//				item_component->AttachToComponent(parent_component, FAttachmentTransformRules::KeepRelativeTransform);
	//				item_component->RegisterComponent();
	//				item_component->OnAddedToOwner(parent_actor);
	//				item_component->SetIsReplicated(true);

	//				auto hism = Cast<UHierarchicalInstancedStaticMeshComponent>(parent_component);
	//				if (hism) {
	//					item_component->InstanceComponent = hism;
	//					item_component->InstanceID = request.hit_result.Item;

	//					item_component->SetWorldTransform(FTransform(item_component->InstanceComponent->PerInstanceSMData[item_component->InstanceID].Transform));

	//					//FString reference_path = UCommon::GetReferencePath(hism->GetStaticMesh());
	//					FString container_reference = AAutoInstancedStaticMeshActor::GetComponentKey(hism, EInstancedCategory::Foliage);

	//					FInstancedComponentsEntry* entry = NULL;
	//					auto world = this->GetWorld();
	//					if (world) {
	//						entry = parent_actor->InstancedComponents.Find(container_reference);

	//						if (entry == NULL) {
	//							FInstancedComponentsEntry new_entry(hism, EInstancedCategory::Foliage);
	//							entry = &parent_actor->InstancedComponents.Add(container_reference, new_entry);
	//						}
	//					}

	//					auto scene_component = AAutoInstancedStaticMeshActor::GetDataForInstance<USceneComponent>(hism, request.hit_result.Item, EInstancedCategory::Foliage);
	//					auto wsmc = Cast<UWorldStaticMeshComponent>(scene_component);
	//					if (wsmc) {
	//						wsmc->OnChildComponentAttached(item_component);
	//					}
	//					/*else if (scene_component) {

	//					}*/
	//					else if (entry) {
	//						FString instance_key = container_reference;
	//						instance_key.AppendInt(request.hit_result.Item);

	//						int required_slots = (request.hit_result.Item - entry->ComponentData.Num()) + 1;
	//						if (required_slots > 0) {
	//							while (required_slots-- > 0) {
	//								entry->ComponentData.Add(NULL);
	//							}
	//						}
	//						entry->ComponentData[request.hit_result.Item] = item_component;
	//					}
	//				}
	//			}
	//			else if (parent_component->IsA(UStaticMeshComponent::StaticClass()))
	//			{
	//				auto parent_actor = request.hit_result.GetActor();
	//				item_component = NewObject<UItemComponent>(parent_actor, item_component_class);
	//				item_component->AttachToComponent(parent_component, FAttachmentTransformRules::KeepRelativeTransform);
	//				item_component->RegisterComponent();
	//				item_component->OnAddedToOwner(parent_actor);
	//				item_component->SetIsReplicated(true);

	//				item_component->SetWorldTransform(parent_component->GetComponentTransform());

	//				//auto lod_cmp = parent_component->GetLODParentPrimitive();
	//				//if(lod_cmp) {
	//				//	auto actor = lod_cmp->GetOwner();
	//				//	if (actor) {
	//				//		auto StaticMeshComponent = Cast<UStaticMeshComponent>(lod_cmp);
	//				//		/*if (!IsValidLowLevel()) return;
	//				//		if (!StaticMeshComponent) return;
	//				//		if (!StaticMeshComponent->GetStaticMesh()) return;
	//				//		if (!StaticMeshComponent->GetStaticMesh()->RenderData) return;*/

	//				//		if (StaticMeshComponent->GetStaticMesh()->RenderData->LODResources.Num() > 0)
	//				//		{
	//				//			FPositionVertexBuffer* VertexBuffer = &StaticMeshComponent->GetStaticMesh()->RenderData->LODResources[0].PositionVertexBuffer;


	//				//			auto test = &StaticMeshComponent->GetStaticMesh()->RenderData->LODResources[0].AdjacencyIndexBuffer;
	//				//			
	//				//			FRawStaticIndexBuffer* ixBuffer = &StaticMeshComponent->GetStaticMesh()->RenderData->LODResources[0].IndexBuffer;
	//				//			if (ixBuffer) {
	//				//				ixBuffer->RemoveIndicesAt(ixBuffer->GetNumIndices() - 4, 3);
	//				//				//ixBuffer->
	//				//				//&StaticMeshComponent->GetStaticMesh()->RenderData->LODResources[0].IndexBuffer->SetIndicies();
	//				//			}
	//				//			FStaticMeshVertexBuffer* smVertexBuffer = &StaticMeshComponent->GetStaticMesh()->RenderData->LODResources[0].VertexBuffers.StaticMeshVertexBuffer;
	//				//			 

	//				//			FPositionVertexBuffer* VertexBuffer = &StaticMeshComponent->GetStaticMesh()->RenderData->LODResources[0].VertexBuffers.PositionVertexBuffer;
	//				//			//smVertexBuffer->

	//				//			//VertexBuffer->

	//				//			//IndexBuffer->GetCopy(indices);

	//				//			//if (VertexBuffer)
	//				//			//{
	//				//			//	const int32 VertexCount = VertexBuffer->GetNumVertices();
	//				//			//	for (int32 Index = 0; Index < VertexCount; Index++)
	//				//			//	{
	//				//			//		//This is in the Static Mesh Actor Class, so it is location and tranform of the SMActor
	//				//			//		const FVector WorldSpaceVertexLocation = actor->GetActorLocation() + actor->GetTransform().TransformVector(VertexBuffer->VertexPosition(Index));
	//				//			//		//add to output FVector array

	//				//			//		
	//				//			//	}
	//				//			//}
	//				//		}
	//				//	}
	//				//	//auto sma = smc->GetStaticMesh();
	//				//	//auto lod = sma->RenderData->LODResources[0];/*HLODDestructionIndex*/

	//				//	/*auto lod_actor = Cast<ALODActor>(lod_cmp->GetOwner());
	//				//	if (lod_actor) {
	//				//		for (auto child : lod_actor->SubActors) {
	//				//			GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString(TEXT("LOD: ")).Append(child->GetName()));
	//				//			auto sma = Cast<AStaticMeshActor>(child);
	//				//			if (sma) {
	//				//			}
	//				//		}
	//				//	}*/
	//				//}
	//			}
	//		}

	//		/*smc->SetMobility(EComponentMobility::Movable);
	//		smc->SetSimulatePhysics(true);
	//		smc->SetMassOverrideInKg(NAME_None, 20000.0, true);
	//		smc->SetMassScale(NAME_None, 1);
	//		GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("COMPONENT ADDED"));*/
	//	}
	//}

	////if (result->ActorBlueprint.Len() > 0) {
	//if (item_component && item_component->ItemInstance.ItemID == 0) {
	//	auto instance = this->GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache;
	//	item_component->ItemInstance = instance->GetItemByID(result->ItemID);
	//	if (item_component->ItemInstance.ItemID > 0) {
	//		//item_component->ItemInstance = result->AsItemInstance(item_component, result);
	//		//item_component->ItemInstance->Alias = result->AsItemAliasInstance(item_component->ItemInstance);
	//		item_component->OnInstanceLoaded();
	//	}

	//	//auto loot = DatabaseLoader::GetLootForItem(item_component->ItemInstance->ItemID, request.trigger);
	//	//for (int i = 0; i < loot.Num(); i++) {
	//	//	auto lootInstance = loot[i]->AsItemInstance(item_component->ItemInstance); // parent item instance so the Alias is shared
	//	//	item_component->ItemInstance->Loot.Add(lootInstance);
	//	//}
	//}

	return true;
	/*}

	return false;*/
}

void UNativeContentResolverCache::TransformFoliageInstanceToChunks()
{
	/*TActorIterator<AInstancedFoliageActor> foliageIterator(GetWorld());
	AInstancedFoliageActor* foliageActor = *foliageIterator;*/

	//TArray<AInstancedFoliageActor*> actors;
	//for (TActorIterator<AInstancedFoliageActor> foliageIterator(GetWorld()); foliageIterator; ++foliageIterator) {
	//	actors.Add(*foliageIterator);
	//}

	//for (int i = 0; i < actors.Num(); i++) {
	//	AInstancedFoliageActor* foliageActor = actors[i];
	//	if (foliageActor) {
	//		auto components = foliageActor->GetComponentsByClass(UFoliageInstancedStaticMeshComponent::StaticClass());
	//		if (components.Num() > 0) {
	//			for (int i = 0; i < components.Num(); i++) {
	//				auto component = Cast<UFoliageInstancedStaticMeshComponent>(components[i]);

	//				TArray<FFoliageInstanceRef> instance_ref;

	//				const int CHUNK_SIZE = 1000000;
	//				auto instances = component->GetInstanceCount();
	//				if (instances > 0/*CHUNK_SIZE*/) {
	//					FTransform instance_transform = FTransform();
	//					for (int i = 0; i < instances; i++) {
	//						component->GetInstanceTransform(i, instance_transform, true);

	//						instance_ref.Add(FFoliageInstanceRef(component, instance_transform, i));
	//					}

	//					auto mesh = component->GetStaticMesh();
	//					auto ordered = instance_ref; // UNativeContentResolverCache::OrderByDistance(instance_ref);
	//					UHierarchicalInstancedStaticMeshComponent* chunk_component = NULL;
	//					int current = 0;
	//					for (int i = ordered.Num() - 1; i >= 0; i--) {
	//						auto ref = ordered[i];

	//						if (chunk_component == NULL || current >= CHUNK_SIZE) {
	//							//auto parent = NewObject<AInstancedFoliageActor>(GetWorld(), UInstancedStaticMeshComponent::StaticClass());
	//							auto parent = GetWorld()->SpawnActor(AInstancedFoliageActor::StaticClass());

	//							chunk_component = NewObject<UHierarchicalInstancedStaticMeshComponent>(parent, UHierarchicalInstancedStaticMeshComponent::StaticClass());

	//							chunk_component->bAutoRebuildTreeOnInstanceChanges = false;

	//							//chunk_component->AttachTo(foliageActor->GetRootComponent());
	//							//chunk_component->AttachToComponent(foliageActor->GetRootComponent(), FAttachmentTransformRules(EAttachmentRule::SnapToTarget, true/*super dooper important in order for world position to work*/));

	//							chunk_component->SetMobility(EComponentMobility::Movable);
	//							chunk_component->SetCollisionProfileName(TEXT("QueryOnly"));
	//							chunk_component->SetStaticMesh(mesh);
	//							chunk_component->RegisterComponent();
	//							current = 0;
	//						}

	//						//chunk_component->AddInstance(ref.Transform);
	//						ref.Component->RemoveInstance(ref.InstanceID);

	//						chunk_component->AddInstance(ref.Transform);

	//						current++;
	//					}
	//				}
	//			}
	//		}
	//		foliageActor->Destroy();
	//	}
	//	else {

	//	}
	//}
}

TArray<FFoliageInstanceRef> UNativeContentResolverCache::OrderByDistance(TArray<FFoliageInstanceRef> pointList)
{
	TArray<FFoliageInstanceRef> orderedList;

	FFoliageInstanceRef currentPoint = pointList[0];

	while (pointList.Num() > 1)
	{
		orderedList.Add(currentPoint);

		for (int i = 0; i < pointList.Num(); i++) {
			if (pointList[i].InstanceID == currentPoint.InstanceID) {
				pointList.RemoveAt(i);
				break;
			}
		}

		auto closestPointIndex = 0;
		auto closestDistance = 0;
		bool has_closest = false;

		for (int i = 0; i < pointList.Num(); i++)
		{
			auto distance = UCommon::Distance(currentPoint.Transform, pointList[i].Transform);
			if (distance < closestDistance || !has_closest)
			{
				closestPointIndex = i;
				closestDistance = distance;
				has_closest = true;
			}
		}

		currentPoint = pointList[closestPointIndex];
	}

	// Add the last point.
	orderedList.Add(currentPoint);

	return orderedList;
}

//TArray<UItemUpgradeInstance*> UNativeContentResolverCache::ResolveUpgradesForItem(UItemInstance* item)
//{
//	return UDatabaseLoader::GetUpgradeRequirements(item->ItemID);
//}

//TArray<UItemRepairInstance*> UNativeContentResolverCache::ResolveRepairRequirementsForItem(FItemData item)
//{
//	return UDatabaseLoader::GetRepairRequirements(item.ItemID);
//}

void UNativeContentResolverCache::AddInteractionAtLocation(FHitResult hitResult, UPrimitiveComponent* component, int damage, float radius, float strength)
{
	//if (surfaceSettings)
	{
		// destruction
		{
			if (component)
			{
				FRotator direction = (hitResult.TraceEnd - hitResult.TraceStart).Rotation();

				auto dm = Cast<UDestructibleComponent>(component);
				if (dm)
				{
					dm->ApplyRadiusDamage(damage, hitResult.Location, radius, strength, false);
				}
				//if (surfaceSettings.AllowHitImpulse && component && component->IsSimulatingPhysics())
				if (component && component->Mobility == EComponentMobility::Movable && component->IsSimulatingPhysics())
				{
					//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, surfaceSettings.Name);
					/*float impulseVelocity = UGameSettings::Instance->BulletImpulseVelocity;
					if (impulseVelocity == 0) {
						impulseVelocity = this->Speed;
					}*/
					//if (invert) {
					//	/*auto mtx = FRotationMatrix(this->CurrentRotation);
					//	mtx.Mirror(EAxis::X, EAxis::X);
					//	component->AddImpulseAtLocation(mtx.GetScaledAxis(EAxis::X) * impulseVelocity, location);*/
					//	component->AddImpulseAtLocation(FRotationMatrix(this->CurrentRotation.GetInverse()).GetScaledAxis(EAxis::X) * (impulseVelocity), location);
					//	DrawDebugSolidBox(GetWorld(), location, FVector(3.f), FColor::Purple, true, this->MaxLifeTime);
					//}
					//else {
					component->AddImpulseAtLocation(FRotationMatrix(direction).GetScaledAxis(EAxis::X) * 1000, hitResult.Location);
					//	DrawDebugSolidBox(GetWorld(), location, FVector(3.f), FColor::Orange, true, this->MaxLifeTime);
					//}
				}
				else {
					//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("No impulse"));
				}
			}
		}
	}
}