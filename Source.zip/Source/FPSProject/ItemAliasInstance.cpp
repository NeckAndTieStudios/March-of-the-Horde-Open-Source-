#include "ItemAliasInstance.h"
#include "ContentResolver.h"

void UItemAliasInstance::Load()
{
	//this->Instance = UContentResolver::Instance->FindObjectByReference<UObject>(this->Name);
}

UObject* UItemAliasInstance::GetInstance()
{
	if (!this->Instance) {
		this->Instance = UContentResolver::Instance->FindObjectByReference<UObject>(this->Name, true);
	}
	return this->Instance;
}