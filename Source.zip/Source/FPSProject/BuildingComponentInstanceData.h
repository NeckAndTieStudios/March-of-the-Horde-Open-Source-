// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "WordStaticMeshDecal.h"
#include "ItemComponent.h"
#include "ItemInstance.h"
#include "BuildingComponentInstanceData.generated.h"

class UBuildingComponentRelation;
class UBuildingComponent;

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FBuildingComponentInstanceData
{
	GENERATED_BODY()

		FBuildingComponentInstanceData() {}

	//	FBuildingComponentInstanceData(UBuildingComponent* parent, int32 instanceID)
	//{
	//		//this->SetParent(parent, instanceID);
	//}

	/*FBuildingComponentInstanceData(FMatrix transform)
	{
		this->Transform = transform;
	}*/

	///** Health of the instance. */
	//UPROPERTY(EditAnywhere, Category = "Binding")
		//FMatrix Transform = FMatrix();

	/** Health of the instance. */
	UPROPERTY(EditAnywhere, Category = "Additional Instance Data")
		float Health = 100.f;

	/*UPROPERTY(EditAnywhere, Category = "Additional Instance Data")
		float Gore = 0.f;*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<FWordStaticMeshDecal> DecalInstances;

	UPROPERTY()
		bool Selected = false;
	UPROPERTY()
		bool CopyInProcess = false;

	/*UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<FMeshBreakpoint> MeshBreakpoints;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<FGoreBreakpoint> GoreBreakpoints;*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Additional Instance Data")
		TSubclassOf<class UItemComponent> ItemComponentClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Additional Instance Data")
		TSubclassOf<class UItemInstance> ItemClass;

	UItemComponent* ItemComponent = NULL;
	UItemInstance* ItemInstance = NULL;

	UBuildingComponent* CurrentComponent = NULL;
	int32 CurrentComponentIndex = -1;

	UPROPERTY()
		TArray<UBuildingComponentRelation*> Children;

	//UPROPERTY()
		//TArray<UBuildingComponentRelation> Children;

	UBuildingComponentRelation* ParentChildRecord = NULL;

	UBuildingComponent* ParentComponent = NULL;
	int32 ParentComponentIndex = -1;

	void SetParent(UBuildingComponent* parent, int32 instanceID);

	void BeginPlay(USceneComponent* parent, int32 InstanceIndex);

	FBuildingComponentInstanceData Duplicate();

	void SetCurrentComponent(UBuildingComponent* parent, int32 instanceID);
};