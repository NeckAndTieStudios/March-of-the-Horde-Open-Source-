// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Weighting.generated.h"

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FWeighting
{
	GENERATED_USTRUCT_BODY()

public:
	// defines how many chances the item has of being used
	// 0 to disable
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weighting")
		float Weighting = 0.f;
};