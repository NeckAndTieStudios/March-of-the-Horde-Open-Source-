// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Common.h"
#include "HitLoot.generated.h"

USTRUCT(Blueprintable, BlueprintType)
struct FPSPROJECT_API FHitLoot
{
	GENERATED_USTRUCT_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FString Name = "Unknown";
	/*
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UTexture2D * LootTexture;*/

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float Stack = 3.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float MaxStack = 25.f;

	// allows a new item be be spawned when in hand
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TSubclassOf<class AActor> HeldItem;

	// alternate to HeldItem, allows a specific (reusable) actor to be placed in the hand
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool AllowHeldItemActor = false;

	// alternate to HeldItem, allows a specific (reusable) actor to be placed in the hand
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (EditCondition = "AllowHeldItemActor"))
		AActor * HeldItemActor;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsConsumable = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsPlaceable = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool IsPlantable = false;

	// the offset in the foliage actors, starting from 0
	// unreal will pack each foliage actor into an array, which is used at runtime
	// to add and remove instances for that index (actor);
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (EditCondition = "IsPlantable"))
		int PlantFoliageIndex = 0;
};