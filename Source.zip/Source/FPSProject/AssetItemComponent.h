// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "GlobalBulletSettings.h"
#include "Components/AudioComponent.h"
#include "AssetItemComponent.generated.h"

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent))
class FPSPROJECT_API UAssetItemComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	// Sets default values for this component's properties
	UAssetItemComponent();

protected:
	// Called when the game starts
	virtual void BeginPlay() override;

	UFUNCTION()
	void OnActorDestroyed(AActor* OtherActor);

public:
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	/** Unregister the component, remove it from its outer Actor's Components array and mark for pending kill. */
	virtual void DestroyComponent(bool bPromoteChildren = false) override;

	// Played when the actor is spawned into the world. Ensure your sound has Loop turned on to keep the sound going
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "World")
		USoundCue * Spawn = NULL;

	UPROPERTY(EditAnywhere, Category = Bullet)
		bool InheritBulletSettings = true;

	UPROPERTY(EditAnywhere, Category = Bullet, meta = (EditCondition = "!InheritBulletSettings"))
		FGlobalBulletSettings BulletSettings;


	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Interactable")
		bool CanClimb;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Interactable")
		bool CanPickup;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Interactable")
		FString Title;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Interactable", meta = (EditCondition = "CanClimb || CanPickup"))
		bool AutoInteractOnOverlap = true;

	// Distance in cm
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Interactable")
		float InteractionRange = 100.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UAudioComponent* AudioComponent;
};
