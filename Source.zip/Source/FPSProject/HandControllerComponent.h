// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
//#include "GlobalGameInstance.h"
#include "HitInstance.h"
#include "HitLoot.h"
#include "FPSCharacter.h"
#include "HandControllerComponent.generated.h"

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent, ShowWorldContextPin), Blueprintable)
class FPSPROJECT_API UHandControllerComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	UHandControllerComponent();

protected:
	//UPROPERTY(EditAnywhere, BlueprintReadOnly)
		//UGlobalGameInstance * GameInstance;

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int SectionId;

	/*UFUNCTION(BlueprintCallable)
		USceneComponent* PlaceItem(AFPSCharacter * character, UItemInstance* item, FTransform location, USceneComponent* parent);*/

	UFUNCTION(BlueprintCallable)
		void SecondaryAction(AMOTHCharacter * character);

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
		AInstancedFoliageActor * InstancedFoliageActor;
};