// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Buff.generated.h"

UCLASS(Blueprintable, BlueprintType)
class FPSPROJECT_API UBuff : public UUserWidget
{
	GENERATED_BODY()

public:

};

UCLASS(Blueprintable, BlueprintType)
class FPSPROJECT_API UOverWeightBuff : public UBuff
{
	GENERATED_BODY()

public:

};