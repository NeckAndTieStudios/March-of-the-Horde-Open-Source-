// Fill out your copyright notice in the Description page of Project Settings.

#include "GlobalGameInstance.h"
#include "Engine.h"
#include "Engine/StaticMeshActor.h"
#include "Common.h"
//#include "SurfaceType.h"

//UContentResolver* UGlobalGameInstance::ContentResolver = NULL;

UGlobalGameInstance::UGlobalGameInstance()
{
	this->SurfaceMap = {
		FGlobalBulletSettings(FString("Unknown")),
		FGlobalBulletSettings(FString("Dirt")),
		FGlobalBulletSettings(FString("Rock")),
		FGlobalBulletSettings(FString("Sand")),
		FGlobalBulletSettings(FString("Water")),
		FGlobalBulletSettings(FString("Glass")),
		FGlobalBulletSettings(FString("Cloth")),
		FGlobalBulletSettings(FString("Metal")),
		FGlobalBulletSettings(FString("Wood")),
		FGlobalBulletSettings(FString("Grass")),

		FGlobalBulletSettings(FString("Carpet")),
		FGlobalBulletSettings(FString("Concrete")),
		FGlobalBulletSettings(FString("Snow")),
		FGlobalBulletSettings(FString("Tile")),
		FGlobalBulletSettings(FString("Asphalt")),
		FGlobalBulletSettings(FString("Brick")),
		FGlobalBulletSettings(FString("Cardboard")),
		FGlobalBulletSettings(FString("Clay")),
		FGlobalBulletSettings(FString("Plastic")),
		FGlobalBulletSettings(FString("Electronics")),

		FGlobalBulletSettings(FString("Sheetrock")),
		FGlobalBulletSettings(FString("Plaster")),
		FGlobalBulletSettings(FString("Leaves")),
		FGlobalBulletSettings(FString("Blood")),
		FGlobalBulletSettings(FString("Glass_Beer_Bottle")),
		FGlobalBulletSettings(FString("Wood_Glass_Combined")),
		FGlobalBulletSettings(FString("Plastic_Electronic")),
		FGlobalBulletSettings(FString("Wood_Plaster")),
	};
	this->HitSettingsMap = {};
}

FGlobalBulletSettings UGlobalGameInstance::GetBySurfaceType(uint8 surfaceType)
{
	if (surfaceType >= (uint8)EPhysicalSurface::SurfaceType_Default && surfaceType < this->SurfaceMap.Num())
	{
		return this->SurfaceMap[surfaceType];
	}
	else {
		if (GEngine)
		{
			//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("Invalid surface type."));
		}
	}
	if (this->SurfaceMap.Num()) {
		return this->SurfaceMap[0]; // default / unknown settings
	}
	return FGlobalBulletSettings();
}

void UGlobalGameInstance::Init()
{
	UCommon::Test();

	//this->InstanceMeshReplicator = GetWorld()->SpawnActor<AInstanceMeshReplicator>();

	/*for (TActorIterator<AInstanceMeshReplicator> ActorItr(GetWorld()); ActorItr; ++ActorItr)
	{
		this->InstanceMeshReplicator = Cast<AInstanceMeshReplicator>(*ActorItr);
		break;
	}*/

	this->StaticMeshActorPool = NewObject<UActorPool>(this);
	this->StaticMeshActorPool->ActorClass = AStaticMeshActor::StaticClass();

	this->DatabaseLoader = NewObject<UDatabaseLoader>(this);
	UDatabaseLoader::Instance = this->DatabaseLoader;

	if (!USQLiteDatabase::IsDatabaseRegistered(UDatabaseLoader::DatabaseName))
	{
		if (!USQLiteDatabase::RegisterDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::DatabasePath, true))
		{
			//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("DEAD"));
		}
	}

	if (!UDatabaseLoader::Instance->SqliteDatabase) {
		int returnCode = 0;
		USQLiteDatabase::OpenDatabase(UDatabaseLoader::DatabaseName, UDatabaseLoader::Instance->SqliteDatabase, returnCode);
	}

	UGameInstance::Init();

	UGameSettings::Instance = NewObject<UGameSettings>(this, this->GameSettings);
	this->Settings = UGameSettings::Instance;

	UDecalPool::Instance = NewObject<UDecalPool>(this, this->DecalPoolClass);
	this->DecalPool = UDecalPool::Instance;
	this->DecalPool->BeginWatching();

	this->ItemCache = NewObject<UItemCache>(this);
	this->ItemCache->Load();

	if (this->ContentResolverClass) {
		UContentResolver::Instance = NewObject<UContentResolver>(this, this->ContentResolverClass, NAME_None, RF_Standalone);
		this->ContentResolver = UContentResolver::Instance;

		//this->ContentResolver->world = this->GetWorld();
		this->ContentResolver->Initialise();

		this->Recipes.Empty();
		//this->Recipes.Append(this->ContentResolver->ResolveRecipes(this));
		this->Recipes.Append(this->ItemCache->GetRecipes());
	}
	else {
		//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("ContentResolver not specified"));
	}
}

void UGlobalGameInstance::Shutdown()
{
	Super::Shutdown();

	USQLiteDatabase::CloseDatabase(UDatabaseLoader::Instance->SqliteDatabase);
}

bool UGlobalGameInstance::MoveISMInstance(UHierarchicalInstancedStaticMeshComponent* source, int32 InstanceID, UStaticMesh* targetMesh, UItemComponent* item_component, UHierarchicalInstancedStaticMeshComponent*& target, int32& targetInstanceID, UHierarchicalInstancedStaticMeshComponent* parent, int32 reuse_instance, bool use_hidden_instance)
{
	//UBuildingComponent* target = NULL;
	auto components = source->GetOwner()->GetComponentsByClass(source->GetClass());
	for (auto component : components)
	{
		auto bc = Cast<UHierarchicalInstancedStaticMeshComponent>(component);
		if (bc && bc->GetStaticMesh() == targetMesh && (parent == NULL || bc->GetAttachParent() == parent)) {
			target = bc;
			break;
		}
	}

	if (!target) {
		target = NewObject<UHierarchicalInstancedStaticMeshComponent>(source->GetOwner());
		target->SetStaticMesh(targetMesh);
		target->SetCollisionProfileName(source->GetCollisionProfileName());
		target->SetWorldLocation(source->GetComponentLocation());

		if (parent) {
			target->AttachToComponent(parent, FAttachmentTransformRules::KeepWorldTransform);
		}

		target->RegisterComponent();
	}

	if (target) {
		auto transform = FTransform(source->PerInstanceSMData[InstanceID].Transform);

		if (item_component) {
			item_component->RemoveInstance();
		}

		int32 new_index = reuse_instance;

		if (reuse_instance < 0 && use_hidden_instance) {
			for (int i = 0; i < target->PerInstanceSMData.Num(); i++) {
				auto location = FTransform(target->PerInstanceSMData[i].Transform).GetLocation();
				if ((int)location.Z == -100000) {
					new_index = i;
					target->UpdateInstanceTransform(i, transform, true);
					break;
				}
			}
		}

		if (new_index < 0) {
			new_index = target->AddInstance(transform);
		}

		targetInstanceID = new_index;

		return true;
	}

	return false;
}