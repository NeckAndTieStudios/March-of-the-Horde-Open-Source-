// Fill out your copyright notice in the Description page of Project Settings.

#include "DatabaseModels.h"
#include "Database.h"
#include "ItemAliasInstance.h"
#include "ItemCache.h"
#include "GlobalGameInstance.h"
#include "Engine.h"

/*
Item
* /
TArray<UItemModel *> UItemModel::Instances;
TArray<UItemAliasModel *> UItemAliasModel::Instances;
TArray<UItemAttributeModel *> UItemAttributeModel::Instances;
TArray<UItemLootModel *> UItemLootModel::Instances;
TArray<UItemPlaceableModel *> UItemPlaceableModel::Instances;
TArray<UItemPlaceableTypeModel *> UItemPlaceableTypeModel::Instances;
TArray<UItemTypeModel *> UItemTypeModel::Instances;

/*
Bullet
* /
TArray<UBulletModel *> UBulletModel::Instances;
TArray<UBulletComponentModel *> UBulletComponentModel::Instances;
TArray<UBulletSurfaceModel *> UBulletSurfaceModel::Instances;
TArray<UBulletTypeModel *> UBulletTypeModel::Instances;

/*
Interaction Trigger
* /
TArray<UInteractionTriggerModel *> UInteractionTriggerModel::Instances;

/*
Surface
* /
TArray<USurfaceEffectModel *> USurfaceEffectModel::Instances;
TArray<USurfaceTypeModel *> USurfaceTypeModel::Instances;

/*
Tool
* /
TArray<UToolModel *> UToolModel::Instances;
TArray<UToolTypeModel *> UToolTypeModel::Instances;*/


//TArray<USurfaceTypeModel *> USurfaceTypeModel::Instances;

//UItemInstance * UItemModel::AsItemInstance(UObject * owner, UItemAliasQueryByAliasResult* existingAlias)
UItemInstance * UItemModel::AsItemInstance(UObject * owner, UItemAliasQueryResult* existingAlias, bool load)
{
	//UItemInstance * instance = NewObject<UItemInstance>(owner);
	//instance->ItemID = this->ItemID; // TODO: use reflection
	//instance->Health = UItemInstance::GetHealth(this->HealthMin, this->HealthMax);
	//instance->DefaultMaxStack = this->MaxStack; // TODO: use reflection
	//instance->MaxStack = this->MaxStack; // TODO: use reflection
	//instance->DisplayName = this->DisplayName; // TODO: use reflection
	//instance->ItemLootFormulaID = this->ItemLootFormulaID; // TODO: use reflection
	//instance->FoliageTypeID = this->FoliageTypeID; // TODO: use reflection
	//instance->FoliageScaleIndex = this->FoliageScaleIndex; // TODO: use reflection
	//instance->LootSelf = this->LootSelf; // TODO: use reflection
	//instance->Stack = 1;
	//instance->SurfaceEffectID = this->SurfaceEffectID;
 //	instance->Thumbnail = this->LoadThumbnail(owner);
	//instance->Alias = UContentResolver::Instance->ResolveAliasForItem(instance);
	//instance->Load();
	///*if (instance->Thumbnail && instance->Thumbnail == owner->Thumbnail) {
	//	instance->Alias = owner->Alias;
	//}
	//else {
	//	instance->Alias = UContentResolver::Instance->ResolveAliasForItem(instance, false);
	//}*/
	//return instance;

	UItemInstance * instance = NewObject<UItemInstance>(owner);
	instance->ItemID = this->ItemID; // TODO: use reflection
	if (this->FoliageTypeID > 0) {
		instance->Data.Health = UItemInstance::GetHealth(this->HealthMin, this->HealthMax);
	}
	else {
		instance->Data.Health = this->Health; // TODO: use reflection
	}
	instance->DefaultMaxStack = this->MaxStack; // TODO: use reflection
	instance->Data.MaxStack = this->MaxStack; // TODO: use reflection
	instance->Data.DisplayName = this->DisplayName; // TODO: use reflection
	instance->Data.ItemLootFormulaID = this->ItemLootFormulaID; // TODO: use reflection
	instance->Data.ItemLootFormulaValue = this->ItemLootFormulaValue; // TODO: use reflection
	instance->FoliageTypeID = this->FoliageTypeID; // TODO: use reflection
	instance->FoliageScaleIndex = this->FoliageScaleIndex; // TODO: use reflection
	instance->ToolTypeID = this->ToolTypeID; // TODO: use reflection
	instance->BaseLevel = this->BaseLevel; // TODO: use reflection
	instance->CraftDuration = this->CraftDuration; // TODO: use reflection
	instance->RepairDuration = this->RepairDuration; // TODO: use reflection
	instance->Data.Weight = this->Weight; // TODO: use reflection
	//instance->Stack = this->LootQuantity; // TODO: use reflection
	//instance->LootSelf = this->LootSelf; // TODO: use reflection
	instance->UpgradeStage = this->UpgradeStage; // TODO: use reflection

	if (this->BuildOffset.Len() > 0) {
		instance->BuildOffset = UCommon::ParseVector(this->BuildOffset);
	}
	if (this->HandOffsetLocation.Len() > 0) {
		instance->HandOffsetLocation = UCommon::ParseVector(this->HandOffsetLocation);
	}
	if (this->HandOffsetRotation.Len() > 0) {
		instance->HandOffsetRotation = UCommon::ParseRotator(this->HandOffsetRotation);
	}
	instance->InteractionDelay = this->InteractionDelay;
	instance->Data.InteractionMode = static_cast<EInteractionMode>(this->InteractionMode);
	instance->FireBurnTime = this->FireBurnTime;
	instance->FuelProduced = this->FuelProduced;
	//instance->BuildTargetSocket;
	/*this->BuildTargetSockets.s(instance->BuildTargetSockets, TEXT(","));
	for (int i = 0; i < instance->BuildTargetSockets.Num(); i++) {
		instance->BuildTargetSockets[i] = instance->BuildTargetSockets[i].Trim();
	}*/
	int index = -1;
	auto csv = this->BuildTargetSockets;
	while (csv.FindChar(',', index)) {
		auto segment = csv.Left(index).TrimStart().TrimEnd();
		csv.RemoveAt(0, index + 1);
		instance->BuildTargetSockets.Add(FName(*segment));
	}
	if (csv.Len() > 0) {
		csv = csv.TrimStart().TrimEnd();
		instance->BuildTargetSockets.Add(FName(*csv));
	}

	//instance->BuildOnGround = this->BuildOnGround == 1;
	//instance->BuildSocketRequired = this->BuildSocketRequired == 1;

	//if (this->PreviewMesh.Len() > 0) {
	//	instance->PreviewMesh = UContentResolver::Instance->FindObjectByReference<UStaticMesh>(this->PreviewMesh); // TODO: use reflection
	//}
	UTexture2D * t = this->LoadThumbnail(owner);
	instance->Thumbnail = t;
	instance->ItemGroupID = this->ItemGroupID;

	if (existingAlias) {
		instance->Alias = existingAlias->AsItemAliasInstance(instance);
	}

	if (!instance->Alias) {
		UItemInstance* item_owner = Cast<UItemInstance>(owner);
		auto itemcache = item_owner->GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache;
		if (item_owner) {
			if (instance->Thumbnail && instance->Thumbnail == item_owner->Thumbnail) {
				instance->Alias = item_owner->Alias;
			}
			else {
				auto aliases = itemcache->GetItemAliasesByID(instance->ItemID);
				if (aliases.Num() > 0) {
					//instance->Alias = UContentResolver::Instance->ResolveAliasForItem(instance);
					instance->Alias = aliases[0];
				}
			}
		}
		else {
			//instance->Alias = UContentResolver::Instance->ResolveAliasForItem(instance);
			auto aliases = itemcache->GetItemAliasesByID(instance->ItemID);
			if (aliases.Num() > 0) {
				instance->Alias = aliases[0];
			}
		}
	}

	/*if (instance->Alias) {
		instance->AliasName
	}*/

	if (load) {
		instance->Load();
	}
	return instance;
}

UTexture2D * UItemModel::LoadThumbnail(UObject * outer)
{
	UTexture2D* texture = NULL;
	if (this->Thumbnail.Len() > 0) {
		auto obj = StaticLoadObject(UTexture2D::StaticClass(), outer, *this->Thumbnail);
		texture = Cast<UTexture2D>(obj);
		if (!texture && GEngine) {
			//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Failed to load thumbnail: ").Append(this->Thumbnail));
		}
	}
	return texture;
}

//UItemInstance * UItemRecipeQueryResult::AsItemInstance(UObject * owner)
//{
//	auto item = Super::AsItemInstance(owner);
//	item->Stack = this->RequiredQuantity;
//	return item;
//}

UItemInstance * UItemIngredientQueryResult::AsItemInstance(UObject * owner, UItemAliasQueryResult* existingAlias, bool load )
{
	auto item = Super::AsItemInstance(owner, existingAlias, load);
	item->Data.Stack = this->RequiredQuantity;
	return item;
}

//UItemInstance * UItemLootQueryResult::AsItemInstance(UItemInstance * owner)
//{
//	UItemInstance * instance = NewObject<UItemInstance>(owner);
//	instance->ItemID = this->ItemID; // TODO: use reflection
//	instance->Health = UItemInstance::GetHealth(this->HealthMin, this->HealthMax);
//	instance->DefaultMaxStack = this->MaxStack; // TODO: use reflection
//	instance->MaxStack = this->MaxStack; // TODO: use reflection
//	instance->DisplayName = this->DisplayName; // TODO: use reflection
//	instance->ItemLootFormulaID = this->ItemLootFormulaID; // TODO: use reflection
//	instance->FoliageTypeID = this->FoliageTypeID; // TODO: use reflection
//	instance->FoliageScaleIndex = this->FoliageScaleIndex; // TODO: use reflection
//	//instance->Stack = this->LootQuantity; // TODO: use reflection
//	instance->LootSelf = this->LootSelf; // TODO: use reflection
//	UTexture2D * t = this->LoadThumbnail(owner);
//	instance->Thumbnail = t;
//	instance->SurfaceEffectID = this->SurfaceEffectID;
//	if (instance->Thumbnail && instance->Thumbnail == owner->Thumbnail) {
//		instance->Alias = owner->Alias;
//	}
//	else {
//		instance->Alias = UContentResolver::Instance->ResolveAliasForItem(instance);
//	}
//	instance->Load();
//	return instance;
//}
//
//UItemInstance * UItemPossibleRecipeQueryResult::AsItemInstance(UItemInstance * owner)
//{
//	UItemInstance * instance = NewObject<UItemInstance>(owner);
//	instance->ItemID = this->ItemID; // TODO: use reflection
//	instance->Health = UItemInstance::GetHealth(this->HealthMin, this->HealthMax);
//	instance->DefaultMaxStack = this->MaxStack; // TODO: use reflection
//	instance->MaxStack = this->MaxStack; // TODO: use reflection
//	instance->DisplayName = this->DisplayName; // TODO: use reflection
//	instance->ItemLootFormulaID = this->ItemLootFormulaID; // TODO: use reflection
//	instance->FoliageTypeID = this->FoliageTypeID; // TODO: use reflection
//	instance->FoliageScaleIndex = this->FoliageScaleIndex; // TODO: use reflection
//	//instance->Stack = this->LootQuantity; // TODO: use reflection
//	instance->LootSelf = this->LootSelf; // TODO: use reflection
//	UTexture2D * t = this->LoadThumbnail(owner);
//	instance->Thumbnail = t;
//	instance->SurfaceEffectID = this->SurfaceEffectID;
//	if (instance->Thumbnail && instance->Thumbnail == owner->Thumbnail) {
//		instance->Alias = owner->Alias;
//	}
//	else {
//		instance->Alias = UContentResolver::Instance->ResolveAliasForItem(instance);
//	}
//	instance->Load();
//	return instance;
//}

//UItemAliasInstance * UItemAliasQueryByAliasResult::AsItemAliasInstance(UObject * outer)
//{
//	UItemAliasInstance * instance = NewObject<UItemAliasInstance>(outer);
//	instance->Name = this->ItemAlias;
//	instance->DefaultComponent = this->DefaultComponent; // TODO: use reflection
//	instance->ActorBlueprint = this->ActorBlueprint; // TODO: use reflection
//	instance->FoliageIndex = this->FoliageIndex; // TODO: use reflection
//	instance->ItemPlaceableTypeID = this->ItemPlaceableTypeID; // TODO: use reflection
//	instance->HealthBreakpoint = this->HealthBreakpoint; // TODO: use reflection
//	instance->Particle = UContentResolver::Instance->FindObjectByReference<UParticleSystem>(this->Particle);
//	instance->ParticleFlags = static_cast<EParticleFlag>(this->ParticleFlags);
//	instance->ParticleRotation = UCommon::ParseRotator(this->ParticleRotation);
//	instance->ParticleScale = UCommon::ParseVector(this->ParticleScale);
//	instance->DestructibleMesh = UContentResolver::Instance->FindObjectByReference<UDestructibleMesh>(this->DestructibleMesh); // TODO: use reflection
//	instance->Load();
//	return instance;
//}

//UItemAliasInstance * UItemAliasQueryByIDResult::AsItemAliasInstance(UObject * outer)
UItemAliasInstance * UItemAliasQueryResult::AsItemAliasInstance(UObject * outer)
{
	UItemAliasInstance * instance = NewObject<UItemAliasInstance>(outer);
	instance->ItemID = this->ItemID;
	instance->Name = this->ItemAlias;
	instance->DefaultComponent = this->DefaultComponent; // TODO: use reflection
	instance->ActorBlueprint = this->ActorBlueprint; // TODO: use reflection
	instance->FoliageIndex = this->FoliageIndex; // TODO: use reflection
	instance->ItemPlaceableTypeID = this->ItemPlaceableTypeID; // TODO: use reflection
	instance->Particle = UContentResolver::Instance->FindObjectByReference<UParticleSystem>(this->Particle, true);
	instance->HealthBreakpoint = this->HealthBreakpoint; // TODO: use reflection
	instance->BreakpointSurfaceEffectID = this->BreakpointSurfaceEffectID; // TODO: use reflection
	instance->ParticleFlags = static_cast<EParticleFlag>(this->ParticleFlags);
	instance->ParticleRotation = UCommon::ParseRotator(this->ParticleRotation);
	instance->ParticleScale = UCommon::ParseVector(this->ParticleScale);
	instance->DestructibleMesh = UContentResolver::Instance->FindObjectByReference<UDestructibleMesh>(this->DestructibleMesh, true);
	instance->Load();
	return instance;
}

USurfaceEffect* USurfaceEffectModel::AsSurfaceEffect(UObject * outer)
{
	if (!this->effect) {
		this->effect = NewObject<USurfaceEffect>(outer);
		//effect.USurfaceTypeID = this->USurfaceTypeID;
		this->effect->SurfaceEffectID = this->SurfaceEffectID;
		this->effect->Name = this->Name;
		this->effect->HitParticle = UContentResolver::Instance->FindObjectByReference<UParticleSystem>(this->HitParticle, true);
		this->effect->HitParticleMinSpeed = this->HitParticleMinSpeed;
		this->effect->HitParticleScale = UCommon::ParseVector(this->HitParticleScale);
		this->effect->HitParticleRotation = UCommon::ParseRotator(this->HitParticleRotation);
		this->effect->AllowHitImpulse = this->AllowHitImpulse;
		this->effect->AllowDamage = this->AllowDamage;
		//this->effect->DecalType = this->ParseMaterial(this->DecalType);
	/*	this->effect->DecalType = UContentResolver::Instance->FindObjectByReference<UMaterialInterface>(this->DecalType);
		if (this->Decal.Len() > 0) {
			this->effect->Decal = UContentResolver::Instance->FindObjectByReference<UObject>(this->Decal);
		}*/
		//this->effect->DecalSize = UCommon::ParseVector(this->DecalSize);

		auto sounds = UDatabaseLoader::GetSurfaceEffectSounds(this->SurfaceEffectID);
		for (int i = 0; i < sounds.Num(); i++) {
			auto sound = sounds[i]->AsSurfaceEffectSound(this->effect);
			this->effect->Sounds.Add(sound);
		}

		auto decals = UDatabaseLoader::GetSurfaceEffectDecals(this->SurfaceEffectID);
		for (int i = 0; i < decals.Num(); i++) {
			auto decal = decals[i]->AsSurfaceEffectDecal(this->effect);
			this->effect->Decals.Add(decal);
		}

		auto particles = UDatabaseLoader::GetSurfaceEffectParticles(this->SurfaceEffectID);
		for (int i = 0; i < particles.Num(); i++) {
			auto particle = particles[i]->AsSurfaceEffectParticle(this->effect);
			this->effect->Particles.Add(particle);
		}

		//this->effect->SetFlags(RF_Standalone); // alternative to AddToRoot(); use this when OUTER apposed to ATR as this will auto clean
	}

	return this->effect;
}

//USurfaceEffect* USurfaceTypeModel::AsSurfaceEffect(UObject * outer)
//{
//	if (!this->effect) {
//		this->effect = NewObject<USurfaceEffect>(outer);
//		//effect.USurfaceTypeID = this->USurfaceTypeID;
//		this->effect->SurfaceEffectID = this->SurfaceEffectID;
//		this->effect->Name = this->Name;
//		this->effect->HitParticle = this->HitParticle;
//		this->effect->HitParticleMinSpeed = this->HitParticleMinSpeed;
//		this->effect->AllowHitImpulse = this->AllowHitImpulse;
//		this->effect->AllowDamage = this->AllowDamage;
//		this->effect->ParticleScale = this->ParticleScale;
//		this->effect->ParticleRotation = this->ParseRotator(this->ParticleRotation);
//		this->effect->DecalType = this->ParseMaterial(this->DecalType);
//		this->effect->DecalSize = this->ParseVector(this->DecalSize);
//
//		auto sounds = DatabaseLoader::GetSurfaceEffectSounds(this->SurfaceEffectID);
//		for (int i = 0; i < sounds.Num(); i++) {
//			auto sound = sounds[i]->AsSurfaceEffectSound(outer);
//			this->effect->Sounds.Add(sound);
//		}
//	}
//
//	return this->effect;
//}

//FVector USurfaceEffectModel::ParseVector(const FString& reference)
//{
//	FVector result;
//
//	FString text = *reference;
//	text.RemoveFromStart(TEXT("FVector("));
//	text.RemoveFromEnd(TEXT(")"));
//
//	int index = -1;
//	if (text.FindChar(',', index)) {
//		if (index > 0) { // intentional - 0 should at least be 1 digit
//			FString x = text.LeftChop(index);
//			result.X = FCString::Atof(*x);
//
//			text.RemoveAt(0, index + 1);
//
//			if (text.FindChar(',', index)) {
//				if (index > 0) { // intentional - 0 should at least be 1 digit
//					FString y = text.LeftChop(index);
//					result.Y = FCString::Atof(*y);
//
//					text.RemoveAt(0, index + 1);
//
//					// no commar left, use remaining
//					text = text.TrimStart();
//					result.Z = FCString::Atof(*text);
//				}
//			}
//		}
//	}
//
//	return result;
//}
//
//FRotator USurfaceEffectModel::ParseRotator(const FString& reference)
//{
//	FRotator result(0, 0, 0);
//
//	FString text = *reference;
//	text.RemoveFromStart(TEXT("FRotator("));
//	text.RemoveFromEnd(TEXT(")"));
//
//	int index = -1;
//	if (text.FindChar(',', index)) {
//		if (index > 0) { // intentional - 0 should at least be 1 digit
//			FString p = text.LeftChop(index);
//			result.Pitch = FCString::Atof(*p);
//
//			text.RemoveAt(0, index + 1);
//
//			if (text.FindChar(',', index)) {
//				if (index > 0) { // intentional - 0 should at least be 1 digit
//					FString y = text.LeftChop(index);
//					result.Yaw = FCString::Atof(*y);
//
//					text.RemoveAt(0, index + 1);
//
//					// no commar left, use remaining
//					text = text.TrimStart();
//					result.Roll = FCString::Atof(*text);
//				}
//			}
//		}
//	}
//
//	return result;
//}

UMaterialInterface *  USurfaceEffectModel::ParseMaterial(const FString& reference)
{
	UMaterialInterface * result = NULL;

	return result;
}

USurfaceEffectSound* USurfaceEffectSoundModel::AsSurfaceEffectSound(UObject * outer)
{
	USurfaceEffectSound* sound = NewObject<USurfaceEffectSound>(outer);// = FSurfaceEffectSound();

	sound->SurfaceEffectSoundID = this->SurfaceEffectSoundID;
	sound->SurfaceEffectID = this->SurfaceEffectID;
	//sound.Cue = this->ParseCue(this->Cue);
	sound->Cue = UContentResolver::Instance->FindObjectByReference<USoundCue>(this->Cue, true);
	sound->Weighting = this->Weighting;

	return sound;
}

USurfaceEffectDecal* USurfaceEffectDecalModel::AsSurfaceEffectDecal(UObject * outer)
{
	USurfaceEffectDecal* decal = NewObject<USurfaceEffectDecal>(outer);// = FSurfaceEffectDecal();

	decal->SurfaceEffectDecalID = this->SurfaceEffectDecalID;
	decal->SurfaceEffectID = this->SurfaceEffectID;
	decal->Decal = UContentResolver::Instance->FindObjectByReference<UObject>(this->Decal, true);
	decal->DecalSize = UCommon::ParseVector(this->DecalSize);
	decal->Weighting = this->Weighting;

	return decal;
}

USurfaceEffectParticle* USurfaceEffectParticleModel::AsSurfaceEffectParticle(UObject * outer)
{
	USurfaceEffectParticle* particle = NewObject<USurfaceEffectParticle>(outer);// = FSurfaceEffectDecal();

	particle->SurfaceEffectParticleID = this->SurfaceEffectParticleID;
	particle->SurfaceEffectID = this->SurfaceEffectID;
	particle->Particle = UContentResolver::Instance->FindObjectByReference<UParticleSystem>(this->Particle, true);
	particle->Rotation = UCommon::ParseRotator(this->Rotation);
	particle->Scale = UCommon::ParseVector(this->Scale);
	particle->Weighting = this->Weighting;

	return particle;
}

//USoundCue * USurfaceEffectSoundModel::ParseCue(const FString& reference)
//{
//	USoundCue * cue = NULL;
//
//	/*auto c = UContentResolver::Instance->FindClass(reference);
//	if (c) {
//		
//	}*/
//
//
//	/*UObject* ClassPackage = ANY_PACKAGE;
//
//	if (USoundCue* Result = FindObject<USoundCue>(ClassPackage, *reference))
//		return (USoundCue*)Result;
//
//	if (UObjectRedirector* RenamedClassRedirector = FindObject<UObjectRedirector>(ClassPackage, *reference))
//		return (USoundCue*)CastChecked<USoundCue>(RenamedClassRedirector->DestinationObject);*/
//
//	return cue;
//}