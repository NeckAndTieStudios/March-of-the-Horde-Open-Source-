#include "ItemContainer.h"

//void UItemContainer::GetLifetimeReplicatedProps(TArray< FLifetimeProperty >& OutLifetimeProps) const
//{
//	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
//
//	DOREPLIFETIME(UItemContainer, Items);
//}

bool UItemContainerComponent::ReplicateSubobjects(class UActorChannel* Channel, class FOutBunch* Bunch, FReplicationFlags* RepFlags)
{
	bool WroteSomething = Super::ReplicateSubobjects(Channel, Bunch, RepFlags);

	if (Container != nullptr)
	{
		WroteSomething |= Channel->ReplicateSubobject(Container, *Bunch, *RepFlags);
	}

	return WroteSomething;
}

void UItemContainerComponent::OnRegister()
{
	//GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString(TEXT("UItemContainerComponent.BeginPlay")));
	//UE_LOG(LogTemp, Warning, TEXT("UItemContainerComponent.BeginPlay"));
	if (GetOwner()->HasAuthority())
	{
		GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString(TEXT("UItemContainerComponent.BeginPlay AUTH")));
		UE_LOG(LogTemp, Warning, TEXT("UItemContainerComponent.BeginPlay AUTH"));
		this->Container = NewObject<UItemContainer>(this, ItemContainerClass, FName(*this->GetName().Append(FString("_Container"))));
		//this->SetNetAddressable();

		//this->Container = CreateDefaultSubobject<UItemContainer>(FName("Container"), ItemContainerClass);

		if (ContainerName.Len() > 0) {
			this->Container->Name = ContainerName;
		}
	}
	else
	{
		GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString(TEXT("UItemContainerComponent.BeginPlay Not AUTH")));
		UE_LOG(LogTemp, Warning, TEXT("UItemContainerComponent.BeginPlay Not AUTH"));
	}

	Super::OnRegister();
}

void UItemContainerComponent::OnRep_Container()
{
	GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString(TEXT("UItemContainerComponent.Container replicated")));
	UE_LOG(LogTemp, Warning, TEXT("UItemContainerComponent.Container replicated"));
	Container->OwningComponent = this;
}