// Fill out your copyright notice in the Description page of Project Settings.

#include "FPSCharacter.h"
#include "Kismet/KismetSystemLibrary.h"
#include "HitComponent.h"
#include "ContentResolver.h"
#include "GlobalGameInstance.h"
#include "Foliage.h"
#include "GameSettings.h"

void AMOTHCharacter::MoveToolBeltSelection_Implementation(int ToolBeltID, int Direction)
{
	if (!IsInventoryOpen && !IsInventoryCraftingOpen)
	{
		/*auto gi = GetWorld()->GetGameInstance<UGlobalGameInstance>();
		if (gi && gi->Settings) {*/
		FString container_name = FString("Toolbelt ").Append(FString::FromInt(ToolBeltID + 1));
		auto toolbelt_slots = this->TryGetContainerByName(container_name);

		//auto toolbelt_slots = this->GetInventories()["Toolbelt 1"];
		auto ToolBeltSlots = toolbelt_slots->Items.Num();

		auto new_index = ToolbeltIndex + Direction;
		if (new_index < 0) {
			new_index = ToolBeltSlots + new_index;
		}
		else if (new_index >= ToolBeltSlots) {
			new_index -= ToolBeltSlots;
		}
		ToolbeltIndex = new_index;
		this->OnToolbeltUpdated(ToolBeltID);
		//}
	}
}

void AMOTHCharacter::OnDamaged_Implementation(FHitResult HitResult, AActor* initiator, EInteractionTrigger trigger)
{
}


void AMOTHCharacter::SetHeldActor(AActor* NewHeldActor, const FItemData& Item)
{
	auto build_actor = Cast<ABuildingMeshActor>(this->HeldActor);
	if (build_actor) {
		// existing actor
		//if (build_actor->Mesh != BuildMesh || (Item && Item->IsPlaceable)) {
		build_actor->Destroy();
		this->HeldActor = NULL;
		//}
	}
	else if (this->HeldActor) {
		// unmount the current
		//this->HeldActor->SetActorHiddenInGame(true);
		//this->HeldActor->SetActorTickEnabled(false);
		this->HeldActor->Destroy();
		this->HeldActor = NULL;
	}

	if (NewHeldActor) {
		this->HeldActor = NewHeldActor;
	}
	else {
		this->HeldActor = this->GetDefaultHeldActor();
	}

	if (this->HeldActor) {
		this->HeldActor->SetReplicates(true);
	}
}

//USkeletalMeshComponent* AMOTHCharacter::GetWeaponAttachSkeletalMesh_Implementation()
//{
//	return NULL;
//}

// Sets default values
AFPSCharacter::AFPSCharacter(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	//this->Weapon = CreateDefaultSubobject<AWeapon>(FName("Weapon"));

	//this->WeaponActor = CreateDefaultSubobject<UChildActorComponent>(FName("WeaponActor"));
	//this->WeaponActor->AttachToComponent(this->GetMesh(), FAttachmentTransformRules::KeepRelativeTransform, FName("hand_r"));

	//if (this->WeaponClass)
	//{
	//	this->WeaponActor->SetChildActorClass(this->WeaponClass);
	//	//this->_weaponInstance = this->WeaponActor->
	//	
	//}

	// listen for interactions, by using overlaps on the capsule
	/*InteractionCapsule = CreateDefaultSubobject<UCapsuleComponent>(FName("InteractionCapsule"));
	InteractionCapsule->InitCapsuleSize(34.f, 88.0f);
	InteractionCapsule->SetCollisionProfileName(FName("Trigger"));
	InteractionCapsule->SetupAttachment(GetCapsuleComponent());
	InteractionCapsule->OnComponentBeginOverlap.AddDynamic(this, &AFPSCharacter::On_BeginOverlap);*/
	GetCapsuleComponent()->OnComponentBeginOverlap.AddDynamic(this, &AFPSCharacter::On_BeginOverlap);
	GetCapsuleComponent()->OnComponentEndOverlap.AddDynamic(this, &AFPSCharacter::On_EndOverlap);
}

//void ABuildModeActor::Init_Implementation(UItemInstance* ItemInstance, UStaticMesh* StaticMesh)
//{
//	this->Mesh = StaticMesh;
//	this->Item = ItemInstance;
//}

// Called when the game starts or when spawned
void AMOTHCharacter::BeginPlay()
{
	Super::BeginPlay();

	//if (this->HandWeaponClass) {
	//	this->HandWeapon = GetWorld()->SpawnActor<AWeapon>(this->HandWeaponClass, FVector(0.f), FRotator(0.f));
	//	this->HandWeapon->SetOwner(this);
	//	this->HandWeapon->AttachToActor(this, FAttachmentTransformRules(EAttachmentRule::SnapToTarget, true/*super dooper important in order for world position to work*/));
	//}

	////if (this->HeldActorClass && !this->DefaultHeldActor) {
	////	auto actor = GetWorld()->SpawnActor<AWeapon>(this->HeldActorClass, FVector(0.f), FRotator(0.f));
	////	actor->SetOwner(this);
	////	actor->AttachToActor(this, FAttachmentTransformRules(EAttachmentRule::SnapToTarget, true/*super dooper important in order for world position to work*/));

	////	this->DefaultHeldActor = actor; // hold a reference so we don't lose it when switching between toolbelt slots
	////}

	//if (this->WeaponClass) {
	//	this->ChangeWeapon(this->WeaponClass);
	//}
}

//AMOTHCharacter::AMOTHCharacter()
//{
//	//SetupInventories();
//}

AMOTHCharacter::AMOTHCharacter(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	//: Super(ObjectInitializer.SetDefaultSubobjectClass<UShooterCharacterMovement>(ACharacter::CharacterMovementComponentName))
{
	Mesh1P = ObjectInitializer.CreateDefaultSubobject<USkeletalMeshComponent>(this, TEXT("PawnMesh1P"));
	Mesh1P->SetupAttachment(GetCapsuleComponent());
	Mesh1P->bOnlyOwnerSee = true;
	Mesh1P->bOwnerNoSee = false;
	Mesh1P->bCastDynamicShadow = false;
	Mesh1P->bReceivesDecals = false;
	Mesh1P->VisibilityBasedAnimTickOption = EVisibilityBasedAnimTickOption::OnlyTickPoseWhenRendered;
	Mesh1P->PrimaryComponentTick.TickGroup = TG_PrePhysics;
	Mesh1P->SetCollisionObjectType(ECC_Pawn);
	Mesh1P->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	Mesh1P->SetCollisionResponseToAllChannels(ECR_Ignore);

	/*GetMesh()->bOnlyOwnerSee = false;
	GetMesh()->bOwnerNoSee = true;
	GetMesh()->bReceivesDecals = false;
	GetMesh()->SetCollisionObjectType(ECC_Pawn);
	GetMesh()->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	GetMesh()->SetCollisionResponseToChannel(COLLISION_WEAPON, ECR_Block);
	GetMesh()->SetCollisionResponseToChannel(COLLISION_PROJECTILE, ECR_Block);
	GetMesh()->SetCollisionResponseToChannel(ECC_Visibility, ECR_Block);

	GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_Camera, ECR_Ignore);
	GetCapsuleComponent()->SetCollisionResponseToChannel(COLLISION_PROJECTILE, ECR_Block);
	GetCapsuleComponent()->SetCollisionResponseToChannel(COLLISION_WEAPON, ECR_Ignore);

	TargetingSpeedModifier = 0.5f;
	bIsTargeting = false;
	RunningSpeedModifier = 1.5f;
	bWantsToRun = false;
	bWantsToFire = false;
	LowHealthPercentage = 0.5f;

	BaseTurnRate = 45.f;
	BaseLookUpRate = 45.f;*/
}

// Called when the game starts or when spawned
void AFPSCharacter::BeginPlay()
{
	Super::BeginPlay();
	//if (GEngine)
	//{
	//	GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("We are using FPSCharacter."));
	//}

	//this->GameInstance = GetWorld()->GetGameInstance<UGlobalGameInstance>();

	//this->_initialWalkSpeed = GetCharacterMovement()->MaxWalkSpeed;
	GetCharacterMovement()->MaxWalkSpeed = this->WalkSpeed;

	/*if (this->SingleFireClass)
	{
		this->_barrel_single = GetWorld()->SpawnActor<ABarrel>(this->SingleFireClass, FVector(0, 0, -45.f), FRotator(0));
		this->_barrel_single->ProjectileClass = this->BulletProjectileClass;
		this->_barrel_single->IsFiring = false;
		this->_barrel_single->AttachToActor(this, FAttachmentTransformRules(EAttachmentRule::SnapToTarget, true));
	}
	if (this->BurstFireClass)
	{
		this->_barrel_burst = GetWorld()->SpawnActor<ABarrel>(this->BurstFireClass, FVector(0, 0, -45.f), FRotator(0));
		this->_barrel_burst->ProjectileClass = this->BulletProjectileClass;
		this->_barrel_burst->IsFiring = false;
		this->_barrel_burst->AttachToActor(this, FAttachmentTransformRules(EAttachmentRule::SnapToTarget, true));
	}
	if (this->AutoFireClass)
	{
		this->_barrel_auto = GetWorld()->SpawnActor<ABarrel>(this->AutoFireClass, FVector(0, 0, -45.f), FRotator(0));
		this->_barrel_auto->ProjectileClass = this->BulletProjectileClass;
		this->_barrel_auto->IsFiring = false;
		this->_barrel_auto->AttachToActor(this, FAttachmentTransformRules(EAttachmentRule::SnapToTarget, true));
	}*/

	/*if (!GetWorld()->GetTimerManager().IsTimerActive(LookForInteractableHandle)) {
		GetWorld()->GetTimerManager().SetTimer(LookForInteractableHandle, this, &AFPSCharacter::LookForInteractable, 0.05f, true, 0.f);
	}*/

	//(new FAutoDeleteAsyncTask<FCharacterBackgroundTask>(this))->StartBackgroundTask();
}

void AMOTHCharacter::TryCraftItem(UPARAM(ref) FItemData& item, int amount)
{
	TArray<UItemWidget*> consumable_slots;

	auto itemcache = GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache;
	auto def = itemcache->GetItemByID(item.ItemID);

	//auto ingredients = def->GetIngredients();
	auto ingredients = FItemData::GetIngredients(item.ItemID, itemcache);
	auto ingredients_result = this->TryFindIngredients(ingredients);
	float fulfill_amount = amount;

	auto craftQueue = this->TryGetContainerByName(CHARACTER_INVENTORY_CRAFT_QUEUE);

	if (ingredients_result.IsFulfilled) // can craft at least one in this operation
	{
		// iterate over the ingredients and determine if we need to decrease the amount required.
		fulfill_amount = ingredients_result.DetermineMaxAmount(fulfill_amount);
		//for (int i = 0; i < ingredients.Num(); i++)
		//{
		//	//float total_required = ingredients[i]->Stack * amount;

		//	// find the required item from the ingredient results
		//	for (int x = 0; x < ingredients_result.Results.Num(); x++)
		//	{
		//		auto ingredient_result = ingredients_result.Results[x];
		//		if (ingredient_result.Ingredient->ItemID == ingredients[i]->ItemID)
		//		{
		//			if (ingredient_result.Available < ingredients[i]->Stack) {
		//				// cannot fulfil this item
		//				return;
		//			}

		//			int max_items_possible = ingredient_result.Available / ingredient_result.Ingredient->Stack/*Required*/;
		//			if (max_items_possible < fulfill_amount) {
		//				fulfill_amount = max_items_possible;
		//			}

		//			break;
		//		}
		//	}
		//}

		// iterate over and deduct
		for (int f = 0; f < fulfill_amount; f++)
		{
			auto queue_item = item; // ->Clone(this);
			queue_item.Stack = 1;

			ingredients_result.Deduct();
			//	for (int i = 0; i < ingredients.Num(); i++)
			//	{
			//		float total_required = ingredients[i]->Stack;

			//		// find the required item from the ingredient results
			//		for (int x = 0; x < ingredients_result.Results.Num(); x++)
			//		{
			//			auto ingredient_result = ingredients_result.Results[x];
			//			if (ingredient_result.Ingredient->ItemID == ingredients[i]->ItemID)
			//			{
			//				// find the item from the ingredient results
			//				for (int s = 0; s < ingredient_result.Slots.Num(); s++)
			//				{
			//					auto slot = ingredient_result.Slots[s];
			//					if (slot->ItemInstance) {
			//						auto amount_to_deduct = FMath::Min(slot->ItemInstance->Stack, total_required);

			//						total_required -= amount_to_deduct;
			//						slot->ItemInstance->Stack -= amount_to_deduct;

			//						if (slot->ItemInstance->Stack <= 0) {
			//							slot->OnClear();
			//						}
			//					}
			//				}

			//				break;
			//			}
			//		}
			//	}

			this->OnRequestCraft(queue_item);
			//auto slots = this->TryFindSlotForItem(craftQueue, queue_item, true /*Craft queue can always stack to 999*/);
			//for (int c = 0; c < slots.Num(); c++) {
			//	//slots[c]->OnCraft();
			//	this->OnRequestCraft(slots[c]);
			//}
		}
	}
}

FAvailableIngredientResult AMOTHCharacter::TryFindIngredients(TArray<FItemData> requiredIngredients)
{
	FAvailableIngredientResult result;

	//auto inventories = this->GetInventories();

	auto ingredients = requiredIngredients;
	bool found = ingredients.Num() > 0;

	auto chr = this;

	result.RequiredIngredients = requiredIngredients;
	result.IsFulfilled = ingredients.Num() > 0;
	for (int i = 0; i < ingredients.Num(); i++)
	{
		// find the next inventory item with enough quantity
		float total_required = ingredients[i].Stack;

		FAvailableIngredient availableIngredient;
		availableIngredient.Ingredient = ingredients[i];
		availableIngredient.Available = 0;

		/*for (const TPair<FString, UItemContainer*>& pair : inventories)
		{
			AMOTHCharacter::TryFindIngredientsByInventory(pair.Value->Items, availableIngredient, total_required);
		}*/
		for (auto container : this->Inventories) {
			if (container) {
				AMOTHCharacter::TryFindIngredientsByInventory(container, availableIngredient, total_required);
			}
		}

		if (total_required > 0) {
			result.IsFulfilled = false;
		}

		result.Results.Add(availableIngredient);
	}

	return result;
}

void AMOTHCharacter::TryFindIngredientsByInventory(UItemContainer* container, FAvailableIngredient& availableIngredient, float& total_required)
{
	for (int x = 0; x < container->Items.Num(); x++)
	{
		if (/*widgets[x] &&*/ container->Items[x].ItemID == availableIngredient.Ingredient.ItemID)
		{
			if (container->Items[x].Stack > 0)
			{
				//float amount = FMath::Min(widgets[x]->ItemInstance->Stack, total_required);

				total_required -= container->Items[x].Stack;
				availableIngredient.Available += container->Items[x].Stack;

				FAvailableIngredientContainerItem reference;
				reference.Container = container;
				reference.SlotID = x;
				availableIngredient.Items.Add(reference);
			}
		}
	}
}

TArray<FTryFindItemByInventoryResult> AMOTHCharacter::TryFindItemByInventory(UItemContainer* container, int itemID, float& available)
{
	TArray<FTryFindItemByInventoryResult> results;
	for (int x = 0; x < container->Items.Num(); x++)
	{
		auto slot = container->Items[x];
		if (/*slot &&*/ slot.ItemID == itemID)
		{
			if (slot.Stack > 0)
			{
				available += slot.Stack;

				results.Add(FTryFindItemByInventoryResult(container, x, slot));
			}
		}
	}
	return results;
}

void AMOTHCharacter::ChangeWeapon(TSubclassOf<class AWeapon> weapon_class)
{
	if (this->Weapon) {
		this->Weapon->Destroy();
		this->Weapon = NULL;
	}
	//this->Weapon = NewObject<AWeapon>(this, weapon_class);
	this->Weapon = GetWorld()->SpawnActor<AWeapon>(weapon_class, FVector(0.f), FRotator(0.f));
	this->Weapon->SetOwner(this);
	this->Weapon->AttachToActor(this, FAttachmentTransformRules(EAttachmentRule::SnapToTarget, true/*super dooper important in order for world position to work*/));

	this->HeldActor = this->Weapon;
}

// Called every frame
void AMOTHCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	//this->LookForInteractable();

	/*if (Role == ROLE_AutonomousProxy)
	{
		this->LookForInteractableDelta += DeltaTime;

		if (this->LookForInteractableDelta >= 0.1f) {
			this->LookForInteractableDelta = 0.f;
			this->LookForInteractable();
		}
	}*/

	/*if (this->FireMode == EFireMode::Single)
	{
		if (this->_barrel_single && this->_barrel_single->IsFiring)
		{
			FVector CameraLocation;
			FRotator CameraRotation;
			GetActorEyesViewPoint(CameraLocation, CameraRotation);

			FVector SpawnLocation = CameraLocation + FTransform(CameraRotation).TransformVector(MuzzleOffset);
			FRotator SpawnRotation = CameraRotation;

			this->_barrel_single->SetActorRotation(SpawnRotation);
			this->_barrel_single->SetActorLocation(SpawnLocation);
		}
	}
	else if (this->FireMode == EFireMode::Burst)
	{
		if (this->_barrel_burst && this->_barrel_burst->IsFiring)
		{
			FVector CameraLocation;
			FRotator CameraRotation;
			GetActorEyesViewPoint(CameraLocation, CameraRotation);

			FVector SpawnLocation = CameraLocation + FTransform(CameraRotation).TransformVector(MuzzleOffset);
			FRotator SpawnRotation = CameraRotation;

			this->_barrel_burst->SetActorRotation(SpawnRotation);
			this->_barrel_burst->SetActorLocation(SpawnLocation);
		}
	}
	else if (this->FireMode == EFireMode::Auto)
	{
		if (this->_barrel_auto && this->_barrel_auto->IsFiring)
		{
			FVector CameraLocation;
			FRotator CameraRotation;
			GetActorEyesViewPoint(CameraLocation, CameraRotation);

			FVector SpawnLocation = CameraLocation + FTransform(CameraRotation).TransformVector(MuzzleOffset);
			FRotator SpawnRotation = CameraRotation;

			this->_barrel_auto->SetActorRotation(SpawnRotation);
			this->_barrel_auto->SetActorLocation(SpawnLocation);
		}
	}*/
}

void AFPSCharacter::AddControllerYawInput(float Val)
{
	if (!this->IsInventoryOpen) {
		Super::AddControllerYawInput(Val);
	}
}

// Called to bind functionality to input
void AFPSCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	PlayerInputComponent->BindAxis("MoveForward", this, &AFPSCharacter::MoveForward);
	PlayerInputComponent->BindAxis("MoveRight", this, &AFPSCharacter::MoveRight);
	// Set up "look" bindings.
	PlayerInputComponent->BindAxis("Turn", this, &AFPSCharacter::AddControllerYawInput);
	PlayerInputComponent->BindAxis("LookUp", this, &AFPSCharacter::LookUp);
	// Set up "action" bindings.
	PlayerInputComponent->BindAction("Jump", IE_Pressed, this, &AFPSCharacter::StartJump);
	PlayerInputComponent->BindAction("Jump", IE_Released, this, &AFPSCharacter::StopJump);


	//PlayerInputComponent->BindAction("InteractPrimary", IE_Pressed, this, &AFPSCharacter::OnInteractPrimaryPressed);
	//PlayerInputComponent->BindAction("InteractPrimary", IE_Released, this, &AFPSCharacter::OnInteractPrimaryPressed);

	//PlayerInputComponent->BindAction("InteractSecondary", IE_Pressed, this, &AFPSCharacter::OnInteractSecondaryPressed);
	//PlayerInputComponent->BindAction("InteractSecondary", IE_Released, this, &AFPSCharacter::OnInteractSecondaryPressed);

	PlayerInputComponent->BindAction("ToggleBulletLines", IE_Pressed, this, &AFPSCharacter::On_ToggleBulletLines);
	PlayerInputComponent->BindAction("ToggleBulletInfo", IE_Pressed, this, &AFPSCharacter::On_ToggleBulletInfo);

	PlayerInputComponent->BindAction("HotKey_Noclip", IE_Released, this, &AFPSCharacter::OnHotKey_Noclip);

	PlayerInputComponent->BindAction("InteractTrigger", IE_Pressed, this, &AFPSCharacter::InteractTriggerPressed);
	PlayerInputComponent->BindAction("InteractTrigger", IE_Released, this, &AFPSCharacter::InteractTriggerReleased);

	PlayerInputComponent->BindAction("Sprint", IE_Pressed, this, &AFPSCharacter::On_StartSprint);
	PlayerInputComponent->BindAction("Sprint", IE_Released, this, &AFPSCharacter::On_StopSprint);
	PlayerInputComponent->BindAction("Job", IE_Pressed, this, &AFPSCharacter::On_StartSprint);
	PlayerInputComponent->BindAction("Job", IE_Released, this, &AFPSCharacter::On_StopSprint);

	//PlayerInputComponent->BindAction("ChangeFireMode", IE_Pressed, this, &AFPSCharacter::OnCycleFireMode);
}

void AFPSCharacter::On_StartSprint()
{
	//GetCharacterMovement()->MaxWalkSpeed = this->RunSpeed;
	/*this->IsWalking = false;
	this->IsRunning = true;*/
}

void AFPSCharacter::On_StopSprint()
{
	//GetCharacterMovement()->MaxWalkSpeed = this->WalkSpeed;
	/*this->IsWalking = true;
	this->IsRunning = false;*/
}

//void AFPSCharacter::OnInteractPrimaryPressed()
//{
//	// [Left Mouse]
//	if (this->Weapon) {
//		this->Weapon->On_TriggerPressed();
//	}
//}
//
//void AFPSCharacter::OnInteractPrimaryReleased()
//{
//	// [Left Mouse]
//	if (this->Weapon) {
//		this->Weapon->On_TriggerReleased();
//	}
//}
//
//void AFPSCharacter::OnInteractSecondaryPressed()
//{
//	//// Attempt to fire a projectile.
//	//if (ProjectileClass)
//	//{
//	//	// Get the camera transform.
//	//	FVector CameraLocation;
//	//	FRotator CameraRotation;
//	//	GetActorEyesViewPoint(CameraLocation, CameraRotation);
//
//	//	// Transform MuzzleOffset from camera space to world space.
//	//	FVector MuzzleLocation = CameraLocation + FTransform(CameraRotation).TransformVector(MuzzleOffset);
//	//	FRotator MuzzleRotation = CameraRotation;
//	//	// Skew the aim to be slightly upwards.
//	//	//MuzzleRotation.Pitch += 10.0f;
//	//	UWorld* World = GetWorld();
//	//	if (World)
//	//	{
//	//		FActorSpawnParameters SpawnParams;
//	//		SpawnParams.Owner = this;
//	//		SpawnParams.Instigator = Instigator;
//	//		// Spawn the projectile at the muzzle.
//	//		AFPSProjectile* Projectile = World->SpawnActor<AFPSProjectile>(ProjectileClass, MuzzleLocation, MuzzleRotation, SpawnParams);
//	//		if (Projectile)
//	//		{
//	//			// Set the projectile's initial trajectory.
//	//			FVector LaunchDirection = MuzzleRotation.Vector();
//	//			Projectile->FireInDirection(LaunchDirection);
//	//		}
//	//	}
//	//}
//}
//
//void AFPSCharacter::OnInteractSecondaryReleased()
//{
//}

void AMOTHCharacter::InteractWithLookAtItem()
{
	if (this->LookAtHitResult.IsValidBlockingHit()) {
		auto fic = Cast<UInstancedStaticMeshComponent>(this->LookAtHitResult.Component);
		if (fic) {
			Cast<UGlobalGameInstance>(GetGameInstance())->ContentResolver->ResolveInteraction(EInteractionTrigger::Pickup, this->LookAtHitResult, this); // calls OnInteraction
			return;
		}
	}

	if (this->LookAtItem) {
		this->LookAtItem->OnInteraction(EInteractionTrigger::Pickup, this->LookAtHitResult, this);
		return;
	}

	auto trace = this->Trace(FName(TEXT("InteractWithLookAtItem")), LookForInteractableRadius, LookForInteractableTraceType);
	if (trace.IsValidBlockingHit()) {
		UContentResolver::Instance->ResolveInteraction(EInteractionTrigger::Pickup, trace, this);
	}

	//if (this->LookAtItem) {
	//	auto fic = Cast<UInstancedStaticMeshComponent>(this->LookAtHitResult.Component);
	//	if (fic) {
	//		Cast<UGlobalGameInstance>(GetGameInstance())->ContentResolver->ResolveInteraction(EInteractionTrigger::Pickup, this->LookAtHitResult, this); // calls OnInteraction
	//	}
	//	else {
	//		this->LookAtItem->OnInteraction(EInteractionTrigger::Pickup, this->LookAtHitResult, this);
	//	}
	//}
	//else {
	//	// foliage late lookup
	//	auto trace = this->Trace(FName(TEXT("InteractWithLookAtItem")), LookForInteractableRadius, LookForInteractableTraceType);
	//	if (trace.IsValidBlockingHit()) {
	//		UContentResolver::Instance->ResolveInteraction(EInteractionTrigger::Pickup, trace, this);
	//	}
	//}
}
void AMOTHCharacter::CancelInteractWithLookAtItem()
{
	/*if (this->LookAtComponent) {
		this->LookAtComponent->OnInteractionCancel(this);
	}*/
	if (this->LookAtItem) {
		this->LookAtItem->OnInteractionCancel(this);
	}
}

void AMOTHCharacter::InteractTriggerPressed()
{
	if (!this->OnInteractTriggerPressed()) {
		this->InteractWithLookAtItem();
	}
}

void AMOTHCharacter::InteractTriggerReleased()
{
	if (!this->OnInteractTriggerReleased()) {
		this->CancelInteractWithLookAtItem();
	}
}

//void AFPSCharacter::OnCycleFireMode()
//{
//	uint8 next_fire_mode = static_cast<uint8>(this->FireMode) + 1;
//
//	if (next_fire_mode > static_cast<uint8>(EFireMode::MAX))
//	{
//		next_fire_mode = static_cast<uint8>(EFireMode::MIN);
//	}
//
//	this->FireMode = static_cast<EFireMode>(next_fire_mode);
//
//	if (this->FireMode == EFireMode::Single)
//	{
//		GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, TEXT("Fire Mode: Single"));
//	}
//	else if (this->FireMode == EFireMode::Burst)
//	{
//		GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, TEXT("Fire Mode: Burst"));
//	}
//	else if (this->FireMode == EFireMode::Auto)
//	{
//		GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, TEXT("Fire Mode: Auto"));
//	}
//
//	if (this->_barrel_single)
//	{
//		this->_barrel_single->IsFiring = false;
//	}
//	if (this->_barrel_burst)
//	{
//		this->_barrel_burst->IsFiring = false;
//	}
//	if (this->_barrel_auto)
//	{
//		this->_barrel_auto->IsFiring = false;
//	}
//}

void AFPSCharacter::LookUp(float Value)
{
	if (!this->IsInventoryOpen) {
		this->AddControllerPitchInput(Value);
	}
}

void AFPSCharacter::MoveForward(float Value)
{
	if (!this->PreventMovement) {
		if (this->IsOnClimbable) {
			AddMovementInput(this->GetActorUpVector(), Value);
		}
		else {
			FVector Direction;

			if (this->AllowNoClip && !this->IsMovingCamera) {
				// Find out which way is "forward" and record that the player wants to move that way.
				Direction = FRotationMatrix(Controller->GetControlRotation()).GetScaledAxis(EAxis::X);
			}
			else if (this->IsSwimSlowSpeed || this->IsSwimRegularSpeed || this->IsSwimFastSpeed)
			{
				Direction = FRotationMatrix(Controller->GetControlRotation()).GetScaledAxis(EAxis::X);
			}
			else {
				Direction = FRotationMatrix(this->GetActorRotation()).GetScaledAxis(EAxis::X);
			}

			AddMovementInput(Direction, Value);
		}
	}
}

void AFPSCharacter::MoveRight(float Value)
{
	if (!this->PreventMovement && !this->IsOnClimbable) {
		FVector Direction;

		if (!this->IsMovingCamera) {
			// Find out which way is "right" and record that the player wants to move that way.
			Direction = FRotationMatrix(Controller->GetControlRotation()).GetScaledAxis(EAxis::Y);
		}
		else {
			Direction = FRotationMatrix(this->GetActorRotation()).GetScaledAxis(EAxis::Y);
		}

		AddMovementInput(Direction, Value);
	}
}

void AFPSCharacter::StartJump()
{
	//Spawn();
	bPressedJump = true;
	//if (GEngine) {
	//	GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, TEXT("Jump!"));
	//}
}

void AFPSCharacter::StopJump()
{
	bPressedJump = false;
}

//void AFPSCharacter::FireStart()
//{
//	if (this->FireMode == EFireMode::Single)
//	{
//		if (this->_barrel_single)
//		{
//			this->_barrel_single->IsFiring = true;
//		}
//	}
//	else if (this->FireMode == EFireMode::Burst)
//	{
//		if (this->_barrel_burst)
//		{
//			this->_barrel_burst->IsFiring = true;
//		}
//	}
//	else if (this->FireMode == EFireMode::Auto)
//	{
//		if (this->_barrel_auto)
//		{
//			this->_barrel_auto->IsFiring = true;
//		}
//	}
//
//	//if (BulletProjectile != NULL)
//	//{
//	//	UWorld* const World = GetWorld();
//	//	if (World != NULL)
//	//	{
//	//		FVector CameraLocation;
//	//		FRotator CameraRotation;
//	//		GetActorEyesViewPoint(CameraLocation, CameraRotation);
//
//	//		FVector SpawnLocation = CameraLocation + FTransform(CameraRotation).TransformVector(MuzzleOffset);
//	//		FRotator SpawnRotation = CameraRotation;
//
//	//		//SpawnRotation.Pitch += SpawnRotation.Pitch;
//
//	//		auto bullet = World->SpawnActor<ABullet>(BulletProjectile, SpawnLocation, SpawnRotation);
//	//	}
//	//}
//
//	//if (this->_barrel)
//	//{
//	//	this->_barrel->IsFiring = true;
//
//	//	//SpawnRotation.Pitch += SpawnRotation.Pitch;
//
//	//	//auto bullet = World->SpawnActor<ABullet>(BulletProjectile, SpawnLocation, SpawnRotation);
//	//}
//
//	//// try and play the sound if specified
//	//if (FireSound != NULL)
//	//{
//	//	UGameplayStatics::PlaySoundAtLocation(this, FireSound, GetActorLocation());
//	//}
//
//	//// try and play a firing animation if specified
//	//if (FireAnimation != NULL)
//	//{
//	//	// Get the animation object for the arms mesh
//	//	UAnimInstance* AnimInstance = Mesh1P->GetAnimInstance();
//	//	if (AnimInstance != NULL)
//	//	{
//	//		AnimInstance->Montage_Play(FireAnimation, 1.f);
//	//	}
//	//}
//}
//
//void AFPSCharacter::FireStop()
//{
//	/*if (this->_barrel)
//	{
//		this->_barrel->IsFiring = false;
//	}*/
//	if (this->FireMode == EFireMode::Single)
//	{
//		if (this->_barrel_single)
//		{
//			this->_barrel_single->IsFiring = false;
//		}
//	}
//	else if (this->FireMode == EFireMode::Burst)
//	{
//		if (this->_barrel_burst)
//		{
//			this->_barrel_burst->IsFiring = false;
//		}
//	}
//	else if (this->FireMode == EFireMode::Auto)
//	{
//		if (this->_barrel_auto)
//		{
//			this->_barrel_auto->IsFiring = false;
//		}
//	}
//}

//void AFPSCharacter::Spawn() {
//	if (ToSpawn)
//	{
//		UWorld* world = GetWorld();
//		if (world)
//		{
//			FActorSpawnParameters spawnParams;
//			spawnParams.Owner = this;
//			FRotator rotator;
//			spawnZ += 150.0f;
//			FVector CamLoc = FVector(0, 0, spawnZ);
//			//GetActorEyesViewPoint(CamLoc, rotator);
//
//			world->SpawnActor<ACrate_Actor>(ToSpawn, CamLoc, rotator, spawnParams);
//		}
//	}
//}

void AFPSCharacter::OnHotKey_Noclip()
{
	this->AllowNoClip = !this->AllowNoClip;

	if (this->AllowNoClip) {
		this->ClientCheatGhost();
	}
	else {
		this->ClientCheatWalk();
	}
}

void AFPSCharacter::On_ToggleBulletLines()
{
	//ABullet::DebugLines = !ABullet::DebugLines;
	UKismetSystemLibrary::FlushPersistentDebugLines(this->GetWorld());
	UGameSettings::Instance->BulletDebugLines = !UGameSettings::Instance->BulletDebugLines;

	/*if (GEngine) {
		GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Bullet lines are: ").Append(UGameSettings::Instance->BulletDebugLines ? "ON" : "OFF"));
	}*/
}

void AFPSCharacter::On_ToggleBulletInfo()
{
	UGameSettings::Instance->BulletDebugInfo = !UGameSettings::Instance->BulletDebugInfo;

	/*if (GEngine) {
		GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Bullet info is: ").Append(UGameSettings::Instance->BulletDebugLines ? "ON" : "OFF"));
	}*/
}

void AFPSCharacter::On_BeginOverlap(class UPrimitiveComponent* OverlappedComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	//GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString("Begin overlap: "));

	//// check interactable component
	//if (OtherActor) {
	//	auto assetComponent = Cast<UAssetItemComponent>(OtherActor->GetComponentByClass(UAssetItemComponent::StaticClass()));
	//	if (assetComponent) {
	//		//GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString("OVERLAPPED: ").Append(assetComponent->Title));

	//		if (assetComponent->AutoInteractOnOverlap) {

	//			if (assetComponent->CanClimb) {
	//				this->IsNearClimbable = true;

	//				if (!this->IsOnClimbable) {
	//					this->IsOnClimbable = true;
	//					this->On_IsOnClimbableChange(false);
	//					this->GetCharacterMovement()->SetMovementMode(EMovementMode::MOVE_Flying);
	//				}
	//			}
	//		}
	//	}
	//}
}
void AFPSCharacter::On_EndOverlap(class UPrimitiveComponent* OverlappedComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	////GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString("End overlap"));
	//if (OtherActor) {
	//	auto assetComponent = Cast<UAssetItemComponent>(OtherActor->GetComponentByClass(UAssetItemComponent::StaticClass()));
	//	if (assetComponent) {
	//		//GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString("OVERLAPPED: ").Append(assetComponent->Title));

	//		if (assetComponent->AutoInteractOnOverlap) {
	//			if (assetComponent->CanClimb) {
	//				this->IsNearClimbable = false;
	//				this->IsOnClimbable = false;
	//				this->GetCharacterMovement()->SetMovementMode(EMovementMode::MOVE_Walking);

	//				GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Red, FString("IsNearClimbable,IsOnClimbable: false"));

	//				//if (this->IsOnClimbable) {
	//				//	/*bool prev = this->IsOnClimbable;
	//				//	this->IsOnClimbable = false;
	//				//	this->On_IsOnClimbableChange(prev);*/
	//				//	this->GetCharacterMovement()->SetMovementMode(EMovementMode::MOVE_Walking);
	//				//}
	//			}
	//		}
	//	}
	//}
}

UCameraComponent* AMOTHCharacter::GetCamera_Implementation()
{
	return NULL;
}

void AMOTHCharacter::LookForInteractable(bool force)
{
	////TODO: move skip to a timer
	//if (this->interactableSkip++ <= 3) {
	//	return;
	//}
	//this->interactableSkip = 0;

	bool unchanged = false;
	bool created = false;

	//// unset active look at item
	//auto camera = GetCamera();
	//if (camera) {
		//auto cam = GEngine->GetFirstLocalPlayerController(GetWorld())->PlayerCameraManager;
		//auto controller = Cast<APlayerController>(this->GetController());
		//auto cam = controller->PlayerCameraManager;

		//FCollisionQueryParams collision_params(FName(TEXT("InteractionLook")), true, this);
		//collision_params.bReturnPhysicalMaterial = true;

		//// ignore the current character or else we will hit weapons or build actors (should make a flag to ignore build mode here)
		//collision_params.AddIgnoredActor(this);

		//FCollisionObjectQueryParams object_params;
		//object_params.AddObjectTypesToQuery(ECC_WorldStatic);
		//object_params.AddObjectTypesToQuery(ECC_WorldDynamic);
		//object_params.AddObjectTypesToQuery(ECC_PhysicsBody);
		//object_params.AddObjectTypesToQuery(ECC_Destructible);
		//object_params.AddObjectTypesToQuery(ECC_EngineTraceChannel2);
		//object_params.AddObjectTypesToQuery(ECC_GameTraceChannel2);

		//FHitResult hit_result;

		//auto direction = camera->GetComponentRotation();
		//auto trace_start = camera->GetComponentLocation();
		//auto trace_end = trace_start + direction.RotateVector(FVector(this->InteractionDistance, 0.f, 0.f));

		//if (this->HasAuthority()) {
		//	DrawDebugLine(GetWorld(), trace_start, trace_end, FColor::Red, true, 40.f);
		//}
		//else {
		//	//DrawDebugLine(GetWorld(), trace_start, trace_end, FColor::Purple, true, 20.f);
		//}

		//DrawDebugLine(GetWorld(), trace_start, trace_end, FColor::Purple, true, 20.f);

		//if (GetWorld()->SweepSingleByObjectType(hit_result, trace_start, trace_end, FQuat(), object_params, FCollisionShape::MakeSphere(20.f), collision_params) && hit_result.IsValidBlockingHit())
	auto trace = this->Trace(FName(TEXT("InteractionLook")), LookForInteractableRadius, LookForInteractableTraceType);
	//if (GetWorld()->LineTraceSingleByObjectType(hit_result, trace_start, trace_end, object_params, collision_params) && hit_result.IsValidBlockingHit())
	if (trace.IsValidBlockingHit())
	{
		//trace_end = hit_result.ImpactPoint;

		//auto hit_actor = hit_result.GetActor();
		//if (hit_actor) {
		//	this->LookAtHitResult = hit_result;
		//	if (this->LookAtActor != hit_actor) {
		//		if (this->LookAtComponent) {
		//			this->LookAtComponent->OnFocusOut(this);
		//		}
		//		if (this->LookAtItem) {
		//			this->LookAtItem->OnFocusOut(this);
		//		}

		//		this->LookAtActor = hit_actor;

		//		//FHitInteraction interaction;
		//		this->LookAtInteraction = FHitInteraction();

		//		this->LookAtItem = UContentResolver::Instance->ResolveInteraction(EInteractionTrigger::Look, hit_result, this);

		//		if (this->LookAtComponent) {
		//			this->LookAtComponent->OnFocus(this);
		//		}
		//		if (this->LookAtItem) {
		//			this->LookAtItem->OnFocus(this);
		//			this->InteractableFocused();
		//		}
		//	}
		//	updated = true;
		//}
		if (!this->lookInProcess) {
			this->lookInProcess = true;
			//AsyncTask(ENamedThreads::GameThread, [this, hit_result]()
			//{

			auto hit_component = trace.GetComponent();

			bool is_owned_by_character = IsValid(Cast<ACharacter>(hit_component->GetOwner()));

			if (!is_owned_by_character && hit_component->GetOwner() && hit_component->GetOwner()->GetRootComponent()) {
				auto parent = hit_component->GetOwner()->GetRootComponent()->GetAttachParent();
				if (parent) {
					is_owned_by_character = IsValid(Cast<ACharacter>(parent->GetOwner()));
				}
			}

			//auto current_look_at_items = this->LookAtItems;

			if (hit_component && !is_owned_by_character) {
				auto instance_mesh_invalidated = IsValid(this->InstanceMeshReplicator) && this->InstanceMeshReplicator->LookAtInvalidate != this->InstanceMeshReplicator->LastLookAtInvalidate;
				auto look_at_invalidated = this->LookAtInvalidate != this->_lastLookAtInvalidate;
				auto look_at_item_invalidated = IsValid(this->LookAtItem) && this->LookAtItem->LookAtInvalidate != this->LookAtItem->LastLookAtInvalidate;

				if (force
					|| this->LookAtComponent != hit_component
					|| this->LookAtHitResult.Item != trace.Item
					|| look_at_item_invalidated
					|| look_at_invalidated
					|| instance_mesh_invalidated
					) {
					if (look_at_invalidated) {
						_lastLookAtInvalidate = LookAtInvalidate;
					}
					if (look_at_item_invalidated) {
						this->LookAtItem->LastLookAtInvalidate = this->LookAtItem->LookAtInvalidate;
					}
					if (instance_mesh_invalidated) {
						this->InstanceMeshReplicator->LastLookAtInvalidate = this->InstanceMeshReplicator->LookAtInvalidate;
					}

					this->LookAtHitResult = trace;
					this->LookAtComponent = hit_component;

					TArray<UItemComponent*> new_look_at_items;
					UItemComponent* new_item = NULL;
					UItemComponent* focused = NULL;
					UItemComponent* focused_fallback = NULL; // this allows the focus component to take preference over the first primary component found.

					auto trace_component = trace.Component.Get();

					auto components = UContentResolver::Instance->ResolveInteraction(EInteractionTrigger::Look, trace, this);
					if (components.Num() > 0) {
						//new_item = components[0];

						for (auto component : components) {
							bool component_applies = false;

							if (component->ActiveFocusRequirement == EFocusRequirement::Always) {
								focused = component;
							}

							//bool component_applies = component->IsPrimaryUIComponent || component->ApplyToAllMeshesInActor;
							//bool 

							/*if (!new_item) { removed as we only care about focus
								new_item = component;
							}*/

							if (component->FocusRequirement == EFocusRequirement::Always || component->FocusRequirement == EFocusRequirement::Legacy) {
								// the trace found a match. this is needed so for when changing from one primary component to another within the same actor.
								// all matches found with the trace are considered to be in focus, however, the component can decide if logic occurs selectively
								if (!component->HasFocus) {
									component->OnFocus(this);
								}
							}

							//// the trace found a match. this is needed so for when changing from one primary component to another within the same actor.
							//// all matches found with the trace are considered to be in focus, however, the component can decide if logic occurs selectively
							//if (!component->HasFocus) {
							//	component->OnFocus(this);
							//} not as accurate as first thought. we kind of need this to be selectively without multiple flags. its out of control

							new_look_at_items.Add(component);
							this->LookAtItems.Remove(component);

							// try to find the component that is really being looked at. this will become the primary component being looked at (LookAtItem)
							auto attachment = component->GetAttachParent();
							if (attachment) {
								if (trace_component == attachment) {
									//focused = component;
									//break; // no need for focus? currently bus etc arent getting loot components without removing the isprimaryflag (might be required yet)
									// ^^ yes we need this now. a component can have multiple itemcomponents that receive focus as they are a direct child.

									//if()

									/*if (component_applies) {
										focused = component;
									}*/
									if (component->ActiveFocusRequirement == EFocusRequirement::DirectFocus) {
										focused = component;
									}
									else if (component->ActiveFocusRequirement == EFocusRequirement::Legacy && (component->IsPrimaryUIComponent || component->ApplyToAllMeshesInActor)) {
										focused = component;
									}


									if (component->FocusRequirement == EFocusRequirement::DirectFocus) {
										// the trace found a match. this is needed so for when changing from one primary component to another within the same actor.
										// all matches found with the trace are considered to be in focus, however, the component can decide if logic occurs selectively
										if (!component->HasFocus) {
											component->OnFocus(this);
										}
									}
								}
							}

							/*if (component_applies && !focused && component->ApplyToAllMeshesInActor) {
								focused_fallback = component;
							}*/
						}
					}

					if (!IsValid(focused) && IsValid(focused_fallback)) {
						focused = focused_fallback;
					}
					if (IsValid(focused)) {
						new_item = focused;
					}

					if (this->LookAtItem != new_item) {
						for (auto old_ic : this->LookAtItems) {
							if (old_ic && old_ic->HasFocus) {
								old_ic->OnFocusOut(this);
							}
						}
						if (this->LookAtItem) {
							this->LookAtItem->HasActiveFocus = false;
							this->LookAtItem->RebuildInteractionTextForCurrentActor();
						}
						/*if (this->LookAtItem) {
							this->LookAtItem->OnFocusOut(this);
						}*/

						this->LookAtItem = new_item;
						this->LookAtItems = new_look_at_items;

						if (this->LookAtItem) {
							//this->LookAtItem->LastLookAtInvalidate = this->LookAtItem->LookAtInvalidate;

							this->LookAtItem->HasActiveFocus = true;
							//this->LookAtItem->OnFocus(this);
							this->InteractableFocused();
							this->LookAtItem->RebuildInteractionTextForCurrentActor();

							// ignore focus out due to the change
							created = true;
						}
					}
					else {
						// ignore focus out
						unchanged = true;

						/*if (!this->LookAtItem && !new_item) {
							auto fc = Cast<UMOTHFoliageInstanceStaticMeshComponent>(this->LookAtComponent);
							if (IsValid(fc)) {

							}
						}*/
					}
				}
				else {
					// ignore focus out
					unchanged = true;
				}
			}

			this->lookInProcess = false;
			//});
		}
	}
	//}

	if (!unchanged && !created) {
		/*if (this->LookAtComponent) {
			this->LookAtComponent->OnFocusOut(this);
		}*/
		for (auto old_ic : this->LookAtItems) {
			if (old_ic && old_ic->HasFocus) {
				old_ic->OnFocusOut(this);
			}
		}
		this->LookAtItems.Reset();
		/*if (this->LookAtItem) {
			this->LookAtItem->OnFocusOut(this);
		}*/

		//this->LookAtActor = NULL;
		this->LookAtComponent = NULL;

		if (this->LookAtItem) {
			this->LookAtItem->HasActiveFocus = false;
		}
		this->LookAtItem = NULL;
	}
}

//void AFPSCharacter::GiveHitLoot(FHitLoot hit_loot)
//{
//	//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("GiveHitLoot"));
//	this->OnGiveHitLoot(hit_loot);
//}

TArray<FItemData> AMOTHCharacter::TryFindSlotForItem(UItemContainer* container, UPARAM(ref) FItemData& item, bool allow_max_stack, float amount)
{
	auto res = UCommon::TryFindSlotForItem(container, item, allow_max_stack, this, amount);
	this->CalculateInventoryWeight();

	this->UpdateCurrentlyHeldItem();

	return res;
	//TArray<UItemWidget*> slots;
	//bool has_more = false;
	//auto wc_item = item->Clone(this); // ->Clone(this);   no need for a clone, if it really needs to be a clone the caller must do it

	//min_capacity = FMath::Max(collection.Num(), min_capacity);

	//// try find an existing stack
	//for (int slot = 0; slot < min_capacity; slot++) {
	//	auto tb_item = collection[slot]->ItemInstance;
	//	if (collection[slot]->ItemInstance && collection[slot]->ItemInstance->ItemID == wc_item->ItemID /*&& !collection[slot]->IsLocked*/) {
	//		float free_space = (allow_max_stack ? ITEM_MAX_STACK : tb_item->MaxStack) - tb_item->Stack;
	//		if (free_space > 0) {
	//			float deduction_amt = FMath::Min(free_space, wc_item->Stack);

	//			wc_item->Stack -= deduction_amt;
	//			tb_item->Stack += deduction_amt;

	//			collection[slot]->OnUpdated(collection, slot, false, deduction_amt);
	//			slots.Add(collection[slot]);
	//		}
	//	}
	//	if (wc_item->Stack <= 0) {
	//		// cancel the loop if we have consumed the stack
	//		break;
	//	}
	//}

	//if (wc_item->Stack > 0) {
	//	// else if we still have quantity to consume, then try to find a free slot
	//	for (int slot = 0; slot < min_capacity; slot++) {
	//		if (collection.Num() == slot || collection[slot]->ItemInstance == NULL || collection[slot]->ItemInstance->Stack <= 0 /*|| collection[slot]->ItemInstance->Thumbnail == NULL*/) {
	//			// needs a new slot created
	//			auto clone = wc_item->Clone(this);
	//			clone->MaxStack = allow_max_stack ? ITEM_MAX_STACK : clone->DefaultMaxStack; // restore the initial stack as this has now become a inventory item

	//			float stack = FMath::Min(clone->Stack, (allow_max_stack ? ITEM_MAX_STACK : clone->MaxStack));

	//			wc_item->Stack -= stack;
	//			clone->Stack = stack;

	//			collection[slot]->OnSetItem(clone);
	//			collection[slot]->OnUpdated(collection, slot, true, stack);
	//			slots.Add(collection[slot]);
	//		}
	//		if (wc_item->Stack <= 0) {
	//			// cancel the loop if we have consumed the stack
	//			break;
	//		}
	//	}
	//}

	//if (wc_item->Stack > 0) {
	//	// try to put into main inventory
	//	// else drop item ...
	//	//GEngine->AddOnScreenDebugMessage(-1, 10.0f, FColor::Magenta, FString::Printf(TEXT("Cannot fit into toolbelt: %f"), wc_item->Stack));

	//	//has_more = true;
	//}

	//item->Stack = wc_item->Stack;

	//return slots;
}

TArray<FItemData> AMOTHCharacter::TryFindSlotForItemByInventory(FString inventory_name, UPARAM(ref) FItemData& item, bool allow_max_stack, float amount)
{
	//if (widget->ItemContainerType == EItemContainerType::Player && widget->ItemContainerName == inventory_name)
	//{
	//	// item is already located here
	//	TArray<UItemWidget*> empty;
	//	return empty;
	//}
	if (inventory_name == "Toolbelt")
	{
		auto inv = this->TryGetContainerByName("Toolbelt 1");
		auto results = this->TryFindSlotForItem(inv, item, allow_max_stack, amount);

		if (item.Stack > 0) {
			inv = this->TryGetContainerByName("Inventory");
			results.Append(this->TryFindSlotForItem(inv, item, allow_max_stack, amount));
		}

		return results;
	}
	else {
		auto inv = this->TryGetContainerByName(inventory_name);
		return this->TryFindSlotForItem(inv, item, allow_max_stack, amount);
	}
}

//void AFPSCharacter::OnFindSlotForItem(const TArray<UItemWidget*> &slots, UItemInstance* item, FString ignore, bool allow_max_stack, bool show_notification)
//{
//
//}

//TArray<UItemWidget*> AFPSCharacter::TryFindSlotForItem(UItemInstance* item, TArray<UItemContainer*>& container_pool, FString ignore, bool allow_max_stack, bool show_notification)
//{
//	float initialQuantity = item->Stack;
//	TArray<UItemWidget*> slots;
//
//	this->OnFindSlotForItem(slots, item, ignore, allow_max_stack, show_notification);
//
//	for (int i = 0; i < container_pool.Num(); i++)
//	{
//		auto container = container_pool[i];
//		if (item->Stack > 0 && ignore != container->Name) {
//			auto slot_tb = AFPSCharacter::TryFindSlotForItem(container->UISlots, item, container->UISlots.Num(), allow_max_stack);
//			if (slot_tb.Num() > 0) {
//				slots.Append(slot_tb);
//			}
//		}
//
//	}
///*
//	if (item->Stack > 0 && ignore != TEXT("Toolbelt 1")) {
//		auto slot_tb = AFPSCharacter::TryFindSlotForItem(this->Inventories["Toolbelt 1"].Widgets, item, UGameSettings::Instance->ToolBeltSlots, allow_max_stack);
//		if (slot_tb.Num() > 0) {
//			slots.Append(slot_tb);
//		}
//	}
//	if (item->Stack > 0 && ignore != CHARACTER_INVENTORY_MAIN) {
//		auto slot_inv = AFPSCharacter::TryFindSlotForItem(this->Inventories[CHARACTER_INVENTORY_MAIN].Widgets, item, UGameSettings::Instance->InventorySlots, allow_max_stack);
//		if (slot_inv.Num() > 0) {
//			slots.Append(slot_inv);
//		}
//	}*/
//
//	if (show_notification && slots.Num() > 0) {
//		this->OnItemAdded(item, initialQuantity);
//	}
//
//	return slots;
//}

TArray<FItemData> AMOTHCharacter::TryFindSlotForItem(UPARAM(ref) FItemData& item, FString ignore, bool allow_max_stack, bool show_notification, float amount)
{
	float initialQuantity = item.Stack;
	TArray<FItemData> slots;
	UItemContainer* container = NULL;

	this->OnFindSlotForItem(slots, item, ignore, allow_max_stack, show_notification, amount);

	//auto inventories = this->GetInventories();

	if (item.Stack > 0 && ignore != TEXT("Toolbelt 1")) {
		container = this->TryGetContainerByName("Toolbelt 1");
		if (container) {
			auto slot_tb = this->TryFindSlotForItem(container, item, allow_max_stack, amount);
			if (slot_tb.Num() > 0) {
				slots.Append(slot_tb);
			}
		}
	}
	if (item.Stack > (amount == -1 ? 0 : initialQuantity - amount) && ignore != CHARACTER_INVENTORY_MAIN) {
		container = this->TryGetContainerByName(CHARACTER_INVENTORY_MAIN);
		if (container) {
			auto slot_inv = this->TryFindSlotForItem(container, item, allow_max_stack, amount);
			if (slot_inv.Num() > 0) {
				slots.Append(slot_inv);
			}
		}
	}

	if (show_notification && slots.Num() > 0) {
		this->OnItemAdded(item, initialQuantity);
	}

	return slots;
}

//void AMOTHCharacter::AddInventoryWidget(FString inventory_name, UItemInstance* widget)
//{
//	if (!this->Inventory.Contains(inventory_name))
//	{
//		//FCharacterInventoryWidget entry;
//		auto container = NewObject<UItemContainer>(this);
//		container->Name = inventory_name;
//		this->Inventory.Add(inventory_name, container);
//	}
//	this->Inventory[inventory_name]->Items.Add(widget);
//	widget->Container = this->Inventory[inventory_name];
//}

bool AMOTHCharacter::GiveItem(UPARAM(ref) FItemData& item, bool show_notification)
{
	auto slots = this->TryFindSlotForItem(item, TEXT(""), false, show_notification);
	if (item.Stack >= 0) {
		// drop on the ground
	}
	return item.Stack <= 0;
}

void AMOTHCharacter::UpdateCraftRecipes(UScrollBox* parent, bool is_queue_full) //UGridPanel* craft_queue)
{
	auto itemcache = GetWorld()->GetGameInstance<UGlobalGameInstance>()->ItemCache;
	/*bool is_queue_full = craft_queue->GetChildrenCount() > 0;
	if (craft_queue) {
		for (int i = 0; i < craft_queue->GetChildrenCount(); i++) {
			auto widget = Cast<UItemWidget>(craft_queue->GetChildAt(i));
			if (widget) {
				if (!widget) {
					is_queue_full = false;
					break;
				}
			}
		}
	}*/

	// find if URecipeWidget is the parent to the cra

	// no need to keep in sync, this array should never change (at present), so we only need to alter the enabled state
	if (parent) {
		for (int i = 0; i < parent->GetChildrenCount(); i++) {
			auto widget = Cast<URecipeWidget>(parent->GetChildAt(i));
			if (widget) {
				//auto item = widget->GetItemInstance();
				auto ingredients = this->TryFindIngredients(FItemData::GetIngredients(widget->RecipeItem.ItemID, itemcache));

				// do we have any ingredients for this widget?
				widget->IsRecipeEnabled = !is_queue_full && ingredients.IsFulfilled;

				// for each of the recipe widget's, find the correct slot and update its availability state
				auto slots = widget->GetSlots();
				//auto slots = widget->GetContainedItems();
				for (int s = 0; s < slots.Num(); s++) {
					//auto slot_item = slots[s];
					auto slot = slots[s];
					auto slot_item = slot->GetItemInstance();

					if (slot_item.ItemID > 0) {
						// find it's result
						for (int r = 0; r < ingredients.Results.Num(); r++)
						{
							if (ingredients.Results[r].Ingredient.ItemID == slot_item.ItemID) {

								//GEngine->AddOnScreenDebugMessage(-1, 10.0f, FColor::Magenta, FString::Printf(TEXT("%s %f/%f"), *slot->ItemInstance->DisplayName, ingredients.Results[r].Available, slot->ItemInstance->Stack));

								if (ingredients.Results[r].Available >= slot_item.Stack)
								{
									slot->State = EItemWidgetState::Available;
								}
								else {
									slot->State = EItemWidgetState::NotAvailable;
								}
							}
						}
					}
				}
			}
		}
	}
}

TArray<FItemData> AMOTHCharacter::FindItemsWithinInventory(FString item_term, FString inventory_name)
{
	FString item_term_lowered = item_term.ToLower();

	TArray<FItemData> results;
	auto container = this->TryGetContainerByName(inventory_name);
	if (IsValid(container))
	{
		for (int i = 0; i < container->Items.Num(); i++) {
			auto widget = container->Items[i];

			if (/*widget &&*/ widget.DisplayName.ToLower().Contains(item_term_lowered))
			{
				results.Add(widget);
			}
		}
	}
	return results;
}

void AMOTHCharacter::SetSelectedWidget_Implementation(USelectableWidget* widget)
{
	this->SelectedWidget = widget;
}

//bool AMOTHCharacter::IsHUDVisible_Implementation()
//{
//	return this->HUDIsVisible;
//}

float AMOTHCharacter::CalculateInventoryWeightByName(FString inventory_name)
{
	float weight = 0.f;

	auto container = this->TryGetContainerByName(inventory_name);
	if (IsValid(container))
	{
		weight = container->CalculateWeight();
		/*for (int i = 0; i < inv->Slots.Num(); i++) {
			auto widget = inv->Slots[i];

			if (widget->ItemInstance)
			{
				weight += widget->ItemInstance->Weight * widget->ItemInstance->Stack;
			}
		}*/
	}

	return weight;
}

//template< class T : public FTakeFromInventoryRequest >
//bool AFPSCharacter::TryTakeFromInventory(const TArray<T> requests, bool(*Process)(const TArray<UItemWidget*> results, const TArray<T> requests))
//{
//	TArray<UItemWidget*> required;
//
//	//ensure the upgrade can be fulfilled 
//	bool can_fulfill = true;
//	for (int i = 0; i < requests.Num(); i++)
//	{
//		auto request = requests[i];
//		if (request.RequiredAmount > 0.f) {
//			// is in inventory?
//
//			TArray<UItemWidget*> slots;
//			float available = 0.f;
//
//			slots = this->TryFindItemByInventory(this->Inventories[CHARACTER_INVENTORY_MAIN].Widgets, request.RequiredItemID, available);
//
//			if (slots.Num() > 0) {
//				required.Append(slots);
//			}
//
//			if (available < request.RequiredAmount) { // keep looking for more
//				for (int t = 0; t < UGameSettings::Instance->ToolBelts; t++) {
//					FString toolbelt = (CHARACTER_INVENTORY_TOOLBELT);
//					toolbelt = toolbelt.Append(FString::FromInt(t + 1));
//
//					auto inventory = this->Inventories.Find(toolbelt);
//					if (inventory) {
//						slots = this->TryFindItemByInventory(inventory->Widgets, request.RequiredItemID, available);
//
//						if (slots.Num() > 0) {
//							required.Append(slots);
//						}
//
//						if (available >= request.RequiredAmount) { // if there is enough, no need to continue looking
//							break;
//						}
//					}
//				}
//			}
//
//			// we are done looking for this requirement, if there is enough we can no longer proceed
//			if (available < request.RequiredAmount) {
//				can_fulfill = false;
//				break;
//			}
//		}
//	}
//
//	if (can_fulfill) {
//		if (Process(required, requests)) {
//			// deduct
//			for (int i = 0; i < requests.Num(); i++)
//			{
//				auto request = requests[i];
//				float remaining = request.RequiredAmount;
//
//				for (int x = 0; x < required.Num(); x++) {
//					auto slot = required[x];
//					if (slot->ItemInstance->ItemID == request.RequiredItemID) {
//						float amount_to_deduct = FMath::Min(slot->ItemInstance->Stack, remaining);
//
//						slot->ItemInstance->Stack -= amount_to_deduct;
//						remaining -= amount_to_deduct;
//
//						if (remaining <= 0.f) {
//							break;
//						}
//					}
//				}
//			}
//
//		}
//	}
//
//	return false;
//}

bool AMOTHCharacter::GiveItemByID(int itemID, float quantity, bool show_notification)
{
	auto gameinstance = this->GetWorld()->GetGameInstance<UGlobalGameInstance>();
	if (gameinstance) {
		auto instance = gameinstance->ItemCache;
		auto item = instance->GetItemByID(itemID);
		//auto item = UContentResolver::Instance->ResolveItemByID(itemID);
		if (item.ItemID > 0) {
			item.Stack = quantity;
			return this->GiveItem(item, show_notification);
		}
		//return false;
	}
	return false;
}

//bool AFPSCharacter::OnInteractTriggerPressed()
//{
//	return false;
//}
//
//bool AFPSCharacter::OnInteractTriggerReleased_Implementation()
//{
//	return false;
//}

TArray<FItemData> AMOTHCharacter::GetCraftableRecipes()
{
	TArray<FItemData> recipes;

	auto gameInstance = GetWorld()->GetGameInstance<UGlobalGameInstance>();
	if (gameInstance) {
		for (int i = 0; i < gameInstance->Recipes.Num(); i++)
		{
			auto recipe = gameInstance->Recipes[i];
			auto known = FItemData::GetIngredients(recipe.ItemID, gameInstance->ItemCache);
			auto ingredients = this->TryFindIngredients(known);

			if (!ingredients.IsFulfilled) {
				if (GEngine) {
					//GEngine->AddOnScreenDebugMessage(-1, 10.0f, FColor::Magenta, FString::Printf(TEXT("Not enough ingredients for %s"), *recipe->DisplayName));
				}
			}
			//else {
			//	//GEngine->AddOnScreenDebugMessage(-1, 10.0f, FColor::Magenta, TEXT(""));
			//}

			recipes.Add(recipe);
		}
	}

	return recipes;
}

TArray<UItemComponent*> AMOTHCharacter::GetFoliageFromRequest(FResolutionRequest request, bool allowInitialisation)
{
	//GEngine->AddOnScreenDebugMessage(-1, 3.0f, FColor::Green, TEXT("Stuff %i"));
	TArray<UItemComponent*> OutItemComponents;
	bool any = false;
	/*auto ism = Cast<UInstancedStaticMeshComponent>(request.hit_result.Component);
	if (!IsValid(ism)) {
		auto ca = Cast< AMothInstanceMeshChunkActor>(request.hit_result.Actor);
		if (IsValid(ca)) {
			auto component = ca->GetChunkComponent();
			ism = Cast<UInstancedStaticMeshComponent>(component);
		}
	}*/
	auto ism = UCommon::GetFoliageComponent(request.hit_result);
	if (IsValid(ism)) {
		int index = request.hit_result.Item;
		if (ism->PerInstanceSMData.IsValidIndex(index)) {

			//auto game_instance = this->GetWorld()->GetGameInstance<UGlobalGameInstance>();
			//if (IsValid(game_instance) && !IsValid(game_instance->InstanceMeshReplicator)) {
			if (!IsValid(this->InstanceMeshReplicator)) {
				for (TActorIterator<AInstanceMeshReplicator> ActorItr(GetWorld()); ActorItr; ++ActorItr)
				{
					this->InstanceMeshReplicator = Cast<AInstanceMeshReplicator>(*ActorItr);
					break;
				}
			}
			//if (IsValid(game_instance) && IsValid(game_instance->InstanceMeshReplicator)) {
			if (IsValid(this->InstanceMeshReplicator)) {
				auto actor = ism->GetOwner();
				/*FString foliage_ID = actor->GetName()
					.Append("_").Append(ism->GetName())
					.Append("_").Append(FString::FromInt(index));*/
				FString foliage_ID = UCommon::GetFoliageID(request.hit_result);

				//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Found instance mesh, looking up component set using ID: ").Append(foliage_ID));

				FInstanceMeshComponentEntry data;
				auto has_entry = this->InstanceMeshReplicator->Find(foliage_ID, data);
				if (has_entry) {
					//auto data = *entry;
					if (IsValid(data.Component)) { // GetName() to compare network replicated items
						auto entry_name = data.Component->GetName();
						auto target_name = ism->GetName();
						if (entry_name == target_name && data.InstanceID == index) { // GetName() to compare network replicated items
							for (auto component : data.Components) {
								auto ic = Cast<UItemComponent>(component);
								if (IsValid(ic)) {
									OutItemComponents.Add(ic);
									any = true;
								}
							}
						}
					}
					else {
						//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Instance Mesh failed lookup: detected ISM component lookup mismatch. this is not a normal error, something is usually wrong."));
					}
				}
				else if (allowInitialisation) {
					//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("New Instance Mesh registration: ").Append(foliage_ID));

					FInstanceMeshComponentEntry new_entry = FInstanceMeshComponentEntry(ism, index, foliage_ID);

					//if (game_instance->InstanceMeshReplicator->HasAuthority()) {
					if (this->InstanceMeshReplicator->HasAuthority()) {
						UClass* destruction_class = UContentResolver::Instance->ResolveBlueprint("Blueprint'/Game/Blueprints/Objects/BP_FoliageDestructionComponent.BP_FoliageDestructionComponent'");
						if (destruction_class) {
							auto cmp = NewObject<USceneComponent>(this->InstanceMeshReplicator, destruction_class);
							if (IsValid(cmp)) {

								if (cmp->GetClass()->ImplementsInterface(UInstanceMeshReceiver::StaticClass()))
								{
									//Don't call your functions directly, use the 'Execute_' prefix
									//the Execute_ function is generated on compile
									//you may need to compile before these functions will appear
									IInstanceMeshReceiver::Execute_OnRegistering(cmp, new_entry, request);
								}

								cmp->RegisterComponent();
								new_entry.Components.Add(cmp);

								auto ic = Cast<UItemComponent>(cmp);
								if (IsValid(ic)) {
									OutItemComponents.Add(ic);
									any = true;

									/*auto moth_foliage_component = Cast<UMOTHFoliageInstanceStaticMeshComponent>(ism);
									if (IsValid(moth_foliage_component)) {

										if (moth_foliage_component->SetHealthBasedOnScale) {
											FTransform transform;
											if (moth_foliage_component->GetInstanceTransform(index, transform, true)) {
												auto mass = ism->GetMass();
												auto mass_scale = ism->GetMassScale();
												auto mass_x_scale = mass * FVector::Distance(transform.GetScale3D(), FVector(1));

												ic->Health
											}
										}

									}*/

									// new component should now be ready for resolution
									// however the characters trace is still looking at
									// the foliage component and instance, it has no idea
									// something has changed, so we invalidate to inform
									this->InvalidateLookItem(true);
								}
							}
						}
						else {
							//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Instance Mesh lookup warning: No destruction class."));
						}

						this->InstanceMeshReplicator->Add(new_entry);
					}
					else {
						//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("No authority to register foliage."));
					}
				}
			}
		}
		else {
			//GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, FString("Instance Mesh failed lookup"));
		}
	}

	/*if (OutItemComponents.Num() > 0) {
		this->InvalidateLookItem();
	}*/

	return OutItemComponents;
}

void AMOTHCharacter::RequestFoliageInteraction_Implementation(FResolutionRequest request)
{
	GEngine->AddOnScreenDebugMessage(-1, 3.0f, FColor::Green, TEXT("Stuff %i"));

	this->GetFoliageFromRequest(request);
	this->InvalidateLookItem(true);

	/*if (request.trigger == EInteractionTrigger::Pickup) {

	}*/
}

void AMOTHCharacter::RequestFoliageInteractionNetwork_Implementation(FResolutionRequest request)
{
	RequestFoliageInteraction(request);
}

bool AMOTHCharacter::RequestFoliageInteractionNetwork_Validate(FResolutionRequest request)
{
	return true;
}